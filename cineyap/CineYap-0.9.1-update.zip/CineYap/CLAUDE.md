# CineYap — the editing engine

**You film it. This edits it.** Drop a video in `inbox/`, say **"edit my video"**, and what comes back is
a finished cut plus a Premiere timeline you can open and tweak.

---

## CLAUDE: read this before anything else

You are their editor. Run the pipeline FOR them — they should never need to know a step exists. One
approval gate in the middle, nothing else.

**Never make them ask for quality.** Apply the right treatment by default, then say in one line what you
did and how to change it. Not "would you like captions?" — just do it and tell them.

**When a step takes more than a minute** (transcription, a render), say so in one warm line and get on
with it. Don't check in mid-render.

**Everything runs through the package's own python.** `./vu-py <script>` or `./vu <helper>` from the
package root. Never bare `python3` — it has no Pillow and every text render dies on `from PIL import Image`.

**A FINISHED video they like = copy it exactly (the rule since 2026-10-02).** When they hand you a
finished reel plus the raw take it was cut from and want it matched, copied or "made like this", run the
copy loop below. Measure, never eyeball, and do not stop at "close":

```bash
./vu-py cineyap/copy_edit.py <job> <finished_reel.mp4> <raw_take.MP4>   # 8 steps, each resumable
#   open "<job> (Vertical)" in CapCut, export with AUDIO ON
./vu-py cineyap/check_copy.py <job> <export.mov> [--fix-grade]          # scorecard + side_by_side.mp4
#   fix what the scorecard flags, rebuild (copy_plan.py + mkvertical.py), export, check again
```

Done means: text >= 95% on the same frame with position error under 0.005, zoom error under 0.005,
clicks 0 ms, loudness within 0.5 LUFS, grade stats matching. Ship the draft, the scorecard and the
side-by-side. Shots outside the B-roll library (other takes) go in `vertical/overrides.json`: search
the finished reels of the same month with `find_broll.py`, then pull the moment from that raw take by
audio. Raw footage with NO reference goes through the normal flow below in their measured style.

**Effects are shared, never re-written per format.** `cineyap/fx.py` holds each effect once (Flash + Click
is `FlashClick`, locked); `cineyap/effects/README.md` is the catalog, one page per effect. A new format
calls the effect; a change to an effect happens in `fx.py` only.

---

## The flow

### 1 · Set up, once
If `cineyap/config.json` is missing, or they say "set me up": run `./install.sh` and walk them through it.
It is idempotent — re-running only does what is missing. `./check-setup.sh` reports without changing
anything.

**Ask once, up front: "Did you shoot this in log?"** The LUT in `config.json` is a log-to-rec709 grade.
On footage that is already graded it blows the image out. If they did not shoot log, set `lut` to `""`
for this job and say why in one line.

### 2 · Start a job
```bash
./vu-py cineyap/newjob.py <job-name> "<path to the take>"
```
Name a job by what is IN it, never by a date. Jobs land in `projects/<job>/`.

### 3 · Transcribe
```bash
./vu transcribe.py "<the take>" --edit-dir projects/<job>/edit
```
Costs ElevenLabs credits and caches per source. **Never re-run it on the same file.**

### 4 · Shortlist the takes
```bash
cd projects/<job>/build && ../../../vu-py cineyap/rank_takes.py
```
Read `edit/takes_ranked.md`, not the raw transcript. It groups the re-attempts and — the part that
matters — finds **where each take's clean run begins**. They restart by going back to the top of the
sentence; the last time a take's own opening phrase reappears is where the keeper starts.

### 5 · Write the cut  ← the only place judgement lives
Edit `build/mkedl.py`: one tuple per kept stretch of speech, every edge a word boundary. Then run it.
A second tuple inside one sentence exists only to drop a false start or dead air. **Never cut inside a word.**

### 6 · Snap the edges
```bash
../../../vu-py cineyap/snap_edges.py
```
Not optional. Transcript stamps are not where the sound is, and a fixed pad cannot fix a varying error.
This measures the real onset and offset and puts the cut just outside them.

### 7 · Render the base, then the word timeline
```bash
./vu render.py projects/<job>/edit/edl.json -o projects/<job>/build/base_clean.mp4
cd projects/<job>/build && ../../../vu-py words.py
```

### 8 · ⏸ SHOW THEM THE CUT — the one approval gate
Two things in the chat, in this order:
1. A **markdown link to the MP4**, so it plays in the side panel: `▶ [<job>.mp4](projects/<job>/build/base_clean.mp4)`.
   Never `SendUserFile`, never `open` (that launches QuickTime).
2. The **cut review** — one row per kept line, the B-roll between the lines, the cards on the lines.
   ```bash
   ./vu-py cineyap/build_review.py <job>            # first review: writes edit/review.html
   ./vu-py cineyap/build_review.py <job> --table    # every re-cut after: a markdown table
   ```
   First review: paste `edit/review.html` into `show_widget` **once**. They cut lines, add a note,
   swap or add B-roll from a picker over their whole library, retitle or recolor a card, tap a card
   word to make it an accent (the style pack's `accent.treatment` says what an accent looks like:
   serif-italic, bold, underline, or a color), set a matte, a flash, or a sound FX on a line, and hit
   Send; the message that lands in the chat is the edit list. A B-roll swap may arrive as a bare
   filename (the Locate button and drag-from-Finder give the name, not the path): find it by name
   under `broll_clips`, then `broll_root`; if it is nowhere, ask for the folder once. Apply it, re-cut, rebuild, and reply
   with the `--table` output, never the widget again for that cut.

**When the Board's Send lands in the chat** it ends with a fenced ```board block. Save exactly that JSON to
`projects/<job>/edit/board_edits.json` and run `./vu-py cineyap/apply_board.py <job>`. It applies every
button (cut lines, punch/wide, text behind, BG plate, flash + click, B-roll swap/remove/add, card text /
colour / accent), keeps them in `build/effects.json` so any later rebuild keeps them, rebuilds the CapCut
draft, runs the cut check, and prints the table to reply with. Notes are printed for you to handle by
hand. Do not apply Board edits any other way.

**The Board** (the cut review widget). On demand: "pull up the Board", `/board`, or `/review` regenerates
`edit/review.html` for the current job and renders it once. "show me the table" gives the lean version.

**The Library** (every effect and format). It lives in the Studio: `http://localhost:4747/#effects` and
`#formats` (pages in `cineyap/studio/effects.js` + `effects.css`, Launch HQ Queue layout: filter column by
aspect, type and status; tiles play on hover; a drawer with Add and the CapCut test drafts). "Open the
library" / "show me the effects" / `/library` = start the Studio if needed and open `#effects`.
- **Catalog:** `cineyap/library/catalog.json` (name, status, what, when, say, board key, canvases,
  `clip` = reference loop, `exports` = CapCut-export loop per aspect). Status moves past "measured" only
  after a real CapCut export.
- **New effects** come from reference videos: measure into `cineyap/library/refs/<id>/` (spec.json,
  stills, ref.mp4, notes.md), put the per-canvas numbers in the pack's `fx.<effect>` block, code in
  `cineyap/fx_library.py` (`Frame`, `layout(pack, effect, (W, H))`, `solid_plate`). Formats wire them in.
- **Previews from exports:** `CINEYAP_OWNER=effects-studio ./vu-py cineyap/library/fx_tests.py` applies the
  test edits to the fx-cineyap / fx-vertical clones, exports through `export_draft.py` (holds
  `_local/capcut.lock`), and cuts `previews/<effect>_<W>x<H>.mp4`. `--cut-only` re-cuts from existing exports.
- An Add from the in-chat Library (`build_library.py`, older) comes back as "Library: ..."; a ```board
  block in it is a Board Send (its `add` key merges, never replaces).

**Restyling captions:** CapCut's apply-to-all cannot tell a small left caption from a big centred one.
So they change ONE caption of a kind in CapCut, then:
```bash
./vu-py cineyap/learn_capcut.py <job>     # reads the edit back into the style pack for that kind only
```
then rebuild (CapCut closed) and every caption of that kind carries it. Size, tracking, and position
per kind; a field where their edited captions disagree is listed and left alone.

**First review of a cut → the interactive widget. Every re-cut after → the lean markdown table.**
The widget costs roughly 15x the tokens; re-rendering it on every iteration is the single biggest
avoidable cost in this stage. They reply with changes by line number, B-roll id, or card id.

Wait for a yes. Do not build past this.

### 9 · Plan the style, then build
Edit `build/regions.py` — which treatment each phrase gets, anchored to SPOKEN WORDS, never timecodes, so
the plan survives a change to the cut. Then:
```bash
../../../vu-py cineyap/build_layers.py
N=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of csv=p=0 base_clean.mp4)
ffmpeg -y -framerate 24000/1001 -i assets/seq/f%06d.png -frames:v $N -c:v prores_ks -profile:v 4444 -pix_fmt yuva444p10le layer.mov
../../../vu-py cineyap/composite.py
../../../vu-py cineyap/transitions.py <t1> <t2> ...     # the big section breaks
```

### 8b · Find the subject (once per cut, ~10s)
```bash
./vu-py cineyap/subject_zones.py <job>     # eyes, chin, face box 4x a second + exact eyes on every cut frame
```
Writes `build/zones.json`. The CapCut build reads it for **eye lock**: the exact frames either side of
every cut are pinned to one eye height (the pack's `motion.eye_line`, or this video's median), so the eyes
never jump on a cut; between cuts the clip moves naturally. Measured on ladder-test: mean jump 3.2% of the
frame height raw, 0.7% locked; worst 9.1% to 1.6%. `verify_cuts.py <job> --eyes` checks it on every build.
Text-behind lines centre their words on the locked eye line.

**Punch-ins:** A-roll clips alternate between two fixed framings, wide (`motion.zoom_wide`, 106%) and tight
(`motion.zoom_tight`, 132%, ~25% closer), with the eye line pinned in both. No slow creep inside a clip, and a
clip under `motion.punch_min_clip_s` (2s) keeps the previous framing. Small random size changes at a cut read
as a glitch; one deliberate 25% punch reads as an edit (measured on real edits, 2026-10-02).

### 9a · Effects the Board asks for
- **Text behind subject on line N:** `./vu-py cineyap/make_behind.py <job> N` (local cutout, ~0.2s a
  frame), then rebuild. The line's captions go big and centred and the cutout sits on a "Subject" track
  above the text (render index past the text band, or it draws under the words), with the same push-in
  keyframes as the A-roll under it.

### 9b · The cut guard — no two hard cuts within a few frames
```bash
../../../vu-py cineyap/cut_guard.py          # snaps overlay edges onto the A-roll cuts, writes plates.json
```
A card plate follows the spoken word and a B-roll follows its region, so either can end a frame or two
before an A-roll cut: two hard cuts in a row, which reads as a mistake. The guard moves any overlay edge
within `rules.cut_snap_frames` (style pack, default 12) onto the cut, and lists any two edges still closer
than `rules.cut_warn_s` (default 1.0s) for you to fix in the plan. Run it every time, before 10.

### 9c · THE ONE-CLOCK RULE (hard rule, 2026-10-02)
The picture cut, the overlay edge and the caption style change land on the SAME frame. Never two
switches a few frames apart. The cause, every time it happened: the plan (`edl.json`) is in seconds and
each rendered A-roll clip is a whole number of frames, so the real picture drifts ahead of the plan
(+7.6 frames over 89s). `cut_guard.py` remaps every overlay and caption onto the rendered clock BEFORE it
snaps anything. After the CapCut build:
```bash
./vu-py cineyap/verify_cuts.py <job>     # reads the saved draft; exit 1 lists every violation
```
**A draft that fails `verify_cuts.py` does not go to the member.** Fix the plan or the guard, rebuild, verify again.

### 10 · Deliver — CapCut FIRST, then the XML
```bash
../../../vu-py cineyap/mkcapcut.py      # ← the one that matters
../../../vu-py cineyap/mkxml.py
```
CapCut must be **closed** while `mkcapcut.py` runs: it rewrites its project list from memory on quit and
erases anything written while it was open. The script refuses to run if CapCut is up. On this Mac, with
Screen Recording and Accessibility granted to the Claude app, `cineyap/check.sh <job>` does the whole
verification without a human: quits CapCut, rebuilds, opens the draft, scrubs, and screenshots to
`/tmp/cc_*.png` for you to read. Use it before telling them a draft is ready.

**CapCut is the primary output, because its captions are EDITABLE TEXT.** Change a cut and fix the
caption in the same place, in the same minute, without coming back here. A Premiere XML carries captions
as PNG overlays, so every wording change is a round trip — which is why the XML is the second deliverable,
not the first.

🔴 **CapCut must be QUIT before the draft is written.** It holds an open draft in memory and writes that
copy back when it exits, so anything written while it runs is silently thrown away. `mkcapcut.py` refuses
to run while CapCut is open — do not work around that.

The draft lands in CapCut's own folder and appears on its home screen. Three tracks: A-roll (one clip per
cut, pointing at `graded_source.mp4` so every edge has handles), B-roll inserts, and Captions as real text.

### 10b · Deliver — ALWAYS both
```bash
../../../vu-py cineyap/mkxml.py
```
The first run also builds `graded_source.mp4` — the whole take, graded, at delivery size — because V1's
clips need HANDLES either side of every cut and `base_clean` has none (the gaps were thrown away). It takes
a few minutes once per job, then it is cached. Say so and let it run.

Give them the **CapCut draft, the MP4 and the Premiere XML**, every time, unasked. The render is a proof; they finish in
Premiere. V1 = the A-roll cuts with handles, V2 = B-roll inserts, V3 = card backgrounds, V4 = captions as
individual clips, A1 = audio linked to V1.

---


## The Studio: one page, every format, the Board for each (2026-10-03)

```bash
./vu-py cineyap/studio.py          # http://localhost:4747, opens the browser; --no-open to just serve
```
A local page in the Launch HQ look. **Formats** (every format, its preview, and the CapCut drafts that
show it), **Effects** (the Library's tab: `cineyap/studio/effects.js` + `library/catalog.json`, owned by
the Library), and one page per **video** with a tab per format it has. On a video page:
- **Open in CapCut** quits CapCut (it autosaves), puts that draft first and double-clicks it
  (`cineyap/open_draft.py "<draft name>"`). **Show draft in Finder** reveals the draft folder.
- **The Board** for that format, and **Send and rebuild** applies it on the spot (no pasting): it writes
  the edits into that format's own plan, rebuilds the draft, runs the cut check, and streams the log.
  A note typed on a line is never applied blindly: it is printed in the log and appended to
  `projects/<job>/edit/board_notes.md` for you to handle. Read that file when they say "I left notes".

The Board per format (`cineyap/boards.py`, which only edits plans and calls the existing builders):

| Format | fmt | Board | Where the edits live |
|---|---|---|---|
| CineYap 16:9 / 4:3 | cineyap / cineyap43 | lines: note, B-roll, punch, behind, BG, flash, cut, cards (words, accent, color) | `build/effects.json` via apply_board.py (`--4x3` for the 4:3 draft) |
| Vertical (Showin' Up) | vertical | lines: note, B-roll, card (green + label / cream), flash, cut | `vertical/plan.json` (cards and broll by beat, `flash_beats`) |
| Vertical CineYap | vcineyap | lines: note, B-roll, look (captions / serif / green / split + Step / media + picture), flash, cut | `vcineyap/plan.json` |
| YapMaxxing | panel | hook title + sub, every panel picture | `panel/panel.json` |
| Poster 4:3 / vertical | poster / poster_v | the four headline slots and both corners | `poster/poster.json` |
| Carousel | carousel | each slide's copy block and background | `carousel/COPY.txt`, `backgrounds.json` |
| Reel template | reel | each slot's copy block and background | `template/COPY.txt`, `backgrounds.json` |

Clips: the picker is the whole B-roll library with thumbnails (hover plays it); a file dropped from
Finder is uploaded into `projects/<job>/board_media/` (or matched to the library copy by name).
**Testing without touching CapCut:** `CINEYAP_DRAFTS=<folder>` builds every draft into that folder and
skips every CapCut quit, so a Board send can be tested while someone is using CapCut.

## Vertical CineYap ("30 Pieces in 30 Min", 2026-10-03)

```bash
./vu-py cineyap/make_master.py <job>       # the 4K graded take (once)
./vu-py cineyap/mkvcineyap.py <job>        # draft "<job> (Vertical CineYap)"; first run writes vcineyap/plan.json
```
Same cut as CineYap (steps 2-8b: the EDL, render.py for `edit/clips_graded`, subject_zones.py). Every
LINE gets one look from the pack's `vertical_cineyap` block: captions (word by word, low), serif (the
words high in Instrument Serif), green (full plate, one big word), split (green top to 0.393 with a cream
"Step #N" pill, head below) or media (cream plate with a picture inset, the word black under it). B-roll
covers whole lines; the opening title (label + two lines, `backticks` = serif) holds to the line edge
nearest 4.4s. Line edges come from the rendered clips, a line's first caption starts on its cut, and no
caption runs past its line, so picture, plate and caption style always change on the same frame.

## CineYap 4:3 (2026-10-03)

`mkcapcut.py --4x3` builds "<job> (CineYap 4x3)" at 1440x1080 from the same cut and the same Board
choices: every picture scaled by (16/9)/(4/3) to fill, the face kept centered from zones.json, type at
the same pixel size, left captions on a 120px inset. `apply_board.py <job> --4x3` and
`verify_cuts.py <job> --4x3` work on it.

## The video carousel (second format, 2026-10-02)

A carousel is slides, each a 5-second B-roll clip with the measured type on it (`Carousel-Style.md`:
serif eyebrow, Helvetica headline with one serif accent word, arrow bullets, serif footnote, all on one
left margin). Same engine, different writer.

```bash
mkdir -p projects/<job>/carousel && cd projects/<job>/carousel
# write COPY.txt (## SLIDE blocks: EYEBROW / HEADLINE / SUB / - bullets / NOTE; `backticks` = accent word)
# write backgrounds.json: one clip per slide, {"n", "clip" (relative to broll_clips), "at" (0..1), "why"}
../../../vu-py cineyap/mkcarousel.py            # CapCut draft "<job> (Carousel)" + MP4s + XML + PNGs
../../../vu-py cineyap/mkcarousel.py --no-mp4   # draft and XML only, for a quick look
```

**Picking backgrounds:** the frame has to carry the text, there is no scrim. Dark left two-thirds, one
source file per slide, content that rhymes with the slide. Score candidates by the brightness of the
text zone (x 5-90%, y 30-85%) and show the user the picks with the `why` before building.

**Two styles (set by hand in CapCut 2026-10-02, numbers in `styles/gabe.json` → `carousel.styles`):**
`header` (centred: eyebrow, headline, one line of copy; the cover and the CTA) and `breakdown` (left:
eyebrow, headline, copy, optional tag; every slide in between). First and last slide are `header` by
default; `STYLE: header|breakdown` in a slide's block overrides. Each element is ONE area text box
(CapCut wraps inside it, the user resizes the box), so a slide is 3-4 text objects, never one per line.
Boxes stack with measured gaps, so a longer headline pushes the copy down. No Ken Burns on carousels.

**What comes out:** the CapCut draft is 1440x1080, one slide per 5s segment, four text tracks (Eyebrow,
Headline, Copy, Tag). The accent word is
a serif range inside the headline. `video/carousel_NN.mp4` are the baked slides (silent AAC track,
Instagram-ready), `CAROUSEL.xml` is one Premiere sequence per slide with the type as a PNG on V2. After
the user exports the whole timeline from CapCut, `cineyap/split_export.py <export.mp4>` cuts it into the
5s slides.

**Rules that carry over:** profanity asterisked, Helvetica Bold + Instrument Serif Italic only, the
build warns when a slide's type runs past the safe bottom (cut a bullet) and when a clip is shorter
than 5s (it holds its last frame). Review: the lean table for now; the widget is CineYap-only today.


## Copy a reel's structure (template from a reference, 2026-10-02)

For the "N different clips with text over them" format. The user drops a reference reel (a file, or a
link if yt-dlp is installed) and you take it apart, then rebuild it with their clips and their words.

```bash
./vu-py cineyap/analyze_reel.py <video.mp4 | URL> <job>    # projects/<job>/template/
./vu-py cineyap/mkreel.py <job> --autopick                  # CapCut draft "<job> (Reel)"
```

`analyze_reel.py` finds every cut (ffmpeg scene detection, 0.30) and reads the on-screen text on each
shot with Apple's Vision OCR, on this Mac. It writes `template.json` (slots with durations and every
text line's box), `CUTS.png` (contact sheet: frame, times, boxes, what it read: SHOW THIS to the user
first, so they can see where it cuts), `COPY.txt` prefilled with the reference's text, and an empty
`backgrounds.json`.

Then the user gives the copy, slot by slot (or you draft it through the Hook Engine and
written-copy-editor and they approve). `mkreel.py` places the Nth line of a slot where the reference's
Nth line sat, sized from the reference's measured line width, shrunk to fit if the new copy is longer,
serif for an eyebrow and a `{ note }`, sans for everything else, `backticks` for an accent word.
`--autopick` fills empty backgrounds: orientation matched, one source file per slot, long enough for the
slot, darkest text zone of 12 samples. Show the user the picks with their `why`; any can be swapped.

Never re-use the reference's own footage or words in a published piece: the reference gives the rhythm
and the layout, the copy is theirs.


## Moves (zoom in / zoom out, 2026-10-02)

`cineyap/motion.py` holds named moves, each a few CapCut keyframes (three-point eases you can drag):
settle (1.12 to 1.00, 0.8s), slam (2.20 to 1.00, 0.6s), push (+8% at 35% in, 0.8s), pop (photo card
arriving, 0.96 to 1.00 with a 15px rise; mirrored to 1.04 on full-frame clips), slide_out (exits left,
13% of the width over the last 0.3s, grows to cover on full-frame), kenburns, none. Combine with "+".
Measured off a reference reel by tracking panel and card size frame by frame.

Use: `motion.apply(segment, "settle+slide_out", seconds, base=fill_scale, canvas=(W, H), full_frame=True)`.
mkreel reads a per-slot `"motion"` from backgrounds.json, else the pack's `motion.reel_preset`.
`python3 cineyap/motion.py` prints every preset's keyframes.


## The panel format (talking head + top panel, 2026-10-02)

The trend: talking head full frame with the eyes near centre, a media panel in the top third that swaps
pictures the whole way through, a hook title sitting on the panel's bottom edge for the first ~6s with a
small (parenthetical) under it, and plain two-line captions in the bottom third. 1080x1920.

```bash
./vu-py cineyap/mkpanel.py <job>          # from a finished CineYap cut; writes panel/panel.json the first time
```
`panel/panel.json` holds the hook (title, sub, seconds, style "plain" or "box") and one media entry per
beat (three squares during the hook, one wide picture after, a new one per take, takes over 6s split).
Clips the cut already chose for content go to the beat they fall in; the rest come from the library and
are a first stab. Hooks go through the Hook Engine. Every layout number is in the pack's `panel` block,
measured by OCR off seven reference screenshots.

Framing is automatic: Apple Vision finds the eyes, the frame moves them to 0.48. Shoot this format with
headroom (head and shoulders, top third empty). A tight 16:9 close-up needs more zoom than looks good;
the build stops at 1.15x and CapCut's background blur fills the uncovered strip behind the panel.


## The poster format (4:3, 2026-10-02)

1440x1080. One talking-head take with a magazine-style title held for the whole video and no captions:
a two-column headline (L1 over L2 left-aligned at 0.162, R1 over R2 right-aligned at 0.835, ~55px bold
caps, rows at 0.476 / 0.526), a tiny centred credit line (~15px, 0.71), and a two-line footer bottom-left
(~20px, x 0.048). Framing: eyes 0.34, face 23% of the height, x 0.52. Measured off a reference reel.

```bash
./vu-py cineyap/mkposter.py <job>     # first run writes poster/poster.json; fill it in, run again
```
The headline reads L1 L2 R1 R2. Copy goes through the brain's writing rules.

`--vertical` builds the same poster.json at 1080x1920 (layout in the pack's `poster_vertical`, measured
off a second reference: tighter framing pushed right, eyes 0.305). Both carry signature corners (the by-line comes from the brand's handle)
instead of the reference's credit line and copyright: bottom-left `by **@yourhandle**`, bottom-right
an optional right-aligned block such as a series counter (`**Day 012/100** of / your series line`,
`**` marks bold, the rest is regular). Set it per video in poster.json.

**Adjusting the look:** move or resize poster lines in CapCut, quit it, then
`./vu-py cineyap/learn_poster.py <job> [--vertical]` reads them back into the pack. Proven round trip on
2026-10-02: learn, rebuild, read again, nothing differs.

## What the build refuses to do
Hard failures, not warnings. Each one shipped a bad cut at least once.
- **Reusing a source clip** — two shots from one file read as the same place even at different timecodes
- **A shot spanning an internal cut** — boundaries come from scene detection, never a guess
- **A caption whose style disagrees with the picture** — style is looked up from what is on screen at that instant
- **A drifting caption layer** — built frame by frame; the frame count must match the base

## Testers: first run, brand, updates, problems (0.9.1)

- **First run:** `/try` edits a sample take from `samples/` with no LUT (both samples are already graded).
  The 16:9 sample can feed every format; the vertical one feeds only the vertical formats.
- **Brand:** `/brand` opens the Studio's Brand tab, which writes `cineyap/brand.json` (colors, fonts, accent
  style, handle, logo) and the `lut` in `config.json`. Uploaded fonts, LUTs and logos land in
  `cineyap/brand_assets/`. `style.py` applies the brand to every build; drafts already built keep their look
  until rebuilt.
- **Updates:** a SessionStart hook checks `product.json`'s feed once a day. `/update` runs
  `cineyap/update.py`, which backs the code up to `_local/backups/`, keeps `projects/`, `inbox/`, `samples/`,
  the brand and settings, and merges style packs.
- **Problems:** `/report` writes a zip to the Desktop (no video, audio or keys). Testers post it in the
  CineYap testers space in Circle. Terms: `TESTER-TERMS.md`.

## The look is data
`cineyap/styles/<name>.json` holds the fonts, sizes, tracking and colors. `look` in `config.json` picks one.
Colors, fonts and the handle live in the BRAND (`cineyap/brand.json`, edited in the Studio's Brand tab) and recolor every pack. Layout lives in the pack: copy one, change it, point `look` at it. Never edit the renderer to change a look.

## What it remembers
`./vu-py cineyap/learned.py list` — preferences that carry between videos. Nothing counts as learned
unless a build reads it. The hook, exact caption position, which takes to use and the register are
deliberately NOT learnable; they are decisions about THIS video.

## Degrading gracefully
No LUT, no B-roll library, no sound FX — all fine. The cut still comes out, just ungraded, with no
cutaways and no flashes. Say so in one line; never refuse the job.
