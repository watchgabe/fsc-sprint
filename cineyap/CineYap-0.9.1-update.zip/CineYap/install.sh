#!/usr/bin/env bash
# install-video.sh — get the CineYap pipeline running on THIS machine.
#
# Detect, then skip. Nothing is asked that can be checked, so re-running it is cheap and safe.
# Every step is idempotent. Nothing here reaches the network except the pip install and, if you
# choose, the one-time font download.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
HERE="$ROOT/cineyap"
VENV="$ROOT/.venv"
ENVF="$ROOT/.env"
CFG="$HERE/config.json"
ok(){ printf '  \033[32mOK\033[0m   %s\n' "$1"; }
no(){ printf '  \033[31m!!\033[0m   %s\n' "$1"; }
ask(){ printf '\n%s\n' "$1"; printf '   > '; read -r REPLY; }

echo; echo "CineYap — setting up this machine"; echo

# ---------- 1. python ----------
PY=""
for c in python3.13 python3.12 python3.11 python3.10 python3; do
  command -v "$c" >/dev/null 2>&1 || continue
  V=$("$c" -c 'import sys;print(sys.version_info[0]*100+sys.version_info[1])' 2>/dev/null) || continue
  [ "${V:-0}" -ge 310 ] && { PY="$c"; break; }
done
[ -n "$PY" ] || { no "no python 3.10+ found. Install from python.org, then run this again."; exit 1; }
ok "python: $($PY --version 2>&1)"

# ---------- 2. venv + packages ----------
[ -d "$VENV" ] || { echo "  creating the venv…"; "$PY" -m venv "$VENV" || exit 1; }
if "$VENV/bin/python" -c "import PIL,numpy,scipy,requests,pycapcut,cv2,Vision,Quartz" 2>/dev/null; then
  ok "python packages (Pillow, numpy, scipy, requests, pycapcut, opencv, Apple Vision)"
else
  echo "  installing Pillow, numpy, scipy, requests, pycapcut, opencv, Apple Vision…"
  "$VENV/bin/pip" install -q --upgrade pip >/dev/null 2>&1
  "$VENV/bin/pip" install -q Pillow numpy scipy requests pycapcut opencv-python-headless pyobjc-framework-Vision pyobjc-framework-Quartz || { no "pip install failed"; exit 1; }
  ok "python packages installed"
fi

# ---------- 3. ffmpeg, and it MUST have libass ----------
if ! command -v ffmpeg >/dev/null 2>&1; then
  no "ffmpeg missing.  brew install ffmpeg      (then run this again)"
elif ffmpeg -hide_banner -filters 2>/dev/null | grep -q " subtitles "; then
  ok "ffmpeg has libass (captions can burn in)"
else
  no "ffmpeg is built WITHOUT libass, so burned captions will fail."
  echo "       Fix:  brew uninstall ffmpeg && brew install ffmpeg-full"
fi

# ---------- 3b. Node (text behind subject cuts the subject out with a local model via npx) ----------
if command -v npx >/dev/null 2>&1; then ok "Node $(node --version 2>/dev/null) (text behind subject works)"
else no "Node missing: everything works except text behind subject.  Install from nodejs.org, then run this again."; fi
[ -f "$HERE/models/face_detection_yunet_2023mar.onnx" ] && ok "face finder model (eye lock)" || no "face finder model missing - re-download the package"

# ---------- 4. fonts ----------
# The package ships two free fonts (SIL Open Font License) in fonts/. CapCut reads them straight from
# the file, so nothing has to be installed; your style pack can still point at fonts you own.
[ -f "$ROOT/fonts/Inter-Bold.ttf" ] && [ -f "$ROOT/fonts/InstrumentSerif-Italic.ttf" ] && ok "fonts (Inter Bold, Instrument Serif - shipped)" || no "fonts/ folder incomplete - re-download the package"

# ---------- 5. the ElevenLabs key (BYOK) ----------
if [ -f "$ENVF" ] && grep -q '^ELEVENLABS_API_KEY=.\+' "$ENVF" 2>/dev/null; then
  ok "ElevenLabs key is set"
else
  echo
  echo "  Transcription runs on ElevenLabs Scribe, on YOUR key — so the cost and the"
  echo "  data are yours, not ours. Get one at elevenlabs.io (Profile → API Keys)."
  ask "  Paste your ElevenLabs API key (or press return to do it later):"
  if [ -n "${REPLY:-}" ]; then
    touch "$ENVF"; chmod 600 "$ENVF"
    grep -v '^ELEVENLABS_API_KEY=' "$ENVF" > "$ENVF.tmp" 2>/dev/null || true
    mv "$ENVF.tmp" "$ENVF" 2>/dev/null || true
    echo "ELEVENLABS_API_KEY=$REPLY" >> "$ENVF"; chmod 600 "$ENVF"
    ok "key saved to .env (permissions 600, never leaves this machine)"
  else
    no "skipped — set ELEVENLABS_API_KEY in $ENVF before your first edit"
  fi
fi

# ---------- 6. config ----------
[ -f "$CFG" ] || cp "$HERE/config.example.json" "$CFG"
# a new install starts from the neutral starter brand; the Brand Studio (or "set up my brand") makes it theirs
[ -f "$HERE/brand.json" ] || { cp "$HERE/brand.example.json" "$HERE/brand.json" && ok "brand: the neutral starter (set yours in the Studio's Brand tab)"; }
get(){ "$VENV/bin/python" -c "import json;print(json.load(open('$CFG')).get('$1','') or '')" 2>/dev/null; }
BR="$(get broll_root)"
if [ -n "$BR" ] && [ -d "$BR" ]; then ok "B-roll library: $BR"
else
  echo
  echo "  Your B-roll library is a folder of your own clips, in subfolders by bucket"
  echo "  (Office, Travel, Lifestyle…). It is only used for cutaways — you can skip it."
  ask "  Path to your B-roll folder (or press return to skip):"
  if [ -n "${REPLY:-}" ]; then
    "$VENV/bin/python" - "$CFG" "$REPLY" <<'PYS'
import json,sys
p,v=sys.argv[1],sys.argv[2]
d=json.load(open(p)); d["broll_root"]=v.rstrip("/"); json.dump(d,open(p,"w"),indent=2)
PYS
    BR="$(get broll_root)"
    [ -d "$BR" ] && ok "saved" || no "that folder is not there — fix it in $CFG"
  fi
fi

# ---------- 7. the shot index, built from THEIR footage ----------
if [ -n "$BR" ] && [ -d "$BR" ]; then
  if [ -f "$HERE/shots.json" ]; then ok "B-roll shot index exists ($HERE/shots.json)"
  else
    echo "  Indexing your B-roll (scene detection — this can take a few minutes)…"
    ("$VENV/bin/python" "$HERE/detect_shots.py") && ok "shot index built" || no "indexing failed"
  fi
fi

# ---------- done ----------
mkdir -p "$ROOT/_local" && date > "$ROOT/_local/cineyap-install.ok"
echo
echo "Setup finished. Re-run this any time — it only does what is still missing."
echo "Check anything: $VENV/bin/python $HERE/config.py"
echo
