# Setting CineYap up on a new Mac

About 20 minutes, once. Do it in this order.

## 1. Install what CineYap stands on

| What | How |
|---|---|
| **CapCut** (the free desktop app) | capcut.com, install, open it once, make one empty project, quit it |
| **Claude desktop app** | claude.ai/download, sign in, open the Code tab |
| **Homebrew** | brew.sh |
| **Python 3.11, ffmpeg with libass, Node** | `brew install python@3.11 ffmpeg-full node` |

## 2. Put the folder in place

1. Unzip `CineYap` into `~/Developer/` (anywhere that is NOT iCloud or Dropbox).
2. Open the folder in the Claude app's Code tab and say **"set me up."**
   It builds its own Python, checks ffmpeg and Node, and asks for two things:
   - **ElevenLabs API key**: elevenlabs.io → Profile → API Keys. Transcription runs on it.
   - **B-roll folder**: a folder of your own clips, in subfolders by type (Office, Travel...). Skip it
     if you have none yet; videos still build, just without cutaways.

## 3. Optional, for the full look

Tell Claude where these live and it fills in `cineyap/config.json`:

- **A LUT** (`.cube`) if you shoot in log
- **The flash clip** (`Overlay 1.mp4`) and **the click sound** for flash transitions
- **A folder of already-split B-roll clips** (one shot per file) for the Board's picker

## 4. First video

1. Drop a talking-head video in `inbox/`.
2. Say **"edit my video."**
3. Say **"open the Studio"** to see it in every format, change it on the Board, and open it in CapCut.

`./check-setup.sh` lists anything missing. It changes nothing.

## On this Mac only

- **Screen Recording and Accessibility** for the Claude app (System Settings → Privacy & Security) let
  Claude open drafts and export from CapCut for you. Without them, open drafts in CapCut yourself.
- CapCut is closed while a draft is written; the Studio does this for you.
