"""style.py — load the style pack with the creator's BRAND applied over it. Every builder loads the look here.

Two layers:
  styles/<look>.json   the pack: layout, sizes, timings, motion, effects. Measured, rarely edited by hand.
  brand.json           the brand: colors, fonts, handle (cineyap/brand.json; the Brand Studio writes it).

The pack was measured off Gabe's videos, so its colors are his. A brand recolors the whole pack by
FAMILY rather than by field: every place the pack uses its dark color (the green card, the split band,
the ink on cream) becomes the brand's dark; every light (the cream plate, the label) becomes its light;
and so on. A new effect added to the pack later is recolored the same way with no extra work.

No brand.json = the pack's own colors (Gabe's look). brand.example.json is the neutral starter a new
install begins from.

    from style import load, brand
    sty = load()          # the pack, branded
    b = brand()           # the brand itself (handle, fonts, colors)
"""
import copy, json, pathlib, re
from _root import PKG
import config

STYLES = PKG/"cineyap/styles"
BRAND = PKG/"cineyap/brand.json"

# The pack's color families, as measured. Each value the pack uses belongs to exactly one role.
FAMILIES = {
    "dark":       ["#091A14", "#0C140F", "#161E16", "#10201A"],       # cards, bands, ink on light plates
    "ink":        ["#12130D"],                                         # text on the label / pill
    "light":      ["#F5F0EA"],                                         # cream plates, light words
    "label":      ["#F2F2EB"],                                         # the tag / label / pill box
    "text":       ["#FFFFFF"],                                         # words on footage and on dark
}

def _hex(v):
    if isinstance(v, str) and re.match(r"^#[0-9A-Fa-f]{6}$", v): return v.upper()
    if isinstance(v, list) and len(v) in (3, 4) and all(isinstance(x, (int, float)) for x in v): return "#%02X%02X%02X" % tuple(int(x) for x in v[:3])
    return None

def _as(orig, hx):
    """the brand color in the same shape the pack wrote it (hex string, or an [r,g,b(,a)] list)"""
    if isinstance(orig, str): return hx
    rgb = [int(hx[i:i+2], 16) for i in (1, 3, 5)]
    return rgb + list(orig[3:]) if len(orig) == 4 else rgb

def brand():
    """the brand as saved, or {} for the pack's own look"""
    try: return json.loads(BRAND.read_text()) if BRAND.exists() else {}
    except Exception: return {}

def apply(pack, b):
    """recolor and refont a pack copy with a brand"""
    cols = {k: (v or "").upper() for k, v in (b.get("colors") or {}).items() if _hex(v)}
    swap = {}
    for role, olds in FAMILIES.items():
        if cols.get(role):
            for o in olds: swap[o] = cols[role]
    if b.get("colors", {}).get("dark") and "ink" not in cols:          # ink follows dark unless set
        for o in FAMILIES["ink"]: swap[o] = cols["dark"]
    def walk(o, key=""):
        if isinstance(o, dict):
            # a frame's white and black plates are named colors, not brand colors: leave them
            return {k: (v if key == "plates" and k in ("white", "black") else walk(v, k)) for k, v in o.items()}
        if isinstance(o, list):
            hx = _hex(o)
            if hx and hx in swap and len(o) in (3, 4): return _as(o, swap[hx])
            return [walk(v, key) for v in o]
        hx = _hex(o)
        return _as(o, swap[hx]) if hx and hx in swap else o
    out = walk(pack)
    f = b.get("fonts") or {}
    if f.get("main"):
        out.setdefault("fonts", {})["sans"] = f["main"]; out.setdefault("capcut", {})["sans_path"] = f["main"]
        out["fonts"].pop("sans_index", None)                           # the pack's index was for its own .ttc
    if f.get("accent"): out.setdefault("fonts", {})["serif"] = f["accent"]; out.setdefault("capcut", {})["serif_path"] = f["accent"]
    if f.get("accent_style"): out.setdefault("accent", {})["treatment"] = f["accent_style"]   # serif-italic | bold | underline | color
    if cols.get("accent"): out.setdefault("accent", {})["color"] = cols["accent"]
    if b.get("handle"): out["_handle"] = b["handle"]
    return out

def load(look=None):
    look = look or config.opt("look", "gabe")
    pack = json.loads((STYLES/f"{look}.json").read_text())
    return apply(pack, brand())
