#!/usr/bin/env python3
"""mkcarousel.py — a video carousel as a CapCut draft with EDITABLE TYPE, plus per-slide MP4s and XML.

    ../../vu-py cineyap/mkcarousel.py            from projects/<job>/carousel/
    ../../vu-py cineyap/mkcarousel.py --no-mp4   draft and XML only

Inputs, both in projects/<job>/carousel/:
  COPY.txt          the words, one ## SLIDE block per slide (EYEBROW / HEADLINE / SUB / - bullets / NOTE).
                    `backticks` around a word set it in the serif accent face. Profanity is asterisked.
  backgrounds.json  [{"n": 1, "clip": "Office/Roof top work_02.mp4", "at": 0.45, "why": "..."}, ...]
                    clip is relative to broll_clips (then broll_root); at = where in the clip to start,
                    as a fraction of its length. One source file per slide.

Outputs:
  CapCut draft "<job> (Carousel)"    1440x1080, one 5s slide per segment, every line of type a real
                                     CapCut text object on the same left margin, accent word in serif.
  video/carousel_NN.mp4              the baked slides, 5.00s each, silent AAC track (Instagram-ready)
  CAROUSEL.xml                       Premiere: one sequence per slide, V1 B-roll, V2 the type as PNG
  text-layers/text_NN.png            the type as transparent PNGs (what the XML and MP4s use)

Why the draft is the primary output: the type is the whole carousel, and in CapCut you can retype it.
After exporting from CapCut, cineyap/split_export.py cuts the single MP4 into the 5s slides.
"""
import json, pathlib, re, subprocess, sys
from _root import PKG
sys.path.insert(0, str(PKG/"helpers"))
import config

B = pathlib.Path.cwd(); JOB = B.parent
if not (B/"COPY.txt").exists():
    sys.exit("run this from projects/<job>/carousel/ (it needs COPY.txt and backgrounds.json there)")
NO_MP4 = "--no-mp4" in sys.argv

sty = __import__("style").load()
CS  = sty["carousel"]; cc = sty.get("capcut", {}); ccar = CS.get("capcut", {})
W, H = CS["canvas"]; DUR = float(CS.get("slide_s", 5.0)); FPS = 24000/1001
LEFT = round(CS["margin_frac"] * W)

# ---------------------------------------------------------------- the words
def parse_copy(path):
    slides, cur = [], None
    for raw in path.read_text().splitlines():
        line = raw.rstrip()
        if not line or line.startswith("#") and not line.startswith("## SLIDE"): continue
        m = re.match(r"## SLIDE\s+(\d+)", line)
        if m:
            cur = {"n": int(m.group(1)), "eyebrow": "", "headline": "", "sub": "", "bullets": [], "footnote": ""}
            slides.append(cur); continue
        if cur is None: continue
        if line.startswith("EYEBROW:"):  cur["eyebrow"]  = line[8:].strip()
        elif line.startswith("HEADLINE:"): cur["headline"] = line[9:].strip()
        elif line.startswith("SUB:"):      cur["sub"]      = line[4:].strip()
        elif line.startswith("NOTE:"):     cur["footnote"] = line[5:].strip()
        elif line.startswith("STYLE:"):    cur["style"]    = line[6:].strip().lower()
        elif line.startswith("- "):        cur["bullets"].append(line[2:].strip())
    return slides

slides = parse_copy(B/"COPY.txt")
bgs = {b["n"]: b for b in json.load(open(B/"backgrounds.json"))} if (B/"backgrounds.json").exists() else {}
if not slides: sys.exit("COPY.txt has no ## SLIDE blocks")

def find_clip(rel):
    for key in ("broll_clips", "broll_root"):
        root = config.opt(key)
        if root and (pathlib.Path(root)/rel).exists(): return pathlib.Path(root)/rel
    sys.exit(f"background clip not found under broll_clips or broll_root: {rel}")

def probe(p):
    out = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
                          "stream=width,height:format=duration","-of","json",str(p)], capture_output=True, text=True).stdout
    d = json.loads(out); s = d["streams"][0]
    return int(s["width"]), int(s["height"]), float(d["format"]["duration"])

# ---------------------------------------------------------------- the type, measured
from gabe_carousel import censor, render_slide, _font, _wrap, _w
from PIL import ImageDraw, Image
EYE, HEAD, BUL, FOOT = CS["eyebrow"], CS["headline"], CS["bullets"], CS["footnote"]   # [px size, tracking]
scale = W / 1440.0
def px(v): return v * scale

EST_TRACK = float(ccar.get("wrap_track_em", -35))   # what CapCut track -1 is worth in 1/1000 em, for the wrap estimate
MAXW_EDGE = True
def layout(s):
    """Where each element's vertical CENTRE sits, in canvas px, using the measured grid and the same
    wrapping the PNG renderer uses, so the CapCut type lands where the baked type lands."""
    d = ImageDraw.Draw(Image.new("RGB", (W, H)))
    maxw = W - LEFT - px(40)          # the box runs to the right edge; keep 40px of air
    y = px(CS["block_top"]); out = {}
    if s["eyebrow"]:
        out["eyebrow"] = y + px(EYE[0])/2; y += px(EYE[0]) + px(CS["gap_eyebrow"])
    hl = [l for l in s["headline"].split("\n") if l] or []
    plain = re.sub(r"`", "", s["headline"])
    hlines = _wrap(d, plain, _font(int(px(HEAD[0]))), EST_TRACK/1000*px(HEAD[0]), maxw) if plain else []
    if hlines:
        n = len(hlines); pitch = px(CS["headline_pitch"])
        out["headline"] = y + (px(HEAD[0]) + (n-1)*pitch)/2; out["headline_lines"] = hlines
        y += px(HEAD[0]) + (n-1)*pitch + px(CS.get("gap_headline", 27))
    if s["sub"]:
        out["sub"] = y + px(BUL[0])/2; y += px(BUL[0]) + px(CS.get("gap_headline", 27))
    if s["bullets"]:
        lines = []
        for b in s["bullets"]:
            lines += _wrap(d, b, _font(int(px(BUL[0]))), EST_TRACK/1000*px(BUL[0]), maxw - px(CS["hang"]), hang=0)
        n = len(lines); pitch = px(CS["bullet_pitch"])
        out["bullets"] = y + (px(BUL[0]) + (n-1)*pitch)/2; out["bullet_lines"] = n
        y += px(BUL[0]) + (n-1)*pitch + px(CS["gap_footnote"])
    if s["footnote"]:
        out["footnote"] = y + px(FOOT[0])/2; y += px(FOOT[0])
    out["bottom"] = y
    return out

# ---------------------------------------------------------------- the CapCut draft
import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, trange, KeyframeProperty as KP
from capcut_draft import start, finish, US

name = f"{JOB.name} (Carousel)"
sf, dst = start(name, JOB, W, H)
sf.add_track(draft.TrackType.video, "Slides", relative_index=0)
# one text track per element: CapCut refuses two text objects on one track at the same time
for k, nm in enumerate(("Eyebrow", "Headline", "Copy", "Tag"), 1):
    sf.add_track(draft.TrackType.text, nm, relative_index=k)

def ty(center_px): return (H/2 - center_px) / (H/2)          # CapCut: half-canvas-height units, up positive
unit = float(ccar.get("px_per_unit_1920w", 11.1)) * (W / 1920.0)   # CapCut text scales with canvas WIDTH (OCR-measured on 3 canvases)
def size(pxv): return round(px(pxv) / unit, 2)
rgb = lambda c: tuple(v/255 for v in c[:3]); WHITE = rgb(sty["colors"]["white"])
fonts, made, report = {}, 0, []
SERIF_K = float(ccar.get("serif_factor", 1.3))   # the serif face renders smaller at the same CapCut size (measured on the CineYap cards)
kb = float(CS.get("kenburns", 0.0))            # off by default for carousels (Gabe, 2026-10-02)
STY = CS["styles"]; DEF = CS.get("default_styles", {"first": "header", "last": "header", "rest": "breakdown"})
props = {}

for i, s in enumerate(slides):
    t0 = i * DUR
    bg = bgs.get(s["n"])
    if not bg: sys.exit(f"backgrounds.json has no entry for slide {s['n']}")
    clip = find_clip(bg["clip"]); cw, ch, cd = probe(clip)
    at = max(0.0, min(bg.get("at", 0.5) * cd, cd - DUR - 0.05)) if cd > DUR + 0.05 else 0.0
    seg_dur = min(DUR, cd - 0.05)   # pycapcut refuses a range that reaches the material's last microsecond
    # CapCut fits the clip inside the canvas; scale it up so it FILLS (no bars on a 16:9 clip in 4:3)
    fit, fill = min(W/cw, H/ch), max(W/cw, H/ch); sc = fill / fit
    vs = VideoSegment(str(clip), trange(US(t0), US(seg_dur)), source_timerange=trange(US(at), US(seg_dur)),
                      clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc))
    if kb > 0:
        vs.add_keyframe(KP.uniform_scale, 0, sc); vs.add_keyframe(KP.uniform_scale, US(seg_dur), sc*(1+kb))
    sf.add_segment(vs, "Slides")
    if cd < DUR: report.append(f"slide {s['n']}: clip is {cd:.2f}s, slide holds its last frame to {DUR:.0f}s")

    # ---- type: one AREA text box per element (eyebrow, headline, copy, tag), CapCut wraps inside it.
    # Numbers are the style's, measured off Gabe's hand-set slides; nothing here is computed.
    style = s.get("style") or (DEF["first"] if i == 0 else DEF["last"] if i == len(slides)-1 else DEF["rest"])
    if style not in STY: sys.exit(f"slide {s['n']}: no carousel style '{style}' (have: {', '.join(k for k in STY if not k.startswith('_'))})")
    spec = STY[style]; tr = trange(US(t0), US(DUR))
    # CapCut sizes and box widths are canvas-relative already, so the stamped numbers are not scaled.
    PXU  = float(ccar.get("px_per_unit_1920w", 11.1)) * (W / 1920.0)      # CapCut size -> px
    BOXK = (1674.0 / 643.0) * (W / 1920.0)                                  # fixed_width -> px
    d = ImageDraw.Draw(Image.new("RGB", (W, H)))
    items = []
    if s["eyebrow"]: items.append(("Eyebrow", censor(s["eyebrow"]), "eyebrow", None))
    if s["headline"]:
        text = censor(s["headline"].replace("`", "")).replace("\\n", "\n"); ranges = []
        for m in re.finditer(r"`([^`]+)`", s["headline"]):
            word = censor(m.group(1)); q = text.find(word)
            if q >= 0: ranges.append((q, q + len(word)))
        items.append(("Headline", text, "headline", ranges))
    body = censor(s["sub"]) if s["sub"] else "\n".join("→" + censor(b) for b in s["bullets"])
    if body: items.append(("Copy", body, "copy", None))
    if s["footnote"]: items.append(("Tag", censor(s["footnote"]), "tag", None))
    items = [it for it in items if it[2] in spec]

    # heights from the real wrap: the same font, at the size CapCut will draw, in the box CapCut has
    def height(text, e):
        fpx = e["size"] * e.get("scale", 1.0) * PXU
        boxw = e["fw"] * BOXK * e.get("scale", 1.0)
        trk = (-35/1000 * fpx) if e["track"] < 0 else 0.0
        f = _font(max(1, int(fpx)), e["font"] == "serif")
        n = sum(max(1, len(_wrap(d, para, f, trk, boxw))) for para in text.split("\n"))
        return fpx + (n - 1) * fpx * (1 + e["ls"]), n
    hs = [height(t, spec[el]) for _, t, el, _ in items]
    st_ = spec.get("stack", {"anchor": "top", "top": 235, "gaps": {}}); g = st_.get("gaps", {}); sy = H / 1080.0
    total = sum(h for h, _ in hs) + sum(g.get(el, 30) * sy for _, _, el, _ in items[1:])
    y = (st_.get("center", 540) * sy - total / 2) if st_["anchor"] == "center" else st_.get("top", 235) * sy
    centres = []
    for idx, ((_, _, el, _), (h, _)) in enumerate(zip(items, hs)):
        if idx: y += g.get(el, 30) * sy
        centres.append(y + h / 2); y += h
    if y > H - 40 * sy: report.append(f"slide {s['n']}: type runs {y - (H - 40*sy):.0f}px past the bottom - cut a line")

    for (track, text, el, ranges), cy in zip(items, centres):
        e = spec[el]; serif = e["font"] == "serif"; yv = (H/2 - cy) / (H/2)
        st = TextStyle(size=e["size"], color=WHITE, align=e["align"], letter_spacing=int(e["track"]),
                       auto_wrapping=True, max_line_width=0.95)
        seg = TextSegment(text, tr, style=st, clip_settings=draft.ClipSettings(transform_x=e["x"], transform_y=yv))
        sf.add_segment(seg, track); fonts[seg.material_id] = ranges if ranges else serif; made += 1
        props[seg.material_id] = {"material": {"fixed_width": e["fw"], "force_apply_line_max_width": True,
                                               "line_spacing": e["ls"], "typesetting": 0},
                                  "transform": (e["x"], yv), "scale": e.get("scale", 1.0)}

finish(sf, dst, name, W, H, US(len(slides)*DUR), sty, text_fonts=fonts, text_props=props)

# ---------------------------------------------------------------- PNG type, MP4 slides, XML
(B/"text-layers").mkdir(exist_ok=True); (B/"video").mkdir(exist_ok=True)
import urllib.parse
f_ = lambda s_: int(round(s_*FPS)); url = lambda p: "file://localhost" + urllib.parse.quote(str(p))
R = "<rate><timebase>24</timebase><ntsc>TRUE</ntsc></rate>"
TC = f"<timecode>{R}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>"
def vfile(fid, p, frames, alpha=False):
    al = "<alphatype>straight</alphatype>" if alpha else ""
    return (f'<file id="{fid}"><name>{pathlib.Path(p).name}</name><pathurl>{url(p)}</pathurl>{R}'
            f'<duration>{frames}</duration>{TC}<media><video><samplecharacteristics>{R}'
            f'<width>{W}</width><height>{H}</height>{al}</samplecharacteristics></video></media></file>')
seqs = []
for s in slides:
    n = s["n"]; bg = bgs[n]; clip = find_clip(bg["clip"]); cw, ch, cd = probe(clip)
    at = max(0.0, min(bg.get("at", 0.5) * cd, cd - DUR)) if cd > DUR else 0.0
    png = B/"text-layers"/f"text_{n:02d}.png"
    sd = dict(s); sd["headline"] = s["headline"]; sd["footnote"] = s["footnote"]
    render_slide(sd, png, bg=None, scale=scale, transparent=True)
    if not NO_MP4:
        out = B/"video"/f"carousel_{n:02d}.mp4"
        vf = (f"trim=start={at}:duration={DUR},setpts=PTS-STARTPTS," if cd >= DUR else f"setpts={DUR/cd:.5f}*PTS,")
        fc = (f"[0:v]{vf}scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps=24000/1001,format=yuv420p[bg];"
              f"[1:v]format=rgba[tx];[bg][tx]overlay=0:0:format=auto,trim=duration={DUR},setpts=PTS-STARTPTS[v]")
        subprocess.run(["ffmpeg","-v","error","-y","-i",str(clip),"-i",str(png),"-f","lavfi","-t",str(DUR),
                        "-i","anullsrc=channel_layout=stereo:sample_rate=48000","-filter_complex",fc,
                        "-map","[v]","-map","2:a","-c:v","libx264","-preset","slow","-crf","18","-pix_fmt","yuv420p",
                        "-c:a","aac","-b:a","128k","-t",str(DUR),"-movflags","+faststart",str(out)], check=True)
    NF = f_(DUR)
    src, si, sdur = (clip, f_(at), f_(cd)) if cd >= DUR else (B/"video"/f"carousel_{n:02d}.mp4", 0, NF)
    seqs.append(f'''
 <sequence id="seq{n}"><name>Slide {n:02d}</name><duration>{NF}</duration>{R}{TC}
  <media><video><format><samplecharacteristics>{R}<width>{W}</width><height>{H}</height></samplecharacteristics></format>
   <track><clipitem id="bg{n}"><name>{pathlib.Path(bg["clip"]).name}</name>{R}<duration>{sdur}</duration>
    <start>0</start><end>{NF}</end><in>{si}</in><out>{si+NF}</out><enabled>TRUE</enabled>{vfile(f"fbg{n}", src, sdur)}</clipitem></track>
   <track><clipitem id="tx{n}"><name>text_{n:02d}.png</name>{R}<duration>{NF}</duration>
    <start>0</start><end>{NF}</end><in>0</in><out>{NF}</out><enabled>TRUE</enabled>{vfile(f"ftx{n}", png, NF, alpha=True)}</clipitem></track>
  </video></media></sequence>''')
(B/"CAROUSEL.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="5"><project><name>'
                              f'{JOB.name} carousel</name><children>{"".join(seqs)}</children></project></xmeml>')

print(f"\n{name}")
print(f"  {len(slides)} slides x {DUR:.0f}s · {made} editable text objects · canvas {W}x{H}")
for r in report: print("  !", r)
print(f"  draft: {dst}")
print(f"  {'' if NO_MP4 else 'video/carousel_NN.mp4 · '}CAROUSEL.xml · text-layers/")
print("  After exporting the whole timeline from CapCut: cineyap/split_export.py <export.mp4> -> one file per slide")
