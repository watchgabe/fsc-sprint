#!/usr/bin/env python3
"""copy_edit.py — rebuild a finished vertical edit from its raw take as an editable CapCut draft.

    ./vu-py cineyap/copy_edit.py <job> <finished_reel.mp4> <raw_take.MP4>

The "Showin' Up" proof (2026-10-02) as one command. Every step measures the reel instead of guessing,
and is skipped when its output already exists, so a re-run picks up where the last one stopped:

  1. transcribe the raw take (ElevenLabs Scribe)               edit/transcripts/
  2. recover the cut from the audio                            ref/edl_exact.json      align_edit.py
  3. read the zoom and position of every frame                 ref/motion.json         register_motion.py
  4. fit the grade (raw LOG -> the reel's look)                ref/match.cube          match_grade.py
  5. render the graded, loudness-matched source                build/source_matched.mp4
  6. read every frame: plates, cuts, camera, text              ref/layers/             scan_layers.py
  7. find the B-roll and write the plan                        vertical/plan.json      copy_plan.py (+ find_broll.py)
  8. build the CapCut draft "<job> (Vertical)"                                         mkvertical.py

Then: open the draft in CapCut, export it (audio on), and run
    ./vu-py cineyap/check_copy.py <job> <export.mov>
which measures the export against the reel and says what is still off. Fix, rebuild, re-check.
Shots the B-roll library does not hold go in vertical/overrides.json (see copy_plan.py).
"""
import json, pathlib, re, shutil, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS

if len(sys.argv) < 4: sys.exit(__doc__)
job, REEL, RAW = sys.argv[1], pathlib.Path(sys.argv[2]).expanduser().resolve(), pathlib.Path(sys.argv[3]).expanduser().resolve()
J = PROJECTS/job; REF = J/"ref"
for d in (REF, J/"edit", J/"build", J/"vertical"): d.mkdir(parents=True, exist_ok=True)
PY = sys.executable; C = PKG/"cineyap"
def run(*a): print("  $", " ".join(str(x) for x in a)[:160], flush=True); subprocess.run([str(x) for x in a], check=True)
def step(n, what, out):
    done = pathlib.Path(out).exists()
    print(f"\n[{n}/8] {what}" + ("  (done)" if done else ""), flush=True); return not done

if not (REF/"edit.mp4").exists(): shutil.copy2(REEL, REF/"edit.mp4")
if not (J/"edit/edl.json").exists():
    json.dump({"version": 1, "sources": {"source": str(J/"build/source_matched.mp4")}, "ranges": []}, open(J/"edit/edl.json", "w"), indent=1)

if step(1, "transcribe the raw take", J/f"edit/transcripts/{RAW.stem}.json"):
    run(PY, PKG/"helpers/transcribe.py", RAW, "--edit-dir", J/"edit")
if step(2, "recover the cut from the audio", REF/"edl_exact.json"):
    run(PY, C/"align_edit.py", REF/"edit.mp4", RAW, REF/"edl_exact.json")
if step(3, "read the zoom and position of every frame", REF/"motion.json"):
    run(PY, C/"register_motion.py", REF/"edit.mp4", RAW, REF/"edl_exact.json", REF/"motion.json", "--step", "2")
if step(4, "fit the grade", REF/"match.cube"):
    run(PY, C/"match_grade.py", REF/"edit.mp4", RAW, REF/"motion.json", REF/"match.cube", "--cam-offset", "0")

def lufs(p, extra=()):
    o = subprocess.run(["ffmpeg", "-v", "info", *extra, "-i", str(p), "-vn", "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", o); return float(m[-1]) if m else None
if step(5, "render the graded, loudness-matched source (4K, ~10 min)", J/"build/source_matched.mp4"):
    edl = json.load(open(REF/"edl_exact.json"))
    target = lufs(REF/"edit.mp4")
    a0 = min(s["wav_t0"] for s in edl); a1 = max(s["wav_t1"] for s in edl)
    have = lufs(RAW, ("-ss", f"{a0:.2f}", "-t", f"{a1 - a0:.2f}"))
    gain = (target - have) if (target is not None and have is not None) else 0.0
    print(f"  loudness: reel {target} LUFS, take {have} LUFS -> {gain:+.1f} dB with a limiter")
    tmp = J/"build/source_matched.tmp.mp4"
    run("ffmpeg", "-v", "error", "-y", "-i", RAW, "-vf", f"lut3d={REF/'match.cube'}",
        "-af", f"volume={gain:.2f}dB,alimiter=limit=0.97:attack=2:release=50:level=false",
        "-c:v", "hevc_videotoolbox", "-b:v", "50M", "-tag:v", "hvc1", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", tmp)
    tmp.rename(J/"build/source_matched.mp4")
if step(6, "read every frame of the reel", REF/"layers/ocr_frames.json"):
    run(PY, C/"scan_layers.py", REF)
print("\n[7/8] find the B-roll and write the plan", flush=True)
run(PY, C/"copy_plan.py", REF, job)

print("\n[8/8] build the CapCut draft", flush=True)
if subprocess.run(["pgrep", "-x", "CapCut"], capture_output=True).returncode == 0:
    sys.exit("  CapCut is open. Quit it, then run this again: every step above is kept, only the build runs.")
run(PY, C/"mkvertical.py", job)
print(f"\nNext: open '{job} (Vertical)' in CapCut, export with audio on, then\n  ./vu-py cineyap/check_copy.py {job} <export.mov>")
