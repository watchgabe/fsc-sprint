#!/usr/bin/env python3
"""split_export.py — cut a CapCut carousel export into one MP4 per slide.
    split_export.py <export.mp4> [slide_s=5] [outdir=video]
Every slide is exactly slide_s long on the CapCut timeline, so the split is arithmetic. Re-encodes
each slide (crf 18) so every file starts on a keyframe, and adds a silent AAC track if the export
has no audio - Instagram wants one."""
import subprocess, sys, pathlib, json
src = pathlib.Path(sys.argv[1]); step = float(sys.argv[2]) if len(sys.argv) > 2 else 5.0
out = pathlib.Path(sys.argv[3]) if len(sys.argv) > 3 else src.parent/"video"; out.mkdir(exist_ok=True)
d = json.loads(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration:stream=codec_type","-of","json",str(src)],capture_output=True,text=True).stdout)
dur = float(d["format"]["duration"]); has_audio = any(s["codec_type"]=="audio" for s in d["streams"])
n = int(round(dur/step))
for i in range(n):
    o = out/f"carousel_{i+1:02d}.mp4"
    cmd = ["ffmpeg","-v","error","-y","-ss",f"{i*step:.3f}","-t",f"{step:.3f}","-i",str(src)]
    if not has_audio: cmd += ["-f","lavfi","-t",f"{step:.3f}","-i","anullsrc=channel_layout=stereo:sample_rate=48000","-map","0:v","-map","1:a"]
    cmd += ["-c:v","libx264","-preset","slow","-crf","18","-pix_fmt","yuv420p","-c:a","aac","-b:a","128k","-movflags","+faststart",str(o)]
    subprocess.run(cmd, check=True); print(" ", o.name)
print(f"{n} slides from a {dur:.1f}s export")
