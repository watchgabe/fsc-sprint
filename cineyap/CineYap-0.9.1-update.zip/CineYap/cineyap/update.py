#!/usr/bin/env python3
"""update.py — move this CineYap to a newer version without touching anyone's work.

    ./vu-py cineyap/update.py                  # check the feed in product.json, install a newer version
    ./vu-py cineyap/update.py <CineYap.zip>    # install from a zip someone sent
    ./vu-py cineyap/update.py --check          # just say whether a newer version exists

What it never touches: projects/, inbox/, .env, .venv/, _local/, cineyap/config.json, cineyap/brand.json,
cineyap/shots.json and the CapCut format cache this machine captured. Their videos, keys, brand and
settings stay exactly as they are.

What it does: backs up the current code to _local/backups/<version>-<time>.zip, copies the new code over,
MERGES new settings into every style pack that already exists (a value they changed or "learned" from
CapCut is kept; a setting the new version adds is filled in), adds new packs, then re-runs ./install.sh
quietly in case the new version needs a new library. The log is _local/update.log.
"""
import io, json, pathlib, shutil, subprocess, sys, tempfile, time, urllib.request, zipfile
ROOT = pathlib.Path(__file__).resolve().parent.parent

KEEP = {"projects", "inbox", "samples", ".env", ".venv", "_local", ".git",
        "cineyap/config.json", "cineyap/brand.json", "cineyap/brand_assets", "cineyap/shots.json", "cineyap/_capcut_template",
        "cineyap/_capcut_ref_material.json", "cineyap/_capcut_ref_segment.json", "cineyap/_capcut_mix_screen.json"}
LOG = ROOT/"_local/update.log"

def say(msg):
    print(msg); LOG.parent.mkdir(exist_ok=True)
    with open(LOG, "a") as f: f.write(time.strftime("%Y-%m-%d %H:%M ") + msg + "\n")

def version_tuple(v): return tuple(int(x) if x.isdigit() else 0 for x in (v or "0").split("."))
def product(): return json.loads((ROOT/"product.json").read_text()) if (ROOT/"product.json").exists() else {"version": "0"}

def kept(rel):
    rel = rel.replace("\\", "/")
    return any(rel == k or rel.startswith(k + "/") for k in KEEP)

def merge(old, new):
    """new keys from `new` filled into `old`; every value already in `old` wins"""
    if isinstance(old, dict) and isinstance(new, dict):
        out = dict(old)
        for k, v in new.items(): out[k] = merge(old[k], v) if k in old else v
        return out
    return old

def fetch_feed():
    url = product().get("update_url")
    if not url: sys.exit("This install has no update address (product.json). Ask Gabe for the newest zip.")
    try:
        with urllib.request.urlopen(url, timeout=15) as r: return json.loads(r.read().decode())
    except Exception as e: sys.exit(f"Could not reach the update feed ({e}). Check the internet connection and try again.")

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    have = product().get("version", "0")
    if args:
        src = pathlib.Path(args[0]).expanduser()
        if not src.exists(): sys.exit(f"No file at {src}")
        data = src.read_bytes(); notes = ""
    else:
        feed = fetch_feed(); there = feed.get("version", "0")
        if version_tuple(there) <= version_tuple(have):
            print(f"CineYap {have} is the newest version."); return
        if "--check" in sys.argv:
            print(f"CineYap {there} is out (this install is {have}). {feed.get('notes', '')}"); return
        say(f"downloading {there} from {feed['download']}")
        with urllib.request.urlopen(feed["download"], timeout=300) as r: data = r.read()
        notes = feed.get("notes", "")

    with tempfile.TemporaryDirectory() as tmp:
        zipfile.ZipFile(io.BytesIO(data)).extractall(tmp)
        roots = [p for p in pathlib.Path(tmp).iterdir() if p.is_dir() and (p/"product.json").exists()]
        new = roots[0] if roots else pathlib.Path(tmp)
        if not (new/"product.json").exists() or not (new/"cineyap").is_dir(): sys.exit("That zip is not a CineYap package.")
        there = json.loads((new/"product.json").read_text()).get("version", "?")
        if version_tuple(there) < version_tuple(have) and "--force" not in sys.argv:
            sys.exit(f"That zip is {there}, older than this install ({have}). Nothing changed.")

        # 1. back up the code (everything that is not their work) so an update can always be undone
        bk = ROOT/"_local/backups"; bk.mkdir(parents=True, exist_ok=True)
        bz = bk/f"{have}-{time.strftime('%Y%m%d-%H%M%S')}.zip"
        with zipfile.ZipFile(bz, "w", zipfile.ZIP_DEFLATED) as z:
            for p in ROOT.rglob("*"):
                rel = str(p.relative_to(ROOT))
                if p.is_file() and not kept(rel) and "__pycache__" not in rel: z.write(p, rel)
        say(f"backed up {have} to {bz}")

        # 2. copy the new code over; style packs are merged, never overwritten
        n_new = n_merged = 0
        for p in new.rglob("*"):
            if not p.is_file(): continue
            rel = str(p.relative_to(new)).replace("\\", "/")
            if kept(rel) or "__pycache__" in rel: continue
            dst = ROOT/rel
            if rel.startswith("cineyap/styles/") and rel.endswith(".json") and dst.exists():
                try:
                    old = json.loads(dst.read_text()); dst.write_text(json.dumps(merge(old, json.loads(p.read_text())), indent=1, ensure_ascii=False))
                    n_merged += 1; continue
                except Exception: pass
            dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, dst); n_new += 1
        say(f"installed {there}: {n_new} files, {n_merged} style pack(s) merged (their own settings kept)")

    # 3. a new version may need a new library: install.sh only adds what is missing
    r = subprocess.run(["bash", str(ROOT/"install.sh")], stdin=subprocess.DEVNULL, capture_output=True, text=True)
    bad = [l for l in r.stdout.splitlines() if "!!" in l and "skipped" not in l]
    if bad: say("install check: " + " | ".join(l.strip() for l in bad))
    print(f"\nCineYap {have} -> {there}." + (f"\n{notes}" if notes else ""))
    print("If the Studio is open, restart it (/studio) to load the new version.")

if __name__ == "__main__":
    main()
