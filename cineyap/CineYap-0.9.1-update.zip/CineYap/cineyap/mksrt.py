#!/usr/bin/env python3
"""cues.json -> master.srt. Premiere imports SRT as a CAPTION track, and caption
text IS editable in Premiere's Text panel. The styling is Premiere's, not Gabe's
Helvetica -40 look, so this is for fixing WORDS, not for final look."""
import json, pathlib, subprocess
B=pathlib.Path.cwd()
cues=json.load(open(B/"cues.json"))
TOT=float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
    "-of","csv=p=0",str(B/"base_clean.mp4")],capture_output=True,text=True).stdout.strip())
def tc(s):
    h=int(s//3600); m=int(s%3600//60); sec=s%60
    return f"{h:02d}:{m:02d}:{sec:06.3f}".replace(".",",")
out=[]
for i,c in enumerate(cues):
    t0=c["t"]; t1=cues[i+1]["t"] if i+1<len(cues) else TOT
    if t1-t0 < 0.05: continue
    out.append(f"{len(out)+1}\n{tc(t0)} --> {tc(t1)}\n{c['text']}\n")
p=B.parent/"edit/master.srt"; p.write_text("\n".join(out))
print(f"{len(out)} captions -> {p}")
