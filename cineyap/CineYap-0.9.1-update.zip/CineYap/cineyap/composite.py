# The picture and the caption must change on the SAME frame. Any padding here
# (there used to be +0.05s to avoid inter-insert flashes) leaves B-roll on
# screen after the caption has already switched to the A-roll style.
# Adjacent inserts are contiguous by construction, so no padding is needed.
import json, subprocess
DUR = subprocess.run(["ffprobe","-v","error","-select_streams","v:0",
    "-show_entries","stream=duration","-of","csv=p=0","base_clean.mp4"],
    capture_output=True, text=True).stdout.strip()
ins=json.load(open("inserts.json"))
cmd=["ffmpeg","-y","-v","error","-i","base_clean.mp4"]
for o in ins: cmd+=["-i",o["file"]]
cmd+=["-i","layer.mov"]
mattes=[o for o in ins if o.get("matte")]
for o in mattes: cmd+=["-c:v","libvpx-vp9","-i",o["matte"]]
fc=[]; cur="[0:v]"
for i,o in enumerate(ins):
    fc.append(f"[{i+1}:v]trim=start={o.get('asset_in',0.0)},setpts=PTS-STARTPTS+{o['t0']}/TB[i{i}]")
    fc.append(f"{cur}[i{i}]overlay=0:0:enable='between(t,{o['t0']},{o['t1']})'[v{i}]")
    cur=f"[v{i}]"
L=len(ins)+1
fc.append(f"[{L}:v]setpts=PTS-STARTPTS,format=yuva444p12le[txt]")
fc.append(f"{cur}[txt]overlay=0:0:format=auto[withtxt]")
cur="[withtxt]"
for j,o in enumerate(mattes):
    idx=L+1+j
    fc.append(f"[{idx}:v]format=yuva420p,setpts=PTS-STARTPTS+{o['t0']}/TB[m{j}]")
    fc.append(f"{cur}[m{j}]overlay=0:0:enable='between(t,{o['t0']},{o['t1']})'[mv{j}]")
    cur=f"[mv{j}]"
fc.append(f"{cur}null[outv]")
cmd+=["-filter_complex",";".join(fc),"-map","[outv]","-map","0:a",
      "-t",DUR,"-c:v","libx264","-preset","medium","-crf","17","-pix_fmt","yuv420p",
      "-c:a","copy","-movflags","+faststart","out.mp4"]
print(f"compositing {len(ins)} inserts")
subprocess.run(cmd,check=True); print("done")
