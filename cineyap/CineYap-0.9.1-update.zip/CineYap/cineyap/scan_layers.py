#!/usr/bin/env python3
"""scan_layers.py — read a reference edit frame by frame: plates, cuts, camera-or-not, and every word on screen.

    scan_layers.py <ref_dir>

Needs <ref_dir>/edit.mp4 and <ref_dir>/motion.json (register_motion.py). Writes <ref_dir>/layers/:
  small.npy        every frame at 72x128 (for the flash and the plate test)
  frames.json      per frame: plate colour (green / cream / none), cut strength, camera-or-not
  ocr_frames.json  every frame's text with its box (Apple Vision, on this Mac)
"""
import json, pathlib, subprocess, sys, tempfile, numpy as np

REF = pathlib.Path(sys.argv[1]); L = REF/"layers"; L.mkdir(exist_ok=True)
EDIT = REF/"edit.mp4"; FPS = 24000/1001
W, H = 72, 128
raw = subprocess.run(["ffmpeg","-v","error","-i",str(EDIT),"-vf",f"scale={W}:{H}","-fps_mode","passthrough",
                      "-f","rawvideo","-pix_fmt","rgb24","-"], capture_output=True).stdout
F = np.frombuffer(raw, np.uint8).reshape(-1, H, W, 3); np.save(L/"small.npy", F); F = F.astype(np.float32); n = len(F)
cream = np.array([242, 242, 235])
def plate(f):
    # a full-frame card: one flat colour above and below the middle text band
    m = np.concatenate([f[:int(H*0.35)], f[int(H*0.62):]]).reshape(-1, 3)
    med = np.median(m, 0); frac = (np.abs(m - med).max(1) < 14).mean()
    if frac > 0.93:
        if np.abs(med - cream).max() < 30: return "cream"
        if med.mean() < 80: return "green"
    return None
g = F.mean(3); d = np.r_[0, np.abs(np.diff(g, axis=0)).mean((1, 2))]
mot = json.load(open(REF/"motion.json"))
mt = np.array([r["edit_t"] for r in mot]); ok = np.array([bool(r.get("ok")) for r in mot])
def cam(i):
    t = i/FPS; j = np.argsort(abs(mt - t))[:2]
    return bool(ok[j].any()) if abs(mt[j[0]] - t) < 0.09 else None
json.dump([{"i": i, "t": round(i/FPS, 4), "plate": plate(F[i]), "diff": round(float(d[i]), 2), "aroll": cam(i)} for i in range(n)],
          open(L/"frames.json", "w"))
print(f"  {n} frames: plates, cuts, camera")

import Vision, Quartz
from Foundation import NSURL
tmp = pathlib.Path(tempfile.mkdtemp())
subprocess.run(["ffmpeg","-v","error","-i",str(EDIT),"-vf","scale=540:-2","-fps_mode","passthrough",str(tmp/"f%05d.png")], check=True)
out = []
for i, f in enumerate(sorted(tmp.glob("f*.png"))):
    img = Quartz.CGImageSourceCreateImageAtIndex(Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(f)), None), 0, None)
    req = Vision.VNRecognizeTextRequest.alloc().init()
    req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate); req.setUsesLanguageCorrection_(False)
    Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None).performRequests_error_([req], None)
    tx = []
    for o in req.results() or []:
        c = o.topCandidates_(1)[0]; bb = o.boundingBox()
        if c.confidence() < 0.4 or bb.size.height < 0.012: continue
        tx.append({"t": str(c.string()), "x": round(bb.origin.x, 4), "y": round(1 - bb.origin.y - bb.size.height, 4),
                   "w": round(bb.size.width, 4), "h": round(bb.size.height, 4)})
    out.append({"i": i, "text": tx}); f.unlink()
    if i % 300 == 0: print(f"  OCR {i}/{n}", flush=True)
json.dump(out, open(L/"ocr_frames.json", "w"))
print(f"  OCR on {len(out)} frames -> {L}")
