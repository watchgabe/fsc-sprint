#!/usr/bin/env python3
"""studio.py — the CineYap Studio: one local page with every format and effect, every test draft, and
the Board for every video in every format.

    ./vu-py cineyap/studio.py            -> http://localhost:4747   (opens the browser)
    ./vu-py cineyap/studio.py --no-open

Local only (127.0.0.1). It is a page and not a chat widget because a page on this Mac can do what a
widget cannot: open a draft in CapCut, show a file in Finder, play your real clips, and apply a Board
Send itself instead of round-tripping through a pasted message.

Reads, never copies: the formats and effects come from cineyap/library/catalog.json (the Library), the
Board's data from boards.py, the drafts from CapCut's own project list.
"""
import hashlib, json, mimetypes, os, pathlib, subprocess, sys, threading, time, traceback, urllib.parse, uuid
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
import config, boards, open_draft

PORT = int(os.environ.get("CINEYAP_STUDIO_PORT", 4747))
WEB = PKG/"cineyap/studio"
LIB = PKG/"cineyap/library"
THUMBS = PKG/"_local/thumbs"; THUMBS.mkdir(parents=True, exist_ok=True)
RUNS = {}                                  # run id -> {"log": [...], "done": bool, "ok": bool}
BUSY = threading.Lock()                    # one rebuild at a time: they all share CapCut

FONT_DIRS = [PKG/"fonts", PKG/"cineyap/brand_assets", pathlib.Path.home()/"Library/Fonts", pathlib.Path("/Library/Fonts"), pathlib.Path("/System/Library/Fonts")]

def allowed(p):
    """files the page may read: the package, the projects, the B-roll library, CapCut's drafts, fonts"""
    p = pathlib.Path(p).resolve()
    roots = [PKG, PROJECTS, *boards.broll_roots(), open_draft.DRAFTS, *FONT_DIRS,
             pathlib.Path(config.opt("sfx_flash_overlay") or "/nonexistent").parent]
    return any(str(p).startswith(str(r.resolve())) for r in roots if r)

def jobs():
    """every video and the formats it has, with the draft, the preview and the Board"""
    drafts = open_draft.drafts(); out = []
    for J in sorted(PROJECTS.iterdir(), key=lambda p: -p.stat().st_mtime):
        if not J.is_dir() or J.name.startswith("."): continue
        fm = []
        for fmt, f in boards.FORMATS.items():
            dn = boards.draft_name(J.name, fmt); has = boards.has_format(J.name, fmt)
            if not has and dn not in drafts: continue
            prev = next((str(x) for x in (J/"previews"/f"{fmt}.mp4", J/"previews"/f"{fmt}.jpg") if x.exists()), "")
            fm.append({"fmt": fmt, "name": f["name"], "canvas": f["canvas"], "draft": dn if dn in drafts else "",
                       "board": has, "preview": prev,
                       "modified": int((pathlib.Path(drafts[dn]).stat().st_mtime) if dn in drafts and pathlib.Path(drafts[dn]).exists() else 0)})
        if fm: out.append({"job": J.name, "formats": fm})
    return out

def library():
    root = config.opt("broll_clips") or config.opt("broll_root"); lib = {}
    if root and pathlib.Path(root).is_dir():
        for p in sorted(pathlib.Path(root).rglob("*")):
            if p.suffix.lower() in (".mp4", ".mov") and not p.name.startswith("."):
                lib.setdefault(str(p.parent.relative_to(root)), []).append(str(p.relative_to(root)))
    return {"root": root, "folders": lib}

# ---- the Brand tab: brand.json is the one place a creator's colors, fonts, handle and LUT live (style.py)
BRAND_FILE = PKG/"cineyap/brand.json"; BRAND_ASSETS = PKG/"cineyap/brand_assets"
NATIVE = {"dark": "#091A14", "light": "#F5F0EA", "label": "#F2F2EB", "ink": "#12130D", "text": "#FFFFFF", "accent": ""}
def brand_state():
    ex = json.loads((PKG/"cineyap/brand.example.json").read_text())
    cur = json.loads(BRAND_FILE.read_text()) if BRAND_FILE.exists() else None
    fonts = []
    for d in FONT_DIRS:
        if d.exists():
            for f in sorted(d.glob("*")):
                if f.suffix.lower() in (".ttf", ".otf"): fonts.append({"name": f.stem.replace("-", " "), "path": str(f), "shipped": d == PKG/"fonts"})
    pack = json.loads((PKG/"cineyap/styles"/f"{config.opt('look', 'gabe')}.json").read_text()).get("capcut", {})
    pack_fonts = {"main": os.path.expanduser(pack.get("sans_path", "")), "accent": os.path.expanduser(pack.get("serif_path", ""))}
    return {"pack_fonts": pack_fonts, "brand": cur or {"_native": True, "colors": NATIVE, "fonts": {}, "handle": "", "name": "", "lut": config.opt("lut") or ""},
            "saved": cur is not None, "example": ex, "presets": {"Neutral starter": ex["colors"], "FSCreative": NATIVE},
            "fonts": fonts, "lut": config.opt("lut") or ""}
def save_brand(b):
    b = {k: v for k, v in b.items() if not k.startswith("_")}
    BRAND_FILE.write_text(json.dumps(b, indent=1, ensure_ascii=False))
    if b.get("lut") is not None:                       # the grade new videos start with (config.json "lut")
        cfg_f = PKG/"cineyap/config.json"
        if cfg_f.exists():
            cfg = json.loads(cfg_f.read_text()); cfg["lut"] = b.get("lut") or ""; cfg_f.write_text(json.dumps(cfg, indent=2))
    return True

def thumb(p, t):
    key = hashlib.md5(f"{p}|{t}".encode()).hexdigest(); out = THUMBS/f"{key}.jpg"
    if not out.exists():
        subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{t:.2f}","-i",str(p),"-frames:v","1","-vf","scale=320:-2","-q:v","5",str(out)])
    return out

def start_apply(job, fmt, edits):
    rid = uuid.uuid4().hex[:8]; RUNS[rid] = {"log": ["Applying your edits…"], "done": False, "ok": False}
    def work():
        with BUSY:
            try:
                boards.apply(job, fmt, edits, RUNS[rid]["log"]); RUNS[rid]["ok"] = True
                RUNS[rid]["log"].append(f"Done. '{boards.draft_name(job, fmt)}' is rebuilt.")
            except Exception as e:
                RUNS[rid]["log"].append(f"STOPPED: {e}")
                RUNS[rid]["log"].extend(traceback.format_exc().splitlines()[-4:])
            RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

def start_open(name):
    rid = uuid.uuid4().hex[:8]; RUNS[rid] = {"log": [f"Opening {name} in CapCut…"], "done": False, "ok": False}
    def work():
        with BUSY:
            if not open_draft.take_lock("studio-page", wait=0):
                RUNS[rid]["log"].append("CapCut is busy: another session is exporting (_local/capcut.lock). Try again in a few minutes.")
            else:
                try:
                    msg = open_draft.open_draft(name); RUNS[rid]["log"].append(msg); RUNS[rid]["ok"] = msg.startswith("opened")
                finally: open_draft.release_lock("studio-page")
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send_json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(b)
    def send_file(self, p, ctype=None):
        p = pathlib.Path(p); size = p.stat().st_size; ctype = ctype or mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-"); a = int(a or 0); b = int(b) if b else size - 1; b = min(b, size - 1)
            self.send_response(206); self.send_header("Content-Range", f"bytes {a}-{b}/{size}")
        else:
            a, b = 0, size - 1; self.send_response(200)
        self.send_header("Content-Type", ctype); self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(b - a + 1)); self.end_headers()
        with open(p, "rb") as fh:
            fh.seek(a); left = b - a + 1
            while left > 0:
                chunk = fh.read(min(1 << 20, left))
                if not chunk: break
                try: self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError): return
                left -= len(chunk)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        try:
            if u.path in ("/", "/index.html"): return self.send_file(WEB/"index.html", "text/html; charset=utf-8")
            if u.path.startswith("/static/"):
                f = (WEB/u.path[8:]).resolve()
                if str(f).startswith(str(WEB.resolve())) and f.exists(): return self.send_file(f)
            if u.path.startswith("/library/"):
                f = (LIB/u.path[9:]).resolve()
                if str(f).startswith(str(LIB.resolve())) and f.exists(): return self.send_file(f)
            if u.path == "/api/state":
                cat = json.load(open(LIB/"catalog.json")) if (LIB/"catalog.json").exists() else {}
                return self.send_json({"jobs": jobs(), "catalog": cat, "drafts": list(open_draft.drafts().keys()),
                                       "capcut_open": open_draft.running()})
            if u.path == "/api/board": return self.send_json(boards.model(q["job"], q["fmt"]))
            if u.path == "/api/library": return self.send_json(library())
            if u.path == "/api/brand": return self.send_json(brand_state())
            if u.path == "/api/run": return self.send_json(RUNS.get(q["id"], {"log": ["unknown run"], "done": True, "ok": False}))
            if u.path == "/thumb":
                p = pathlib.Path(q["p"])
                if not p.is_absolute(): p = boards.resolve_clip(q["p"]) or p
                if p.exists() and allowed(p): return self.send_file(thumb(p, float(q.get("t", 0.5))), "image/jpeg")
            if u.path == "/file":
                p = pathlib.Path(q["p"])
                if not p.is_absolute(): p = boards.resolve_clip(q["p"]) or p
                if p.exists() and allowed(p): return self.send_file(p)
            self.send_json({"error": "not found"}, 404)
        except Exception as e:
            self.send_json({"error": str(e), "trace": traceback.format_exc().splitlines()[-3:]}, 500)

    def do_POST(self):
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        n = int(self.headers.get("Content-Length", 0))
        try:
            if u.path == "/api/upload":            # a clip dropped from Finder: the browser gives bytes, not a path
                job = q["job"]; name = pathlib.Path(q["name"]).name
                d = PROJECTS/job/"board_media"; d.mkdir(parents=True, exist_ok=True); out = d/name
                with open(out, "wb") as fh:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(1 << 20, left)); fh.write(chunk); left -= len(chunk)
                found = boards.resolve_clip(name)        # the same clip already in the library: use that one
                return self.send_json({"clip": boards.rel_clip(found) if found and "board_media" not in str(found) else str(out)})
            if u.path == "/api/brand/upload":      # a font, LUT or logo dropped on the Brand tab
                name = pathlib.Path(q["name"]).name; BRAND_ASSETS.mkdir(parents=True, exist_ok=True); out = BRAND_ASSETS/name
                with open(out, "wb") as fh:
                    left = n
                    while left > 0:
                        chunk = self.rfile.read(min(1 << 20, left)); fh.write(chunk); left -= len(chunk)
                return self.send_json({"path": str(out)})
            body = json.loads(self.rfile.read(n) or b"{}")
            if u.path == "/api/brand": save_brand(body["brand"]); return self.send_json({"ok": True})
            if u.path == "/api/apply": return self.send_json({"run": start_apply(body["job"], body["fmt"], body["edits"])})
            if u.path == "/api/open": return self.send_json({"run": start_open(body["draft"])})
            if u.path == "/api/reveal":
                if body["path"].startswith("__draft__"):              # a CapCut draft, by name
                    d = open_draft.drafts().get(body["path"][9:])
                    if d and pathlib.Path(d).exists(): subprocess.run(["open", "-R", d]); return self.send_json({"ok": True})
                    return self.send_json({"ok": False, "error": "no such draft"}, 404)
                p = pathlib.Path(body["path"])
                if not p.is_absolute(): p = boards.resolve_clip(body["path"]) or p
                if p.exists() and allowed(p): subprocess.run(["open", "-R", str(p)]); return self.send_json({"ok": True})
                return self.send_json({"ok": False, "error": "not found"}, 404)
            self.send_json({"error": "not found"}, 404)
        except Exception as e:
            self.send_json({"error": str(e), "trace": traceback.format_exc().splitlines()[-3:]}, 500)

if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
    url = f"http://localhost:{PORT}"
    print(f"CineYap Studio: {url}   (Ctrl-C to stop)")
    if "--no-open" not in sys.argv: subprocess.Popen(["open", url])
    srv.serve_forever()
