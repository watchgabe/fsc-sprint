#!/usr/bin/env python3
"""build_library.py — the Library: every effect and format, with previews and an Add button, shown in chat.

    ./vu-py cineyap/build_library.py            -> cineyap/library/library.html (render it with show_widget)

Reads cineyap/library/catalog.json and the WebP frames in cineyap/library/previews/ (real frames from
CapCut exports, small enough to travel inside the chat). The page is static HTML, so it reads while it
streams; cineyap/library/library.js wires the filters, the flip-book previews and the buttons afterwards.

Add sends one message to Claude: the plain request ("Flash on line 4") and, for effects the Board owns
(flash, behind, bg, zoom), a ```board block with an "add" key that apply_board.py merges into the
current video. Effects without a Board key are placed by Claude in the format's own plan.
A "test draft" button appears only for CapCut drafts that exist on this machine.
"""
import base64, html, json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG

LIB = PKG/"cineyap/library"
CAT = json.load(open(LIB/"catalog.json"))
DRAFTS = pathlib.Path.home()/"Movies/CapCut/User Data/Projects/com.lveditor.draft"
have = {p.name for p in DRAFTS.iterdir()} if DRAFTS.exists() else set()
E = html.escape

def img(key):
    f = LIB/"previews"/f"{key}.webp"
    return "data:image/webp;base64," + base64.b64encode(f.read_bytes()).decode() if f.exists() else ""

TONE = {"good": "background:var(--bg-success);color:var(--text-success)",
        "warn": "background:var(--bg-warning);color:var(--text-warning)",
        "plain": "background:var(--surface-1);color:var(--text-secondary)"}

def card(e, kind):
    label, tone = CAT["status"][e["status"]]
    frames = [img(k) for k in e.get("preview", []) if img(k)]
    if frames:
        pics = "".join(f'<img src="{s}" alt="" data-f="{i}" class="lf" style="opacity:{1 if i == 0 else 0}">' for i, s in enumerate(frames))
        prev = f'<div data-flip class="lp">{pics}</div>'
    else:
        prev = '<div style="position:absolute;inset:0;display:grid;place-items:center;font-size:13px;color:var(--text-muted)">Preview coming</div>'
    fm = " · ".join(e.get("formats", [])) if kind == "fx" else e["cat"]
    say = e.get("say", "")
    if e["status"] == "auto":
        act = '<span style="font-size:13px;color:var(--text-secondary)">Always on</span>'
    elif not say:
        act = f'<span style="font-size:13px;color:var(--text-secondary)">{E(e.get("note", "Not ready yet"))}</span>'
    else:
        ins = ""
        if "{line}" in say: ins += f'<input data-line type="number" min="1" step="1" placeholder="Line" aria-label="Line number for {E(e["name"])}" style="width:72px">'
        if "{text}" in say: ins += f'<input data-text type="text" placeholder="{E(e.get("hint", "Words"))}" aria-label="Words for {E(e["name"])}" style="flex:1;min-width:90px">'
        btn = "Use this format" if kind == "fmt" else "Add"
        act = (f'<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">{ins}'
               f'<button data-add type="button" style="border-radius:999px;padding:0 14px">{btn} ↗</button></div>'
               '<div data-err style="font-size:13px;color:var(--text-danger);min-height:0"></div>')
    tests = [d for d in e.get("test_draft", []) if d in have]
    test = "".join(f'<button data-draft="{E(d)}" type="button" style="font-size:12px;border-radius:999px;padding:0 10px;height:28px">'
                   f'<i class="ti ti-movie" aria-hidden="true" style="font-size:14px;vertical-align:-2px"></i> {E(d)} ↗</button>' for d in tests)
    note = f'<p style="margin:0;font-size:13px;color:var(--text-warning)">{E(e["note"])}</p>' if e.get("note") and say else ""
    return f'''<article data-card class="lc" data-cat="{E(e["cat"] if kind == "fx" else "Formats")}" data-say="{E(say)}" data-board="{E(e.get("board", ""))}" data-name="{E(e["name"])}">
 <div class="lv">{prev}
  <span class="lb">{E(e["name"])} example</span></div>
 <div class="li">
  <div class="lt">
   <h3 style="margin:0;font-size:16px">{E(e["name"])}</h3>
   <span class="lpill {tone}">{E(label)}</span></div>
  <p class="ld">{E(e["what"])}</p>
  <div class="lw">
   <span class="lk">When to use</span>
   <p class="lx">{E(e["when"])}</p>
   {f'<span class="lk">Say</span><p class="ls">{E(say.replace("{line}", "N").replace("{text}", "…"))}</p>' if say else ""}
   {note}
   <span class="lk">{E(fm)}</span></div>
  {act}
  {f'<div style="display:flex;gap:6px;flex-wrap:wrap">{test}</div>' if test else ""}
 </div></article>'''

cats = ["All"] + list(dict.fromkeys(e["cat"] for e in CAT["effects"])) + ["Formats"]
chips = "".join(f'<button data-chip="{c}" type="button" aria-pressed="{"true" if c == "All" else "false"}" '
                f'style="border-radius:999px;height:30px;padding:0 13px;font-size:13px">{c}</button>' for c in cats)
grid = 'style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:12px"'
CSS = '''<style>.lc{background:var(--surface-2);border:0.5px solid var(--border);border-radius:16px;padding:10px;display:flex;flex-direction:column;gap:10px;min-width:0}
.lv{position:relative;aspect-ratio:16/9;background:var(--surface-1);border-radius:10px;overflow:hidden}.lp{position:absolute;inset:10px}
.lf{position:absolute;inset:0;margin:auto;max-width:100%;max-height:100%;border-radius:6px}
.lb{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font-size:11px;padding:2px 9px;border-radius:999px;background:var(--surface-2);color:var(--text-secondary);white-space:nowrap}
.li{padding:2px 6px 6px;display:flex;flex-direction:column;gap:8px}.lt{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}
.lpill{font-size:12px;padding:3px 10px;border-radius:999px;white-space:nowrap}.good{background:var(--bg-success);color:var(--text-success)}
.warn{background:var(--bg-warning);color:var(--text-warning)}.plain{background:var(--surface-1);color:var(--text-secondary)}
.ld,.lx,.ls{margin:0;font-size:14px;line-height:1.5}.ld{color:var(--text-secondary)}.ls{font-family:var(--font-voice);font-style:italic}
.lw{border-top:0.5px solid var(--border);padding-top:8px;display:flex;flex-direction:column;gap:6px}.lk{font-size:12px;color:var(--text-muted)}
@media (prefers-reduced-motion:no-preference){.lf{transition:opacity .15s}}</style>
'''
ready = sum(1 for e in CAT["effects"] if e["status"] in ("locked", "built", "auto"))
page = CSS + f'''<h2 class="sr-only">CineYap Library: {len(CAT["effects"])} effects and {len(CAT["formats"])} formats, each with a preview and an Add button.</h2>
<div style="padding:0.5rem 0 1rem;display:flex;flex-direction:column;gap:14px">
 <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px">
  <div style="background:var(--surface-1);border-radius:12px;padding:12px 14px"><div style="font-size:24px;font-weight:500">{ready}</div><div style="font-size:13px;color:var(--text-secondary)">effects ready</div></div>
  <div style="background:var(--surface-1);border-radius:12px;padding:12px 14px"><div style="font-size:24px;font-weight:500">{len(CAT["effects"]) - ready}</div><div style="font-size:13px;color:var(--text-secondary)">in progress</div></div>
  <div style="background:var(--surface-1);border-radius:12px;padding:12px 14px"><div style="font-size:24px;font-weight:500">{len(CAT["formats"])}</div><div style="font-size:13px;color:var(--text-secondary)">formats</div></div></div>
 <div style="display:flex;gap:6px;flex-wrap:wrap" role="group" aria-label="Filter the library">{chips}</div>
 <div data-grid {grid}>{"".join(card(e, "fx") for e in CAT["effects"])}{"".join(card(e, "fmt") for e in CAT["formats"])}</div>
</div>
<script>{(LIB/"library.js").read_text()}</script>'''
out = LIB/"library.html"; out.write_text(page)
print(f"{out}  {len(page)//1024} KB  ({len(have & {d for e in CAT['effects'] + CAT['formats'] for d in e.get('test_draft', [])})} test drafts found)")

# --preview: the same page outside the chat, with the chat's colors stood in and Add shown instead of sent.
if "--preview" in sys.argv:
    shim = '''<!doctype html><meta charset="utf-8"><title>CineYap Library preview</title>
<style>:root{--surface-0:#f5f4ef;--surface-1:#f5f4ef;--surface-2:#fff;--border:rgba(0,0,0,.1);--border-strong:rgba(0,0,0,.2);
--text-primary:#1f1e1d;--text-secondary:#5e5d59;--text-muted:#8a8984;--text-danger:#a32d2d;--text-success:#3b6d11;--text-warning:#854f0b;
--bg-success:#eaf3de;--bg-warning:#faeeda;--font-voice:Georgia,serif;font-family:-apple-system,system-ui,sans-serif}
body{max-width:680px;margin:24px auto;padding:0 16px;color:var(--text-primary);background:#fff}
button{font:inherit;background:transparent;border:0.5px solid var(--border-strong);border-radius:8px;height:32px;cursor:pointer;color:inherit}
input{font:inherit;height:32px;border:0.5px solid var(--border-strong);border-radius:8px;padding:0 8px}.sr-only{position:absolute;left:-9999px}
#sent{position:sticky;bottom:12px;background:#1f1e1d;color:#fff;padding:10px 14px;border-radius:12px;font-size:13px;white-space:pre-wrap}#sent:empty{display:none}</style>
<script>function sendPrompt(t){document.getElementById("sent").textContent="Would send to Claude:\\n"+t}</script>
'''
    (LIB/"library-preview.html").write_text(shim + page + '<div id="sent"></div>')
    print(LIB/"library-preview.html")
