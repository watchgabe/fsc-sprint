#!/usr/bin/env python3
"""mkpanel.py — the talking-head + top-panel format, as a 1080x1920 CapCut draft with editable text.

    ./vu-py cineyap/mkpanel.py <job>

Takes a finished CineYap cut (edit/edl.json + build/words_out.json) and lays it out the way the trend
does: the talking head full frame with the eyes near centre, a media panel at the top that swaps
pictures through the whole video, a hook title sitting on the panel's bottom edge for the first few
seconds, and simple two-line captions in the bottom third. Every number is in the style pack's
"panel" block, measured off reference screenshots.

projects/<job>/panel/panel.json (written with defaults the first time, then edit it):
  hook   {"title", "sub", "seconds", "style": "plain" | "box"}
  media  one entry per beat: {"beat", "t0", "t1", "layout": "triptych" | "wide", "clips": [...]}
         clips are paths relative to broll_clips (or absolute). Triptych takes 3, wide takes 1.

Panel media is pre-cut to the panel's exact shape (panel/media/), so it drops into CapCut as a plain
clip: no crop settings for CapCut to reinterpret.
"""
import json, pathlib, random, re, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
sys.path.insert(0, str(PKG/"helpers"))
import config

if len(sys.argv) < 2: sys.exit("usage: mkpanel.py <job>")
job = sys.argv[1]; JOB = PROJECTS/job; B = JOB/"build"; P = JOB/"panel"; P.mkdir(exist_ok=True); (P/"media").mkdir(exist_ok=True)
sty = __import__("style").load()
PN  = sty["panel"]; W, H = PN["canvas"]; FPS = 24000/1001
edl = json.load(open(JOB/"edit/edl.json")); words = json.load(open(B/"words_out.json"))
stem = list(edl["sources"])[0]; SRC4K = B/"graded_source_4k.mp4"
SRC = SRC4K if SRC4K.exists() else B/"graded_source.mp4"

def probe(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
        "stream=width,height,nb_frames:format=duration","-of","json",str(p)], capture_output=True, text=True).stdout)
    s = d["streams"][0]; return int(s["width"]), int(s["height"]), float(d["format"]["duration"])
def frames(p):
    return int(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-count_frames","-show_entries",
        "stream=nb_read_frames","-of","csv=p=0",str(p)], capture_output=True, text=True).stdout.strip())

# ---- the A-roll cut, frame-exact like mkcapcut.py
segs, t = [], 0
for i, r in enumerate(edl["ranges"]):
    n = frames(JOB/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4")
    segs.append({"t0": t/FPS, "t1": (t+n)/FPS, "s0": r["start"], "s1": r["start"]+n/FPS}); t += n
TOTAL = t/FPS

# ---- framing: eyes near centre, from Apple Vision face landmarks on a frame of the first take
import Vision, Quartz
from Foundation import NSURL
fr = P/"_face.png"
subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{(segs[0]['s0']+segs[0]['s1'])/2:.2f}","-i",str(SRC),"-frames:v","1",str(fr)], check=True)
img = Quartz.CGImageSourceCreateImageAtIndex(Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(fr)), None), 0, None)
req = Vision.VNDetectFaceLandmarksRequest.alloc().init()
Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None).performRequests_error_([req], None)
faces = req.results() or []
if faces:
    f = max(faces, key=lambda o: o.boundingBox().size.width * o.boundingBox().size.height); bb = f.boundingBox()
    ex = bb.origin.x + bb.size.width/2
    ey = 1 - (bb.origin.y + bb.size.height*0.62)          # eyes sit ~62% up the face box (Vision's origin is bottom-left)
else:
    ex, ey = 0.5, 0.40; print("  NOTE: no face found on the first take - framing at the centre")
cw, ch, _ = probe(SRC)
fit, fill = min(W/cw, H/ch), max(W/cw, H/ch)
EY = PN["eyes_y"]
need = max(1.0, EY/ey, (1-EY)/(1-ey))                               # zoom that would move the eyes with no gap
z = min(need, float(PN.get("max_zoom", 1.15)))
BLUR = need > z + 1e-6                                              # a tight close-up: stop zooming, fill the gap with blur
dispW, dispH = cw*fill*z, ch*fill*z
dx = -(ex-0.5)*dispW; dx = max(-(dispW-W)/2, min((dispW-W)/2, dx))  # centre the face, never past an edge
dy = (EY*H) - (H/2 + (ey-0.5)*dispH)
AR = {"scale": fill/fit*z, "tx": dx/(W/2), "ty": -dy/(H/2)}
print(f"  framing: eyes found at ({ex:.2f},{ey:.2f}) of the source -> {EY:.2f} of the frame, zoom {z:.2f}"
      + (f" (needed {need:.2f}: background blur fills the top {dy/H:.0%})" if BLUR else ""))

# ---- panel.json: defaults the first time
cfg_path = P/"panel.json"
if cfg_path.exists(): cfg = json.load(open(cfg_path))
else:
    first = " ".join(w[2] for w in words if w[0] < 5.0)
    cfg = {"hook": {"title": "", "sub": "", "seconds": PN["hook_s"], "style": "plain",
                    "_note": "Hooks go through the Hook Engine. Title: 3-6 words. Sub: a short (parenthetical)."},
           "media": []}
    print(f"  wrote {cfg_path.name}: fill in hook.title / hook.sub (the take opens: {first[:80]!r})")
hook = cfg["hook"]; HOOK_S = float(hook.get("seconds", PN["hook_s"]))

# beats: the hook is one beat; after it, each take, split when longer than beat_max_s
if not cfg["media"]:
    beats = [{"beat": 1, "t0": 0.0, "t1": HOOK_S, "layout": "triptych", "clips": []}]
    for s in segs:
        a, b = max(s["t0"], HOOK_S), s["t1"]
        if b - a < 0.5: continue
        n = max(1, int((b - a) // PN["beat_max_s"]) + (1 if (b - a) % PN["beat_max_s"] > 2.0 else 0))
        for k in range(n):
            beats.append({"beat": len(beats)+1, "t0": round(a + (b-a)*k/n, 3), "t1": round(a + (b-a)*(k+1)/n, 3), "layout": "wide", "clips": []})
    cfg["media"] = beats

# media: inserts already chosen for content go to the beat they fall in; the rest from the library
roots = [pathlib.Path(r) for r in (config.opt("broll_clips"), config.opt("broll_root")) if r]
def resolve(c):
    p = pathlib.Path(c)
    if p.is_absolute() and p.exists(): return p
    for r in roots:
        if (r/c).exists(): return r/c
    return None
ins = json.load(open(B/"inserts.json")) if (B/"inserts.json").exists() else []
lib = []
cache = P/"library.json"
if cache.exists(): lib = json.load(open(cache))
else:
    for p in sorted(roots[0].rglob("*")):
        if p.suffix.lower() in (".mp4", ".mov") and not p.name.startswith("."):
            try: w_, h_, d_ = probe(p); lib.append({"clip": str(p.relative_to(roots[0])), "w": w_, "h": h_, "dur": d_})
            except Exception: pass
    cache.write_text(json.dumps(lib))
rng = random.Random(job)
fam = lambda c: pathlib.Path(c).stem.rsplit("_", 1)[0]
used = {fam(c) for b in cfg["media"] for c in b["clips"]}
for b in cfg["media"]:
    need = 3 if b["layout"] == "triptych" else 1
    for o in ins:
        if len(b["clips"]) >= need: break
        if b["t0"] - 0.5 <= o["t0"] < b["t1"] and str((B/o["file"]).resolve()) not in b["clips"]:
            b["clips"].append(str((B/o["file"]).resolve())); used.add(fam(o["clip"]))
    pool = [c for c in lib if c["dur"] >= (b["t1"]-b["t0"]) + 0.1 and c["w"] >= c["h"] and fam(c["clip"]) not in used]
    while len(b["clips"]) < need and pool:
        c = pool.pop(rng.randrange(len(pool))); b["clips"].append(c["clip"]); used.add(fam(c["clip"]))
cfg_path.write_text(json.dumps(cfg, indent=1, ensure_ascii=False))

# ---- panel geometry and pre-cut media
def rects(layout):
    if layout == "triptych":
        g = PN["triptych"]; side = ((g["x1"]-g["x0"]) - 2*g["gap"]) / 3 * W
        return [(round(g["x0"]*W + k*(side + g["gap"]*W)), round(g["y0"]*H), round(side), round(side)) for k in range(3)]
    g = PN["wide"]; return [(round(g["x0"]*W), round(g["y0"]*H), round((g["x1"]-g["x0"])*W), round((g["y1"]-g["y0"])*H))]
def precut(src, out, dur, w, h, start):
    if out.exists(): return
    w2, h2 = w + (w % 2), h + (h % 2)
    subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{start:.3f}","-t",f"{dur+0.1:.3f}","-i",str(src),"-an",
                    "-vf",f"scale={w2}:{h2}:force_original_aspect_ratio=increase,crop={w2}:{h2},fps=24000/1001,format=yuv420p",
                    "-c:v","libx264","-crf","17",str(out)], check=True)

# ---- the draft
import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, TextBackground, trange
from capcut_draft import start, finish, US
from gabe_carousel import censor
name = f"{job} (YapMaxxing)"
sf, dst = start(name, JOB, W, H)
for k, nm in enumerate(("A-roll", "Panel 1", "Panel 2", "Panel 3")): sf.add_track(draft.TrackType.video, nm, relative_index=k)
for k, nm in enumerate(("Hook", "Hook sub", "Captions"), 4): sf.add_track(draft.TrackType.text, nm, relative_index=k)

for s in segs:
    d = s["t1"] - s["t0"]
    vs = VideoSegment(str(SRC), trange(US(s["t0"]), US(d)), source_timerange=trange(US(s["s0"]), US(d)),
                      clip_settings=draft.ClipSettings(scale_x=AR["scale"], scale_y=AR["scale"],
                                                       transform_x=AR["tx"], transform_y=AR["ty"]))
    if BLUR: vs.add_background_filling("blur", blur=float(PN.get("fill_blur", 0.375)))
    sf.add_segment(vs, "A-roll")

report = []
for b in cfg["media"]:
    rs = rects(b["layout"]); dur = b["t1"] - b["t0"]
    for k, (x, y, w, h) in enumerate(rs):
        if k >= len(b["clips"]): report.append(f"beat {b['beat']}: no clip for panel {k+1}"); continue
        src = resolve(b["clips"][k])
        if not src: report.append(f"beat {b['beat']}: clip not found {b['clips'][k]}"); continue
        _, _, sd = probe(src); st = max(0.0, min(sd*0.4, sd - dur - 0.15))
        out = P/"media"/f"b{b['beat']:02d}_{k+1}_{w}x{h}_{src.stem[:24]}.mp4"
        precut(src, out, dur, w, h, st)
        mw, mh, md = probe(out); dd = min(dur, md - 0.05)
        sc = w / (mw * min(W/mw, H/mh))                           # CapCut contain-fits the clip, then scales
        cx, cy = x + w/2, y + h/2
        sf.add_segment(VideoSegment(str(out), trange(US(b["t0"]), US(dd)), source_timerange=trange(0, US(dd)),
                       clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc, transform_x=(cx - W/2)/(W/2), transform_y=(H/2 - cy)/(H/2))),
                       f"Panel {k+1}")

# ---- text
unit = float(sty["carousel"]["capcut"].get("px_per_unit_1920w", 11.1)) * (W/1920)
from PIL import ImageFont, ImageDraw, Image
import os
_f = lambda px: ImageFont.truetype(os.path.expanduser(sty["fonts"]["sans"]), max(4, int(px)), index=int(sty["fonts"].get("sans_index", 0)))
_d = ImageDraw.Draw(Image.new("RGB", (8, 8)))
def width(text, px): return _d.textlength(text, font=_f(px)) - 0.035*px*max(0, len(text)-1)
WHITE, BLACK = (1.0, 1.0, 1.0), (0.0, 0.0, 0.0)
fonts, shadowed = {}, set()
def text(track, s, t0, t1, px, cy, color=WHITE, box=False, shadow=True):
    st = TextStyle(size=round(px/unit, 2), color=color, align=1, letter_spacing=-1, auto_wrapping=False, max_line_width=0.95)
    bg = TextBackground(color="#FFFFFF", style=1, alpha=1.0, round_radius=0.35) if box else None
    seg = TextSegment(s, trange(US(t0), US(t1-t0)), style=st, background=bg,
                      clip_settings=draft.ClipSettings(transform_y=(H/2 - cy*H)/(H/2)))
    sf.add_segment(seg, track); fonts[seg.material_id] = False
    if shadow: shadowed.add(seg.material_id)

if hook.get("title"):
    tri = rects("triptych" if cfg["media"] and cfg["media"][0]["layout"] == "triptych" else "wide")
    edge = (tri[0][1] + tri[0][3]) / H                                   # the title sits ON the panel's bottom edge
    tpx = PN["title"]["px"]; tw = width(hook["title"], tpx)
    if tw > PN["title"]["max_w"]*W: tpx *= PN["title"]["max_w"]*W/tw
    box = hook.get("style") == "box"
    text("Hook", censor(hook["title"]), 0.0, HOOK_S, tpx, edge, color=BLACK if box else WHITE, box=box, shadow=not box)
    if hook.get("sub"):
        text("Hook sub", censor(hook["sub"]), 0.0, HOOK_S, PN["sub"]["px"], edge + PN["sub"]["below"])

# captions: two-line groups, broken on pauses and sentence ends
C = PN["captions"]; groups, cur = [], []
for i, w in enumerate(words):
    cur.append(w)
    nxt = words[i+1] if i+1 < len(words) else None
    chars = sum(len(x[2])+1 for x in cur)
    if (nxt is None or nxt[0] - w[1] > C["pause_s"] or w[2][-1:] in ".?!" or
        chars + len(nxt[2]) > 2*C["chars_per_line"]):
        groups.append(cur); cur = []
for gi, g in enumerate(groups):
    ws = [x[2] for x in g]; best, cut = None, 1
    for k in range(1, len(ws)):
        a, b = " ".join(ws[:k]), " ".join(ws[k:])
        if len(a) <= C["chars_per_line"]+4 and len(b) <= C["chars_per_line"]+4:
            sc_ = abs(len(a) - len(b))
            if best is None or sc_ < best: best, cut = sc_, k
    lines = [" ".join(ws)] if len(" ".join(ws)) <= C["chars_per_line"] or len(ws) < 2 else [" ".join(ws[:cut]), " ".join(ws[cut:])]
    t0 = g[0][0]; t1 = groups[gi+1][0][0] if gi+1 < len(groups) else min(TOTAL, g[-1][1] + 0.4)
    t1 = min(t1, g[-1][1] + 0.8)
    if t1 - t0 < 0.08: continue
    px = C["px"]; widest = max(width(l, px) for l in lines)
    if widest > C["max_w"]*W: px *= C["max_w"]*W / widest
    cy = C["y"] + (C["pitch"]/2 if len(lines) == 2 else 0)
    text("Captions", censor("\n".join(lines)), t0, t1, px, cy)

res = finish(sf, dst, name, W, H, US(TOTAL), sty, text_fonts=fonts, left_inset=None)

# shadow: CapCut stores it on the text material (has_shadow + shadow_*), off by default. Fields copied
# from CapCut's own drafts; values from the pack.
sh = PN["shadow"]
for fn in ("draft_info.json", "draft_content.json"):
    jj = json.loads((dst/fn).read_text())
    for tm in jj["materials"]["texts"]:
        if tm["id"] in shadowed:
            tm.update({"has_shadow": True, "shadow_color": sh["color"], "shadow_alpha": sh["alpha"],
                       "shadow_smoothing": sh["smoothing"], "shadow_distance": sh["distance"], "shadow_angle": sh["angle"]})
    (dst/fn).write_text(json.dumps(jj, ensure_ascii=False))

print(f"\n{name}")
print(f"  {TOTAL:.1f}s · {len(segs)} A-roll clips · {len(cfg['media'])} panel beats · {len(groups)} caption groups · canvas {W}x{H}")
print(f"  A-roll source: {SRC.name}")
for r in report: print("  !", r)
print(f"  draft: {dst}\n  edit panel/panel.json to change the hook or swap any beat's clips, then run this again")
