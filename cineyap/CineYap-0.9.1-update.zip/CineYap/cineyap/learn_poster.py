#!/usr/bin/env python3
"""learn_poster.py — read a poster draft you adjusted in CapCut back into the style pack.

    ./vu-py cineyap/learn_poster.py <job> [--vertical] [--check]

Move or resize any poster line in CapCut (the headline, the corners), quit CapCut so it saves, then run
this. Each text track (Headline L1..R2, Corner left, Corner right) is read for its size, position and
edge, and the pack's "poster" (or "poster_vertical") block is updated, so the next build of any video
in this format comes out the way you set it. Scale you applied in CapCut is folded into the size.

The edges are computed back through the same box factor the builder uses, so a rebuild reproduces your
draft exactly.
"""
import json, os, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG
import config

args = [a for a in sys.argv[1:] if not a.startswith("--")]
if not args: sys.exit("usage: learn_poster.py <job> [--vertical] [--check]")
job, VERT, CHECK = args[0], "--vertical" in sys.argv, "--check" in sys.argv
_alt = os.environ.get("CINEYAP_DRAFTS")
DRAFTS = pathlib.Path(_alt) if _alt else pathlib.Path.home()/"Movies/CapCut/User Data/Projects/com.lveditor.draft"
D = DRAFTS/f"{job} (Poster{' Vertical' if VERT else ''})"
if not (D/"draft_info.json").exists(): sys.exit(f"no draft at {D}")
PACK = PKG/"cineyap/styles"/f"{config.opt('look', 'gabe')}.json"
pack = json.loads(PACK.read_text()); key = "poster_vertical" if VERT else "poster"; PS = pack[key]

j = json.load(open(D/"draft_info.json")); W, H = j["canvas_config"]["width"], j["canvas_config"]["height"]
unit = float(pack["carousel"]["capcut"].get("px_per_unit_1920w", 11.1)) * (W/1920)
k = (1674.0/643.0) * (W/1920.0)
mats = {t["id"]: t for t in j["materials"]["texts"]}
got = {}
for tr in j["tracks"]:
    if tr["type"] != "text" or not tr.get("segments"): continue
    sg = tr["segments"][0]; m = mats[sg["material_id"]]; c = json.loads(m["content"])
    sc = sg["clip"]["scale"]["x"]; px = c["styles"][0]["size"] * unit * sc
    y = (H/2 - sg["clip"]["transform"]["y"]*H/2) / H
    cx = W/2 + sg["clip"]["transform"]["x"]*W/2; fw = m.get("fixed_width", -1)
    box = fw * k * sc if fw and fw > 0 else None
    al = m.get("alignment")
    edge = (cx - box/2 if al == 0 else cx + box/2) / W if box and al in (0, 2) else None
    got[tr.get("name", "")] = {"px": round(px, 1), "y": round(y, 4), "edge": edge and round(edge, 4), "lines": c["text"].count("\n") + 1, "align": al}

changes = []
def setv(block, field, new):
    old = block.get(field)
    if old != new and new is not None:
        changes.append(f"{field:10} {old} -> {new}"); block[field] = new
HL = PS["headline"]
L = got.get("Headline L1") or got.get("Headline L2"); R = got.get("Headline R1") or got.get("Headline R2")
if L:
    setv(HL, "px", L["px"]); setv(HL, "left_x", L["edge"])
    rows = [got[n]["y"] for n in ("Headline L1", "Headline L2") if n in got]
    if len(rows) == 2: setv(HL, "rows_y", rows)
if R: setv(HL, "right_x", R["edge"])
CR = PS.get("corners", {})
if "Corner left" in got:
    g = got["Corner left"]; b = CR.setdefault("left", {}); setv(b, "px", g["px"]); setv(b, "x", g["edge"]); setv(b, "y", g["y"]); setv(b, "align", g["align"])
if "Corner right" in got:
    g = got["Corner right"]; b = CR.setdefault("right", {})
    old_px = b.get("px", g["px"]); pitch = round(b.get("pitch", 0.028) * g["px"] / old_px, 4)
    setv(b, "px", g["px"]); setv(b, "x", g["edge"]); setv(b, "pitch", pitch); setv(b, "align", g["align"])
    setv(b, "y_last", round(g["y"] + pitch * (g["lines"] - 1) / 2, 4))   # the block is centred on y; store its last line

print(f"{D.name}: {len(got)} poster lines read")
print("\n".join("  " + c for c in changes) if changes else "  nothing differs from the pack")
if changes and not CHECK:
    PACK.write_text(json.dumps(pack, indent=2, ensure_ascii=False) + "\n"); print(f"  {key} updated in {PACK.name}")
