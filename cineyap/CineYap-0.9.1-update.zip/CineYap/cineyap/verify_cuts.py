#!/usr/bin/env python3
"""verify_cuts.py — read the finished CapCut draft and prove there are no frame-to-frame triple switches.

    verify_cuts.py <job>          exit 0 = clean, exit 1 = lists every violation with its timestamp

Reads what CapCut will actually play, not the plan. Three checks:
  1. NEAR-MISS   a B-roll or card-plate edge within `rules.cut_snap_frames` of an A-roll cut but not ON it
  2. STYLE LAG   a caption whose style (big/centred vs small/left) disagrees with the picture under it
                 for more than one frame: big over A-roll, or small over B-roll / a plate
  3. TRIPLE      three or more visible switches (picture change or caption style change) inside 6 frames
Run it after every CapCut build. A draft that fails this does not go to the member.
"""
import json, os, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG
import config

if len(sys.argv) < 2: sys.exit("usage: verify_cuts.py <job>")
job = sys.argv[1]
_alt = os.environ.get("CINEYAP_DRAFTS")
DRAFTS = pathlib.Path(_alt) if _alt else pathlib.Path.home()/"Movies/CapCut/User Data/Projects/com.lveditor.draft"
D = DRAFTS/(f"{job} (CineYap 4x3)" if "--4x3" in sys.argv else f"{job} (CineYap)")
j = json.load(open(D/"draft_info.json"))
sty = __import__("style").load()
FPS = float(j.get("fps") or 24000/1001); F = 1/FPS
SNAP = float(sty.get("rules", {}).get("cut_snap_frames", 12)) * F
TRIPLE = 6 * F

def spans(name):
    for t in j["tracks"]:
        if t.get("name") == name:
            return [(s["target_timerange"]["start"]/1e6, (s["target_timerange"]["start"]+s["target_timerange"]["duration"])/1e6, s)
                    for s in t["segments"]]
    return []
aroll, broll, cards, caps = spans("A-roll"), spans("B-roll"), spans("Cards") + spans("Background"), spans("Captions")
subject = spans("Subject")          # text-behind-subject lines: big captions over A-roll on purpose
texts = {t["id"]: t for t in j["materials"]["texts"]}
if not aroll: sys.exit(f"{job}: the draft has no A-roll - the build failed, nothing to verify")
cuts = sorted({round(b, 4) for _, b, _ in aroll[:-1]})
END = max(b for _, b, _ in aroll)

def picture(t):
    if any(a <= t < b for a, b, _ in subject): return "behind"
    if any(a <= t < b for a, b, _ in cards): return "card"
    if any(a <= t < b for a, b, _ in broll): return "broll"
    return "aroll"
def cap_style(s):
    """a caption's look: alignment, size and height. The style a picture type should carry is LEARNED from
    this draft (the look most captions over it have), so any caption style works: the pack's left/centre
    pair, the Interrogator tiers, a member's own."""
    m = texts[s["material_id"]]
    try: size = json.loads(m["content"])["styles"][0].get("size")
    except Exception: size = m.get("font_size")
    return (m.get("alignment"), round(float(size or 0), 1), round(float(s["clip"]["transform"]["y"]), 2))
from collections import Counter
_seen = {}
for a_, b_, s_ in caps:
    mids = {picture(a_ + (b_ - a_) * f) for f in (0.25, 0.5, 0.75)}
    if len(mids) == 1: _seen.setdefault(mids.pop(), Counter())[cap_style(s_)] += 1
WANT = {k: c.most_common(1)[0][0] for k, c in _seen.items() if c}

bad = []
# 1. near-misses
for name, sp in (("B-roll", broll), ("card", cards)):
    for a, b, _ in sp:
        for edge, lab in ((a, "in"), (b, "out")):
            c = min(cuts + [0.0, END], key=lambda x: abs(x - edge)); d = abs(c - edge)
            if F * 0.5 < d <= SNAP:
                bad.append((edge, f"NEAR-MISS  {name} {lab} at {edge:.3f} is {d*FPS:.1f} frames from the A-roll cut at {c:.3f}"))
# 2. style lag, sampled at every frame each caption covers (beyond its first frame)
for a, b, s in caps:
    want_small = None; lag = 0; first = None
    t = a + F
    while t < b - 1e-6:
        pic = picture(t); st = cap_style(s)
        # wrong = this caption carries the look another picture type owns, while this picture has its own look
        wrong = pic in WANT and st != WANT[pic] and any(st == v for k, v in WANT.items() if k != pic)
        if wrong:
            lag += 1; first = first if first is not None else t
        t += F
    if lag >= 1:
        txt = json.loads(texts[s["material_id"]]["content"])["text"]
        owner = next((k for k, v in WANT.items() if v == cap_style(s)), "?")
        bad.append((first, f"STYLE LAG  {txt!r} has the {owner} look over {picture(first)} for {lag} frame(s) from {first:.3f}"))
# 3. triples
events = sorted({round(x, 4) for x in cuts} | {round(x, 4) for a, b, _ in broll + cards for x in (a, b)} |
                {round(a, 4) for i, (a, b, s) in enumerate(caps) if i and cap_style(s) != cap_style(caps[i-1][2])})
for i in range(len(events) - 2):
    if events[i+2] - events[i] < TRIPLE - 1e-6:
        bad.append((events[i], f"TRIPLE     switches at {events[i]:.3f}, {events[i+1]:.3f}, {events[i+2]:.3f} (inside 6 frames)"))

# 4. EYE JUMP (with --eyes): the exact frames either side of every A-roll cut, given the draft's own
# zoom and position (CapCut was measured to follow: scale about centre, then up by p/2 of the height),
# run through the face finder. A cut whose eye line moves more than 3% of the frame height fails.
if "--eyes" in sys.argv:
    import subprocess, numpy as np, cv2
    SRC = PKG/"projects"/job/"build"/"base_clean.mp4"; W2, H2 = 960, 540
    fd = cv2.FaceDetectorYN.create(str(PKG/"cineyap/models/face_detection_yunet_2023mar.onnx"), "", (W2, H2), 0.6)
    def frame(n):
        raw = subprocess.run(["ffmpeg","-v","error","-i",str(SRC),"-vf",f"select=eq(n\\,{n}),scale={W2}:{H2}","-frames:v","1",
                              "-f","rawvideo","-pix_fmt","bgr24","-"], capture_output=True).stdout
        return np.frombuffer(raw, np.uint8).reshape(H2, W2, 3)
    def kf(seg, prop, off, d):
        for k in seg.get("common_keyframes", []):
            if k["property_type"] == prop:
                pts = sorted((p["time_offset"]/1e6, p["values"][0]) for p in k["keyframe_list"])
                return float(np.interp(off, [a for a, _ in pts], [v for _, v in pts]))
        return d
    def eye(img, S, p):
        M = np.float32([[S, 0, (1-S)*W2/2], [0, S, (1-S)*H2/2 - p/2*H2]])
        _, f = fd.detect(cv2.warpAffine(img, M, (W2, H2)))
        if f is None or not len(f): return None
        f = max(f, key=lambda r: r[2]*r[3]); return (f[5]+f[7])/2/H2
    jumps = []
    for (a0, a1, sa), (b0, b1, sb) in zip(aroll, aroll[1:]):
        if picture(b0 + F/2) != "aroll" or picture(b0 - F/2) != "aroll": continue     # covered cut: no jump to see
        na = round(b0 / F); nb = na - 1
        e1 = eye(frame(nb), kf(sa,"KFTypeScaleX",nb*F-a0,1.0), kf(sa,"KFTypePositionY",nb*F-a0,0.0))
        e2 = eye(frame(na), kf(sb,"KFTypeScaleX",na*F-b0,1.0), kf(sb,"KFTypePositionY",na*F-b0,0.0))
        if e1 is None or e2 is None: continue
        jumps.append(abs(e2 - e1))
        if abs(e2 - e1) > 0.03: bad.append((b0, f"EYE JUMP   at the cut {b0:.3f}: eyes move {abs(e2-e1)*100:.1f}% of the frame height"))
    if jumps: print(f"  eye line across {len(jumps)} visible cuts: mean jump {np.mean(jumps)*100:.1f}%, worst {max(jumps)*100:.1f}%")

print(f"{job}: {len(cuts)} A-roll cuts, {len(broll)} B-roll, {len(cards)} plates, {len(caps)} captions @ {FPS:.3f}fps")
if not bad:
    print("  CLEAN - no near-misses, no style lag, no triples"); sys.exit(0)
for _, m in sorted(bad): print("  " + m)
print(f"  {len(bad)} violation(s)"); sys.exit(1)
