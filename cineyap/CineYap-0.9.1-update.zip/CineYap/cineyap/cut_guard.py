#!/usr/bin/env python3
"""cut_guard.py — no two hard cuts within a few frames of each other.

A card plate follows the spoken word and a B-roll insert follows its region, so either can end one or
two frames before an A-roll cut. On screen that is two hard cuts in a row, which reads as a mistake.
Run from the job's build/ directory, before mkcapcut / mkxml / composite:

    cut_guard.py            snap and report
    cut_guard.py --check    report only, change nothing

Rules (numbers from the style pack's "rules" block):
  cut_snap_frames  an overlay edge within this many frames of an A-roll cut is moved ONTO the cut
  cut_warn_s       any two edges still closer than this are listed, because only the plan can fix them

Writes inserts.json in place (backup inserts.json.bak) and plates.json, the card-plate spans with their
snapped edges, which mkcapcut.py reads instead of re-deriving plates from the cues.
"""
import json, pathlib, shutil, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG
import config

B = pathlib.Path.cwd(); JOB = B.parent
if not (JOB/"edit/edl.json").exists(): sys.exit("run this from the job's build/ directory")
check = "--check" in sys.argv
sty   = __import__("style").load()
rules = sty.get("rules", {})
FPS   = float(sty.get("fps", 24000/1001)) if "fps" in sty else 24000/1001
SNAP  = float(rules.get("cut_snap_frames", 12)) / FPS
WARN  = float(rules.get("cut_warn_s", 1.0))

edl  = json.load(open(JOB/"edit/edl.json"))
ins  = json.load(open(B/"inserts.json.bak" if (B/"inserts.json.bak").exists() else B/"inserts.json")) if (B/"inserts.json").exists() else []
cues = json.load(open(B/"cues.json.bak" if (B/"cues.json.bak").exists() else B/"cues.json")) if (B/"cues.json").exists() else []

# ---- THE BOARD'S CHOICES (build/effects.json, written by apply_board.py), applied to the pristine plan
# before anything else, so they survive every rebuild. B-roll ids and card ids are positional, in the
# same order the Board numbered them.
EFX = json.load(open(B/"effects.json")) if (B/"effects.json").exists() else {}
BR = EFX.get("broll", {})
_spans, _t = [], 0.0
for r in edl["ranges"]: _spans.append((_t, _t + r["end"] - r["start"])); _t += r["end"] - r["start"]
for i, o in enumerate(ins): o["id"] = f"b{i+1}"          # permanent ids: the plan's own order, never renumbered
for bid, sw in (BR.get("swap") or {}).items():
    for o in ins:
        if o["id"] == bid: o.update(file=sw["file"], clip=sw["clip"], asset_in=0.0, asset_dur=sw["asset_dur"], board=True)
_drop = set(BR.get("remove") or [])
ins = [o for o in ins if o["id"] not in _drop]
# Adds on a line share the part of the line NO B-roll covers yet, in the order they were added. Laying
# each over the whole line stacked clips on one track, which CapCut refuses.
_byline = {}
for n, a in enumerate(BR.get("add") or [], 1):
    if f"add{n}" not in _drop: _byline.setdefault(int(a["take"]) - 1, []).append((n, a))
for k, adds in sorted(_byline.items()):
    if not (0 <= k < len(_spans)): continue
    L0, L1 = _spans[k]; free, cur = [], L0
    for o in sorted([o for o in ins if o["t1"] > L0 and o["t0"] < L1], key=lambda o: o["t0"]):
        if o["t0"] > cur: free.append((cur, o["t0"]))
        cur = max(cur, o["t1"])
    if cur < L1: free.append((cur, L1))
    free = [f for f in free if f[1] - f[0] >= 0.5]
    if not free: print(f"  NOTE: line {k+1} is already covered by B-roll - {len(adds)} added clip(s) skipped"); continue
    a0, a1 = max(free, key=lambda f: f[1] - f[0]); step = (a1 - a0) / len(adds)
    for j, (n, a) in enumerate(adds):
        t0 = a0 + j * step; t1 = min(t0 + step, t0 + a["asset_dur"] - 0.05)
        ins.append({"file": a["file"], "t0": round(t0, 3), "t1": round(t1, 3), "asset_in": 0.0, "asset_dur": a["asset_dur"],
                    "clip": a["clip"], "why": "added on the Board", "board": True, "id": f"add{n}"})
ins.sort(key=lambda o: o["t0"])
if True:                                        # card ids, permanent like the B-roll ids
    groups, cur = [], None
    for i, c in enumerate(sorted(range(len(cues)), key=lambda j: cues[j]["t"])):
        q = cues[c]
        if not q.get("colour"): continue
        if cur and q["colour"] == cues[cur[-1]]["colour"] and q["t"] - cues[cur[-1]]["t"] < 1.0: cur.append(c)
        else:
            if cur: groups.append(cur)
            cur = [c]
    if cur: groups.append(cur)
    for gi, g in enumerate(groups):
        for c in g: cues[c]["card"] = f"c{gi+1}"
    drop, extra = set(), []
    for cid, ov in (EFX.get("cards") or {}).items():
        gi = int(cid[1:]) - 1
        if not (0 <= gi < len(groups)): continue
        g = groups[gi]
        if ov.get("remove"):
            for c in g: cues[c].update(kind="small", colour=None, serif=False)
            continue
        col = ov.get("colour") or cues[g[0]]["colour"]; words = ov.get("words") or [cues[c]["text"] for c in g]
        acc = set(ov.get("accent") or [])
        if len(words) == len(g):
            for j, c in enumerate(g): cues[c].update(text=words[j], colour=col, serif=j in acc)
        else:                                   # different word count: spread the new words over the card's time
            t0, t1 = cues[g[0]]["t"], cues[g[-1]]["t"] + 0.3; base = dict(cues[g[0]]); drop |= set(g)
            for j, w in enumerate(words):
                extra.append(dict(base, t=round(t0 + (t1 - t0) * j / len(words), 3), text=w, colour=col, serif=j in acc))
    cues = sorted([c for i, c in enumerate(cues) if i not in drop] + extra, key=lambda c: c["t"])
if BR or EFX.get("cards"): print(f"  board: {len(BR.get('swap') or {})} swap, {len(_drop)} removed, {len(BR.get('add') or [])} added, {len(EFX.get('cards') or {})} card edit(s)")

# ---- ONE CLOCK. The plan (edl.json) is in seconds; each rendered A-roll clip is a whole number of
# frames, so the real picture drifts ahead of the plan (+3 frames by 31s, +7.6 by 89s on ladder-test).
# B-roll, plates and captions were placed on the plan's clock and the picture cut on the rendered
# one: every cut became plate -> old A-roll -> new A-roll. So the cuts come from the rendered clips,
# and every overlay and caption time is remapped onto that clock before any rule runs.
import subprocess
stem = pathlib.Path(list(edl["sources"].values())[0]).stem
def nframes(f):
    out = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=nb_frames",
                          "-of","csv=p=0",str(f)], capture_output=True, text=True).stdout.strip()
    return int(out) if out.isdigit() else None
E, C = [0.0], [0.0]                       # plan-clock and picture-clock segment starts
for i, r in enumerate(edl["ranges"]):
    n = nframes(JOB/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4")
    E.append(E[-1] + (r["end"] - r["start"]))
    C.append(C[-1] + (n / FPS if n else (r["end"] - r["start"])))
def remap(t):
    for i in range(len(E) - 1):
        if E[i] <= t < E[i+1] or i == len(E) - 2:
            return round(C[i] + min(t - E[i], C[i+1] - C[i]), 4)
cuts = [round(c, 4) for c in C]
END = cuts[-1]
drift = (C[-1] - E[-1]) * FPS
for o in ins: o["t0"], o["t1"] = remap(o["t0"]), remap(o["t1"])
for c in cues: c["t"] = remap(c["t"])

def nearest(x):
    c = min(cuts, key=lambda q: abs(q - x)); return c, abs(c - x)

moved, log = 0, []
def snap(label, obj, key):
    global moved
    c, d = nearest(obj[key])
    if 0 < d <= SNAP:
        log.append(f"  {label} {key} {obj[key]:7.3f} -> {c:7.3f}  ({d*FPS:.1f} frames from the cut)")
        obj[key] = c; moved += 1

HOLD = float(rules.get("cut_hold_s", 1.0))
def prev_cut(x): return max([c for c in cuts if c <= x], default=None)
def next_cut(x): return min([c for c in cuts if c >= x], default=None)
def hold(label, obj, room_before=None, room_after=None):
    """The editor's rule: an overlay that ENDS within HOLD of the next A-roll cut holds until the cut,
    one that STARTS within HOLD after the previous cut starts on it. room_* bound the move for a
    B-roll whose asset only has so much material; None means unbounded (a plate)."""
    global moved
    c = next_cut(obj["t1"]); d = (c - obj["t1"]) if c is not None else None
    if d is not None and 0 < d <= HOLD and (room_after is None or d <= room_after + 1e-6):
        log.append(f"  {label} held to the cut: end {obj['t1']:7.3f} -> {c:7.3f}  (+{d*FPS:.1f} frames)"); obj["t1"] = c; moved += 1
    elif d is not None and 0 < d <= HOLD:
        log.append(f"  {label} ends {d:.2f}s before the cut at {c:.3f} but the clip has only {room_after:.2f}s more - re-pick or shorten the region")
    c = prev_cut(obj["t0"]); d = (obj["t0"] - c) if c is not None else None
    if d is not None and 0 < d <= HOLD and (room_before is None or d <= room_before + 1e-6):
        log.append(f"  {label} pulled to the cut: start {obj['t0']:7.3f} -> {c:7.3f}  (-{d*FPS:.1f} frames)")
        if room_before is not None: obj["asset_in"] = round(obj.get("asset_in", 0.0) - d, 3)
        obj["t0"] = c; moved += 1

# B-roll inserts: snap the tiny misses, then hold to the cut where the asset has the material
for i, o in enumerate(ins, 1):
    snap(f"B-roll {i}", o, "t0"); snap(f"B-roll {i}", o, "t1")
    ain = o.get("asset_in", 0.0); adur = o.get("asset_dur")
    room_after = (adur - ain - (o["t1"] - o["t0"])) if adur else 0.0
    hold(f"B-roll {i}", o, room_before=ain, room_after=max(0.0, room_after))
    if o["t1"] <= o["t0"]: log.append(f"  B-roll {i} collapsed after snapping - check the plan")

# card plates: contiguous card cues of one colour, ending where the next caption starts
plates = []
for i, c in enumerate(cues):
    if c.get("kind") != "card": continue
    t0 = c["t"]; t1 = cues[i+1]["t"] if i+1 < len(cues) else END
    col = "green" if c.get("colour") == "green" else "cream"
    if plates and plates[-1]["colour"] == col and abs(plates[-1]["t1"] - t0) < 0.08: plates[-1]["t1"] = t1
    else: plates.append({"colour": col, "t0": t0, "t1": t1})
for i, p in enumerate(plates, 1):
    snap(f"card {i}", p, "t0"); snap(f"card {i}", p, "t1")
    hold(f"card {i}", p)

# captions: every caption boundary near an A-roll cut, a B-roll edge or a plate edge moves onto it. A
# caption change one frame off any of those is the third switch in a frame-to-frame triple. Tighter
# window than the overlays, because a word cannot drift far from the speech it belongs to.
CSNAP = float(rules.get("caption_snap_frames", 4)) / FPS
anchors = sorted(set(cuts) | {o["t0"] for o in ins} | {o["t1"] for o in ins} | {p["t0"] for p in plates} | {p["t1"] for p in plates})
# Only the ONE caption nearest each anchor moves, and only if the move keeps it at least a frame away
# from its neighbours. Two captions pulled onto the same instant would delete a word from the screen.
cmoved = 0
cues.sort(key=lambda c: c["t"])
for a in anchors:
    near = [(abs(c["t"] - a), i) for i, c in enumerate(cues) if 0 < abs(c["t"] - a) <= CSNAP]
    if not near: continue
    d, i = min(near)
    lo = cues[i-1]["t"] if i > 0 else -1e9
    hi = cues[i+1]["t"] if i+1 < len(cues) else 1e9
    if lo + 1/FPS <= a <= hi - 1/FPS:
        cues[i]["t"] = a; cmoved += 1
if cmoved: log.append(f"  {cmoved} caption boundary(ies) moved onto a cut or edge (within {CSNAP*FPS:.0f} frames, none dropped)")

# ---- THE RULE: caption style changes on exactly the frame the picture changes.
# A word spoken across a B-roll or plate edge used to keep its style until the next word, so the
# picture switched on the cut and the caption switched a few frames later: the triple switch Gabe
# sees in every editor. So every caption is re-typed from what is on screen at its start, and a
# caption that straddles an overlay edge is split there, big on one side and small on the other.
BGS = [(cuts[int(n)-1], cuts[int(n)], col) for n, col in (EFX.get("bg") or {}).items() if 0 < int(n) < len(cuts)]
# a tagged card or a full-screen hook covers its whole line too: captions split at its edges like a BG line
BGS += [(cuts[int(n)-1], cuts[int(n)], (v.get("plate") or "green")) for n, v in (EFX.get("card_tag") or {}).items() if v and 0 < int(n) < len(cuts)]
BGS += [(cuts[int(n)-1], cuts[int(n)], "green") for n, v in (EFX.get("hook") or {}).items() if v and 0 < int(n) < len(cuts)]
def overlay_at(t):
    for a, b, col in BGS:                      # a Board BG line is a plate for the whole line
        if a <= t < b: return ("card", col)
    for p in plates:
        if p["t0"] <= t < p["t1"]: return ("card", p["colour"])
    for o in ins:
        if o["t0"] <= t < o["t1"]: return ("big", None)
    return ("small", None)
overlay_edges = sorted({o["t0"] for o in ins} | {o["t1"] for o in ins} | {p["t0"] for p in plates} | {p["t1"] for p in plates}
                       | {a for a, _, _ in BGS} | {b for _, b, _ in BGS})
cues.sort(key=lambda c: c["t"])
split_cues, nsplit, retyped = [], 0, 0
for i, c in enumerate(cues):
    t0 = c["t"]; t1 = cues[i+1]["t"] if i+1 < len(cues) else END
    inside = [e for e in overlay_edges if t0 + 1/FPS <= e <= t1 - 1/FPS]
    parts = [t0] + inside
    for k, pt in enumerate(parts):
        d = dict(c); d["t"] = pt
        kind, col = overlay_at(pt)
        if d.get("kind") != kind or (col and d.get("colour") != col):
            if not (kind == "small" and d.get("kind") == "small"): retyped += 1
            d["kind"] = kind; d["colour"] = col
        if k: nsplit += 1
        split_cues.append(d)
cues[:] = split_cues
if nsplit or retyped: log.append(f"  captions: {nsplit} split at an overlay edge, {retyped} re-typed to match the picture")

# anything still too close: every edge against every other edge
edges = [(c, "A-roll cut") for c in cuts[1:-1]]
edges += [(o["t0"], f"B-roll {i} in") for i, o in enumerate(ins, 1)] + [(o["t1"], f"B-roll {i} out") for i, o in enumerate(ins, 1)]
edges += [(p["t0"], f"card {i} in") for i, p in enumerate(plates, 1)] + [(p["t1"], f"card {i} out") for i, p in enumerate(plates, 1)]
edges += [(c["t"], "caption") for c in cues]
edges.sort()
# a run of 3+ distinct switch instants inside the warn window is the thing Gabe sees; list those too
inst = sorted(set(round(e[0], 3) for e in edges))
runs = []
for i in range(len(inst)):
    k = i
    while k + 1 < len(inst) and inst[k+1] - inst[i] < WARN: k += 1
    if k - i >= 2: runs.append(inst[i:k+1])
runs = [r for n, r in enumerate(runs) if not (n and set(r) <= set(runs[n-1]))]
warn = []
same = lambda la, lb: la.rsplit(" ", 1)[0] == lb.rsplit(" ", 1)[0] and la != lb and "cut" not in la
for (a, la), (b, lb) in zip(edges, edges[1:]):
    if same(la, lb) or "caption" in (la, lb): continue   # captions change every word; only overlay/cut pairs warn
    if 0 < b - a < WARN: warn.append(f"  {la} at {a:.3f} and {lb} at {b:.3f} are {b-a:.2f}s apart")
for r in runs:
    if any(x in cuts or x in anchors for x in r):
        warn.append(f"  {len(r)} switches within {r[-1]-r[0]:.2f}s at {', '.join(f'{x:.2f}' for x in r)}")

print(f"cut guard: snap within {SNAP*FPS:.0f} frames, hold to the cut within {HOLD:g}s, warn under {WARN:g}s")
print(f"  plan -> picture clock: {drift:+.1f} frames of drift by the end, every time remapped")
print("\n".join(log) if log else "  nothing within the snap window")
if warn: print("  still close (fix in the plan, these are not auto-moved):"); print("\n".join(warn))
else:    print("  no two cuts closer than the warn window")
if not check:
    if True:
        if not (B/"inserts.json.bak").exists(): shutil.copy(B/"inserts.json", B/"inserts.json.bak")
        json.dump(ins, open(B/"inserts.json", "w"), indent=1)
    json.dump(plates, open(B/"plates.json", "w"), indent=1)
    if cmoved or nsplit or retyped:
        if not (B/"cues.json.bak").exists(): shutil.copy(B/"cues.json", B/"cues.json.bak")
        json.dump(cues, open(B/"cues.json", "w"), indent=1)
    print(f"  {moved} edge(s) moved; plates.json written ({len(plates)} plate(s))")
