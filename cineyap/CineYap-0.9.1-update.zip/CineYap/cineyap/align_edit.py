#!/usr/bin/env python3
"""align_edit.py — recover a finished edit's cut from its audio: which raw second each edit second came from.

    align_edit.py <edit.mp4> <raw_take> <out edl_exact.json>

The edit's audio is matched against the raw take's own audio (camera scratch audio is enough; the
clock is the raw video's): 0.75s windows every 0.25s, each found in the whole take by normalised
cross-correlation, consecutive windows with the same offset joined into one segment, and each edge
placed to 10 ms where the two neighbouring offsets stop and start fitting. Picture cuts are refined
later by copy_plan.py, which moves every visible camera cut onto the frame the picture changes.

Output rows: edit_t0, edit_t1, wav_t0, wav_t1 (wav_* = raw take time; the name is historical).
"""
import json, subprocess, sys, numpy as np

EDIT, RAW, OUT = sys.argv[1:4]
SR = 16000; HOPF = 160                     # features every 10 ms
FPS_F = SR // HOPF; WIN = int(1.5*FPS_F); HOP = int(0.25*FPS_F)

def aud(p):
    return np.frombuffer(subprocess.run(["ffmpeg","-v","error","-i",p,"-vn","-ac","1","-ar",str(SR),"-f","f32le","-"],
                                        capture_output=True).stdout, np.float32).astype(np.float64)
def feats(x):
    """log energy in 8 bands (150 Hz-5 kHz) every 10 ms, each band standardised: survives a different mic"""
    n = len(x) // HOPF; fr = x[:n*HOPF].reshape(n, HOPF) * np.hanning(HOPF)
    sp = np.abs(np.fft.rfft(fr, 512, axis=1))**2; f = np.fft.rfftfreq(512, 1/SR)
    edges = np.geomspace(150, 5000, 9)
    b = np.stack([np.log(sp[:, (f >= lo) & (f < hi)].sum(1) + 1e-9) for lo, hi in zip(edges, edges[1:])], 1)
    b = b - np.convolve(b.mean(1), np.ones(50)/50, "same")[:, None]        # drop slow level changes
    return (b - b.mean(0)) / (b.std(0) + 1e-9)
e_a, r_a = aud(EDIT), aud(RAW)
E, Rf = feats(e_a), feats(r_a)
print(f"  edit {len(e_a)/SR:.1f}s, raw {len(r_a)/SR:.1f}s")
N = 1 << int(np.ceil(np.log2(len(Rf) + WIN)))
RF = [np.fft.rfft(Rf[:, k], N) for k in range(Rf.shape[1])]
cs = np.r_[np.zeros((1, Rf.shape[1])), np.cumsum(Rf**2, 0)]
local = np.sqrt(np.maximum((cs[WIN:] - cs[:-WIN]).sum(1), 1e-9))
eng = np.log(np.convolve(e_a**2, np.ones(HOPF), "valid")[::HOPF] + 1e-12)[:len(E)]

rows = []
for s in range(0, len(E) - WIN, HOP):
    if np.median(eng[s:s+WIN]) < np.percentile(eng, 20): continue          # silence matches anything
    w = E[s:s+WIN]; nw = np.linalg.norm(w)
    cc = sum(np.fft.irfft(RF[k] * np.conj(np.fft.rfft(w[:, k], N)), N) for k in range(E.shape[1]))[:len(local)]
    sc = cc / (local * nw); k = int(np.argmax(sc))
    if sc[k] > 0.5: rows.append((s, k - s, float(sc[k])))
print(f"  {len(rows)} windows matched")

runs = []
for s, off, sc in rows:
    if runs and abs(off - runs[-1]["off"]) <= 2 and s - runs[-1]["s1"] <= 2*HOP:
        runs[-1]["s1"] = s + WIN; runs[-1]["n"] += 1; runs[-1]["offs"].append(off)
    else:
        runs.append({"s0": s, "s1": s + WIN, "off": off, "n": 1, "offs": [off]})
runs = [x for x in runs if x["n"] >= 2]
merged = []
for x in runs:
    x["off"] = int(np.median(x["offs"]))
    if merged and abs(x["off"] - merged[-1]["off"]) <= 2: merged[-1]["s1"] = x["s1"]
    else: merged.append(dict(x))
runs = merged

def fit(a, b, off):
    if a < 0 or b > len(E) or a + off < 0 or b + off > len(Rf) or b <= a: return -1
    x, y = E[a:b].ravel(), Rf[a+off:b+off].ravel()
    return float(np.dot(x, y) / (np.linalg.norm(x) * np.linalg.norm(y) + 1e-9))

edges = []
L = int(0.4*FPS_F)
for A, B in zip(runs, runs[1:]):
    lo, hi = max(A["s0"] + 1, A["s1"] - WIN), min(B["s1"] - 1, B["s0"] + WIN)
    if hi <= lo: hi = lo + 1
    best = max(range(lo, hi), key=lambda b: fit(b - L, b, A["off"]) + fit(b, b + L, B["off"]))
    edges.append(best)

segs = []
starts = [0] + edges; ends = edges + [len(E)]
for x, a, b in zip(runs, starts, ends):
    segs.append({"edit_t0": round(a/FPS_F, 3), "edit_t1": round(b/FPS_F, 3),
                 "wav_t0": round((a + x["off"])/FPS_F, 3), "wav_t1": round((b + x["off"])/FPS_F, 3)})
segs[-1]["edit_t1"] = round(len(e_a)/SR, 3); segs[-1]["wav_t1"] = round(segs[-1]["wav_t0"] + segs[-1]["edit_t1"] - segs[-1]["edit_t0"], 3)
json.dump(segs, open(OUT, "w"), indent=1)
print(f"  {len(segs)} segments, {segs[-1]['edit_t1']:.1f}s of edit from {len(r_a)/SR:.0f}s of take -> {OUT}")
