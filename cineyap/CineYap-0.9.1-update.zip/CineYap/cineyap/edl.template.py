#!/usr/bin/env python3
"""Rebuild the EDL from scratch. Every edge is a Scribe word boundary.

Sub-segments inside one spoken sentence exist to remove dead air between words
without cutting inside a word (Hard Rule 6).
"""
import json, pathlib

SRC = "<absolute path to the raw take>"
# Rough pads only. snap_edges.py (step 3.5) replaces both with the measured onset/offset,
# so do not tune these - they are a starting point, not the final edge.
PAD_IN, PAD_OUT = 0.05, 0.08

# One tuple per kept stretch of speech: (start, end, beat, quote, why)
# Every edge is a Scribe word boundary. Extra sub-segments inside one sentence
# exist only to remove dead air without cutting inside a word.
R = [
 # (64.32, 68.20, "HOOK_FACE", "these are the three easiest things...", "why this take"),
]

ranges = []
for a, b, beat, quote, why in R:
    ranges.append({"source": pathlib.Path(SRC).stem, "start": round(a - PAD_IN, 2), "end": round(b + PAD_OUT, 2),
                   "beat": beat, "quote": quote, "reason": why})
edl = {"version": 1, "sources": {pathlib.Path(SRC).stem: SRC}, "ranges": ranges,
       "grade": f"lut3d={pathlib.Path(__file__).parent}/lut.cube",
       "total_duration_s": round(sum(r["end"] - r["start"] for r in ranges), 2)}
pathlib.Path("../edit/edl.json").write_text(json.dumps(edl, indent=2))
print(f"{len(ranges)} segments, {edl['total_duration_s']}s")
