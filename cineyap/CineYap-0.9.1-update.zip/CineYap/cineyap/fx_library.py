"""fx_library.py — effects pulled from Gabe's reference videos. Imported at the end of fx.py, so every
format reaches them as fx.<Name>.

Same contract as fx.FlashClick: a class built with (sf, job_dir, pack, canvas=(W, H)), with add(...) per
moment and an optional finish(dst). Every number comes from measuring a reference and lives in the style
pack under "fx": {"<effect>": {...}}, never in this file. Each effect gets a card in
cineyap/library/catalog.json, a preview loop from make_previews.py, and a proof on a real CapCut export
before its status moves past "measured".

Owned by the Library session. fx.py and the format builders (mkcapcut, mkvertical, mkvcineyap) are wired
by the Studio session from the call each effect documents.
"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import pycapcut as draft
from pycapcut import VideoSegment, trange

US = lambda s: int(round(s * 1_000_000))
__all__ = ["Frame", "layout", "solid_plate", "MEASURED"]


def _rgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


class Frame:
    """THE FRAME: the footage inside a plain plate, like a matte photo border (measured 2026-10-03 from
    three of Gabe's screenshots; spec and refs in cineyap/library/refs/frame/).

    Looks (pack fx.frame):
      inset      the footage scaled 0.804 about the center on a plate; caption over the footage
      letterbox  16:9 footage across a vertical canvas, 92.6% wide; the caption UNDER it in ink
                 (vertical canvases only: on landscape the footage already fills)
      rounded    a thin plate (4% of the short side) and a rounded window; caption over the footage
      window     the footage at 62% on a plate, caption under it, text dark or light by the plate (BTS 1:00)
      side       a 9:16 window holding a DROPPED-IN clip (muted), the caption in a left column; on vertical
                 canvases the caption sits above the window (Packaging Is Your Moat 0:19)
    Plates: cream, white, black, green (pack fx.frame.plates).

    How it is built: one PNG per look and plate, canvas-sized, the plate color with a TRANSPARENT window
    cut in it (rounded corners drawn in the PNG, so no CapCut mask to calibrate). It sits on its own track
    above the footage and below the text. The format then fits its footage into window() for the same
    time range: that is the one thing the builder must do itself, because it owns the footage's scale.

        fr = Frame(sf, job_dir, pack, canvas=(W, H))      # adds the "Frame" video track
        fr.add(t0, t1, look="rounded", plate="white")      # the plate over [t0, t1)
        w = fr.window("rounded")    # {"x","y","w","h"} px; scale the A-roll and B-roll of [t0, t1)
                                    # so the picture covers w x h, centered on (x + w/2, y + h/2)
        c = fr.caption("letterbox") # {"where": "over" | "below", "center_y": px, "color": "#hex" | None}
    """
    def __init__(self, sf, job_dir, pack=None, canvas=(1080, 1920), track="Frame", index=12):
        self.sf, self.J, self.W, self.H = sf, pathlib.Path(job_dir), int(canvas[0]), int(canvas[1])
        self.P = ((pack or {}).get("fx") or {}).get("frame") or {}
        if not self.P: raise ValueError("style pack has no fx.frame block")
        self.track = track; sf.add_track(draft.TrackType.video, track, relative_index=index)
        self.dir = self.J/"fx/frame"; self.dir.mkdir(parents=True, exist_ok=True)

    @property
    def vertical(self): return self.H > self.W

    def window(self, look):
        L, W, H, s = self.P[look], self.W, self.H, min(self.W, self.H)
        if look == "inset":
            w, h = round(W * L["scale"]), round(H * L["scale"]); return {"x": (W - w) // 2, "y": (H - h) // 2, "w": w, "h": h}
        if look == "letterbox":
            if not self.vertical: raise ValueError("letterbox is for vertical canvases; use inset on landscape")
            w = round(W * L["width"]); h = round(w * 9 / 16)
            cy = L["center_y"]["9:16"] if H / W > 1.6 else L["center_y"]["3:4"]
            return {"x": (W - w) // 2, "y": round(H * cy - h / 2), "w": w, "h": h}
        if look == "rounded":
            m = round(s * L["margin_short"]); mb = round(m * (1 + L.get("bottom_extra", 0)))
            return {"x": m, "y": m, "w": W - 2 * m, "h": H - m - mb}
        if look == "window":
            if not self.vertical:
                w, h = round(W * L["scale_landscape"]), round(H * L["scale_landscape"]); return {"x": (W - w) // 2, "y": (H - h) // 2, "w": w, "h": h}
            b = L["box_portrait"]["9:16" if H / W > 1.6 else "3:4"]
            return {"x": round(b[0] * W), "y": round(b[1] * H), "w": round((b[2] - b[0]) * W), "h": round((b[3] - b[1]) * H)}
        if look == "side":
            if not self.vertical:
                ar = "16:9" if W / H > 1.6 else "4:3"; h = H; w = round(h * 9 / 16)
                return {"x": round(L["landscape"]["window_center_x"][ar] * W - w / 2), "y": 0, "w": w, "h": h}
            q = L["portrait"]["9:16" if H / W > 1.6 else "3:4"]; h = round(q["window_h"] * H); w = round(h * 9 / 16)
            return {"x": (W - w) // 2, "y": round(q["window_y"] * H), "w": w, "h": h}
        raise ValueError(f"unknown frame look {look!r}")

    def text_color(self, look, plate=None):
        """the caption color on this plate: the look's own, or dark/light by the plate's brightness"""
        L = self.P[look]; c = L.get("caption_color")
        if c and c != "auto": return c
        plate = plate or L.get("plate", "cream"); hx = self.P["plates"].get(plate, plate); r, g, b = (v / 255 for v in _rgb(hx))
        lum = 0.2126 * r + 0.7152 * g + 0.0722 * b; t = self.P["plates"].get("auto_text", {})
        return t.get("light", "#091A14") if lum >= t.get("threshold_luminance", 0.4) else t.get("dark", "#FFFFFF")

    def caption(self, look, plate=None):
        """where that range's captions go: over the footage (unchanged), below the window, or in the left column"""
        L, win = self.P[look], self.window(look)
        if look == "side":
            if not self.vertical:
                ar = "16:9" if self.W / self.H > 1.6 else "4:3"
                return {"where": "left", "x": round(L["landscape"]["caption_x"][ar] * self.W), "center_y": round(L["landscape"]["caption_center_y"] * self.H),
                        "max_w": win["x"] - round(L["landscape"]["caption_x"][ar] * self.W) - 40, "align": "left", "color": self.text_color(look, plate)}
            q = L["portrait"]["9:16" if self.H / self.W > 1.6 else "3:4"]
            return {"where": "above", "center_y": round(q["caption_center_y"] * self.H), "align": "center", "color": self.text_color(look, plate)}
        if look == "window":
            return {"where": "below", "center_y": round(win["y"] + win["h"] + L["caption_baseline_gap_short"] * min(self.W, self.H) * 0.8),
                    "align": "center", "color": self.text_color(look, plate)}
        if L.get("caption") == "below":
            return {"where": "below", "center_y": round(win["y"] + win["h"] + L["caption_gap_h"] * self.H + 0.0156 * self.H),
                    "align": "center", "color": self.text_color(look, plate)}
        return {"where": "over", "center_y": round(win["y"] + win["h"] / 2), "align": "center", "color": None}

    def plate_png(self, look, plate=None):
        from PIL import Image, ImageDraw
        plate = plate or self.P[look].get("plate", "cream"); color = self.P["plates"].get(plate, plate)
        f = self.dir/f"{look}_{plate}_{self.W}x{self.H}.png"
        if f.exists(): return f
        win, r = self.window(look), round(min(self.W, self.H) * self.P[look].get("radius_short", 0))
        SS = 4                                              # draw 4x and shrink: smooth rounded corners
        im = Image.new("RGBA", (self.W * SS, self.H * SS), _rgb(color) + (255,))
        ImageDraw.Draw(im).rounded_rectangle([win["x"] * SS, win["y"] * SS, (win["x"] + win["w"]) * SS - 1, (win["y"] + win["h"]) * SS - 1],
                                             radius=r * SS, fill=(0, 0, 0, 0))
        im.resize((self.W, self.H), Image.LANCZOS).save(f); return f

    def add(self, t0, t1, look="inset", plate=None):
        """the plate with its window over [t0, t1) on the Frame track"""
        seg = VideoSegment(str(self.plate_png(look, plate)), trange(US(t0), US(t1 - t0)))
        self.sf.add_segment(seg, self.track); return seg


# ------------------------------------------------------------------ measured layouts for every other effect
MEASURED = ("card_tag", "fullscreen_hook", "bold_behind", "hook_pullback", "type_interrogator", "split", "media_frame", "greenscreen")

def layout(pack, effect, canvas):
    """the resolved numbers for one effect on one canvas, from pack fx.<effect>.canvases["WxH"] (measured off
    Gabe's reference, with his decisions applied; see fx.<effect>.decisions and cineyap/library/refs/).
    Returns {"canvas": {...}, "colors": {...}, "decisions": [...], plus the effect's own keys}.
    Positions are px on that canvas unless a key ends in _frac."""
    P = ((pack or {}).get("fx") or {}).get(effect)
    if not P: raise ValueError(f"style pack has no fx.{effect} block")
    key = f"{int(canvas[0])}x{int(canvas[1])}"
    if key not in P.get("canvases", {}): raise ValueError(f"fx.{effect} has no numbers for {key}")
    out = {k: v for k, v in P.items() if k not in ("canvases",)}
    out["canvas"] = P["canvases"][key]; return out

def solid_plate(job_dir, color, canvas):
    """a canvas-size plate PNG of one color (cards, bands, frames), cached in the job's fx/plates/"""
    from PIL import Image
    d = pathlib.Path(job_dir)/"fx/plates"; d.mkdir(parents=True, exist_ok=True)
    f = d/f"{color.lstrip('#').upper()}_{int(canvas[0])}x{int(canvas[1])}.png"
    if not f.exists(): Image.new("RGB", (int(canvas[0]), int(canvas[1])), _rgb(color)).save(f)
    return f


# ================================================================== the effects measured off Gabe's references
# Contract (agreed with the Studio session, 2026-10-03): X(sf, job_dir, pack, canvas=(W, H)) adds its own tracks
# (text tracks relative_index 9-14, video plates 5-8, Frame stays 12); add(t0, t1, **params) draws its plates and
# TEXT for [t0, t1) and returns {material_id: True | False | [(a, b) serif char ranges]} to merge into
# capcut_draft.finish(text_fonts=...). What the effect needs from the FOOTAGE (a band, a window, zoom keys,
# a cutout) is exposed as methods; the format applies those to its A-roll, B-roll and cutout tracks.
# Numbers: pack fx.<effect>.canvases["WxH"] via layout(). Text centre from a measured baseline: CapCut centres
# the line box, and its baseline sits 0.40 x px below that centre (measured 2026-10-03 on a CapCut export).
from pycapcut import TextSegment, TextStyle, TextBackground, KeyframeProperty as KP
__all__ += ["TaggedCard", "FullscreenHook", "BoldBehind", "Split", "MediaFrame", "GreenScreen", "HookPullback", "TypeInterrogator"]

def _hex1(h): return tuple(v / 255 for v in _rgb(h))

class _Fx:
    """shared: the canvas, layout numbers, text drawing in canvas px"""
    EFFECT = ""
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        self.sf, self.J, self.pack = sf, pathlib.Path(job_dir), pack
        self.W, self.H = int(canvas[0]), int(canvas[1]); self.L = layout(pack, self.EFFECT, (self.W, self.H)); self.C = self.L["canvas"]
        self.unit = 11.1 * self.W / 1920                     # CapCut text px per size unit (scales with canvas width)
        self.fonts = {}; self._tracks = set()
    def track(self, name, kind="text", index=10):
        if not hasattr(self, "_idx"): self._busy, self._idx = {}, {}
        self._idx.setdefault(name, index)
        if name not in self._tracks:
            self.sf.add_track(draft.TrackType.text if kind == "text" else draft.TrackType.video, name, relative_index=index); self._tracks.add(name)
        return name
    def text(self, track, s, t0, t1, px, cy, cx=None, color="#FFFFFF", serif=False, align=1, tracking=-1, bg=None, keys=None, maxw=0.95):
        """one text box; px and cy/cx in canvas px (cy = the line's centre). serif: bool or [(a, b)] char ranges"""
        if t1 - t0 < 0.04: return None
        cx = self.W / 2 if cx is None else cx
        st = TextStyle(size=round(px / self.unit, 2), color=_hex1(color) if isinstance(color, str) else color, align=align,
                       letter_spacing=tracking if serif is not True else 0, auto_wrapping=False, max_line_width=maxw)
        seg = TextSegment(s, trange(US(t0), US(t1 - t0)), style=st, background=bg,
                          clip_settings=draft.ClipSettings(transform_x=(cx - self.W / 2) / (self.W / 2), transform_y=(self.H / 2 - cy) / (self.H / 2)))
        for prop, pts in (keys or {}).items():
            for tt, v in pts: seg.add_keyframe(prop, US(tt), v)
        track = self._free(track, t0, t1)                    # two lines on screen at once need two tracks
        self.sf.add_segment(seg, track); self.fonts[seg.material_id] = serif; return seg
    def _free(self, track, t0, t1):
        if not hasattr(self, "_busy"): self._busy, self._idx = {}, {}
        base, k = track, 1
        while any(a < t1 - 1e-6 and t0 < b - 1e-6 for a, b in self._busy.get(track, [])):
            k += 1; track = f"{base} {k}"
            if track not in self._tracks: self.track(track, "text", self._idx.get(base, 10))
        self._busy.setdefault(track, []).append((t0, t1)); return track
    def width(self, word, px, tracking_em=-0.06, serif=False):
        """ink width of text at px in the pack's sans (or serif) face, with tracking in em"""
        from PIL import ImageFont
        import os
        key = "serif" if serif else "sans"
        cands = [os.path.expanduser((self.pack.get("capcut") or {}).get(f"{key}_path") or ""), os.path.expanduser((self.pack.get("fonts") or {}).get(key, "")),
                 str(pathlib.Path(__file__).resolve().parent.parent/"fonts"/("InstrumentSerif-Italic.ttf" if serif else "Inter-Bold.ttf"))]
        f = next((x for x in cands if x and os.path.exists(x) and not x.endswith(".ttc")), None)
        if not f: return len(word) * 0.6 * px
        b = ImageFont.truetype(f, max(1, int(px))).getbbox(word)
        return (b[2] - b[0]) + tracking_em * px * max(0, len(word) - 1)
    def plate(self, track, color, t0, t1, png=None):
        self.sf.add_segment(VideoSegment(str(png or solid_plate(self.J, color, (self.W, self.H))), trange(US(t0), US(t1 - t0))), track)
    @staticmethod
    def centre(baseline, px): return baseline - 0.40 * px      # measured on a CapCut export (fx-cineyap card, 101.5px: baseline 41px below the box centre)
    @property
    def landscape(self): return self.W > self.H


class TaggedCard(_Fx):
    """THE TAGGED CARD (Anchor Everything 0:35): a full green or cream card, a square tag above centre whose first
    word is serif italic ("*external* source"), the line's words big under it. Vertical = the existing vertical
    card's numbers; horizontal measured (word 101.5px at 1080 high), in the vertical card's colors (Gabe).
        tc = TaggedCard(sf, job, pack, (W, H)); fonts.update(tc.add(t0, t1, tag="external source", plate="green",
                                                                         words=[(a, b, "caption text"), ...]))
    words: the line's captions for [t0, t1); omit them to draw only the plate and tag and style the captions
    yourself with tc.word_style(plate)."""
    EFFECT = "card_tag"
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        super().__init__(sf, job_dir, pack, canvas)
        self.track("FX Card", "video", 6); self.track("FX Tag", "text", 11); self.track("FX Card words", "text", 10)
    def word_style(self, plate="green"):
        c, col = self.C, self.L["colors"]; m = c["main"]; u = (self.H / 1080) if self.landscape else (self.W / 1080)
        px = m["font_px"] * (u if self.landscape else 1.0)
        cy = (m["cap_band_center_frac"] if "cap_band_center_frac" in m else m["center_frac"]) * self.H
        return {"px": px, "cy": cy, "color": col["word_on_green"] if plate == "green" else col["word_on_cream"]}
    def add(self, t0, t1, tag="", plate="green", words=None):
        col = self.L["colors"]; tg = self.C["tag"]; u = self.H / 1080 if self.landscape else 1.0
        self.plate("FX Card", col["plate_green"] if plate == "green" else col["plate_cream"], t0, t1)
        out = {}
        if tag:
            first = len(tag.split()[0]) if " " in tag else 0
            bg = TextBackground(color=col["tag_bg"], style=1, alpha=1.0, round_radius=0.0, height=0.22, width=0.12)
            s = self.text("FX Tag", tag, t0, t1, tg["font_px"] * u, tg["center_frac"][1] * self.H, color=col["tag_ink"],
                          serif=[(0, first)] if first else False, bg=bg)
            if s: out[s.material_id] = self.fonts[s.material_id]
        ws = self.word_style(plate)
        for a, b, s_ in (words or []):
            s = self.text("FX Card words", s_, max(a, t0), min(b, t1), ws["px"], ws["cy"], color=ws["color"])
            if s: out[s.material_id] = False
        return out


class FullscreenHook(_Fx):
    """THE FULL-SCREEN HOOK (BTS 0:03): a centred title over full-screen B-roll: bold words plus one serif italic
    word on the same line, a smaller subtitle under it. No shadow (Gabe). The format puts B-roll under [t0, t1)
    and a FlashClick on both cuts.
        fh = FullscreenHook(sf, job, pack, (W, H)); fonts.update(fh.add(t0, t1, title="Bulk Creation", serif="BTS",
                                                                          sub="How to capture your life cinematically"))"""
    EFFECT = "fullscreen_hook"
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        super().__init__(sf, job_dir, pack, canvas); self.track("FX Hook", "text", 12)
    def add(self, t0, t1, title="", serif="", sub=""):
        c = self.C; out = {}; s1 = (title + (" " + serif if serif else "")).strip()
        if s1:
            rng = [(len(title) + 1, len(s1))] if serif else False
            s = self.text("FX Hook", s1, t0, t1, c["title_size_px"], self.centre(c["title_baseline_y"], c["title_size_px"]),
                          serif=rng, tracking=-2)
            if s: out[s.material_id] = rng
        if sub:
            s = self.text("FX Hook", sub, t0, t1, c["subtitle_size_px"], self.centre(c["subtitle_baseline_y"], c["subtitle_size_px"]))
            if s: out[s.material_id] = False
        return out


class BoldBehind(_Fx):
    """BOLD BEHIND (CBC Launch, opening): huge white words, one per cut, BEHIND the whole subject (412px at 1080
    high, -0.06em; one size for the whole moment, width-bound on narrow canvases). The format must put the
    subject cutout on a track ABOVE these words (relative_index > 9 here: words sit on 9) and may run it on B-roll.
        bb = BoldBehind(sf, job, pack, (W, H)); fonts.update(bb.add(t0, t1, words=[(a, b, "Nobody"), ...]))"""
    EFFECT = "bold_behind"
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        super().__init__(sf, job_dir, pack, canvas); self.track("FX Behind words", "text", 9)
    def _width(self, word, px):
        """ink width of a word in Helvetica-like bold at px, with the reference's -0.06em tracking"""
        from PIL import ImageFont
        import os
        cands = [os.path.expanduser((self.pack.get("capcut") or {}).get("sans_path") or ""), os.path.expanduser((self.pack.get("fonts") or {}).get("sans", "")),
                 str(pathlib.Path(__file__).resolve().parent.parent/"fonts/Inter-Bold.ttf")]
        f = next((x for x in cands if x and os.path.exists(x) and not x.endswith(".ttc")), None)
        if not f: return len(word) * 0.6 * px
        fnt = ImageFont.truetype(f, int(px)); b = fnt.getbbox(word)
        return (b[2] - b[0]) - 0.06 * px * max(0, len(word) - 1)
    def add(self, t0, t1, words=()):
        """one word per cut (a two-word caption is split, its time shared by letters), one size for the whole
        moment: the measured size, shrunk only so the longest word fits 0.90 of the canvas width"""
        c = self.C; cy = c["cap_top_y"] + c["cap_px"] / 2; out = {}
        singles = []
        for a, b, w in words:
            parts = [p for p in w.split() if p] or [w]; tot = sum(len(p) for p in parts) or 1; t = a
            for p in parts:
                d = (b - a) * len(p) / tot; singles.append((t, t + d, p)); t += d
        if not singles: return out
        px = c["font_px"]; widest = max(self._width(w, px) for _, _, w in singles)
        if widest > 0.90 * self.W: px *= 0.90 * self.W / widest
        cy = cy + (px - c["font_px"]) * 0                     # the cap centre stays where it was measured
        for a, b, w in singles:
            s = self.text("FX Behind words", w, max(a, t0), min(b, t1), px, cy, tracking=-3)
            if s: out[s.material_id] = False
        return out


class Split(_Fx):
    """SPLIT SCREEN (30 Pieces 0:13): a green band (top 0.394 on portrait, LEFT on landscape), a cream "Step #N"
    pill, one big cream word at a time in the band; the subject cut out over the band edge (the format puts the
    cutout above the band). Head does NOT shift (Gabe). A one-frame flash in and out (the format's FlashClick).
        sp = Split(sf, job, pack, (W, H)); fonts.update(sp.add(t0, t1, step="Step #1", words=[(a, b, "batch"), ...]))
        sp.band() -> {"x","y","w","h"} px: keep the A-roll as it is; the cutout of it goes over the band."""
    EFFECT = "split"
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        super().__init__(sf, job_dir, pack, canvas)
        self.track("FX Band", "video", 7); self.track("FX Step", "text", 11); self.track("FX Band words", "text", 10)
    def band(self):
        b = self.C["band_px"]; return {"x": round(b[0]), "y": round(b[1]), "w": round(b[2] - b[0]), "h": round(b[3] - b[1])}
    def _png(self):
        from PIL import Image
        f = self.J/"fx/plates"/f"band_{self.W}x{self.H}.png"; f.parent.mkdir(parents=True, exist_ok=True)
        if not f.exists():
            im = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0)); b = self.band()
            im.paste(Image.new("RGBA", (b["w"], b["h"]), _rgb(self.L["colors"]["band"]) + (255,)), (b["x"], b["y"])); im.save(f)
        return f
    def add(self, t0, t1, step="", words=()):
        c, col = self.C, self.L["colors"]; out = {}
        self.plate("FX Band", None, t0, t1, png=self._png())
        if step:
            p = c["pill"]; bg = TextBackground(color=col["pill_bg"], style=1, alpha=1.0, round_radius=1.0, height=0.30, width=0.18)
            s = self.text("FX Step", step, t0, t1, p["font_px"], p["center_px"][1], cx=p["center_px"][0], color=col["pill_ink"], bg=bg)
            if s: out[s.material_id] = False
        w = c["word"]; last = len(words) - 1; px = w["font_px"]
        widest = max([self.width(s_, px, serif=(k == last and len(words) > 1)) for k, (_, _, s_) in enumerate(words)] or [0])
        if widest > w.get("max_ink_width_px", 9e9): px *= w["max_ink_width_px"] / widest      # "shrink to max_ink_width if wider"
        for k, (a, b, s_) in enumerate(words):
            s = self.text("FX Band words", s_, max(a, t0), min(b, t1), px, self.centre(w["baseline_px"], px),
                          cx=w["center_x_px"], color=col["word"], serif=(k == last and len(words) > 1))
            if s: out[s.material_id] = self.fonts[s.material_id]
        return out


class MediaFrame(_Fx):
    """MEDIA FRAME (30 Pieces 0:33-0:39): a cream plate, a dropped-in clip or picture in a window sized to the
    media's shape (9:16, 4:5, 4:3, 16:9), one ink word under it.
        mf = MediaFrame(sf, job, pack, (W, H)); fonts.update(mf.add(t0, t1, words=[(a, b, "results")]))
        mf.window("9:16") -> {"x","y","w","h"}: the format cover-fits the media clip into it (above the plate)."""
    EFFECT = "media_frame"
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        super().__init__(sf, job_dir, pack, canvas); self.track("FX Media plate", "video", 5); self.track("FX Media word", "text", 10)
    def window(self, shape="9:16"):
        ins = self.C["insets"]; k = shape if shape in ins else next((x for x in ins if x.startswith(shape)), "9:16")
        p = ins[k]["px"]; return {"x": round(p[0]), "y": round(p[1]), "w": round(p[2] - p[0]), "h": round(p[3] - p[1])}
    def add(self, t0, t1, words=()):
        c, col = self.C, self.L["colors"]; out = {}; self.plate("FX Media plate", col["plate"], t0, t1); w = c["word"]
        for a, b, s_ in words:
            s = self.text("FX Media word", s_, max(a, t0), min(b, t1), w["font_px"], self.centre(w["baseline_px"], w["font_px"]),
                          cx=w["center_x_px"], color=col["word"])
            if s: out[s.material_id] = False
        return out


class GreenScreen(_Fx):
    """GREEN SCREEN (30 Pieces 1:04): another video fills a panel (the top 0.711 on portrait, the left on
    landscape), the subject cut out over it, captions above the head. No flash. Nothing is drawn here: the
    format cover-fits the panel video into window(), keeps its A-roll under it, puts the subject cutout on
    top, and sets that range's captions with caption_style().
        gs = GreenScreen(sf, job, pack, (W, H)); gs.window(); gs.caption_style()"""
    EFFECT = "greenscreen"
    def window(self):
        p = self.C["panel_px"]; return {"x": round(p[0]), "y": round(p[1]), "w": round(p[2] - p[0]), "h": round(p[3] - p[1]),
                                        "anchor": "top" if not self.landscape else "center"}
    def caption_style(self):
        c = self.C["caption"]; return {"px": c["font_px"], "cy": self.centre(c["baseline_px"], c["font_px"]), "cx": c["center_x_px"], "color": self.L["colors"]["caption"]}
    def add(self, t0, t1, **_): return {}


class HookPullback(_Fx):
    """HOOK PULL-BACK (Interrogator 0:08): the shot cuts in at 1.44x and eases out to 1.0 over 2.952s about the
    frame centre; a three-line title (label, line 1, line 2 with a serif word) rides the same zoom; the captions
    do not. A flash at each end (the format's FlashClick).
        hp = HookPullback(sf, job, pack, (W, H))
        hp.keys(t0) -> [(t, scale)]: put these uniform_scale keyframes on the A-roll clip that starts at t0
        fonts.update(hp.add(t0, t1, label="the interrogator", line1="ask better", line2="questions", serif_word="better"))"""
    EFFECT = "hook_pullback"
    def __init__(self, sf, job_dir, pack, canvas=(1080, 1920)):
        super().__init__(sf, job_dir, pack, canvas); self.track("FX Hook title", "text", 12)
    def _scale(self, u):
        z = self.C["zoom"]; x1, y1, x2, y2 = 0.077, 0.706, 0.276, 1.0       # measured cubic-bezier
        lo, hi = 0.0, 1.0
        for _ in range(40):                                                     # solve bezier x(s) = u
            s = (lo + hi) / 2; x = 3*(1-s)**2*s*x1 + 3*(1-s)*s**2*x2 + s**3
            lo, hi = (s, hi) if x < u else (lo, s)
        y = 3*(1-s)**2*s*y1 + 3*(1-s)*s**2*y2 + s**3
        return z["from"] + (z["to"] - z["from"]) * y
    def keys(self, t0=0.0, n=10):
        d = self.C["zoom"]["dur_s"]; return [(t0 + d * i / n, round(self._scale(i / n), 4)) for i in range(n + 1)]
    def add(self, t0, t1, label="", line1="", line2="", serif_word=""):
        T = self.C["title"]; out = {}; H = self.H
        # the title arrives 0.3s after the cut (one flash frame at 8.43s on a shot cut at 8.13s), already partly zoomed
        lag = float(self.C.get("title_lag_s", 0.30)); d = self.C["zoom"]["dur_s"]
        ks = [(t - lag, k) for t, k in self.keys(0.0, n=20) if t >= lag - 1e-9]
        ks = [(0.0, round(self._scale(lag / d), 4))] + [x for x in ks if x[0] > 1e-6]; k0 = ks[0][1]
        # keep the whole block inside the frame at entry: if the top line's top, scaled about the frame centre,
        # sits above title_min_top, push the block down by that much at entry and ease the push out with the zoom
        top_px = T.get("block_top_frac", T["label"].get("cap_top_frac", 0.14)) * H
        top_entry = H / 2 + (top_px - H / 2) * k0
        push = max(0.0, self.C.get("title_min_top_frac", 0.0) * H - top_entry)
        ease = lambda k: (k - 1.0) / (k0 - 1.0) if k0 > 1.0 else 0.0
        for txt, part, px in ((label, T["label"], T["label"]["px"]), (line1, T["line1"], T["line1"]["px"]), (line2, T["line2"], T["line2"].get("sans_px", 81.5))):
            if not txt: continue
            cy = self.centre(part["baseline_frac"] * H, px)
            keys = {KP.uniform_scale: [(t, k) for t, k in ks if t < t1 - t0],
                    KP.position_y: [(t, (H / 2 - (H / 2 + (cy - H / 2) * k + push * ease(k))) / (H / 2)) for t, k in ks if t < t1 - t0]}
            rng = False
            if serif_word and serif_word in txt: i = txt.index(serif_word); rng = [(i, i + len(serif_word))]
            s = self.text("FX Hook title", txt, t0 + lag, t1, px, cy, serif=rng, keys=keys)
            if s: out[s.material_id] = rng
        return out


class TypeInterrogator(_Fx):
    """THE INTERROGATOR CAPTION STYLE (Interrogator, whole video): white Helvetica Neue Bold, centred, one word
    cutting to the next; "low" tier on the chest over A-roll, "mid" tier bigger over B-roll and plates; accent
    words in serif italic in the same color (Gabe: not rust). A style, not a moment: the format asks it per caption.
        ti = TypeInterrogator(sf, job, pack, (W, H)); ti.style("aroll" | "broll" | "plate") -> {"px","cy","color","max_w"}"""
    EFFECT = "type_interrogator"
    def style(self, where="aroll", plate_color=None):
        c = self.C; t = c["low"] if where == "aroll" else c["mid"]
        color = self.L["colors"]["text_on_cream"] if (plate_color or "").upper() in ("#F5F0EA", "#F2F2EB") else self.L["colors"]["text"]
        return {"px": t["px"], "cy": self.centre(t["baseline_frac"] * self.H, t["px"]), "color": color, "max_w": c["max_line_width_frac"] * self.W}
    def add(self, t0, t1, **_): return {}
