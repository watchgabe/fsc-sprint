#!/usr/bin/env python3
"""mkvertical.py — Gabe's vertical CineYap ("Showin' Up" style) as a 1080x1920 CapCut draft, editable text.

    ./vu-py cineyap/mkvertical.py <job>

Every rule is in the style pack's `vertical_batch` block, measured off his own reel (watch.gabe,
2026-05-11): word-by-word captions above the head on A-roll and mid-frame on B-roll, an opening that
eases out from a punch on the face with a serif title riding down, green day cards (cream label + big
words), a stacking list card, a cream card, a slow push on most A-roll shots, and the CTA keyword held
big in quotes above the captions to the end.

Inputs:
  edit/edl.json              the cut (ranges in source time; each range carries a `beat` name)
  edit/transcripts/*.json    Scribe words, same clock as the source
  build/source_graded.mp4    the graded vertical take with its audio
  vertical/plan.json         what goes where, by beat:
     {"title": "...", "cta": {"word": "batch", "beats": ["CTA", "CTA2"]},
      "cards": [{"beat": "TUESDAY", "type": "green", "label": "Tuesday – Scripting"},
                {"beat": "HOOK", "type": "stack", "from_word": "is", "stack": ["batch", "record"], "then_cream_from": "your"}],
      "broll": [{"beats": ["SOURCES", "SOURCES2"], "clip": "Vertical/Working-Office Vertical_04.mp4"}]}
"""
import json, pathlib, re, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
sys.path.insert(0, str(PKG/"helpers"))
import config

if len(sys.argv) < 2: sys.exit("usage: mkvertical.py <job> [--3x4]")
job = sys.argv[1]; J = PROJECTS/job
sty = __import__("style").load()
V = sty["vertical_batch"]; W, H = V["canvas"]
# 3:4 (1080x1440): the same build on a shorter canvas. Every position in the pack is a fraction of the
# canvas and type sizes scale with its width, so only the canvas changes; the cover maths is generic.
THREE4 = "--3x4" in sys.argv
if THREE4: H = int(round(W * 4 / 3))
edl = json.load(open(J/"edit/edl.json")); plan = json.load(open(J/"vertical/plan.json"))
SRC = next((p for p in (J/"build/source_matched.mp4", J/"build/source_graded.mp4", J/"build/graded_master.mp4") if p.exists()),
           J/"build/source_graded.mp4").resolve()        # graded_master: the 4K take a CineYap job already graded
tr = json.load(open(sorted((J/"edit/transcripts").glob("*.json"))[0]))
WORDS = [w for w in tr["words"] if w.get("type") == "word"]
norm = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())

def probe_audio_s(p):
    return subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(p)], capture_output=True, text=True).stdout.strip() or 0
def probe(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
        "stream=width,height:stream_side_data=rotation:format=duration","-of","json",str(p)], capture_output=True, text=True).stdout)
    s = d["streams"][0]; w, h = int(s["width"]), int(s["height"])
    rot = next((abs(int(sd.get("rotation", 0))) for sd in s.get("side_data_list", []) if "rotation" in sd), 0)
    return (h, w, float(d["format"]["duration"])) if rot in (90, 270) else (w, h, float(d["format"]["duration"]))

# ---- the cut on the timeline, and every word placed on it
GRID = 1/24.0                                                           # the draft's frame grid
snap = lambda t: round(t / GRID) * GRID
segs, words, t = [], [], 0.0
if plan.get("cut_from"):
    # an exact copy: the reference edit's own cut (edl_exact.json from the audio alignment), each edge
    # moved onto the draft's frame grid with the source in-point moved by the same amount
    edl["ranges"] = []
    for k, r in enumerate(json.load(open(plan["cut_from"]))):
        a, b = snap(r["edit_t0"]), snap(r["edit_t1"]); s0 = r["wav_t0"] + (a - r["edit_t0"])
        segs.append({"t0": a, "t1": b, "s0": s0, "s1": s0 + (b - a), "beat": f"S{k}"})
    for s in segs:
        for w in WORDS:
            if w["start"] >= s["s0"] - 0.02 and w["end"] <= s["s1"] + 0.05:
                words.append({"t0": s["t0"] + w["start"] - s["s0"], "t1": s["t0"] + w["end"] - s["s0"], "w": w["text"], "beat": s["beat"]})
    t = segs[-1]["t1"]
for r in edl["ranges"]:
    d = r["end"] - r["start"]
    segs.append({"t0": t, "t1": t + d, "s0": r["start"], "s1": r["end"], "beat": r.get("beat", "")})
    for w in WORDS:
        if w["start"] >= r["start"] - 0.02 and w["end"] <= r["end"] + 0.05:
            words.append({"t0": t + w["start"] - r["start"], "t1": t + w["end"] - r["start"], "w": w["text"], "beat": r.get("beat", "")})
    t += d
TOTAL = t
beat_span = {}
for s in segs: beat_span.setdefault(s["beat"], [s["t0"], s["t1"]]); beat_span[s["beat"]][1] = s["t1"]

# ---- framing from the face (Apple Vision): face height and eye line to the measured numbers
import Vision, Quartz
from Foundation import NSURL
fr = J/"vertical/_face.png"
subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{(segs[1]['s0']+segs[1]['s1'])/2:.2f}","-i",str(SRC),"-frames:v","1",str(fr)], check=True)
img = Quartz.CGImageSourceCreateImageAtIndex(Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(fr)), None), 0, None)
rq = Vision.VNDetectFaceRectanglesRequest.alloc().init(); Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None).performRequests_error_([rq], None)
b = max(rq.results(), key=lambda o: o.boundingBox().size.width).boundingBox()
fh, ex, ey = b.size.height, b.origin.x + b.size.width/2, 1 - (b.origin.y + b.size.height*0.62)
cw, ch, _ = probe(SRC); fit = min(W/cw, H/ch)
def framing(z):
    dW, dH = cw*fit*z, ch*fit*z
    dx = (V["framing"]["face_x"]-0.5)*W - (ex-0.5)*dW; dx = max(-(dW-W)/2, min((dW-W)/2, dx))
    dy = V["framing"]["eyes_y"]*H - (H/2 + (ey-0.5)*dH); dy = max(-(dH-H)/2, min((dH-H)/2, dy))
    return dx/(W/2), -dy/(H/2)
Z = V["framing"]["face_h"] / fh * (ch*fit/H)        # face height in canvas fractions -> zoom over contain-fit
print(f"  framing: face {fh:.3f} of the source height, eyes ({ex:.2f},{ey:.2f}) -> zoom {Z:.2f}")

# ---- the draft
import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, trange, KeyframeProperty as KP
from capcut_draft import start, finish, US
from gabe_carousel import censor
from PIL import Image
import numpy as np
name = f"{job} (Vertical 3x4)" if THREE4 else f"{job} (Vertical)"
sf, dst = start(name, J, W, H)
for k, nm in enumerate(("A-roll", "B-roll", "Plates")): sf.add_track(draft.TrackType.video, nm, relative_index=k)
from fx import FlashClick
fc = FlashClick(sf, J, V, canvas=(W, H))                     # the flash + click transition (effects library, fx.py)
for k, nm in enumerate(("Captions", "Stack 1", "Stack 2", "Stack 3", "Label", "Title", "CTA"), 3): sf.add_track(draft.TrackType.text, nm, relative_index=k)

cta_beats = set(plan.get("cta", {}).get("beats", []))
mo = V["slow_push"]; pushed = 0; mapped = 0; ZC = []; EASE_FIRST = False
# MOTION. With a registered reference (register_motion.py on an edit of this same take), every A-roll
# frame's scale and position is read off that edit by its source time: the editor's own zooms, punches
# and pushes, frame for frame. Without one, the pack's rules: opening ease-out, slow pushes.
REF = None
if plan.get("motion_ref"):
    REF = sorted([r for r in json.load(open(plan["motion_ref"])) if r.get("ok")], key=lambda r: r["src_t"])
FR = 1/(24000/1001)
def ref_curve(s0, s1):
    pts = [r for r in REF if s0 - 0.02 <= r["src_t"] <= s1 + 0.02] if REF else []
    # an exact copy takes whatever the reference shows of a shot, even a shot mostly under B-roll
    if len(pts) < 3 or (not plan.get("cut_from") and (pts[-1]["src_t"] - pts[0]["src_t"]) < 0.4*(s1 - s0)): return None
    out = []
    # registration jitters by ~0.01; a median of 5 removes it without rounding off a punch (a punch is
    # a step, and a median keeps steps sharp)
    import statistics as _st
    for key in ("scale", "tx", "ty"):
        raw = [r[key] for r in pts]
        for i, r in enumerate(pts):
            if 2 <= i <= len(pts) - 3: r[key] = _st.median(raw[i-2:i+3])      # the ends stay exact
    sc = [r["scale"] for r in pts]
    for i, r in enumerate(pts):
        # a punch is a jump BETWEEN two flat stretches; a fast zoom moves on every sample and is left smooth
        jump = i > 0 and abs(sc[i] - sc[i-1]) > 0.04
        flat_before = i < 2 or abs(sc[i-1] - sc[i-2]) < 0.012
        flat_after = i + 1 >= len(sc) or abs(sc[i+1] - sc[i]) < 0.012
        if out and jump and flat_before and flat_after:                 # hold, then cut to the new size on the next frame
            out.append((r["src_t"] - s0 - FR, out[-1][1], out[-1][2], out[-1][3]))
        out.append((r["src_t"] - s0, r["scale"], r["tx"], r["ty"]))
    # thin the smooth stretches: keep a point when it departs from the straight line between neighbours
    keep = [out[0]]
    for i in range(1, len(out)-1):
        p, c, n = keep[-1], out[i], out[i+1]
        if n[0] - p[0] <= 0: continue
        f = (c[0]-p[0])/(n[0]-p[0])
        lin = [p[j] + (n[j]-p[j])*f for j in (1, 2, 3)]
        if abs(c[1]-lin[0]) > 0.004 or max(abs(c[2]-lin[1]), abs(c[3]-lin[2])) > 0.012:
            keep.append(c)
    keep.append(out[-1])
    # a jump in the last tenth of a second is the next shot's framing bleeding in: drop it
    while len(keep) > 2 and (s1 - s0) - keep[-1][0] < 0.1 and abs(keep[-1][1] - keep[-2][1]) > 0.04: keep.pop()
    return keep
BASE = float(V["framing"].get("base_scale", 0)) or None
for i, s in enumerate(segs):
    d = s["t1"] - s["t0"]
    curve = ref_curve(s["s0"], s["s1"])
    if curve:
        z0, tx, ty = curve[0][1], curve[0][2], curve[0][3]
    else:
        z0 = (BASE or Z) * (V["framing"]["cta_punch"] if s["beat"] in cta_beats else 1.0); tx, ty = framing(z0) if not BASE else (0.0, 0.0)
    vs = VideoSegment(str(SRC), trange(US(s["t0"]), US(s["t1"]) - US(s["t0"])), source_timerange=trange(US(s["s0"]), US(s["t1"]) - US(s["t0"])),
                      clip_settings=draft.ClipSettings(scale_x=z0, scale_y=z0, transform_x=tx, transform_y=ty))
    if i == 0:
        # the opening is ONE eased move, two keyframes, the way Gabe builds it by hand: editable in CapCut,
        # and the ease-out is CapCut's own curve (applied to the saved JSON after finish()).
        oz = V["opening_zoom"]; settle = min(oz["settle_s"], d); curve = None
        vs.add_keyframe(KP.uniform_scale, 0, oz["from"]); vs.add_keyframe(KP.uniform_scale, US(settle), oz["to"])
        EASE_FIRST = True; mapped += 1
    if curve:
        for tt, z, x_, y_ in curve:
            tt = max(0.0, min(d, tt))
            vs.add_keyframe(KP.uniform_scale, US(tt), z); vs.add_keyframe(KP.position_x, US(tt), x_); vs.add_keyframe(KP.position_y, US(tt), y_)
        mapped += 1
    elif i == 0:
        pass                                                         # handled above as one eased move
    elif d >= 2.5 and s["beat"] not in cta_beats and (i % 5) not in (2, 4) and not plan.get("cut_from"):
        vs.add_keyframe(KP.uniform_scale, 0, z0); vs.add_keyframe(KP.uniform_scale, US(d), z0*(1 + mo["rate_per_s"]*d)); pushed += 1
    sf.add_segment(vs, "A-roll")
print(f"  motion: {mapped} shot(s) carry the reference edit's own zooms, {pushed} rule-based pushes")

# ---- the adjustment layer. In the reference the title and the hook words sit on the opening zoom: they
# shrink and slide toward the frame centre with the footage (fit to 0.002 on every sample). The punches
# later on are on the clip alone; captions keep their size through them (measured: same height, same y).
OZ = V["opening_zoom"]; OPEN_END = segs[0]["t1"]
def open_k(t):
    """the opening's scale over its settled value at cut time t: CapCut's ease-out (FreeCurveIn/Out, the
    handles mkvertical writes) is a bezier with x = d*u^3, which predicts the export to 0.005"""
    st = min(OZ["settle_s"], OPEN_END)
    if t >= st: return 1.0
    u = (max(0.0, t) / st) ** (1/3); w = 3*(1-u)*u*u + u**3
    return (OZ["from"] + (OZ["to"] - OZ["from"]) * w) / OZ["to"]
def ride(t0, t1, cy):
    """keyframes that carry a text placed at centre-y cy (settled) on the opening zoom from t0 to t1"""
    ty = (H/2 - cy*H)/(H/2); st = min(OZ["settle_s"], OPEN_END)
    ts = [t0] + [x for x in np.arange(t0 + 2*GRID, min(t1, st), 2*GRID)] + ([st] if t0 < st < t1 else []) + [min(t1, st + GRID)]
    ts = sorted(set(round(x - t0, 4) for x in ts if x - t0 < t1 - t0))
    return {KP.uniform_scale: [(x, open_k(t0 + x)) for x in ts], KP.position_y: [(x, ty * open_k(t0 + x)) for x in ts]}

# ---- B-roll: whole beats, so every edge lands on an A-roll cut (no double cuts)
roots = [pathlib.Path(r) for r in (config.opt("broll_clips"), config.opt("broll_root")) if r]
def find(rel):
    for r in roots:
        if (r/rel).exists(): return r/rel
    if (J/"board_media"/pathlib.Path(rel).name).exists(): return J/"board_media"/pathlib.Path(rel).name
    print(f"  NOTE: B-roll clip not found, skipped: {rel} (set broll_clips in config.json, or pick another on the Board)")
    return None
# FULL-SCREEN HOOK (fx_library): plan "hooks" = {beat: {title, serif, sub, clip}}. Its clip covers the beat
# like B-roll (and replaces any B-roll there), the effect draws the title, and the flash fires on both cuts.
HOOKS = {b_: v for b_, v in (plan.get("hooks") or {}).items() if b_ in beat_span and v and (v.get("title") or v.get("sub"))}
hook_spans = [tuple(beat_span[b_]) for b_ in HOOKS]
plan["broll"] = [b for b in plan.get("broll", []) if not any(x in HOOKS and HOOKS[x].get("clip") for x in (b.get("beats") or []))]
plan["broll"] += [{"beats": [b_], "clip": v["clip"], "still": True} for b_, v in HOOKS.items() if v.get("clip")]
broll_spans = []
for bplan in plan.get("broll", []):
    if "t0" in bplan: a, bb = snap(bplan["t0"]), snap(bplan["t1"])       # an exact copy: the reference's own spans
    else: a = min(beat_span[x][0] for x in bplan["beats"]); bb = max(beat_span[x][1] for x in bplan["beats"])
    p = find(bplan["clip"])
    if p is None: continue
    pw, ph, pd = probe(p); dd = min(bb - a, pd - 0.05)
    st = bplan["in_s"] if "in_s" in bplan else max(0.0, min(pd*0.25, pd - dd - 0.05))
    st = max(0.0, min(st, pd - dd - 0.02))
    sc = bplan.get("scale") or max(W/pw, H/ph) / min(W/pw, H/ph)          # the reference's own framing, else fill
    bs = VideoSegment(str(p), trange(US(a), US(dd)), source_timerange=trange(US(st), US(dd)),
                      clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc, transform_x=bplan.get("tx", 0.0), transform_y=bplan.get("ty", 0.0)))
    if bplan.get("scale_end"):
        bs.add_keyframe(KP.uniform_scale, 0, sc); bs.add_keyframe(KP.uniform_scale, US(dd), bplan["scale_end"])
    elif not bplan.get("still") and V.get("broll", {}).get("push", False):    # the reference's B-roll holds still
        bs.add_keyframe(KP.uniform_scale, 0, sc); bs.add_keyframe(KP.uniform_scale, US(dd), sc*(1 + mo["rate_per_s"]*dd))
    sf.add_segment(bs, "B-roll"); broll_spans.append((a, a + dd))

# ---- FRAME (fx_library.Frame): a beat's footage inside a plain plate. plan "frames" = {beat: {look, plate}}
FRM = {b_: v for b_, v in (plan.get("frames") or {}).items() if (v or {}).get("look") and b_ in beat_span}
FSPANS, FCAPS, SIDES = [], [], []
if FRM:
    import fx
    from frame_fit import frame_span
    fr_fx = fx.Frame(sf, J, sty, canvas=(W, H))
    for b_, v in FRM.items():
        a_, z_ = beat_span[b_]
        fr_fx.add(a_, z_, look=v["look"], plate=v.get("plate"))
        c_ = fr_fx.caption(v["look"], v.get("plate"))
        if c_["where"] in ("below", "above", "left"): FCAPS.append((a_, z_, c_))
        if v["look"] == "side":                               # a dropped-in clip fills the window, the take is hidden
            if v.get("clip"): SIDES.append((a_, z_, v["clip"]))
            continue
        FSPANS.append(frame_span(fr_fx, v["look"], W, H, a_, z_, cover=(BASE or Z)))
    print(f"  frame: {len(FSPANS)} beat(s) inside a plate")
for a_, z_, clip_ in SIDES:
    win_ = fr_fx.window("side"); p_ = find(clip_)
    if p_ is None: continue
    pw_, ph_, pd_ = probe(p_)
    sc_ = max(win_["w"] / pw_, win_["h"] / ph_) / min(W / pw_, H / ph_)     # cover the window
    dd_ = min(z_ - a_, pd_ - 0.05)
    if "Side" not in sf.tracks: sf.add_track(draft.TrackType.video, "Side", relative_index=11)
    sf.add_segment(VideoSegment(str(p_), trange(US(a_), US(dd_)), source_timerange=trange(0, US(dd_)), volume=0.0,
                                clip_settings=draft.ClipSettings(scale_x=sc_, scale_y=sc_, transform_x=(win_["x"] + win_["w"]/2 - W/2)/(W/2),
                                                                 transform_y=(H/2 - win_["y"] - win_["h"]/2)/(H/2))), "Side")
def frame_cap(t0, t1=None):
    """the letterbox caption rule for a caption that is MOSTLY inside a letterboxed beat (a copied edit's
    captions do not start on the cut, so the first one can begin a few frames before it)"""
    t1 = t0 + 0.02 if t1 is None else t1
    for a_, z_, c_ in FCAPS:
        if min(t1, z_) - max(t0, a_) > 0.5 * (t1 - t0): return c_
    return None

# ---- plates
PL = J/"vertical"; plate = {}
for k, c in (("green", sty["colors"]["ink"]), ("cream", sty["colors"]["paper"])):
    f = PL/f"plate_{k}_{W}x{H}.png"
    if not f.exists(): Image.fromarray(np.tile(np.array(list(c[:3]) + [255], np.uint8), (H, W, 1))).save(f)
    plate[k] = f
def word_t(beat, w, after=0.0):
    for x in words:
        if x["beat"] == beat and norm(x["w"]) == norm(w) and x["t0"] >= after: return x["t0"]
    sys.exit(f"word {w!r} not found in beat {beat}")
cards = []                                   # (t0, t1, kind, card)
for c in plan.get("cards", []):
    if "t0" in c:                                   # an exact copy: the reference's own card spans
        cards.append((snap(c["t0"]), snap(c["t1"]), c["type"], c)); continue
    a, bb = beat_span[c["beat"]]
    if c["type"] == "green": cards.append((a, bb, "green", c))
    elif c["type"] == "cream": cards.append((a, bb, "cream", c))          # a whole line on cream (the Board's card button)
    elif c["type"] == "stack":
        a = word_t(c["beat"], c["from_word"]); cream_t = word_t(c["beat"], c["then_cream_from"], a) if c.get("then_cream_from") else bb
        cards.append((a, cream_t, "stack", c))
        if c.get("then_cream_from"): cards.append((cream_t, bb, "cream", c))
for a, bb, kind, c in cards:
    sf.add_segment(VideoSegment(str(plate["cream" if kind == "cream" else "green"]), trange(US(a), US(bb) - US(a))), "Plates")

# ---- text
unit = 11.1 * W / 1920                         # CapCut text px per size unit (measured: scales with canvas width)
WHITE, INK = (1.0, 1.0, 1.0), tuple(v/255 for v in sty["colors"]["ink"][:3])
fonts = {}
def text(track, s, t0, t1, px, cy, color=WHITE, serif=False, keys=None, bg=None):
    if t1 - t0 < 0.04: return None
    st = TextStyle(size=round(px/unit, 2), color=color, align=1, letter_spacing=-1 if not serif else 0, auto_wrapping=False, max_line_width=0.95)
    seg = TextSegment(censor(s), trange(US(t0), US(t1) - US(t0)), style=st, background=bg,
                      clip_settings=draft.ClipSettings(transform_y=(H/2 - cy*H)/(H/2)))
    for prop, pts in (keys or {}).items():
        for tt, v in pts: seg.add_keyframe(prop, US(tt), v)
    sf.add_segment(seg, track); fonts[seg.material_id] = serif; return seg
def on(t, spans): return any(a <= t < b for a, b in spans)
def card_at(t): return next(((a, bb, k, c) for a, bb, k, c in cards if a <= t < bb), None)

# captions: 1-2 words, a short word rides with the next. For an exact copy, the reference's own groups
# and on/off times, read off it frame by frame (plan["captions"]).
if plan.get("captions"):
    caps = [(snap(c["t0"]), snap(c["t1"]), c["text"]) for c in plan["captions"]]
else:
    groups, i = [], 0
    while i < len(words):
        g = [words[i]]
        if i+1 < len(words) and len(norm(words[i]["w"])) <= 3 and words[i+1]["t0"] - words[i]["t1"] < 0.15 and \
           len(words[i]["w"]) + len(words[i+1]["w"]) <= 10 and words[i+1]["beat"] == words[i]["beat"]:
            g.append(words[i+1])
        groups.append(g); i += len(g)
    caps = []
    for gi, g in enumerate(groups):
        t1 = groups[gi+1][0]["t0"] if gi+1 < len(groups) else TOTAL
        caps.append((g[0]["t0"], min(t1, g[-1]["t1"] + 0.6), " ".join(x["w"] for x in g)))
def in_hook(t0, t1):
    return any(min(t1, b_) - max(t0, a_) > 0.5 * (t1 - t0) for a_, b_ in hook_spans)
def is_stack_word(t0, s):
    cd = card_at(t0 + 0.01)
    return bool(cd and cd[2] == "stack" and norm(s.split()[0]) in [norm(x) for x in cd[3]["stack"]])
caps.sort()
flat = [k for k, (t0, t1, s) in enumerate(caps) if not is_stack_word(t0, s)]
for a_, b_ in zip(flat, flat[1:]):                           # one caption at a time on the caption track
    if caps[a_][1] > caps[b_][0]: caps[a_] = (caps[a_][0], caps[b_][0], caps[a_][2])
hk = V["hook_caption"]; hook_end = OPEN_END
stacked = {}
if HOOKS:
    import fx
    fh_fx = fx.FullscreenHook(sf, J, sty, canvas=(W, H))
    for b_, v in HOOKS.items():
        a_, z_ = beat_span[b_]
        fonts.update(fh_fx.add(a_, z_, title=v.get("title", ""), serif=v.get("serif", ""), sub=v.get("sub", "")))
    print(f"  hook: full-screen title on beat(s) {sorted(HOOKS)}")
for t0, t1, s in caps:
    if in_hook(t0, t1): continue                           # the hook's title replaces the captions there
    cd = card_at(t0 + 0.01)
    if cd and cd[2] == "stack":
        stack = [norm(x) for x in cd[3]["stack"]]
        if norm(s.split()[0]) in stack:                    # list words stack line by line and hold to the card's end
            k = stack.index(norm(s.split()[0])); stacked[k] = (t0, cd[1], s); continue
        text("Captions", s, t0, t1, V["cream_card"]["word"]["px"], V["green_card"]["stack"].get("lead_y", 0.50)); continue
    if cd and cd[2] == "cream":
        text("Captions", s, t0, t1, V["cream_card"]["word"]["px"], V["cream_card"]["word"]["y"], color=INK); continue
    if cd and cd[2] == "green":
        text("Captions", s, t0, t1, V["green_card"]["word"]["px"], V["green_card"]["word"]["y"]); continue
    fcap = frame_cap(t0, t1)
    if fcap:                                                # letterbox: the caption under the picture
        ink = tuple(int(fcap["color"].lstrip("#")[i:i+2], 16)/255 for i in (0, 2, 4)) if fcap.get("color") else WHITE
        text("Captions", s, t0, t1, V["caption_aroll"]["px"], fcap["center_y"] / H, color=ink); continue
    if on(t0 + 0.01, broll_spans):
        text("Captions", s, t0, t1, V["caption_broll"]["px"], V["caption_broll"]["y"]); continue
    if t0 < hook_end:                                       # the hook: big, on the opening zoom (adjustment layer)
        text("Captions", s, t0, t1, hk["px_to"], hk["y_to"], keys=ride(t0, t1, hk["y_to"])); continue
    text("Captions", s, t0, t1, V["caption_aroll"]["px"], V["caption_aroll"]["y"])
pitch = V["green_card"]["stack"]["line_pitch"]; sy0 = V["green_card"]["stack"].get("first_y", 0.446)
for k, (t0, t1, s) in sorted(stacked.items()):
    text(f"Stack {k+1}", s.capitalize(), t0, t1, V["green_card"]["word"]["px"], sy0 + k*pitch*1.4)

# card labels
for a, bb, kind, c in cards:
    if kind == "green" and c.get("label"):
        lb = V["green_card"]["label"]
        # cream box, dark ink: measured off the reference's day labels (#F2F2EB / #12130D)
        text("Label", c["label"], a, bb, lb["px"], lb["y"], color=tuple(v/255 for v in lb["ink"]),
             bg=__import__("pycapcut").TextBackground(color="#%02X%02X%02X" % tuple(lb["bg"]), style=1, alpha=1.0,
                                                    round_radius=0.0, height=0.22, width=0.12))

# opening title: serif, on the opening zoom (the adjustment layer): two keys, the same ease as the footage
title_ids = []
if plan.get("title"):
    tl = V["title_label"]; st = min(OZ["settle_s"], OPEN_END); ty = (H/2 - tl["to_y"]*H)/(H/2)
    t_end = plan.get("title_until") or (hook_end if not cards or cards[0][0] > hook_end else cards[0][0])
    sg = text("Title", plan["title"], 0.0, snap(t_end), tl["px"], tl["to_y"], serif=True,
              keys={KP.uniform_scale: [(0, open_k(0)), (st, 1.0)], KP.position_y: [(0, ty*open_k(0)), (st, ty)]})
    title_ids.append(sg.segment_id)

# CTA: the keyword in quotes, big, above the captions, from when it is said to the end
if plan.get("cta"):
    ct = snap(plan["cta"]["t0"]) if "t0" in plan["cta"] else word_t(plan["cta"]["beats"][0], plan["cta"]["word"])
    text("CTA", f"“{plan['cta']['word'].upper()}”", ct, TOTAL, V["cta_word"]["px"], V["cta_word"]["y"])

# ---- the flash + click transition (fx.py): out of every card back to camera, plus any the plan names.
# An exact copy passes the reference's own flash frames and click times.
if plan.get("flash") is not None: fl = [snap(x) for x in plan["flash"]]
else: fl = sorted({snap(b_) for a_, b_, k_, c_ in cards if 0 < b_ < TOTAL and not card_at(b_ + 0.01)})
# the Board's flash button: a flash on the cut that starts each listed beat, on top of the automatic ones
fl = sorted(set(fl) | {snap(beat_span[b_][0]) for b_ in plan.get("flash_beats", []) if b_ in beat_span and beat_span[b_][0] > 0})
fl = sorted(set(fl) | {snap(a_) for a_, b_ in hook_spans if a_ > 0} | {snap(b_) for a_, b_ in hook_spans if b_ < TOTAL - 0.05})
for t_ in fl: fc.add(t_, click=plan.get("clicks") is None)
clicks = list(plan["clicks"]) if plan.get("clicks") is not None else [t_ - fc.lead for t_ in fl]
if plan.get("clicks") is not None:
    for t_ in plan["clicks"]: fc.add_click(t_)
print(f"  sound: {len(clicks)} click(s), {len(fl)} flash(es)")

finish(sf, dst, name, W, H, US(TOTAL), sty, text_fonts=fonts, left_inset=None)

# the opening's ease-out, in CapCut's own format (read off Gabe's hand-set curve): start key FreeCurveIn
# with no handle, end key FreeCurveOut with its incoming handle flat across the whole move
if EASE_FIRST:
    for fn in ("draft_info.json", "draft_content.json"):
        jj = json.loads((dst/fn).read_text())
        a_roll = next(t_ for t_ in jj["tracks"] if t_["type"] == "video")
        eased = [a_roll["segments"][0]] + [sg for t_ in jj["tracks"] for sg in t_["segments"] if sg["id"] in title_ids]
        for kl in [kl for sg in eased for kl in (sg.get("common_keyframes") or [])]:
            ks = kl["keyframe_list"]
            if len(ks) == 2:                       # the title rides the same curve: same handles, scale and position
                dur = int(ks[1]["time_offset"]) - int(ks[0]["time_offset"])
                ks[0].update({"curveType": "FreeCurveIn", "left_control": {"x": 0.0, "y": 0.0}, "right_control": {"x": 0.0, "y": 0.0}})
                ks[1].update({"curveType": "FreeCurveOut", "left_control": {"x": -float(dur), "y": 0.0}, "right_control": {"x": 1.0, "y": 0.0}})
        (dst/fn).write_text(json.dumps(jj, ensure_ascii=False))
    print(f"  opening: one eased zoom-out (CapCut ease curve), title on it: {bool(title_ids)}")

print(f"  Screen blend on {fc.finish(dst)} flash(es)")
if FSPANS:
    from frame_fit import fit
    print(f"  frame: {fit(dst, FSPANS)} clip(s) fitted into the window")
print(f"\n{name}")
print(f"  {TOTAL:.1f}s · {len(segs)} A-roll cuts ({pushed} slow pushes) · {len(broll_spans)} B-roll · {len(cards)} cards · {len(caps)} captions")
print(f"  draft: {dst}")
