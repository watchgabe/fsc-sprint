#!/usr/bin/env python3
"""zero_start.py [folder] - shift every B-roll clip so its picture starts at 0.000s. Stream copy only: no re-encode.
Writes a temp file beside the original, verifies it, then renames over the original."""
import json, os, pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import config
ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else (config.opt("broll_clips") or config.opt("broll_root")))
def probe(p):
    r = subprocess.run(["ffprobe","-v","error","-show_entries","stream=index,codec_type,start_time,nb_frames,duration",
                        "-of","json",str(p)], capture_output=True, text=True)
    return json.loads(r.stdout or "{}").get("streams", [])
done = skipped = failed = 0
files = sorted(f for f in ROOT.rglob("*.mp4") if not f.name.startswith("."))
for n, f in enumerate(files, 1):
    st = probe(f); v = next((s for s in st if s["codec_type"] == "video"), None)
    if not v: print(f"FAIL no video: {f}"); failed += 1; continue
    off = float(v.get("start_time") or 0)
    if abs(off) < 1e-6: skipped += 1; continue
    has_a = any(s["codec_type"] == "audio" for s in st)
    tmp = f.with_name(f".zs_{f.name}")
    cmd = ["ffmpeg","-y","-v","error","-itsoffset",f"{-off:.6f}","-i",str(f)]
    if has_a: cmd += ["-i",str(f),"-map","0:v","-map","1:a"]
    else:     cmd += ["-map","0:v"]
    cmd += ["-c","copy","-map_metadata","0","-movflags","+faststart",str(tmp)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    nv = next((s for s in probe(tmp) if s["codec_type"] == "video"), None) if tmp.exists() else None
    ok = (r.returncode == 0 and nv and abs(float(nv.get("start_time") or 0)) < 1e-6
          and nv.get("nb_frames") == v.get("nb_frames")
          and abs(float(nv.get("duration") or 0) - float(v.get("duration") or 0)) < 0.05)
    if not ok:
        print(f"FAIL {f.relative_to(ROOT)}: {r.stderr.strip()[:200]} new={nv}"); failed += 1
        tmp.unlink(missing_ok=True); continue
    os.replace(tmp, f); done += 1
    if done % 25 == 0: print(f"  {done} fixed ({n}/{len(files)} checked)", flush=True)
print(f"DONE: {done} fixed, {skipped} already at zero, {failed} failed, {len(files)} total")
