#!/usr/bin/env python3
"""Build B-roll inserts + the continuous caption layer.

Two rules are enforced structurally here rather than by eye:

  1. CAPTION STYLE FOLLOWS THE PICTURE. The style of every caption is decided by
     looking up what is actually on screen at that instant, not by which region
     it belongs to. B-roll or a card -> large centred. A-roll -> small left.
     Inserts tile their region exactly, so there is never a frame of A-roll
     showing under a centred caption (or the reverse).

  2. ONE SHOT PER SOURCE CLIP per video. Two picks from the same file read as
     reuse even when the timecodes differ. Violations raise.
"""
import json, subprocess, sys, pathlib
from _root import HELPERS, CINEYAP, PY  # noqa  (also puts both on sys.path)
sys.path.insert(0, ".")
# THE LOOK IS DATA. gabe_text is the renderer; which STYLE PACK it draws with comes from
# `look` in config.json (a file in cineyap/styles/). Copy styles/gabe.json, change the fonts,
# sizes, tracking and colors, point `look` at it, and every frame in every job follows.
from gabe_text import render_small_left, render_big_centre, render_card, GREEN, WHITE
from PIL import Image
import regions as R

from learned import get as learned
import gabe_text as GT

# A job is vertical when regions.py sets VERTICAL = True. Everything downstream
# (canvas, caption layout, insert crop) follows from that one flag.
if getattr(R, "VERTICAL", False):
    GT.use_vertical()
CANVAS = (1080, 1920) if getattr(R, "VERTICAL", False) else (1920, 1080)

from config import need as cfg_need
class _LazyBroll:
    """Resolve the B-roll folder only when a region actually asks for a shot.
    A member with no B-roll library still gets a captioned cut."""
    _p = None
    def _r(self):
        if self._p is None: self._p = cfg_need("broll_root")
        return self._p
    def __truediv__(self, o): return self._r() / o
    def __str__(self): return str(self._r())
B = _LazyBroll()
A = pathlib.Path("assets"); A.mkdir(exist_ok=True)
words = json.load(open("words_out.json"))
regs = R.build(words)
_sj = pathlib.Path(__file__).parent / "shots.json"
if not _sj.exists():
    raise SystemExit(
        "No shots.json - the B-roll index has not been built on this machine yet.\n"
        "  It indexes YOUR footage, so the package never ships one.\n"
        "  Build it once:\n"
        "    ./vu-py cineyap/detect_shots.py")
shots = json.load(open(_sj))

# The SANDWICH layout: one 16:9 talking-head clip above, the caption in green in
# the middle, a second clip below, all on cream. Gabe 2026-09-24 - preferred over
# a hard zoom when the cutaway footage is horizontal.
INSET_W = 880                       # clip width; height follows 16:9 (495)
INSET_TOP, INSET_BOTTOM = 335, 1090 # y of each clip on a 1080x1920 canvas
INSET_BG = "0xF5F0EA"
INSET_CAPTION_Y = 0.5               # dead centre, between the two clips


def build_sandwich(shots_two, dur, out, lut=False):
    """Two clips + cream background -> one full-frame vertical insert.

    lut=False by default: B-roll library exports are ALREADY graded and a second
    LUT pass blows them out. Only pass lut=True for raw log footage.
    """
    g = f"lut3d={LUT}," if lut else ""
    a, b = shots_two
    cmd = ["ffmpeg", "-y", "-v", "error",
           "-ss", str(a["start"]), "-t", f"{dur:.3f}", "-i", a["path"],
           "-ss", str(b["start"]), "-t", f"{dur:.3f}", "-i", b["path"],
           "-f", "lavfi", "-t", f"{dur:.3f}",
           "-i", f"color=c={INSET_BG}:s={CANVAS[0]}x{CANVAS[1]}:r=24000/1001",
           "-filter_complex",
           f"[0:v]{g}scale={INSET_W}:-2,fps=24000/1001[a];"
           f"[1:v]{g}scale={INSET_W}:-2,fps=24000/1001[b];"
           f"[2:v][a]overlay={(CANVAS[0]-INSET_W)//2}:{INSET_TOP}[t];"
           f"[t][b]overlay={(CANVAS[0]-INSET_W)//2}:{INSET_BOTTOM}[o]",
           "-map", "[o]", "-an", "-c:v", "libx264", "-crf", "16",
           "-pix_fmt", "yuv420p", str(out)]
    subprocess.run(cmd, check=True)

# B-roll keeps its NATIVE resolution. The timeline is 1080 and CapCut fits a 4K clip to it at 100%, so a
# punch, a reframe or the Ken Burns push stays sharp up to 200%. These used to scale to 1920x1080 first,
# and a 130% reframe then enlarged a 1080 picture (Gabe, 2026-10-02: "why would it be enlarged?").
# The presets are the same framings as before, written as fractions of the source instead of pixels.
_A = CANVAS[0] / CANVAS[1]
FIT = (f"crop='min(iw,ih*{_A:.4f})':'min(ih,iw/{_A:.4f})',"           # the canvas shape, no resampling
       f"scale='if(lt(iw,{CANVAS[0]}),{CANVAS[0]},iw)':-2,")             # only a clip SMALLER than the canvas is scaled (up)
REFRAME = {
 "zoom":          "crop=iw*0.835:ih*0.835:iw*0.261:ih*0.093,",
 "subject_right": "crop=iw*0.738:ih*0.738:0:ih*0.137,",
}
LUT = pathlib.Path("../lut.cube").resolve()
TOTAL = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
                              "-of","csv=p=0","base_clean.mp4"],
                             capture_output=True, text=True).stdout.strip())


def resolve(key):
    """SHOT:NAME -> the detected shot containing its pick point.

    A rel path prefixed __ABS__ is a one-off clip outside the B-roll library
    (a second take from the same shoot, say). It skips the shot index and is
    used from its pick point for as long as the region needs.
    """
    rel, t, why = R.SHOT_PICKS[key]
    # LEARNED: a clip Gabe has retired must never come back, in any video.
    for dead in learned("retired_shots", []):
        if dead and dead.lower() in rel.lower():
            raise SystemExit(f"SHOT RETIRED: {key} -> {rel}\n"
                             f"  Gabe retired this clip. Pick another, or "
                             f"`learned.py forget <n>` if that was wrong.")
    if rel.startswith("__ABS__"):
        p = rel[len("__ABS__"):]
        return {"clip": p, "path": p, "start": t, "end": t + 30, "dur": 30,
                "key": key, "why": why}
    hit = [s for s in shots if s["clip"] == rel and s["start"] <= t <= s["end"]]
    if not hit:
        raise SystemExit(f"{key}: no detected shot contains t={t} in {rel}")
    s = dict(hit[0]); s["key"] = key; s["why"] = why
    return s


def snap_starts(region):
    return [w[0] for w in words[region["i0"]:region["i1"] + 1]]


# ------------------------------------------------------------------ inserts
inserts, used_clips = [], {}
for ri, r in enumerate(regs):
    if r["kind"] != "broll":
        continue
    opt = r["payload"] if isinstance(r["payload"], dict) else {}
    keys = opt.get("shots", r["payload"])
    MIN = opt.get("min_shot", 1.5)
    starts = snap_starts(r)

    if keys and isinstance(keys[0], (list, tuple)):
        bounds = []
        for anchor, k in keys:
            hit = next((w[0] for w in words[r["i0"]:r["i1"]+1] if w[2] == anchor), None)
            if hit is None:
                raise SystemExit(f"anchor word not in region: {anchor}")
            bounds.append((hit, k))
        spans = [(bounds[i][0], bounds[i+1][0] if i+1 < len(bounds) else r["t1"], bounds[i][1])
                 for i in range(len(bounds))]
        merged = []
        for sp in spans:
            if merged and sp[1] - sp[0] < MIN:
                merged[-1] = (merged[-1][0], sp[1], merged[-1][2])
            else:
                merged.append(sp)
        while len(merged) > 1 and merged[-1][1] - merged[-1][0] < MIN:
            merged[-2] = (merged[-2][0], merged[-1][1], merged[-2][2]); merged.pop()
        spans = merged
    else:
        n = len(keys); span = (r["t1"] - r["t0"]) / n
        spans = [(r["t0"] + i*span, r["t0"] + (i+1)*span, k) for i, k in enumerate(keys)]

    # tile the region exactly: snap interior edges to word starts, pin the ends
    spans = [list(sp) for sp in spans]
    for i in range(1, len(spans)):
        edge = min(starts, key=lambda s: abs(s - spans[i][0]))
        spans[i][0] = edge; spans[i-1][1] = edge
    spans[0][0] = r["t0"]; spans[-1][1] = r["t1"]

    if opt.get("inset"):
        two = [resolve(k) for k in (opt.get("shots") or keys)][:2]
        out = A / f"ins_{ri:02d}_sandwich.mp4"
        build_sandwich(two, r["t1"] - r["t0"] + 0.2, out, lut=bool(opt.get("lut")))
        inserts.append({"file": str(out), "t0": round(r["t0"], 3), "t1": round(r["t1"], 3),
                        "key": "SANDWICH", "clip": "|".join(s["clip"] for s in two),
                        "why": " + ".join(s["why"] for s in two),
                        "colour": "green", "matte": None})
        continue
    for a, b, key in spans:
        sh = resolve(key)
        # One shot per clip, UNLESS the region opts in: a run of talking-head
        # cutaways from one A-roll file is deliberate, not reuse.
        sig = (sh["clip"], sh["start"])
        if sig in used_clips:
            raise SystemExit(f"SHOT REUSED: {sh['clip']} @{sh['start']:.1f} at {a:.1f}s")
        if sh["clip"] in {c for c, _ in used_clips} and not opt.get("allow_same_clip", keys and isinstance(keys[0], (list, tuple))):
            raise SystemExit(f"CLIP REUSED: {sh['clip']} at {a:.1f}s")
        used_clips[sig] = a
        ps = opt.get("per_shot", {}).get(key, {})
        # Cut with HANDLES: up to 0.5s before the region and 1.0s after, as far as the shot allows, so
        # the cut guard can hold a B-roll to the next A-roll cut instead of leaving a frame of old
        # A-roll between them. asset_in is where the region starts inside the asset.
        head = min(0.5, 0.0)   # shots are detected from their first clean frame; no head room by default
        tail = min(1.0, max(0.0, sh["dur"] - (b - a) - 0.2))
        need = b - a + 0.2 + tail
        if sh["dur"] < b - a + 0.2:
            print(f"  ! {key} only {sh['dur']:.1f}s, need {b-a+0.2:.1f}s")
        out = A / f"ins_{ri:02d}_{key.split(':')[1]}.mp4"
        subprocess.run(["ffmpeg","-y","-v","error","-ss",str(sh["start"] - head),"-t",f"{need:.3f}",
                        "-i", sh["path"], "-an",
                        "-vf", ((f"lut3d={LUT}," if (ps.get("lut") or opt.get("lut")) else "")

                                + REFRAME.get(ps.get("reframe") or opt.get("reframe"),
                                ("" if opt.get("inset") else FIT))
                                + "fps=24000/1001,setpts=PTS-STARTPTS"),   # start at 0.000, or Finder previews black and editors show a blank first frame
                        "-c:v","libx264","-crf","16","-pix_fmt","yuv420p", str(out)], check=True)
        matte = None
        if ps.get("mask_subject") or opt.get("mask_subject"):
            matte = A / f"sub_{ri:02d}_{key.split(':')[1]}.webm"
            if not matte.exists():
                print(f"    matting {key} (slow, local model)…")
                subprocess.run(["npx","--yes","hyperframes@latest","remove-background",
                                str(out),"-o",str(matte),"--quality","best"], check=True)
        inserts.append({"file": str(out), "t0": round(a,3), "t1": round(b,3),
                        "asset_in": round(head, 3), "asset_dur": round(min(need, sh["dur"] + head), 3),
                        "key": key, "clip": sh["clip"], "why": sh["why"],
                        "colour": ps.get("colour") or opt.get("colour"),
                        "matte": str(matte) if matte else None})
json.dump(inserts, open("inserts.json","w"), indent=1)
print(f"  {len(inserts)} inserts from {len(used_clips)} distinct clips (no reuse)")

# ------------------------------------------------- exposed hard-cut check
# Gabe 2026-09-23: an A-roll jump cut is fine, that is the style. What reads as
# a glitch is a cover (B-roll or card) RELEASING just before one - you see him
# in position A for a beat, then he snaps to position B. Two parts:
#   1. nudge any cover whose edge lands within NUDGE of a join so it spans it
#   2. fail the build if a join is still exposed within EXPOSE_MIN of a release
EXPOSE_MIN, JUMP_MIN, NUDGE = 2.0, 1.5, 0.45
_edl = json.load(open("../edit/edl.json"))
_off, _joins, _prev = 0.0, [], None
for _r in _edl["ranges"]:
    if _prev is not None and _r["start"] - _prev["end"] > 0.15:
        _joins.append((round(_off, 2), round(_r["start"] - _prev["end"], 2)))
    _off += _r["end"] - _r["start"]; _prev = _r

for _o in inserts:                       # 1. pull each insert across a nearby join
    for _jt, _gap in _joins:
        if 0 < _jt - _o["t0"] < NUDGE or 0 < _o["t0"] - _jt < NUDGE:
            _o["t0"] = round(min(_o["t0"], _jt - 0.15), 3)
        if 0 < _jt - _o["t1"] < NUDGE or 0 < _o["t1"] - _jt < NUDGE:
            _o["t1"] = round(max(_o["t1"], _jt + 0.15), 3)

def _covered(t):
    for _r in regs:
        if _r["kind"] in ("green", "cream") and _r["t0"] <= t < _r["t1"]:
            return True
    return any(_o["t0"] <= t < _o["t1"] for _o in inserts)

_flash = []
for _jt, _gap in _joins:
    if _gap <= JUMP_MIN or _covered(_jt):
        continue
    _t = _jt                              # walk back to where cover was lost
    while _t > 0 and not _covered(_t):
        _t -= 1/24
    _exposed = _jt - _t
    if _exposed < EXPOSE_MIN:
        _flash.append(f"hard cut at {_jt:.2f}s ({_gap:.1f}s jump) with only "
                      f"{_exposed:.2f}s of A-roll after the cover released")
if _flash:
    raise SystemExit("EXPOSED HARD CUT:\n  " + "\n  ".join(_flash))
json.dump(inserts, open("inserts.json", "w"), indent=1)

# --------------------------------------------------------------- coverage map
def cover(t):
    """What is actually on screen at t."""
    for r in regs:
        if r["kind"] in ("green","cream") and r["t0"] <= t < r["t1"]:
            return ("card", r["kind"])
    for ins in inserts:
        if ins["t0"] <= t < ins["t1"]:
            return ("broll", ins.get("colour"))
    return ("aroll", None)

SMALL_WORDS = learned("small_words",
                      1 if getattr(R, "VERTICAL", False) else 2)   # vertical: one word
RAMP_STEP = 1.35          # each repeat of a word this much bigger
MASK_MIN_W = 760          # the subject occupies roughly the middle 400px at 1080p


def wide_enough(txt):
    """Would this caption read past the subject on a masked shot?"""
    from PIL import Image, ImageDraw
    from gabe_text import _font, _tracked_width, BIG_SIZE, BIG_TRACK
    d = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    f = _font(True, BIG_SIZE)
    return _tracked_width(d, txt, f, BIG_TRACK / 1000 * BIG_SIZE) >= MASK_MIN_W


# ------------------------------------------------------------------- captions
cues = []
for r in regs:
    seg = words[r["i0"]:r["i1"]+1]
    opt = r["payload"] if isinstance(r["payload"], dict) else {}
    serif = set(opt.get("serif", []))
    hold = opt.get("hold_tail")
    body = seg[:-hold[0]] if hold else seg
    masked = bool(opt.get("mask_subject"))
    ramp = bool(opt.get("ramp_repeats"))
    run_word, run_n = None, 0
    chunk = []
    for w in body:
        kind, colour = cover(w[0])
        if kind == "broll" and masked:
            # On a masked shot a short centred word lands entirely behind the
            # subject and vanishes. Group words until the caption is wide enough
            # to read past him on both sides.
            chunk.append(w)
            txt = " ".join(c[2] for c in chunk).lower().rstrip(",")
            if wide_enough(txt) or w is body[-1]:
                cues.append((chunk[0][0], ("big", txt, False, colour, 1.0)))
                chunk = []
            continue
        if kind == "aroll":
            chunk.append(w)
            if len(chunk) >= SMALL_WORDS or chunk[-1][2][-1:] in ".,?!":
                cues.append((chunk[0][0], ("small", " ".join(c[2] for c in chunk).lower().rstrip(","))))
                chunk = []
        else:
            if chunk:
                cues.append((chunk[0][0], ("small", " ".join(c[2] for c in chunk).lower().rstrip(","))))
                chunk = []
            txt = w[2].lower().rstrip(",")
            it = w[2] in serif
            sc = 1.0
            if ramp:
                # "subtract, subtract, subtract" — each repeat 10% bigger
                if txt == run_word:
                    run_n += 1
                else:
                    run_word, run_n = txt, 0
                sc = round(RAMP_STEP ** run_n, 3)
            if kind == "card":
                cues.append((w[0], ("card", txt, it, colour, sc)))
            else:
                cues.append((w[0], ("big", txt, it,
                                    "green" if opt.get("inset") else colour, sc,
                                    INSET_CAPTION_Y if opt.get("inset") else 0.5)))
    if chunk:
        cues.append((chunk[0][0], ("small", " ".join(c[2] for c in chunk).lower().rstrip(","))))
    if hold:
        kind, colour = cover(seg[-hold[0]][0])
        cues.append((seg[-hold[0]][0],
                     ("card", hold[1], False, colour, 1.0) if kind == "card" else ("big", hold[1], False, colour, 1.0)))
cues.sort(key=lambda c: c[0])

# A cue hangs until the next one starts, which can outlast the cover it was
# styled for: the B-roll ends and the caption stays large and centred over
# A-roll for a frame or two. Gabe caught this repeatedly. Split every cue that
# spans a cover edge and re-style the tail for what is on screen after it.
edges = sorted({round(t, 3) for o in inserts for t in (o["t0"], o["t1"])} |
               {round(t, 3) for r in regs if r["kind"] in ("green", "cream")
                for t in (r["t0"], r["t1"])})
split = []
for i, (t0, spec) in enumerate(cues):
    t1 = cues[i + 1][0] if i + 1 < len(cues) else 10 ** 9
    split.append((t0, spec))
    for e in edges:
        if t0 + 0.02 < e < t1 - 0.02:
            kind, colour = cover(e + 0.001)
            txt = spec[1]
            if kind == "aroll":
                new = ("small", txt)
            elif kind == "card":
                new = ("card", txt, spec[2] if spec[0] == "card" else False, colour, 1.0)
            else:
                new = ("big", txt, spec[2] if spec[0] == "big" else False, colour,
                       spec[4] if len(spec) > 4 else 1.0)
            # Same look on both sides of the edge (a serif card word over a card): no split. Re-typing it
            # dropped the serif, so the accent flipped to sans for the last frames before the cut.
            if new[:4] != spec[:4]: split.append((e, new))
cues = sorted(split, key=lambda c: c[0])

uniq = {}
for _, spec in cues:
    if spec in uniq:
        continue
    i = len(uniq); uniq[spec] = i
    p = A / f"cue{i:03d}.png"
    sc = spec[4] if len(spec) > 4 else 1.0
    yf = spec[5] if len(spec) > 5 else 0.5
    if spec[0] == "small":
        render_small_left(spec[1], p)
    elif spec[0] == "big":
        render_big_centre(spec[1], p, serif=spec[2],
                          colour=GREEN if spec[3]=="green" else WHITE, scale=sc, y_frac=yf)
    else:
        render_card(spec[1], p, green=(spec[3] == "green"), serif=spec[2], scale=sc)
print(f"  {len(cues)} cues, {len(uniq)} unique frames")

# A manifest of what each cue SAYS. The PNGs are pixels; downstream steps that
# need the words (an SRT, an After Effects text build, a wording fix) read this.
json.dump([{"t": round(t,3), "png": f"cue{uniq[spec]:03d}.png", "kind": spec[0],
            "text": spec[1], "serif": bool(spec[2]) if len(spec) > 2 else False,
            "colour": spec[3] if len(spec) > 3 else None,
            "scale": spec[4] if len(spec) > 4 else 1.0}
           for t, spec in cues], open("cues.json", "w"), indent=1)

Image.new("RGBA",CANVAS,(0,0,0,0)).save(A/"blank.png")

# FRAME-EXACT layer. The concat demuxer rounds every image duration up to a whole
# frame; across ~280 cues that accumulated to 1.24s of drift, so captions lagged
# the picture more and more through the video. Build an explicit frame sequence
# instead: one symlink per output frame pointing at its cue.
FPS = 24000/1001
nframes = int(round(TOTAL * FPS))
seq = A / "seq"
if seq.exists():
    for f in seq.iterdir(): f.unlink()
else:
    seq.mkdir()
def cue_at(t):
    lo, hi, best = 0, len(cues)-1, None
    for i,(t0,spec) in enumerate(cues):
        if t0 <= t: best = i
        else: break
    return best
for n in range(nframes):
    t = n / FPS
    i = cue_at(t)
    src = (A/"blank.png") if i is None else (A/f"cue{uniq[cues[i][1]]:03d}.png")
    (seq/f"f{n:06d}.png").symlink_to(src.resolve())
print(f"  layer: {nframes} frames, frame-exact to {TOTAL:.3f}s")
