#!/bin/bash
# check.sh — build the draft, open it in CapCut, open the project, scrub to a few spots, screenshot.
# Lets a build be verified by eye without a human quitting and reopening the app each time.
#   check.sh <job> [out-prefix] [t1 t2 t3...]   (seconds to scrub to; default 2 14.5 36)
set -e
JOB="${1:-ladder-test}"; OUT="${2:-/tmp/cc}"; shift 2 2>/dev/null || true
TIMES="${@:-2 14.5 36}"
PKG="$HOME/Developer/CineYap"; PY="$PKG/.venv/bin/python"; M="$PKG/cineyap/mouse.py"

osascript -e 'tell application "CapCut" to quit' 2>/dev/null || true
for i in $(seq 30); do pgrep -x CapCut >/dev/null || break; sleep 0.5; done
pgrep -x CapCut >/dev/null && { killall CapCut 2>/dev/null; sleep 3; }   # CapCut sometimes answers quit with 'user canceled'

cd "$PKG/projects/$JOB/build"
"$PY" "$PKG/cineyap/mkcapcut.py"

open -a CapCut; sleep 7
osascript -e 'tell application "CapCut" to activate'; sleep 1
osascript -e 'tell application "System Events" to tell process "CapCut" to set position of first window to {0, 25}' 2>/dev/null || true
osascript -e 'tell application "System Events" to tell process "CapCut" to set size of first window to {1920, 1055}' 2>/dev/null || true
sleep 1
screencapture -x -o "${OUT}_home.png"
"$PY" "$M" click 306 813 2; sleep 10          # first project tile = the newest draft
# ruler: 00:00 at x=185, 10s per 143px at the default zoom
for T in $TIMES; do
  X=$(awk -v t="$T" 'BEGIN{printf "%d", 185 + t*14.3}')
  "$PY" "$M" click "$X" 655 1; sleep 2
  screencapture -x -o "${OUT}_t${T}.png"
done
echo "shots: ${OUT}_home.png ${OUT}_t*.png"
