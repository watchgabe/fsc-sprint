#!/usr/bin/env python3
"""build_review.py — the cut review as an interactive widget (first look) or a lean table (re-cuts).

    build_review.py <job>            -> projects/<job>/edit/review.html   (paste into show_widget)
    build_review.py <job> --table    -> markdown table on stdout          (every re-cut after the first)

One row per kept take: the spoken line, its length, trash, note. Between takes, a row for each B-roll
insert with a picker over the whole library, and "+ B-roll here" on any take that has none. Cards show
their word and color. Send compiles every click into one plain message Claude acts on.

Why two outputs: the widget is ~25K tokens to render and the table is ~1.5K. The widget is the first
look; after that the table carries the same line numbers so edits map straight back.

Everything the widget needs comes from files the pipeline already writes:
  edit/edl.json       the kept takes (source times + quote), in timeline order
  build/inserts.json  B-roll placed on the timeline (t0/t1 + clip)
  build/cues.json     every caption; the ones with a colour are card words
The B-roll library is whatever lives under config broll_root, grouped by its folder.
"""
import json, pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
import config

if len(sys.argv) < 2:
    sys.exit("usage: build_review.py <job> [--table]")
job   = sys.argv[1]
table = "--table" in sys.argv
JOB   = PROJECTS / job
if not (JOB / "edit/edl.json").exists():
    sys.exit(f"no edit/edl.json in {JOB} - run the cut first")

edl  = json.load(open(JOB / "edit/edl.json"))
ins  = json.load(open(JOB / "build/inserts.json")) if (JOB / "build/inserts.json").exists() else []
cues = json.load(open(JOB / "build/cues.json"))    if (JOB / "build/cues.json").exists()    else []

# ---- takes on the PICTURE clock: each rendered clip is a whole number of frames, so the real cut
# drifts from the plan (+7.6 frames over 89s on ladder-test). inserts.json and cues.json are on the
# picture clock after cut_guard.py, so the takes must be too or the Board files B-roll under the
# wrong line (b1 showed on line 1 while the draft had it exactly on line 2).
import subprocess
FPS = 24000/1001
stem = pathlib.Path(list(edl["sources"].values())[0]).stem
def nframes(f):
    out = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=nb_frames",
                          "-of","csv=p=0",str(f)], capture_output=True, text=True).stdout.strip()
    return int(out) if out.isdigit() else None
takes, t = [], 0.0
for i, r in enumerate(edl["ranges"], 1):
    n = nframes(JOB/f"edit/clips_graded/seg_{i-1:02d}_{stem}.mp4")
    d = n / FPS if n else r["end"] - r["start"]
    takes.append({"n": i, "t0": round(t, 3), "t1": round(t + d, 3), "dur": round(d, 1),
                  "beat": r.get("beat", ""), "text": r.get("quote", "").strip()})
    t += d

def take_at(sec, end=None):
    """The take an element belongs to: the one it overlaps MOST, not the one its first frame touches."""
    if end is None:
        for k in takes:
            if k["t0"] <= sec < k["t1"]: return k["n"]
        return takes[-1]["n"] if takes else 0
    best = max(takes, key=lambda k: min(end, k["t1"]) - max(sec, k["t0"]))
    return best["n"]

# ---- B-roll inserts, attached to the take they start on
import base64
def thumb(path, at):
    """A small still of a clip as a data URI: the widget sandbox cannot load files, only inline images."""
    raw = subprocess.run(["ffmpeg","-v","error","-ss",f"{at:.2f}","-i",str(path),"-frames:v","1","-vf","scale=112:-2",
                          "-q:v","14","-f","image2","-c:v","mjpeg","-"], capture_output=True).stdout
    return "data:image/jpeg;base64," + base64.b64encode(raw).decode() if raw else ""
brolls = []
for j, o in enumerate(ins, 1):
    f = (JOB/"build"/o["file"]) if not pathlib.Path(o["file"]).is_absolute() else pathlib.Path(o["file"])
    brolls.append({"id": o.get("id") or f"b{j}", "take": take_at(o["t0"], o["t1"]), "t0": o["t0"], "t1": o["t1"],
                   "clip": o.get("clip") or pathlib.Path(o["file"]).name,
                   "why": o.get("why", ""), "thumb": thumb(f, float(o.get("asset_in", 0)) + 0.5) if f.exists() else ""})
# the framing each line got in the last build (mkcapcut writes it): wide or tight
_fr = JOB/"build/framing.json"
FR = json.load(open(_fr)) if _fr.exists() else []
for k in takes: k["zoom"] = FR[k["n"]-1] if k["n"]-1 < len(FR) else "wide"
_ef = JOB/"build/effects.json"; EF = json.load(open(_ef)) if _ef.exists() else {}
for k in takes:
    k["behind"] = any(int(e["take"]) == k["n"] for e in EF.get("behind", []))
    k["bg"] = (EF.get("bg") or {}).get(str(k["n"]), "")
    k["flash"] = k["n"] in {int(n) for n in EF.get("flash") or []}

# ---- cards: consecutive coloured cue words within a second of each other form one card
cards, cur = [], None
for c in sorted(cues, key=lambda x: x["t"]):
    if not c.get("colour"): continue
    same = (c.get("card") and cur and c.get("card") == cur.get("id")) or \
           (not c.get("card") and cur and c["colour"] == cur["colour"] and c["t"] - cur["t1"] < 1.0)
    if same:
        cur["words"].append(c["text"]); cur["t1"] = c["t"]
        if c.get("serif"): cur["accent"].append(len(cur["words"]) - 1)
    else:
        if cur: cards.append(cur)
        cur = {"colour": c["colour"], "t0": c["t"], "t1": c["t"], "words": [c["text"]], "id": c.get("card"),
               "accent": [0] if c.get("serif") else []}
if cur: cards.append(cur)
for k, c in enumerate(cards, 1):
    c["id"] = c.get("id") or f"c{k}"; c["take"] = take_at(c["t0"], c["t1"] + 0.3); c["text"] = " ".join(c["words"])

# ---- the B-roll library, grouped by folder, for the picker. Prefer the split library (one shot
# per file, so a pick is a shot, not a 4-minute reel to scrub) and fall back to the raw folder.
root = config.opt("broll_clips") or config.opt("broll_root")
lib = {}
if root and pathlib.Path(root).is_dir():
    for p in sorted(pathlib.Path(root).rglob("*")):
        if p.suffix.lower() in (".mp4", ".mov") and not p.name.startswith("."):
            lib.setdefault(str(p.parent.relative_to(root)), []).append(p.stem)

total = takes[-1]["t1"] if takes else 0
def fmt(s): return f"{int(s // 60)}:{int(round(s % 60)):02d}"

# ---------------------------------------------------------------- lean table (re-cuts)
if table:
    out = ["| # | line | dur | on this take |", "|---|------|-----|--------------|"]
    for k in takes:
        extra = [f"B-roll {b['id']}: {b['clip']}" for b in brolls if b["take"] == k["n"]]
        extra += [f"card {c['id']} ({c['colour']}): {c['text']}" for c in cards if c["take"] == k["n"]]
        out.append(f"| {k['n']} | {k['text'][:70]}{'…' if len(k['text']) > 70 else ''} | {k['dur']}s | {'; '.join(extra)} |")
    out.append(f"\n**total: {fmt(total)} · reply with changes by line number, B-roll id, or card id**")
    print("\n".join(out)); sys.exit(0)

# ---------------------------------------------------------------- the widget
def esc(s): return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
static_rows = "".join(
    f'<div data-static style="display:flex;gap:12px;padding:8px 12px;border:0.5px solid var(--border);'
    f'border-radius:var(--radius);font-size:14px;"><span style="color:var(--text-muted)">{k["n"]}</span>'
    f'<span style="flex:1">{esc(k["text"])}</span><span style="color:var(--text-secondary)">{k["dur"]}s</span></div>'
    for k in takes)

sty = __import__("style").load()
acc = sty.get("accent", {"treatment": "serif-italic", "color": None})
data = json.dumps({"job": job, "takes": takes, "brolls": brolls, "cards": cards,
                   "accent": {"treatment": acc.get("treatment", "serif-italic"), "color": acc.get("color")}},
                  ensure_ascii=False)

BOARD_JS = (PKG / 'cineyap/board.js').read_text()   # the row layout lives in its own file: plain JS, no f-string brace doubling
html = f'''<h2 class="sr-only">Cut review for {esc(job)}: every kept line with its B-roll and cards, each editable, with a length meter and a send button.</h2>
<div data-cy-root style="padding:0.5rem 0 1rem;">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
    <div style="display:flex;gap:14px;font-size:13px;color:var(--text-secondary);">
      <span><span data-kept style="color:var(--text-primary);font-weight:500;">0</span> kept</span>
      <span><span data-cut style="color:var(--text-primary);font-weight:500;">0</span> cut</span>
      <span><span data-changes style="color:var(--text-primary);font-weight:500;">0</span> changes</span>
    </div>
    <div style="display:flex;align-items:center;gap:10px;">
      <div style="width:140px;height:6px;border-radius:999px;background:var(--surface-1);overflow:hidden;"><div data-meter style="height:100%;width:0%;background:var(--text-secondary);"></div></div>
      <span data-len style="font-size:13px;font-weight:500;min-width:40px;text-align:right;">0:00</span>
    </div>
  </div>
  <div data-rows style="display:flex;flex-direction:column;gap:6px;">{static_rows}</div>
  <div style="display:flex;gap:10px;margin-top:14px;flex-wrap:wrap;">
    <button type="button" data-send>Send my edits <i class="ti ti-arrow-up-right" aria-hidden="true"></i></button>
    <button type="button" data-reset><i class="ti ti-refresh" aria-hidden="true"></i> Reset</button>
  </div>
  <div data-fb style="display:none;margin-top:12px;padding:12px;border:0.5px solid var(--border-strong);border-radius:var(--radius);background:var(--surface-1);">
    <div data-fb-note style="font-size:13px;color:var(--text-secondary);margin-bottom:8px;"></div>
    <textarea data-fb-text readonly rows="5" style="width:100%;font-size:13px;resize:vertical;"></textarea>
    <button type="button" data-copy style="margin-top:8px;">Copy <i class="ti ti-copy" aria-hidden="true"></i></button>
  </div>
</div>
<script>(function(){{
var me=document.currentScript, root=null;
if(me&&me.previousElementSibling&&me.previousElementSibling.matches&&me.previousElementSibling.matches("[data-cy-root]")) root=me.previousElementSibling;
if(!root){{var all=document.querySelectorAll("[data-cy-root]");for(var i=0;i<all.length;i++){{if(!all[i].hasAttribute("data-live")){{root=all[i];break;}}}}if(!root&&all.length)root=all[all.length-1];}}
if(!root)return; root.setAttribute("data-live","1");
try{{
var D={data};
var q=function(s){{return root.querySelector(s);}};
var S={{takes:{{}},brolls:{{}},cards:{{}},added:[]}};
function fresh(){{S.takes={{}};S.brolls={{}};S.cards={{}};S.added=[];
 D.takes.forEach(function(k){{S.takes[k.n]={{cut:false,note:"",open:false,matte:k.bg||"",behind:!!k.behind,flash:!!k.flash,sfx:"",fxOpen:false,zoom:k.zoom}};}});
 D.brolls.forEach(function(b){{S.brolls[b.id]={{clip:b.clip,remove:false,open:false}};}});
 D.cards.forEach(function(c){{S.cards[c.id]={{words:c.words.slice(),accent:c.accent.slice(),colour:c.colour,remove:false,edit:false}};}});}}
fresh();
var fmt=function(s){{var m=Math.floor(s/60),x=Math.round(s%60);return m+":"+(x<10?"0":"")+x;}};
function counts(){{var kept=0,cut=0,ch=0,dur=0;
 D.takes.forEach(function(k){{var s=S.takes[k.n];if(s.cut){{cut++;ch++;}}else{{kept++;dur+=k.dur;}}if(s.note.trim())ch++;if(s.matte!==(k.bg||""))ch++;if(s.behind!==!!k.behind)ch++;if(s.flash!==!!k.flash)ch++;if(s.zoom!==k.zoom)ch++;}});
 D.brolls.forEach(function(b){{var s=S.brolls[b.id];if(s.remove||s.clip!==b.clip)ch++;}});
 D.cards.forEach(function(c){{var s=S.cards[c.id];if(s.remove||s.words.join(" ")!==c.words.join(" ")||s.colour!==c.colour||s.accent.slice().sort().join()!==c.accent.slice().sort().join())ch++;}});
 ch+=S.added.filter(function(a){{return a.clip;}}).length;
 q("[data-kept]").textContent=kept;q("[data-cut]").textContent=cut;q("[data-changes]").textContent=ch;
 q("[data-len]").textContent=fmt(dur);var m=q("[data-meter]");m.style.width=Math.min(100,dur/120*100)+"%";
 var good=dur>=45&&dur<=90;m.style.background=good?"var(--text-success)":(dur>90?"var(--text-warning)":"var(--text-secondary)");
 q("[data-len]").style.color=good?"var(--text-success)":"var(--text-primary)";}}
function btn(icon,label,on,active){{var b=document.createElement("button");b.type="button";b.innerHTML='<i class="ti ti-'+icon+'" aria-hidden="true"></i>';b.setAttribute("aria-label",label);
 b.style.cssText="padding:4px 7px;font-size:14px;line-height:1;"+(active?"border-color:var(--border-accent);color:var(--text-accent);":"");b.addEventListener("click",on);return b;}}
{BOARD_JS}
function compile(){{var L=[],J={{cut:[],zoom:{{}},behind:[],bg:{{}},flash:[],broll:{{swap:{{}},remove:[],add:[]}},cards:{{}},notes:{{}}}};
 D.takes.forEach(function(k){{var st=S.takes[k.n];
  if(st.cut){{J.cut.push(k.n);}}
  var n=st.note.trim();if(n){{L.push("Line "+k.n+' ("'+k.text.slice(0,40)+'…"): '+n);J.notes[k.n]=n;}}
  if(st.zoom!==k.zoom){{L.push("Line "+k.n+": "+(st.zoom==="tight"?"punch in":"no zoom")+".");J.zoom[k.n]=st.zoom;}}
  if(st.matte!==(k.bg||""))L.push("Line "+k.n+": background "+(st.matte||"off")+".");if(st.matte)J.bg[k.n]=st.matte;
  if(st.behind!==!!k.behind)L.push("Line "+k.n+": text behind subject "+(st.behind?"on":"off")+".");if(st.behind)J.behind.push(k.n);
  if(st.flash!==!!k.flash)L.push("Line "+k.n+": flash "+(st.flash?"on":"off")+".");if(st.flash)J.flash.push(k.n);}});
 if(J.cut.length)L.unshift("Cut lines: "+J.cut.join(", ")+".");
 D.brolls.forEach(function(b){{var s=S.brolls[b.id];if(s.remove){{L.push("Remove B-roll "+b.id+" ("+b.clip+").");J.broll.remove.push(b.id);}}else if(s.clip!==b.clip){{L.push("Swap B-roll "+b.id+": "+b.clip+" -> "+s.clip+".");J.broll.swap[b.id]=s.clip;}}}});
 S.added.forEach(function(a){{if(a.clip){{L.push("Add B-roll on line "+a.take+": "+a.clip+".");J.broll.add.push({{take:a.take,clip:a.clip}});}}}});
 D.cards.forEach(function(c){{var s=S.cards[c.id];var was=c.words.join(" "),now=s.words.join(" ");var a0=c.accent.slice().sort().join(),a1=s.accent.slice().sort().join();
  if(s.remove){{L.push("Remove card "+c.id+' ("'+was+'").');J.cards[c.id]={{remove:true}};return;}}
  if(now!==was||s.colour!==c.colour||a1!==a0){{J.cards[c.id]={{words:s.words,accent:s.accent.slice().sort(function(x,y){{return x-y;}}),colour:s.colour}};
   L.push("Card "+c.id+': "'+now+'"'+(s.colour!==c.colour?", "+s.colour:"")+(a1!==a0?", accent: "+(s.accent.map(function(i){{return s.words[i];}}).join(", ")||"none"):"")+".");}}}});
 if(!L.length)return "The "+D.job+" cut is approved, no changes. Build the CapCut draft.";
 return "My edits to the "+D.job+" cut (from the Board):\\n- "+L.join("\\n- ")+"\\n\\nApply with cineyap/apply_board.py.\\n\\n```board\\n"+JSON.stringify(J)+"\\n```";}}
function send(){{var msg=compile(),ok=false;try{{if(typeof sendPrompt==="function"){{sendPrompt(msg);ok=true;}}}}catch(e){{}}
 var fb=q("[data-fb]"),ta=q("[data-fb-text]");ta.value=msg;fb.style.display="block";q("[data-fb-note]").textContent=ok?"Sent. If it did not show up in the chat, copy this and paste it:":"Copy this and paste it into the chat:";ta.focus();ta.select();try{{document.execCommand("copy");}}catch(e){{}}}}
q("[data-send]").addEventListener("click",send);
q("[data-reset]").addEventListener("click",function(){{fresh();q("[data-fb]").style.display="none";render();counts();}});
q("[data-copy]").addEventListener("click",function(){{var ta=q("[data-fb-text]");ta.focus();ta.select();try{{document.execCommand("copy");}}catch(e){{}}}});
render();counts();
}}catch(err){{var n=document.createElement("div");n.style.cssText="margin-top:10px;font-size:12px;color:var(--text-secondary);";n.textContent="(Read-only cut. Reply with changes by line number.)";root.appendChild(n);}}
}})();</script>'''

out = JOB / "edit/review.html"
out.write_text(html)
print(f"{out}\n  {len(takes)} takes · {len(brolls)} B-roll · {len(cards)} cards · {len(html)//1024} KB")
