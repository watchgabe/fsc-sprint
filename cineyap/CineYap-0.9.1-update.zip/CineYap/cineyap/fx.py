"""fx.py — the effects library. One implementation per effect, shared by every format.

An effect is a moment that can drop into any format (16:9 CineYap, vertical, panel, poster, reel): the
format decides WHEN, the effect owns HOW. Change an effect here and every format gets it. The catalogue
with what each one looks like, where it was measured and which formats use it: cineyap/effects/README.md.

    from fx import FlashClick
    fc = FlashClick(sf, job_dir, pack)        # adds the Flash video track and the SFX audio track
    fc.add(t)                                 # a flash on the cut at t, its click 2 frames ahead
    ...
    finish(sf, dst, ...)                      # the normal capcut_draft finish
    fc.finish(dst)                            # Screen blend onto every flash (CapCut's own record)
"""
import copy, json, math, pathlib, subprocess, uuid
import numpy as np
import pycapcut as draft
from pycapcut import VideoSegment, AudioSegment, AudioMaterial, trange
from _root import PKG
import config

GRID = 1/24.0                                   # the draft's frame grid (24 fps)
US = lambda s: int(round(s * 1_000_000))
snap = lambda t: round(t / GRID) * GRID


class FlashClick:
    """THE FLASH + CLICK TRANSITION (measured off "How To Keep Showin' Up", locked 2026-10-02).

    Look:  the orange light-leak clip (config `sfx_flash_overlay`, "Overlay 1.mp4"), ORIGINAL file, CapCut
           Screen blend, 0.45s, starting ON the cut so its brightest first frame covers the cut frame.
    Sound: the Quick Click (config `sfx_click`) at volume 0.35 against a -16.7 LUFS voice, its snap
           2 frames BEFORE the flash frame (5 of 6 in the reference, matched by audio).
    Why it is built the way it is, every point measured on CapCut exports:
      - an alpha-converted flash bands (un-premultiplying 8-bit lifts the dark blocks): original + Screen
      - a sub-0.1s audio clip plays in the editor but is DROPPED from the export: the click is padded
      - CapCut rounds an audio clip's start AND its head-trim UP to whole frames: each click sits exactly
        on a frame and carries its own sub-frame lead-in as silence (one tiny wav per click). Result: every
        click within 1 ms of the reference on export.
    """
    def __init__(self, sf, job_dir, pack=None, flash_track="Flash", sfx_track="SFX", flash_index=10, sfx_index=0, canvas=(1080, 1920), fps=24.0, lead_frames=None):
        self.sf, self.J, self.W, self.H = sf, pathlib.Path(job_dir), canvas[0], canvas[1]
        # The frame grid of THIS draft. The vertical drafts run on 24; the 16:9 CineYap runs on 23.976
        # (its A-roll cuts are whole 23.976 frames). A flash snapped to the wrong grid starts up to a frame
        # off its cut, and CapCut rounds a click's start up to the draft's own frames, not ours.
        self.grid = 1.0 / float(fps)
        p = (pack or {}).get("sfx", {})
        self.lead = (p.get("click_lead_frames", 2) if lead_frames is None else lead_frames) * self.grid
        self.volume = p.get("click_volume", 0.35)
        self.flash_track, self.sfx_track = flash_track, sfx_track
        fl = config.opt("sfx_flash_overlay"); self.flash = pathlib.Path(fl) if fl else None
        ck = config.opt("sfx_click"); self.click = pathlib.Path(ck) if ck else None
        if self.flash and not self.flash.exists(): self.flash = None
        if self.click and not self.click.exists(): self.click = None
        if self.flash: sf.add_track(draft.TrackType.video, flash_track, relative_index=flash_index)
        if self.click: sf.add_track(draft.TrackType.audio, sfx_track, relative_index=sfx_index)
        self.flash_ids, self.n_click, self.onset = [], 0, 0.0
        if self.click: self._prep_click()
        self.clip = None
        if self.flash: self._fit_flash()

    def _fit_flash(self):
        """cover the canvas; a portrait leak on a landscape canvas is turned 90 degrees first"""
        d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height:stream_side_data=rotation",
                                       "-of","json",str(self.flash)], capture_output=True, text=True).stdout)["streams"][0]
        fw, fh = d["width"], d["height"]
        if any(abs(int(x.get("rotation", 0))) in (90, 270) for x in d.get("side_data_list", [])): fw, fh = fh, fw
        fit = min(self.W/fw, self.H/fh); dw, dh = fw*fit, fh*fit
        turn = (fw > fh) != (self.W > self.H)
        if turn: dw, dh = dh, dw
        sc = max(self.W/dw, self.H/dh)
        self.clip = draft.ClipSettings(scale_x=sc, scale_y=sc, rotation=90.0 if turn else 0.0)

    def _prep_click(self):
        dur = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(self.click)],
                                   capture_output=True, text=True).stdout.strip() or 0)
        (self.J/"fx/clicks").mkdir(parents=True, exist_ok=True)
        if dur < 0.3:                                              # dropped from exports otherwise
            padded = self.J/"fx/clicks/click_padded.wav"
            subprocess.run(["ffmpeg","-v","error","-y","-i",str(self.click),"-af","apad=pad_dur=0.45","-ar","48000","-ac","2",str(padded)], check=True)
            self.click = padded
        a = np.frombuffer(subprocess.run(["ffmpeg","-v","error","-i",str(self.click),"-ac","1","-ar","48000","-f","f32le","-"],
                                         capture_output=True).stdout, np.float32)
        if len(a): self.onset = float(np.argmax(np.abs(a) > np.abs(a).max()*0.3)) / 48000   # where the snap is in the file

    def add(self, t, flash=True, click=True, click_at=None):
        """a flash on the cut at t (snapped to the frame grid) and its click; click_at overrides the
        click's snap time (an exact copy passes the reference's own click times)"""
        snap = lambda x: round(x / self.grid) * self.grid
        key = round(snap(t), 4)
        if key in getattr(self, "_done", set()): return            # one flash per cut, however many effects ask
        self._done = getattr(self, "_done", set()) | {key}
        if flash and self.flash:
            seg = VideoSegment(str(self.flash), trange(US(snap(t)), US(0.45)), volume=0.0, clip_settings=self.clip)
            self.sf.add_segment(seg, self.flash_track); self.flash_ids.append(seg.material_id)
        if click and self.click:
            self.add_click(click_at if click_at is not None else snap(t) - self.lead)

    def add_click(self, snap_t):
        """the click alone, its snap landing on the sample snap_t"""
        if not self.click: return
        want = max(0.0, snap_t - self.onset); k = math.floor(want / self.grid + 1e-9); lead = want - k*self.grid
        f = self.J/f"fx/clicks/click_{self.n_click:02d}.wav"; self.n_click += 1
        subprocess.run(["ffmpeg","-v","error","-y","-i",str(self.click),"-af",f"adelay={round(lead*48000)}S:all=1,apad=pad_dur=0.3",
                        "-ar","48000","-ac","2",str(f)], check=True)
        m = AudioMaterial(str(f)); ln = min(m.duration/1e6 - 0.002, 0.6)
        self.sf.add_segment(AudioSegment(m, trange(US(k*self.grid), US(ln)), volume=self.volume), self.sfx_track)

    def finish(self, dst):
        """after capcut_draft.finish(): the Screen blend on every flash. CapCut keeps it as a
        materials.effects record (type mix_mode) referenced from the segment's extra_material_refs;
        the record is the one CapCut itself wrote when Gabe set Screen by hand."""
        mixf = PKG/"cineyap/_capcut_mix_screen.json"
        if not self.flash_ids or not mixf.exists(): return 0
        base = json.loads(mixf.read_text()); n = 0
        for fn in ("draft_info.json", "draft_content.json"):
            jj = json.loads((pathlib.Path(dst)/fn).read_text()); n = 0
            for tr_ in jj["tracks"]:
                for sg in tr_["segments"]:
                    if sg.get("material_id") in self.flash_ids:
                        e = copy.deepcopy(base); e["id"] = str(uuid.uuid4()).upper()
                        jj["materials"].setdefault("effects", []).append(e)
                        sg.setdefault("extra_material_refs", []).append(e["id"]); n += 1
            (pathlib.Path(dst)/fn).write_text(json.dumps(jj, ensure_ascii=False))
        return n


# --- Library effects: new effects live in fx_library.py (owned by the Library); every format imports them from here.
try:
    from fx_library import *          # noqa: F401,F403
except ImportError:
    pass
