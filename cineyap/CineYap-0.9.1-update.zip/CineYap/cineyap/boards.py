#!/usr/bin/env python3
"""boards.py — the Board for every format: what a video's Board shows, and how a Send is applied.

The Studio page (studio.py) calls two functions per format:

    model(job, fmt)          -> the Board's data for that video in that format
    apply(job, fmt, edits)   -> writes the edits into that format's own plan, rebuilds the CapCut draft,
                                verifies, returns the log

Two kinds of Board:
  lines   one row per kept line of the cut (CineYap 16:9 and 4:3, Vertical, Vertical CineYap). The tiles
          on a row are the format's `caps`; B-roll slots and cards hang under the line they sit on.
  items   one card per slide / slot / panel (Poster, Carousel, Reel template, YapMaxxing): text fields
          and media slots.

Every format keeps its edits in its OWN plan file (effects.json, vertical/plan.json, poster.json, ...),
so a rebuild for any other reason keeps them. Nothing here re-implements a builder: it edits the plan
and runs the builder that already exists.

    ./vu-py cineyap/boards.py <job> <fmt>                  print the model (debug)
    ./vu-py cineyap/boards.py <job> <fmt> --apply edits.json
"""
import json, pathlib, re, shutil, subprocess, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
import config

PY = str(PKG/".venv/bin/python")
FPS = 24000/1001

FORMATS = {
    "cineyap":  {"name": "CineYap",          "canvas": "16:9", "suffix": "CineYap",         "kind": "lines",
                 "caps": ["note", "broll", "zoom", "behind", "bg", "flash", "frame", "tag", "hook", "bold", "gscreen", "split", "pull"]},
    "cineyap43":{"name": "CineYap 4:3",      "canvas": "4:3",  "suffix": "CineYap 4x3",     "kind": "lines",
                 "caps": ["note", "broll", "zoom", "behind", "bg", "flash", "frame", "tag", "hook", "bold", "gscreen", "split", "pull"]},
    "vertical": {"name": "Vertical",         "canvas": "9:16", "suffix": "Vertical",        "kind": "lines",
                 "caps": ["note", "broll", "card", "flash", "frame", "hook"]},
    "vcineyap": {"name": "Vertical CineYap", "canvas": "9:16", "suffix": "Vertical CineYap","kind": "lines",
                 "caps": ["note", "broll", "look", "flash", "frame", "hook", "bold", "gscreen", "pull"]},
    "vertical34":{"name": "Vertical 3:4",    "canvas": "3:4",  "suffix": "Vertical 3x4",    "kind": "lines",
                 "caps": ["note", "broll", "card", "flash", "frame", "hook"], "flag": "--3x4", "same": "vertical"},
    "vcineyap34":{"name": "Vertical CineYap 3:4", "canvas": "3:4", "suffix": "Vertical CineYap 3x4", "kind": "lines",
                 "caps": ["note", "broll", "look", "flash", "frame", "hook", "bold", "gscreen", "pull"], "flag": "--3x4", "same": "vcineyap"},
    "panel":    {"name": "YapMaxxing",       "canvas": "9:16", "suffix": "YapMaxxing",      "kind": "items"},
    "poster":   {"name": "Poster 4:3",       "canvas": "4:3",  "suffix": "Poster",          "kind": "items"},
    "poster_v": {"name": "Poster vertical",  "canvas": "9:16", "suffix": "Poster Vertical", "kind": "items"},
    "carousel": {"name": "Carousel",         "canvas": "4:3",  "suffix": "Carousel",        "kind": "items"},
    "reel":     {"name": "Reel template",    "canvas": "9:16", "suffix": "Reel",            "kind": "items"},
}

def draft_name(job, fmt): return f"{job} ({FORMATS[fmt]['suffix']})"

def _has_draft(job, fmt):
    from open_draft import drafts
    return draft_name(job, fmt) in drafts()

def portrait(job):
    """the take was shot vertical (the rendered cut is upright, so its own size says)"""
    f = PROJECTS/job/"build/base_clean.mp4"
    if not f.exists(): return False
    o = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height","-of","csv=p=0",str(f)],
                       capture_output=True, text=True).stdout.strip().split(",")
    return len(o) == 2 and o[0].isdigit() and int(o[1]) > int(o[0])

def has_format(job, fmt):
    """a video has a format when that format's plan exists (the draft alone is not enough to edit it)"""
    J = PROJECTS/job
    return {
        "cineyap":  (J/"build/cues.json").exists() and (J/"build/inserts.json").exists() and not portrait(job),
        "cineyap43":(J/"build/cues.json").exists() and (J/"build/inserts.json").exists() and not portrait(job),
        "vertical": (J/"vertical/plan.json").exists(),
        "vcineyap": (J/"vcineyap/plan.json").exists(),
        # the 3:4 builds share the 9:16 plan; they show once a 3:4 draft has been built
        "vertical34": (J/"vertical/plan.json").exists() and _has_draft(job, "vertical34"),
        "vcineyap34": (J/"vcineyap/plan.json").exists() and _has_draft(job, "vcineyap34"),
        "panel":    (J/"panel/panel.json").exists(),
        "poster":   (J/"poster/poster.json").exists(),
        "poster_v": (J/"poster/poster.json").exists(),
        "carousel": (J/"carousel/COPY.txt").exists(),
        "reel":     (J/"template/COPY.txt").exists(),
    }[fmt]

# ------------------------------------------------------------------ shared helpers
def ffprobe_frames(f):
    o = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=nb_frames","-of","csv=p=0",str(f)],
                       capture_output=True, text=True).stdout.strip()
    return int(o) if o.isdigit() else None

def broll_roots():
    return [pathlib.Path(p) for p in (config.opt("broll_clips"), config.opt("broll_root")) if p]

def resolve_clip(name, job=None):
    """a clip from the Board: an absolute path, a path relative to a B-roll root, or a bare filename"""
    p = pathlib.Path(name)
    if p.is_absolute() and p.exists(): return p
    if job and (PROJECTS/job/"board_media"/p.name).exists(): return PROJECTS/job/"board_media"/p.name
    for r in broll_roots():
        if (r/name).exists(): return r/name
    for r in broll_roots():
        hits = list(r.rglob(p.name)) if r.exists() else []
        if hits: return hits[0]
    return None

def rel_clip(p):
    """the shortest stable name for a clip: relative to broll_clips when it lives there"""
    p = pathlib.Path(p)
    for r in broll_roots():
        try: return str(p.relative_to(r))
        except ValueError: pass
    return str(p)

def thumb_url(path, t=0.5):
    from urllib.parse import quote
    return f"/thumb?p={quote(str(path))}&t={t:.2f}"

def words_of(job):
    tr = sorted((PROJECTS/job/"edit/transcripts").glob("*.json"))
    if not tr: return []
    return [w for w in json.load(open(tr[0]))["words"] if w.get("type") == "word"]

def quit_capcut():
    import os
    if os.environ.get("CINEYAP_DRAFTS"): return True          # building into a scratch folder: CapCut is not involved
    from open_draft import running, quit_capcut as q
    return q() if running() else True

def run(args, cwd=None, log=None):
    """run a builder, append its output to the log list; raise on failure"""
    log.append("$ " + " ".join(str(a) for a in args[-3:]))
    r = subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True, text=True)
    out = (r.stdout + ("\n" + r.stderr if r.returncode else "")).strip()
    log.extend(out.splitlines()[-40:])
    if r.returncode: raise RuntimeError(f"{pathlib.Path(str(args[1])).name} failed")
    return r.stdout

# ------------------------------------------------------------------ lines: CineYap (16:9 and 4:3)
def _cineyap_model(job):
    J = PROJECTS/job; B = J/"build"
    edl = json.load(open(J/"edit/edl.json"))
    ins = json.load(open(B/"inserts.json")) if (B/"inserts.json").exists() else []
    cues = json.load(open(B/"cues.json")) if (B/"cues.json").exists() else []
    stem = pathlib.Path(list(edl["sources"].values())[0]).stem
    takes, t = [], 0.0
    for i, r in enumerate(edl["ranges"], 1):
        n = ffprobe_frames(J/f"edit/clips_graded/seg_{i-1:02d}_{stem}.mp4")
        d = n / FPS if n else r["end"] - r["start"]
        takes.append({"n": i, "t0": round(t, 3), "t1": round(t + d, 3), "dur": round(d, 1),
                      "beat": r.get("beat", ""), "text": r.get("quote", "").strip()})
        t += d
    def take_at(a, b):
        return max(takes, key=lambda k: min(b, k["t1"]) - max(a, k["t0"]))["n"] if takes else 0
    brolls = []
    for j, o in enumerate(ins, 1):
        f = (B/o["file"]) if not pathlib.Path(o["file"]).is_absolute() else pathlib.Path(o["file"])
        brolls.append({"id": o.get("id") or f"b{j}", "take": take_at(o["t0"], o["t1"]), "t0": o["t0"], "t1": o["t1"],
                       "clip": o.get("clip") or f.name, "why": o.get("why", ""),
                       "thumb": thumb_url(f, float(o.get("asset_in", 0)) + 0.5) if f.exists() else "", "src": str(f)})
    FR = json.load(open(B/"framing.json")) if (B/"framing.json").exists() else []
    EF = json.load(open(B/"effects.json")) if (B/"effects.json").exists() else {}
    for k in takes:
        k["zoom"] = FR[k["n"]-1] if k["n"]-1 < len(FR) else "wide"
        k["behind"] = any(int(e["take"]) == k["n"] for e in EF.get("behind", []))
        k["bg"] = (EF.get("bg") or {}).get(str(k["n"]), "")
        k["flash"] = k["n"] in {int(n) for n in EF.get("flash") or []}
        k["frame"] = (EF.get("frame") or {}).get(str(k["n"])) or {}
        k["card_tag"] = (EF.get("card_tag") or {}).get(str(k["n"])) or {}
        k["hook"] = (EF.get("hook") or {}).get(str(k["n"])) or {}
        k["bold"] = k["n"] in {int(n) for n in EF.get("bold_behind") or []}
        k["greenscreen"] = (EF.get("greenscreen") or {}).get(str(k["n"])) or {}
        k["split"] = (EF.get("split") or {}).get(str(k["n"]))
        k["pullback"] = (EF.get("pullback") or {}) if k["n"] == 1 else None
    cards, cur = [], None
    for c in sorted(cues, key=lambda x: x["t"]):
        if not c.get("colour"): continue
        same = (c.get("card") and cur and c.get("card") == cur.get("id")) or \
               (not c.get("card") and cur and c["colour"] == cur["colour"] and c["t"] - cur["t1"] < 1.0)
        if same:
            cur["words"].append(c["text"]); cur["t1"] = c["t"]
            if c.get("serif"): cur["accent"].append(len(cur["words"]) - 1)
        else:
            if cur: cards.append(cur)
            cur = {"colour": c["colour"], "t0": c["t"], "t1": c["t"], "words": [c["text"]], "id": c.get("card"),
                   "accent": [0] if c.get("serif") else []}
    if cur: cards.append(cur)
    for k, c in enumerate(cards, 1):
        c["id"] = c.get("id") or f"c{k}"; c["take"] = take_at(c["t0"], c["t1"] + 0.3)
    return {"takes": takes, "brolls": brolls, "cards": cards}

def _cineyap_apply(job, edits, four3, log):
    J = PROJECTS/job
    (J/"edit/board_edits.json").write_text(json.dumps(edits))
    args = [PY, PKG/"cineyap/apply_board.py", job]
    if four3: args.append("--4x3")
    run(args, log=log)

# ------------------------------------------------------------------ lines: Vertical ("Showin' Up")
def _vertical_lines(job):
    """the rows: one per kept range of the cut, with its words, on the draft's clock"""
    J = PROJECTS/job; edl = json.load(open(J/"edit/edl.json")); plan = json.load(open(J/"vertical/plan.json"))
    W = words_of(job); rows, t = [], 0.0
    if plan.get("cut_from"):
        for k, r in enumerate(json.load(open(plan["cut_from"]))):
            a, b = r["edit_t0"], r["edit_t1"]; s0 = r["wav_t0"]
            txt = " ".join(w["text"] for w in W if s0 - 0.02 <= w["start"] and w["end"] <= s0 + (b - a) + 0.05)
            rows.append({"n": k + 1, "t0": round(a, 3), "t1": round(b, 3), "dur": round(b - a, 1), "beat": f"S{k}", "text": txt})
        t = rows[-1]["t1"] if rows else 0.0
    for r in edl["ranges"]:
        d = r["end"] - r["start"]
        txt = r.get("quote") or " ".join(w["text"] for w in W if r["start"] - 0.02 <= w["start"] and w["end"] <= r["end"] + 0.05)
        rows.append({"n": len(rows) + 1, "t0": round(t, 3), "t1": round(t + d, 3), "dur": round(d, 1), "beat": r.get("beat", ""), "text": txt})
        t += d
    return rows, plan

def _vertical_model(job):
    rows, plan = _vertical_lines(job)
    by_beat = {r["beat"]: r["n"] for r in rows}
    def line_at(a, b): return max(rows, key=lambda k: min(b, k["t1"]) - max(a, k["t0"]))["n"]
    brolls = []
    for i, b in enumerate(plan.get("broll", []), 1):
        n = by_beat.get((b.get("beats") or [None])[0]) or (line_at(b["t0"], b["t1"]) if "t0" in b else 1)
        p = resolve_clip(b["clip"])
        brolls.append({"id": f"v{i}", "take": n, "clip": b["clip"], "thumb": thumb_url(p, b.get("in_s", 0.5) + 0.3) if p else "",
                       "src": str(p) if p else "", "t0": rows[n-1]["t0"], "t1": rows[n-1]["t1"]})
    flash_beats = set(plan.get("flash_beats", []))
    for r in rows:
        c = next((c for c in plan.get("cards", []) if c.get("beat") == r["beat"]), None)
        r["card"] = c["type"] if c else ""; r["label"] = (c or {}).get("label", "")
        r["flash"] = r["beat"] in flash_beats
        r["frame"] = (plan.get("frames") or {}).get(r["beat"]) or {}
        r["hook"] = (plan.get("hooks") or {}).get(r["beat"]) or {}
    return {"takes": rows, "brolls": brolls, "cards": [], "copy": bool(plan.get("cut_from"))}

def _vertical_apply(job, e, log, flag=None):
    J = PROJECTS/job; pf = J/"vertical/plan.json"; plan = json.load(open(pf))
    shutil.copy(pf, J/f"vertical/plan.before-board.{time.strftime('%H%M%S')}.json")
    rows, _ = _vertical_lines(job); beat = {r["n"]: r["beat"] for r in rows}
    # cards: the Board sends the full state per line
    for n, c in (e.get("card") or {}).items():
        bt = beat[int(n)]; plan["cards"] = [x for x in plan.get("cards", []) if x.get("beat") != bt]
        if c and c.get("type") in ("green", "cream"):
            entry = {"beat": bt, "type": c["type"]}
            if c.get("label"): entry["label"] = c["label"]
            plan["cards"].append(entry)
    if "flash" in e: plan["flash_beats"] = [beat[int(n)] for n in e["flash"]]
    if "frame" in e: plan["frames"] = {beat[int(n)]: v for n, v in e["frame"].items() if (v or {}).get("look")}
    for v in (plan.get("frames") or {}).values():
        if v.get("clip"):
            p_ = resolve_clip(v["clip"], job)
            if p_ is None: raise RuntimeError(f"frame clip '{v['clip']}' not found")
            v["clip"] = rel_clip(p_)
    if "hook" in e: plan["hooks"] = {beat[int(n)]: v for n, v in e["hook"].items() if v and (v.get("title") or v.get("sub"))}
    br = e.get("broll") or {}
    for bid, clip in (br.get("swap") or {}).items():
        i = int(bid[1:]) - 1; p = resolve_clip(clip, job)
        if p is None: raise RuntimeError(f"B-roll '{clip}' not found")
        plan["broll"][i]["clip"] = rel_clip(p); plan["broll"][i].pop("in_s", None); log.append(f"swap {bid} -> {p.name}")
    for bid in sorted(br.get("remove") or [], key=lambda x: -int(x[1:])):
        log.append(f"remove {bid}"); plan["broll"].pop(int(bid[1:]) - 1)
    for a in br.get("add") or []:
        p = resolve_clip(a["clip"], job)
        if p is None: raise RuntimeError(f"B-roll '{a['clip']}' not found")
        plan.setdefault("broll", []).append({"beats": [beat[int(a["take"])]], "clip": rel_clip(p)}); log.append(f"add {p.name} on line {a['take']}")
    cuts = sorted({int(n) for n in e.get("cut") or []}, reverse=True)
    if cuts:
        if plan.get("cut_from"): raise RuntimeError("this is an exact copy of a finished reel: cut lines in CapCut, not here")
        edl = json.load(open(J/"edit/edl.json"))
        for n in cuts:
            bt = edl["ranges"][n-1].get("beat"); del edl["ranges"][n-1]
            plan["cards"] = [x for x in plan.get("cards", []) if x.get("beat") != bt]
            plan["broll"] = [x for x in plan.get("broll", []) if bt not in (x.get("beats") or [])]
        json.dump(edl, open(J/"edit/edl.json", "w"), indent=1); log.append(f"cut line(s) {sorted(cuts)}")
    json.dump(plan, open(pf, "w"), indent=1)
    if not quit_capcut(): raise RuntimeError("CapCut would not quit")
    run([PY, PKG/"cineyap/mkvertical.py", job] + ([flag] if flag else []), log=log)

# ------------------------------------------------------------------ lines: Vertical CineYap ("30 Pieces")
def _vcy_model(job):
    J = PROJECTS/job; plan = json.load(open(J/"vcineyap/plan.json"))
    edl = json.load(open(J/"edit/edl.json")); W = words_of(job); rows, t = [], 0.0
    for i, r in enumerate(edl["ranges"], 1):
        d = r["end"] - r["start"]
        txt = r.get("quote") or " ".join(w["text"] for w in W if r["start"] - 0.02 <= w["start"] and w["end"] <= r["end"] + 0.05)
        L = (plan.get("lines") or {}).get(str(i), {})
        rows.append({"n": i, "t0": round(t, 3), "t1": round(t + d, 3), "dur": round(d, 1), "beat": r.get("beat", ""), "text": txt,
                     "look": L.get("look", "captions"), "step": L.get("step", ""), "media": L.get("media", ""),
                     "flash": i in set(plan.get("flash", [])), "frame": L.get("frame") or {}, "hook": L.get("hook") or {},
                     "greenscreen": L.get("greenscreen") or {}, "bold": i in set(plan.get("bold_behind") or []),
                     "pullback": (plan.get("pullback") or {}) if i == 1 else None})
        t += d
    brolls = []
    for i, b in enumerate(plan.get("broll", []), 1):
        p = resolve_clip(b["clip"]); n = b["line"]
        brolls.append({"id": f"y{i}", "take": n, "clip": b["clip"], "thumb": thumb_url(p, 1.0) if p else "", "src": str(p) if p else "",
                       "t0": rows[n-1]["t0"] if n-1 < len(rows) else 0, "t1": rows[n-1]["t1"] if n-1 < len(rows) else 0})
    return {"takes": rows, "brolls": brolls, "cards": []}

def _vcy_apply(job, e, log, flag=None):
    J = PROJECTS/job; pf = J/"vcineyap/plan.json"; plan = json.load(open(pf))
    shutil.copy(pf, J/f"vcineyap/plan.before-board.{time.strftime('%H%M%S')}.json")
    lines = plan.setdefault("lines", {})
    for n, L in (e.get("look") or {}).items():
        cur = lines.setdefault(str(n), {})
        for k in ("look", "step", "media"):
            if k in L: cur[k] = L[k]
        if cur.get("look") == "captions": cur.pop("look")
        if cur.get("media"):
            p = resolve_clip(cur["media"], job)
            if p is None: raise RuntimeError(f"media '{cur['media']}' not found")
            cur["media"] = rel_clip(p)
        if not cur: lines.pop(str(n))
    if "flash" in e: plan["flash"] = sorted({int(n) for n in e["flash"]})
    if "frame" in e:                                  # full state: every framed line is listed
        for n in list(lines): lines[n].pop("frame", None)
        for n, v in e["frame"].items():
            if (v or {}).get("look"): lines.setdefault(str(n), {})["frame"] = v
        for n in [n for n, v in lines.items() if not v]: lines.pop(n)
    if "caption_style" in e: plan["caption_style"] = e["caption_style"] or ""
    if "bold_behind" in e: plan["bold_behind"] = sorted({int(n) for n in e["bold_behind"]})
    if "pullback" in e: plan["pullback"] = e["pullback"] or {}
    if "greenscreen" in e:
        for n in list(lines): lines[n].pop("greenscreen", None)
        for n, v in e["greenscreen"].items():
            if v and v.get("clip"):
                p_ = resolve_clip(v["clip"], job)
                if p_ is None: raise RuntimeError(f"green screen clip '{v['clip']}' not found")
                lines.setdefault(str(n), {})["greenscreen"] = {"clip": rel_clip(p_)}
        for n in [n for n, v in lines.items() if not v]: lines.pop(n)
    if "hook" in e:                                   # full state, like frame
        for n in list(lines): lines[n].pop("hook", None)
        for n, v in e["hook"].items():
            if v and (v.get("title") or v.get("sub")): lines.setdefault(str(n), {})["hook"] = v
        for n in [n for n, v in lines.items() if not v]: lines.pop(n)
    br = e.get("broll") or {}
    for bid, clip in (br.get("swap") or {}).items():
        p = resolve_clip(clip, job)
        if p is None: raise RuntimeError(f"B-roll '{clip}' not found")
        plan["broll"][int(bid[1:]) - 1]["clip"] = rel_clip(p); plan["broll"][int(bid[1:]) - 1].pop("in_s", None)
    for bid in sorted(br.get("remove") or [], key=lambda x: -int(x[1:])): plan["broll"].pop(int(bid[1:]) - 1)
    for a in br.get("add") or []:
        p = resolve_clip(a["clip"], job)
        if p is None: raise RuntimeError(f"B-roll '{a['clip']}' not found")
        plan.setdefault("broll", []).append({"line": int(a["take"]), "clip": rel_clip(p)})
    cuts = sorted({int(n) for n in e.get("cut") or []}, reverse=True)
    if cuts:
        edl = json.load(open(J/"edit/edl.json"))
        for n in cuts: del edl["ranges"][n-1]
        renum = lambda n: n - sum(1 for c in cuts if c < n)
        plan["lines"] = {str(renum(int(k))): v for k, v in lines.items() if int(k) not in cuts}
        plan["flash"] = [renum(n) for n in plan.get("flash", []) if n not in cuts]
        plan["broll"] = [dict(b, line=renum(b["line"])) for b in plan.get("broll", []) if b["line"] not in cuts]
        json.dump(edl, open(J/"edit/edl.json", "w"), indent=1); log.append(f"cut line(s) {sorted(cuts)}")
    json.dump(plan, open(pf, "w"), indent=1)
    if not quit_capcut(): raise RuntimeError("CapCut would not quit")
    run([PY, PKG/"cineyap/mkvcineyap.py", job] + ([flag] if flag else []), log=log)

# ------------------------------------------------------------------ items: Poster, YapMaxxing, Carousel, Reel
POSTER_FIELDS = [("L1", "Headline, left top", False), ("L2", "Headline, left bottom", False),
                 ("R1", "Headline, right top", False), ("R2", "Headline, right bottom", False),
                 ("corner_left", "Corner: by-line", False), ("corner_right", "Corner: day block", True)]

def _poster_model(job):
    p = json.load(open(PROJECTS/job/"poster/poster.json"))
    return {"items": [{"id": "poster", "title": "Poster copy", "sub": "Reads L1 L2 R1 R2. **bold** in the corners.",
                       "fields": [{"key": k, "label": lb, "value": p.get(k, ""), "multi": m} for k, lb, m in POSTER_FIELDS], "media": []}]}

def _poster_apply(job, e, vertical, log):
    f = PROJECTS/job/"poster/poster.json"; p = json.load(open(f))
    for k, v in ((e.get("fields") or {}).get("poster") or {}).items(): p[k] = v
    json.dump(p, open(f, "w"), indent=1, ensure_ascii=False)
    if not quit_capcut(): raise RuntimeError("CapCut would not quit")
    run([PY, PKG/"cineyap/mkposter.py", job] + (["--vertical"] if vertical else []), log=log)

def _panel_model(job):
    p = json.load(open(PROJECTS/job/"panel/panel.json")); h = p.get("hook", {})
    items = [{"id": "hook", "title": "Hook", "sub": "On the panel's bottom edge for the first seconds",
              "fields": [{"key": "title", "label": "Title", "value": h.get("title", ""), "multi": False},
                         {"key": "sub", "label": "Under it", "value": h.get("sub", ""), "multi": False}], "media": []}]
    for m in p.get("media", []):
        items.append({"id": f"beat{m['beat']}", "title": f"Panel {m['beat']}", "sub": f"{m['t0']:.1f}s to {m['t1']:.1f}s · {m.get('layout', 'wide')}",
                      "fields": [], "media": [{"key": str(k), "label": f"Picture {k+1}" if len(m["clips"]) > 1 else "Picture",
                                               "clip": c, "thumb": thumb_url(resolve_clip(c) or c, 1.0)} for k, c in enumerate(m["clips"])]})
    return {"items": items}

def _panel_apply(job, e, log):
    f = PROJECTS/job/"panel/panel.json"; p = json.load(open(f))
    for k, v in ((e.get("fields") or {}).get("hook") or {}).items(): p.setdefault("hook", {})[k] = v
    for iid, slots in (e.get("media") or {}).items():
        m = next(x for x in p["media"] if f"beat{x['beat']}" == iid)
        for k, clip in slots.items():
            q = resolve_clip(clip, job)
            if q is None: raise RuntimeError(f"picture '{clip}' not found")
            m["clips"][int(k)] = rel_clip(q) if str(q).startswith(tuple(str(r) for r in broll_roots())) else str(q)
    json.dump(p, open(f, "w"), indent=1, ensure_ascii=False)
    if not quit_capcut(): raise RuntimeError("CapCut would not quit")
    run([PY, PKG/"cineyap/mkpanel.py", job], log=log)

def _blocks(copy_txt, head):
    """COPY.txt -> [(n, header line, body)] for '## SLIDE n' / '## SLOT n' blocks"""
    out, cur = [], None
    for line in copy_txt.splitlines():
        m = re.match(rf"##\s*{head}\s+(\d+)(.*)$", line)
        if m: cur = [int(m.group(1)), line, []]; out.append(cur); continue
        if cur is not None: cur[2].append(line)
    return [(n, h, "\n".join(b).strip("\n")) for n, h, b in out]

def _slides_model(job, sub, head):
    D = PROJECTS/job/sub; blocks = _blocks((D/"COPY.txt").read_text(), head)
    bgs = {b["n"]: b for b in (json.load(open(D/"backgrounds.json")) if (D/"backgrounds.json").exists() else [])}
    items = []
    for n, h, body in blocks:
        b = bgs.get(n, {}); c = b.get("clip", ""); p = resolve_clip(c) if c else None
        items.append({"id": f"s{n}", "title": f"{head.title()} {n}", "sub": h.split(head, 1)[-1].split(str(n), 1)[-1].strip() or (b.get("why") or ""),
                      "fields": [{"key": "copy", "label": "Copy", "value": body, "multi": True}],
                      "media": [{"key": "clip", "label": "Background", "clip": c, "thumb": thumb_url(p, 1.0) if p else ""}]})
    return {"items": items, "help": "`backticks` = accent word. In a carousel: EYEBROW: / HEADLINE: / SUB: / - bullets / NOTE:"}

def _slides_apply(job, e, sub, head, log):
    D = PROJECTS/job/sub; txt = (D/"COPY.txt").read_text(); blocks = _blocks(txt, head)
    edits = e.get("fields") or {}
    lines = txt.splitlines()             # the preamble: everything above the first block header
    first = next((i for i, l in enumerate(lines) if re.match(rf"##\s*{head}\s+\d+", l)), len(lines))
    pre = "\n".join(lines[:first])
    out = [pre.rstrip("\n") + "\n"] if pre.strip() else []
    for n, h, body in blocks:
        body = (edits.get(f"s{n}") or {}).get("copy", body)
        out.append(h + "\n" + body.strip("\n") + "\n")
    (D/"COPY.txt").write_text("\n".join(out).rstrip("\n") + "\n")
    bf = D/"backgrounds.json"; bgs = json.load(open(bf)) if bf.exists() else []
    for iid, slots in (e.get("media") or {}).items():
        n = int(iid[1:]); q = resolve_clip(slots.get("clip", ""), job)
        if q is None: raise RuntimeError(f"background '{slots.get('clip')}' not found")
        b = next((x for x in bgs if x["n"] == n), None)
        if b is None: b = {"n": n}; bgs.append(b)
        b.update({"clip": rel_clip(q), "at": 0.5, "why": "picked on the Board"})
    json.dump(sorted(bgs, key=lambda x: x["n"]), open(bf, "w"), indent=1, ensure_ascii=False)
    if not quit_capcut(): raise RuntimeError("CapCut would not quit")
    if sub == "carousel": run([PY, PKG/"cineyap/mkcarousel.py", "--no-mp4"], cwd=D, log=log)
    else: run([PY, PKG/"cineyap/mkreel.py", job], log=log)

# ------------------------------------------------------------------ the two entry points
def model(job, fmt):
    f = FORMATS[fmt]; base = {"job": job, "fmt": fmt, "format": f["name"], "canvas": f["canvas"], "kind": f["kind"],
                              "caps": f.get("caps", []), "draft": draft_name(job, fmt)}
    sty = __import__("style").load()
    base["accent"] = {"treatment": sty.get("accent", {}).get("treatment", "serif-italic"), "color": sty.get("accent", {}).get("color")}
    if fmt in ("cineyap", "cineyap43"): base.update(_cineyap_model(job))
    elif fmt in ("vertical", "vertical34"): base.update(_vertical_model(job))
    elif fmt in ("vcineyap", "vcineyap34"): base.update(_vcy_model(job))
    elif fmt in ("poster", "poster_v"): base.update(_poster_model(job))
    elif fmt == "panel": base.update(_panel_model(job))
    elif fmt == "carousel": base.update(_slides_model(job, "carousel", "SLIDE"))
    elif fmt == "reel": base.update(_slides_model(job, "template", "SLOT"))
    return base

def apply(job, fmt, edits, log=None):
    log = [] if log is None else log
    notes = edits.get("notes") or {}
    if fmt in ("cineyap", "cineyap43"): _cineyap_apply(job, edits, fmt == "cineyap43", log)
    elif fmt in ("vertical", "vertical34"): _vertical_apply(job, edits, log, FORMATS[fmt].get("flag"))
    elif fmt in ("vcineyap", "vcineyap34"): _vcy_apply(job, edits, log, FORMATS[fmt].get("flag"))
    elif fmt in ("poster", "poster_v"): _poster_apply(job, edits, fmt == "poster_v", log)
    elif fmt == "panel": _panel_apply(job, edits, log)
    elif fmt == "carousel": _slides_apply(job, edits, "carousel", "SLIDE", log)
    elif fmt == "reel": _slides_apply(job, edits, "template", "SLOT", log)
    if notes and fmt not in ("cineyap", "cineyap43"):          # apply_board prints its own
        log.append("NOTES FOR CLAUDE (not applied automatically):")
        log.extend(f"  {k}: {v}" for k, v in notes.items())
    if notes:   # kept where Claude looks, so a note left on the page is never lost
        nf = PROJECTS/job/"edit/board_notes.md"; nf.parent.mkdir(parents=True, exist_ok=True)
        with open(nf, "a") as fh:
            fh.write(f"\n## {time.strftime('%Y-%m-%d %H:%M')} · {FORMATS[fmt]['name']}\n" + "".join(f"- {k}: {v}\n" for k, v in notes.items()))
    return log

if __name__ == "__main__":
    if len(sys.argv) < 3: sys.exit(__doc__)
    job, fmt = sys.argv[1], sys.argv[2]
    if "--apply" in sys.argv:
        print("\n".join(apply(job, fmt, json.load(open(sys.argv[sys.argv.index("--apply") + 1])))))
    else:
        print(json.dumps(model(job, fmt), indent=1, ensure_ascii=False)[:6000])
