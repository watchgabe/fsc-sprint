#!/usr/bin/env python3
"""register_motion.py — read the exact zoom and position of every frame of a finished edit.

    register_motion.py <edit.mp4> <source.mp4> <edl_exact.json> <out.json> [--step 2]

The edit was cut from the source, and edl_exact.json says which source time each edit time came from
(recovered by aligning the audio). So each edited frame can be registered against the very frame it
was made from: SIFT features, a RANSAC similarity fit, and out comes the crop the editor used on that
frame: scale and position, as CapCut transform values. No estimating from faces or backgrounds.
Frames that are not the A-roll (B-roll, plates) fail to register and are marked as gaps.

Output: one row per sampled frame: edit_t, src_t, scale (CapCut, over contain-fit), tx, ty (CapCut
half-canvas units, up positive), inliers.
"""
import json, subprocess, sys, numpy as np, cv2

args = [a for a in sys.argv[1:] if not a.startswith("--")]
EDIT, SRC, EDL, OUT = args[:4]
STEP = int(sys.argv[sys.argv.index("--step")+1]) if "--step" in sys.argv else 2
FPS = 24000/1001

def dims(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height:stream_side_data=rotation",
                                   "-of","json",p], capture_output=True, text=True).stdout)["streams"][0]
    w, h = d["width"], d["height"]
    rot = next((abs(int(s.get("rotation", 0))) for s in d.get("side_data_list", []) if "rotation" in s), 0)
    return (h, w) if rot in (90, 270) else (w, h)
EW, EH = dims(EDIT); SW, SH = dims(SRC)
ES, SS = 0.5, 0.25                       # analysis scales: edit at half, source at quarter (2160x3840 -> 540x960)

def frames(path, t0, dur, scale, w, h):
    ow, oh = int(w*scale) // 2 * 2, int(h*scale) // 2 * 2
    cmd = ["ffmpeg","-v","error","-ss",f"{t0:.4f}","-i",path,"-t",f"{dur:.4f}",
           "-vf",f"select='not(mod(n\\,{STEP}))',scale={ow}:{oh},format=gray","-fps_mode","passthrough","-f","rawvideo","-"]
    raw = subprocess.run(cmd, capture_output=True).stdout
    n = len(raw) // (ow*oh)
    return np.frombuffer(raw[:n*ow*oh], np.uint8).reshape(n, oh, ow), ow, oh

sift = cv2.SIFT_create(nfeatures=1500); bf = cv2.BFMatcher()
def solve(e, s):
    ke, de = sift.detectAndCompute(e, None); ks, ds = sift.detectAndCompute(s, None)
    if de is None or ds is None or len(ke) < 12 or len(ks) < 12: return None
    m = [a for a, b in bf.knnMatch(ds, de, k=2) if a.distance < 0.72*b.distance]
    if len(m) < 12: return None
    src = np.float32([ks[a.queryIdx].pt for a in m]); dst = np.float32([ke[a.trainIdx].pt for a in m])
    M, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=2.0, maxIters=4000)
    if M is None or inl.sum() < 25: return None
    return M, int(inl.sum())

rows = []
for seg in json.load(open(EDL)):
    a, b, w0 = seg["edit_t0"], seg["edit_t1"], seg["wav_t0"]
    E, ew, eh = frames(EDIT, a, b - a, ES, EW, EH)
    S, sw, sh = frames(SRC, w0, b - a, SS, SW, SH)
    n = min(len(E), len(S))
    for i in range(n):
        t = a + i*STEP/FPS
        r = solve(E[i], S[i])
        if r is None: rows.append({"edit_t": round(t, 4), "src_t": round(w0 + i*STEP/FPS, 4), "ok": False}); continue
        M, inl = r
        k_small = float(np.hypot(M[0,0], M[1,0]))              # edit-px per source-px, at the analysis scales
        k = k_small * SS / ES                                    # canvas px per full-res source px
        # where the source centre lands on the canvas
        cx_s, cy_s = sw/2, sh/2
        ex = (M[0,0]*cx_s + M[0,1]*cy_s + M[0,2]) / ES; ey = (M[1,0]*cx_s + M[1,1]*cy_s + M[1,2]) / ES
        fit = min(EW/SW, EH/SH)
        rows.append({"edit_t": round(t, 4), "src_t": round(w0 + i*STEP/FPS, 4), "ok": True,
                     "scale": round(k/fit, 4), "tx": round((ex - EW/2)/(EW/2), 4), "ty": round(-(ey - EH/2)/(EH/2), 4),
                     "rot": round(float(np.degrees(np.arctan2(M[1,0], M[0,0]))), 3), "inliers": inl})
    ok = [r for r in rows if r["ok"] and a <= r["edit_t"] < b]
    if ok: print(f"  {a:6.2f}-{b:6.2f}s: {len(ok)}/{n} frames registered, scale {ok[0]['scale']:.3f} -> {ok[-1]['scale']:.3f}")
    else:  print(f"  {a:6.2f}-{b:6.2f}s: 0/{n} registered (not A-roll)")
json.dump(rows, open(OUT, "w"), indent=0)
print(f"{sum(r['ok'] for r in rows)} of {len(rows)} sampled frames registered -> {OUT}")
