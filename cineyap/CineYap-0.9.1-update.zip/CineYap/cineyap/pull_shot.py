#!/usr/bin/env python3
"""pull_shot.py — pull a shot the reference used from another raw take, graded to match THAT shot.

    pull_shot.py <edit.mp4> <t0> <t1> <raw_take> <raw_t> <out.mp4>

<t0>-<t1> is the span in the edit, <raw_t> the raw-take second it starts on (found by audio). A take
from another day has its own light, so the main take's LUT is wrong for it (2026-10-02: the Communication
shot's lips went orange-red through the Showin' Up LUT). This fits a grade on the shot itself: its raw
frames warped onto the edit's frames, a 2nd-order colour model with ridge (one shot holds few colours,
so the model is kept gentle), checked on frames it was not fitted on. Writes out.mp4 (graded, starting
0.75s before the span) and prints the in-point and the error.
"""
import json, subprocess, sys, numpy as np, cv2

EDIT, T0, T1, RAW, RT, OUT = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), sys.argv[4], float(sys.argv[5]), sys.argv[6]
PRE = 0.75; DUR = (T1 - T0) + 2*PRE; EW, EH = 1080, 1920
ung = OUT.replace(".mp4", ".ungraded.mov")
subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{max(0, RT-PRE):.3f}","-i",RAW,"-t",f"{DUR:.3f}","-an","-c:v","prores_ks","-profile:v","3",ung], check=True)

def frame(p, t, gray=False, h=None):
    vf = ["-vf", f"scale=-2:{h}"] if h else []
    o = subprocess.run(["ffmpeg","-v","error","-ss",f"{max(0,t):.3f}","-i",p,"-frames:v","1",*vf,"-f","image2pipe","-vcodec","png","-"], capture_output=True).stdout
    im = cv2.imdecode(np.frombuffer(o, np.uint8), cv2.IMREAD_COLOR)
    return cv2.cvtColor(im, cv2.COLOR_BGR2GRAY) if gray else cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
sift = cv2.SIFT_create(2000)
def reg(e, c):
    ke, de = sift.detectAndCompute(e, None); kc, dc = sift.detectAndCompute(c, None)
    if de is None or dc is None: return None, 0
    m = [x for x, y in cv2.BFMatcher().knnMatch(dc, de, k=2) if x.distance < 0.72*y.distance]
    if len(m) < 12: return None, 0
    M, inl = cv2.estimateAffinePartial2D(np.float32([kc[x.queryIdx].pt for x in m]), np.float32([ke[x.trainIdx].pt for x in m]),
                                         method=cv2.RANSAC, ransacReprojThreshold=2.0)
    return M, (int(inl.sum()) if M is not None else 0)

# exact in-point: the span's first frame against every snippet frame near the audio estimate
e0 = frame(EDIT, T0 + 0.06, True, 960); fps = 24000/1001
best = max(((reg(e0, frame(ung, PRE + dt, True, 960))[1], dt) for dt in np.arange(-0.25, 0.26, 1/fps)))
IN = PRE + best[1] - 0.06
print(f"  in-point {IN:.3f}s into the snippet ({best[0]} matched points)")

# pairs: snippet frames warped onto the edit, every ~0.1s of the span
ts = np.linspace(T0 + 0.05, T1 - 0.05, max(6, int((T1 - T0)/0.1)))
X, Y, test = [], [], []
for k, t in enumerate(ts):
    e = frame(EDIT, t); c = frame(ung, IN + t - T0)
    M, n = reg(cv2.cvtColor(cv2.resize(e, (540, 960)), cv2.COLOR_RGB2GRAY), cv2.cvtColor(cv2.resize(c, (540, 960)), cv2.COLOR_RGB2GRAY))
    if M is None or n < 40: continue
    S = np.diag([2.0, 2.0, 1.0]); Mi = np.vstack([M, [0, 0, 1]])
    A = (np.diag([EW/540, EH/960, 1]) @ Mi @ np.diag([540/c.shape[1], 960/c.shape[0], 1]))[:2]
    w = cv2.warpAffine(c, A, (EW, EH), flags=cv2.INTER_AREA); v = cv2.warpAffine(np.ones(c.shape[:2], np.uint8), A, (EW, EH)) > 0
    e4 = cv2.resize(e, (EW//4, EH//4), interpolation=cv2.INTER_AREA).astype(np.float32)/255
    w4 = cv2.resize(w, (EW//4, EH//4), interpolation=cv2.INTER_AREA).astype(np.float32)/255
    v4 = cv2.resize(v.astype(np.uint8), (EW//4, EH//4), interpolation=cv2.INTER_NEAREST) > 0
    m = v4 & ~(e4.min(2) > 0.9) & (np.abs(cv2.Laplacian(e4.mean(2), cv2.CV_32F)) < 0.08)   # no caption text, no edges
    (test if k % 4 == 2 else X).append((w4[m], e4[m]))
def feats(x):
    r, g, b = x[:, 0], x[:, 1], x[:, 2]
    return np.stack([np.ones_like(r), r, g, b, r*r, g*g, b*b, r*g, r*b, g*b], 1)
Xa = np.concatenate([a for a, _ in X]); Ya = np.concatenate([b for _, b in X])
F = feats(Xa); lam = 1e-3 * len(F)
coef = np.linalg.solve(F.T @ F + lam*np.eye(F.shape[1]), F.T @ Ya)
err = np.mean([np.abs(np.clip(feats(a) @ coef, 0, 1) - b).mean()*255 for a, b in test]) if test else float("nan")
print(f"  grade fitted on {len(X)} frames, held-out error {err:.1f}/255")
g = np.linspace(0, 1, 33); bb, gg, rr = np.meshgrid(g, g, g, indexing="ij"); grid = np.stack([rr.ravel(), gg.ravel(), bb.ravel()], 1)
cube = OUT.replace(".mp4", ".cube")
with open(cube, "w") as o:
    o.write("LUT_3D_SIZE 33\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n")
    for v in np.clip(feats(grid) @ coef, 0, 1): o.write(f"{v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
subprocess.run(["ffmpeg","-v","error","-y","-i",ung,"-vf",f"lut3d={cube}","-c:v","libx264","-crf","14","-preset","fast","-pix_fmt","yuv420p",OUT], check=True)
json.dump({"in_s": round(IN, 3), "held_out_err": round(float(err), 2), "frames": len(X)}, open(OUT.replace(".mp4", ".json"), "w"))
print(f"-> {OUT}  (in_s {IN:.3f})")
