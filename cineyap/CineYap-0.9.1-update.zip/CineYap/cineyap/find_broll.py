#!/usr/bin/env python3
"""find_broll.py — find which library clip (and which second of it) a B-roll shot in an edit came from.

    find_broll.py <edit.mp4> <library_root> <out.json> --spans "12.60-14.72,14.72-16.81,..."

For each span, three frames of the edit are matched against every clip in the library (one frame a
second, SIFT features + RANSAC, so a crop, a zoom or a grade does not hide it). The best clip is then
searched frame by frame around the hit to recover the exact in-point. Runs on this Mac, ~5 min for
750 clips.
"""
import json, subprocess, sys, pathlib, numpy as np, cv2
from concurrent.futures import ProcessPoolExecutor

args = [a for a in sys.argv[1:] if not a.startswith("--")]
EDIT, LIB, OUT = args[:3]
SPANS = [tuple(map(float, s.split("-"))) for s in sys.argv[sys.argv.index("--spans")+1].split(",")]
FPS = 24000/1001

def frames(path, t0=None, dur=None, fps=1.0, h=480):
    cmd = ["ffmpeg", "-v", "error"]
    if t0 is not None: cmd += ["-ss", f"{max(0,t0):.3f}"]
    cmd += ["-i", str(path)]
    if dur is not None: cmd += ["-t", f"{dur:.3f}"]
    cmd += ["-vf", f"fps={fps},scale=-2:{h},format=gray", "-f", "image2pipe", "-vcodec", "pgm", "-"]
    raw = subprocess.run(cmd, capture_output=True).stdout
    out, i = [], 0
    while i < len(raw):                                   # split the PGM stream
        if raw[i:i+2] != b"P5": break
        parts = raw[i:i+40].split(maxsplit=4); w, hh = int(parts[1]), int(parts[2])
        hdr = len(b" ".join(parts[:4])) + 1; n = w*hh
        out.append(np.frombuffer(raw[i+hdr:i+hdr+n], np.uint8).reshape(hh, w)); i += hdr + n
    return out

sift = cv2.SIFT_create(nfeatures=800)
def feats(img): return sift.detectAndCompute(img, None)
def inliers(a, b):
    (ka, da), (kb, db) = a, b
    if da is None or db is None or len(ka) < 10 or len(kb) < 10: return 0
    m = [x for x, y in cv2.BFMatcher().knnMatch(da, db, k=2) if x.distance < 0.72*y.distance]
    if len(m) < 10: return 0
    M, inl = cv2.estimateAffinePartial2D(np.float32([ka[x.queryIdx].pt for x in m]), np.float32([kb[x.trainIdx].pt for x in m]),
                                         method=cv2.RANSAC, ransacReprojThreshold=3.0)
    return int(inl.sum()) if M is not None else 0

targets = []
for a, b in SPANS:
    ts = [a + (b-a)*f for f in (0.2, 0.5, 0.8)]
    targets.append([feats(frames(EDIT, t, 0.05, fps=FPS, h=480)[0]) for t in ts])

def scan_clip(p):
    try: fr = frames(p, fps=1.0)
    except Exception: return str(p), []
    best = []
    fs = [feats(f) for f in fr]
    for si, tg in enumerate(targets):
        sc = [(max(inliers(t, f) for t in tg), k) for k, f in enumerate(fs)] or [(0, 0)]
        s, k = max(sc); best.append((s, k))
    return str(p), best

if __name__ == "__main__":
    clips = sorted(p for p in pathlib.Path(LIB).rglob("*") if p.suffix.lower() in (".mp4", ".mov") and not p.name.startswith("."))
    print(f"{len(clips)} clips, {len(SPANS)} spans")
    res = []
    with ProcessPoolExecutor(8) as ex:
        for n, r in enumerate(ex.map(scan_clip, clips, chunksize=4)):
            res.append(r)
            if n % 100 == 0: print(f"  {n}/{len(clips)}", flush=True)
    out = []
    for si, (a, b) in enumerate(SPANS):
        ranked = sorted(((r[1][si][0], r[1][si][1], r[0]) for r in res if r[1]), reverse=True)[:3]
        s, k, p = ranked[0]
        hit = {"span": [a, b], "clip": p, "score": s, "near_s": k, "runners_up": [(x[0], pathlib.Path(x[2]).name) for x in ranked[1:]]}
        if s >= 40:
            # exact in-point: the edit's span start against every frame within +-1.5s of the hit
            e0 = feats(frames(EDIT, a + 0.06, 0.05, fps=FPS, h=480)[0])
            fine = frames(p, max(0, k - 1.5 - (b-a)), 3.0 + (b-a), fps=FPS)
            sc = [inliers(e0, feats(f)) for f in fine]
            j = int(np.argmax(sc)); hit["in_s"] = round(max(0, k - 1.5 - (b-a)) + j/FPS - 0.06, 3); hit["in_score"] = sc[j]
        out.append(hit)
        print(f"  {a:6.2f}-{b:6.2f}: {pathlib.Path(p).name} @ {hit.get('in_s', k)}s  score {s}  (next: {hit['runners_up']})")
    json.dump(out, open(OUT, "w"), indent=1)
