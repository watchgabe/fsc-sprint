#!/usr/bin/env python3
"""Phrase-based region plan for C1645.

Every region is anchored to the SPOKEN TEXT, not to clock time, so the plan
survives any change to the cut. Captions run continuously across the whole
piece and simply relocate: small-left over A-roll, large-centre over B-roll
and cards. They never stop.
"""
import json, pathlib

# Options carried in payload for card regions: {"serif":[words], "hold_tail":(n,text)}
# B-roll regions with a bright background may carry {"colour":"green","reframe":True}
#
# (first words of the region, last words of the region, treatment, payload)
#   treatment: "aroll" | "broll" | "green" | "cream"
#   payload for broll: list of library shot ids, split evenly across the region
#   payload for cards: optional set of words to set in Instrument Serif italic
# (first words, last words, treatment, payload)
#   treatment: "aroll" | "broll" | "green" | "cream"
#   broll payload: ["SHOT:KEY"] or [("anchor word","SHOT:KEY"), ...]
#   card payload:  {"serif":[words]} / {"hold_tail":(n,"text")}
#   options:       {"shots":[...], "colour":"green", "reframe":"subject_right",
#                   "min_shot":1.5, "per_shot":{"SHOT:KEY":{...}}}
REGIONS = [
]

SHOT_PICKS = {
 # key            clip                                start  reason
 "SHOT:BTS":      ("Content/BTS.mp4",                  9.0,  "softbox + camera aimed at the couch"),
 "SHOT:AROLL":    ("Content/A Roll Talking.mp4",      53.0,  "talking to camera, alt look"),
 "SHOT:TRAVEL4K": ("Travel/Travel 4k.mp4",           120.0,  "travel — years of shooting"),
 "SHOT:WORKOFF":  ("Office/Working-Office.mp4",        1.0,  "overhead, organising the desk"),
 "SHOT:NEWHOUSE": ("Office/New House B Roll.mp4",    106.3,  "the workspace"),
 "SHOT:AIRPORT":  ("Travel/Airport.mp4",              61.7,  "airport terminal"),
 "SHOT:MEXICO":   ("Lifestyle/Mexico Lifesttle Shots.mp4", 54.6, "hands at the kitchen counter"),
 "SHOT:OFFICE":   ("Office/Office.mp4",               13.6,  "laptop showing an edit timeline"),
 "SHOT:ROOFTOP":  ("Office/Roof top work.mp4",        69.8,  "writing at the rooftop table"),
 "SHOT:FITNESS":  ("Office/New House B Roll.mp4",     100.0,  "overhead, working at the keyboard"),
 "SHOT:CLIFF":    ("Lifestyle/Cliffside.mp4",         39.5,  "cliff edge, sunset"),
}

EXTRA_SHOTS = [
 ("ARoll@12",  "Content/A Roll Talking.mp4",  12.0, "cream tee, living room, talking"),
 ("ARoll@58",  "Content/A Roll Talking.mp4",  58.0, "cream tee, patio, gesturing"),
 ("ARoll@82",  "Content/A Roll Talking.mp4",  82.0, "dark tee, by the stairs"),
 ("ARoll@128", "Content/A Roll Talking.mp4", 128.0, "cream tee, kitchen and lamp"),
 ("Office@36b","Office/Office.mp4",           36.0, "laptop showing an edit timeline"),
 ("RoofTop@75","Office/Roof top work.mp4",    75.0, "writing at the rooftop table"),
 ("Mexico@8",  "Lifestyle/Mexico Lifesttle Shots.mp4", 8.0, "bedroom, tall windows"),
 ("Cliffside@44","Lifestyle/Cliffside.mp4",   44.0, "silhouette with backpack, sunset"),
 ("Mexico@55", "Lifestyle/Mexico Lifesttle Shots.mp4", 55.0, "hands preparing fruit at the counter"),
 ("WorkingOffice@40","Office/Working-Office.mp4", 40.0, "white shirt, typing at the laptop"),
 ("Cliffside@47","Lifestyle/Cliffside.mp4",   47.0, "beside the parked motorbike, looking at the beach"),
]


def match(words, seq, start=0):
    """Index of the first word beginning the given text sequence."""
    tx = [w[2] for w in words]
    for i in range(start, len(tx) - len(seq) + 1):
        if tx[i:i + len(seq)] == seq:
            return i
    return None


def build(words):
    out, cur = [], 0
    for first, last, kind, payload in REGIONS:
        a = match(words, first, cur)
        b = match(words, last, a) if a is not None else None
        if a is None or b is None:
            # The words this treatment was anchored to are gone (a line was cut on the Board). Drop the
            # treatment, keep its time as plain A-roll so nothing else stretches over it, and say so.
            print(f"  NOTE: '{' '.join(first)} ... {' '.join(last)}' is no longer in the cut - its {kind} was dropped")
            if cur < len(words):
                out.append({"i0": cur, "i1": cur, "kind": "aroll", "payload": None, "t0": words[cur][0],
                            "t1": words[cur][1], "text": "(dropped)"})
            continue
        b = b + len(last) - 1
        out.append({"i0": a, "i1": b, "kind": kind, "payload": (sorted(payload) if isinstance(payload,set) else payload),
                    "t0": words[a][0], "t1": words[b][1],
                    "text": " ".join(w[2] for w in words[a:b + 1])})
        cur = b + 1
    for i in range(len(out)-1):
        out[i]["t1"] = out[i+1]["t0"]
    return out


if __name__ == "__main__":
    words = json.load(open("words_out.json"))
    regs = build(words)
    gaps = []
    for i, r in enumerate(regs):
        dur = r["t1"] - r["t0"]
        flag = "  <-- under 4s" if r["kind"] == "broll" and dur < 4 else ""
        print(f"{r['kind']:6} {r['t0']:6.2f}-{r['t1']:6.2f} ({dur:5.2f}s) {r['text'][:62]}{flag}")
        if i and r["t0"] - regs[i - 1]["t1"] > 0.9:
            gaps.append((regs[i - 1]["t1"], r["t0"]))
    print(f"\nregions: {len(regs)}   uncovered gaps >0.9s: {gaps}")
    json.dump(regs, open("regions.json", "w"), indent=1)
