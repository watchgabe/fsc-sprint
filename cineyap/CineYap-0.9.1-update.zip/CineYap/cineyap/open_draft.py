#!/usr/bin/env python3
"""open_draft.py — open one named CapCut draft, from a script, a button, or the Studio page.

    ./vu-py cineyap/open_draft.py "<draft name>"          e.g. "stay-ready (CineYap 4x3)"
    ./vu-py cineyap/open_draft.py "<draft name>" --list   just say whether it exists

CapCut has no command to open a project, so this does what a person would: quit CapCut (it autosaves),
put the draft at the top of the home screen (its project list is ordered by last-modified), open CapCut,
and double-click the first tile. CapCut must be closed while its project list is edited, or it writes its
own copy back on quit. The tile click uses real mouse events (System Events' clicks bounce off CapCut).
"""
import json, pathlib, subprocess, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from capcut_draft import DRAFTS

LOCK = pathlib.Path(__file__).resolve().parent.parent/"_local/capcut.lock"
def take_lock(owner, wait=1800):
    """one driver of CapCut at a time (two sessions may share this Mac). A lock older than 20 minutes is
    stale. Waits up to `wait` seconds for someone else's lock to go."""
    t0 = time.time()
    while LOCK.exists():
        try: who, ts = LOCK.read_text().split("|")[:2]; age = time.time() - float(ts)
        except Exception: who, age = "?", 9e9
        if who == owner or age > 1200: break
        if time.time() - t0 > wait: return False
        time.sleep(10)
    LOCK.parent.mkdir(exist_ok=True); LOCK.write_text(f"{owner}|{time.time()}"); return True
def release_lock(owner):
    try:
        if LOCK.exists() and LOCK.read_text().split("|")[0] == owner: LOCK.unlink()
    except Exception: pass

def running():
    return subprocess.run(["pgrep", "-x", "CapCut"], capture_output=True).returncode == 0

def quit_capcut():
    subprocess.run(["osascript", "-e", 'tell application "CapCut" to quit'], capture_output=True)
    for _ in range(30):
        if not running(): return True
        time.sleep(0.5)
    subprocess.run(["killall", "CapCut"], capture_output=True); time.sleep(3)   # it sometimes answers quit with 'user canceled'
    return not running()

def drafts():
    """every draft on CapCut's home screen: name -> folder"""
    root = DRAFTS/"root_meta_info.json"
    if not root.exists(): return {}
    return {e.get("draft_name"): e.get("draft_fold_path") for e in json.loads(root.read_text()).get("all_draft_store", [])}

def bump(name):
    """make `name` the most recently modified draft, so it is the first tile"""
    root = DRAFTS/"root_meta_info.json"; rj = json.loads(root.read_text())
    store = rj.get("all_draft_store", []); hit = next((e for e in store if e.get("draft_name") == name), None)
    if not hit: return False
    now = int(time.time() * 1e6); hit["tm_draft_modified"] = now
    store.remove(hit); store.insert(0, hit); root.write_text(json.dumps(rj, ensure_ascii=False))
    meta = pathlib.Path(hit["draft_fold_path"])/"draft_meta_info.json"
    if meta.exists():
        mj = json.loads(meta.read_text()); mj["tm_draft_modified"] = now; meta.write_text(json.dumps(mj, ensure_ascii=False))
    return True

def idle_s():
    """seconds since the last keyboard or mouse input"""
    o = subprocess.run(["ioreg", "-c", "IOHIDSystem"], capture_output=True, text=True).stdout
    import re as _re
    m = _re.search(r'"HIDIdleTime" = (\d+)', o)
    return int(m.group(1)) / 1e9 if m else 0

def front():
    """the app in front right now"""
    return subprocess.run(["osascript", "-e", 'tell application "System Events" to get name of first process whose frontmost is true'],
                          capture_output=True, text=True).stdout.strip()

def safe_click(x, y, n=1):
    """click only when CapCut is in front: someone may be using this Mac. Brings it forward once, then
    refuses rather than click into another app."""
    if front() != "CapCut":
        if idle_s() < 60: return False          # someone is working in another app: never pull focus from them
        subprocess.run(["osascript", "-e", 'tell application "CapCut" to activate']); time.sleep(1)
    if front() != "CapCut": return False
    subprocess.run([sys.executable, str(pathlib.Path(__file__).parent/"mouse.py"), "click", str(x), str(y), str(n)])
    return True

def on_home():
    """True while CapCut shows its home screen: the cyan 'Create project' banner at the top"""
    shot = pathlib.Path("/tmp/cineyap_home_probe.png")
    subprocess.run(["screencapture", "-x", "-o", "-R1000,120,150,50", str(shot)])
    try:
        from PIL import Image
        r, g, b = Image.open(shot).convert("RGB").resize((1, 1)).getpixel((0, 0))
        return g > 120 and b > 140 and r < 90
    except Exception:
        return False

def screen_ok():
    """the scripted clicks were measured on a 1920x1055 CapCut window at the top left of the main screen.
    That window only fits a main screen of at least 1920x1080 points; on a smaller one (a laptop's own
    screen) CapCut lays its home screen out differently and a click could land on the wrong project."""
    try:
        import Quartz
        b = Quartz.CGDisplayBounds(Quartz.CGMainDisplayID())
        return b.size.width >= 1920 and b.size.height >= 1080
    except Exception:
        return False

def open_draft(name, click=True):
    if name not in drafts(): return f"no draft called '{name}' on CapCut's home screen"
    if click and not screen_ok(): click = False          # open CapCut with the draft first; they double-click it
    if running() and not quit_capcut(): return "CapCut would not quit"
    bump(name)
    subprocess.run(["open", "-a", "CapCut"]); time.sleep(7)
    subprocess.run(["osascript", "-e", 'tell application "CapCut" to activate']); time.sleep(1)
    # a known window position, so the first tile is at a known point (same as check.sh)
    if click:                    # only where the measured layout fits (screen_ok); otherwise leave their window alone
        subprocess.run(["osascript", "-e", 'tell application "System Events" to tell process "CapCut" to set position of first window to {0, 25}'], capture_output=True)
        subprocess.run(["osascript", "-e", 'tell application "System Events" to tell process "CapCut" to set size of first window to {1920, 1055}'], capture_output=True)
    time.sleep(1)
    if not click: return f"CapCut is open with '{name}' as the first project on its home screen: double-click it to open it"
    # the home screen can take a while to fill after a relaunch; click, then check the editor's window
    # title, and try again if the tile was not there yet
    for attempt in range(4):
        time.sleep(3 if attempt == 0 else 4)
        if not safe_click(306, 813, 2): return "stopped: another app is in front, so nothing was clicked"
        time.sleep(5)
        if not on_home(): return f"opened '{name}'"
    return f"CapCut is open with '{name}' as the first project: double-click it (the tile click did not take)"

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(__doc__)
    name = sys.argv[1]
    if "--list" in sys.argv:
        print("yes" if name in drafts() else "no"); sys.exit(0)
    print(open_draft(name))
