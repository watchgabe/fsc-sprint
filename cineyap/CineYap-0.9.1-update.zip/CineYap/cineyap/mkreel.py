#!/usr/bin/env python3
"""mkreel.py — build a reel from a template made by analyze_reel.py: same cuts, your clips, your type.

    ./vu-py cineyap/mkreel.py <job>              CapCut draft "<job> (Reel)", editable text
    ./vu-py cineyap/mkreel.py <job> --autopick   fill empty backgrounds first (dark text zone, one
                                                 source file per slot, orientation matched), then build

Reads projects/<job>/template/:
  template.json      the cuts and where each line of text sat (from analyze_reel.py)
  COPY.txt           your words, one ## SLOT block per shot, TEXT: lines in reading order
  backgrounds.json   one clip per slot, relative to broll_clips (then broll_root); "at" = 0..1 into it

The Nth TEXT line of a slot goes where the reference's Nth line was (its height and left edge or
centre). Lines past the reference's count stack below the last at the same pitch. Type is the style
pack's: sans for lines, serif for `backtick` words and for lines the reference set noticeably smaller
than the slot's largest line (the eyebrow / footnote pattern).
"""
import json, pathlib, random, re, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
sys.path.insert(0, str(PKG/"helpers"))
import config

args = [a for a in sys.argv[1:] if not a.startswith("--")]
if not args: sys.exit("usage: mkreel.py <job> [--autopick]")
job = args[0]; T = PROJECTS/job/"template"
if not (T/"template.json").exists(): sys.exit(f"no template at {T} - run analyze_reel.py first")
tpl  = json.load(open(T/"template.json"))
W, H = tpl["canvas"]; slots = tpl["slots"]
sty  = __import__("style").load()
ccar = sty.get("carousel", {}).get("capcut", {})

def probe(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
        "stream=width,height:format=duration","-of","json",str(p)], capture_output=True, text=True).stdout)
    s = d["streams"][0]; return int(s["width"]), int(s["height"]), float(d["format"]["duration"])

roots = [pathlib.Path(r) for r in (config.opt("broll_clips"), config.opt("broll_root")) if r]
def find_clip(rel):
    for r in roots:
        if (r/rel).exists(): return r/rel
    sys.exit(f"background clip not found under broll_clips or broll_root: {rel}")

# ---- COPY.txt
# One block per caption BEAT (a beat spans the shots that carry the same caption), or per SLOT in
# templates made before beats existed. Each beat becomes one text object per line, across its shots,
# so changing a caption in CapCut is one edit, not one per shot.
copy, by_beat, cur = {}, False, None
for line in (T/"COPY.txt").read_text().splitlines():
    m = re.match(r"## (BEAT|SLOT)\s+(\d+)", line)
    if m: by_beat = by_beat or m.group(1) == "BEAT"; cur = int(m.group(2)); copy[cur] = []; continue
    if cur is not None and line.startswith("TEXT:"): copy[cur].append(line[5:].strip())
units = tpl.get("beats") if by_beat and tpl.get("beats") else slots

bgs = {b["n"]: b for b in json.load(open(T/"backgrounds.json"))}

# ---- autopick: a first stab at the B-roll
if "--autopick" in sys.argv and any(not bgs.get(s["n"], {}).get("clip") for s in slots):
    import numpy as np
    from PIL import Image
    cache = T/"library.json"
    lib = json.load(open(cache)) if cache.exists() else []
    if not lib:
        root = roots[0]
        for p in sorted(root.rglob("*")):
            if p.suffix.lower() in (".mp4", ".mov") and not p.name.startswith("."):
                try: w, h, d = probe(p); lib.append({"clip": str(p.relative_to(root)), "w": w, "h": h, "dur": d})
                except Exception: pass
        cache.write_text(json.dumps(lib))
    portrait = H > W
    pool = [c for c in lib if (c["h"] > c["w"]) == portrait] or lib
    rng = random.Random(job); used = {pathlib.Path(b["clip"]).stem.rsplit("_", 1)[0] for b in bgs.values() if b.get("clip")}
    for s in slots:
        b = bgs.setdefault(s["n"], {"n": s["n"], "clip": "", "at": 0.5, "why": ""})
        if b.get("clip"): continue
        boxes = [l["box"] for l in s["lines"]] or [[0.05, 0.3, 0.9, 0.55]]
        zx0, zy0 = min(x for x, y, w, h in boxes), min(y for x, y, w, h in boxes)
        zx1, zy1 = max(x+w for x, y, w, h in boxes), max(y+h for x, y, w, h in boxes)
        cands = [c for c in pool if c["dur"] >= s["dur"] - 0.05 and c["clip"].rsplit("/", 1)[-1].rsplit("_", 1)[0] not in used]
        best = None
        for c in rng.sample(cands, min(12, len(cands))):
            f = T/"frames"/"_pick.png"
            subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{c['dur']*0.5:.2f}","-i",str(roots[0]/c["clip"]),"-frames:v","1",
                            "-vf",f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}",str(f)], check=True)
            a = np.asarray(Image.open(f).convert("L"), dtype=float)
            z = a[int(zy0*H):max(int(zy1*H), int(zy0*H)+1), int(zx0*W):max(int(zx1*W), int(zx0*W)+1)]
            if a.mean() < 18 or a.std() < 8: continue      # a black or flat frame is not a background, it is a gap
            score = float(np.percentile(z, 90))          # the brightest bits behind the text decide legibility
            if best is None or score < best[0]: best = (score, c)
        if best:
            c = best[1]; used.add(c["clip"].rsplit("/", 1)[-1].rsplit("_", 1)[0])
            b.update({"clip": c["clip"], "at": 0.5, "why": f"autopick: text zone p90 luma {best[0]:.0f}"})
    (T/"backgrounds.json").write_text(json.dumps([bgs[s["n"]] for s in slots], indent=1))
    print("  autopicked backgrounds:"); [print(f"    {s['n']:2d}  {bgs[s['n']]['clip']}  ({bgs[s['n']]['why']})") for s in slots]

missing = [s["n"] for s in slots if not bgs.get(s["n"], {}).get("clip")]
if missing: sys.exit(f"backgrounds.json has no clip for slot(s) {missing}. Fill them, or run with --autopick.")

# ---- the draft
import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, trange, KeyframeProperty as KP
from capcut_draft import start, finish, US
import motion
from gabe_carousel import censor

name = f"{job} (Reel)"
sf, dst = start(name, PROJECTS/job, W, H)
sf.add_track(draft.TrackType.video, "Clips", relative_index=0)
maxlines = max([len(copy.get(u["n"], [])) for u in units] + [1])
for k in range(maxlines): sf.add_track(draft.TrackType.text, f"Text {k+1}", relative_index=k+1)

unit = float(ccar.get("px_per_unit_1920w", 11.1)) * (W / 1920.0)   # CapCut text scales with canvas WIDTH (OCR-measured on 3 canvases)
OCR_TO_PX = float(ccar.get("ocr_box_to_px", 1.0))               # OCR box height ~ font px for caps-heavy lines
SERIF_K = float(ccar.get("serif_factor", 1.3))
kb = float(sty.get("motion", {}).get("kenburns", 0.12))
WHITE = tuple(v/255 for v in sty["colors"]["white"][:3])
fonts, lefts, report, t = {}, [], [], 0.0
from PIL import ImageFont, ImageDraw, Image
import os
_SANS = (os.path.expanduser(sty["fonts"]["sans"]), int(sty["fonts"].get("sans_index", 0)))
_SERIF = (os.path.expanduser(sty["fonts"]["serif"]), 0)
EST_TRACK = float(ccar.get("wrap_track_em", -35)) / 1000      # CapCut track -1, in em
_d = ImageDraw.Draw(Image.new("RGB", (8, 8)))
def width_px(text, px, serif=False):
    f = ImageFont.truetype(_SERIF[0] if serif else _SANS[0], max(4, int(px)), index=(0 if serif else _SANS[1]))
    return sum(_d.textlength(c, font=f) for c in text) + EST_TRACK * px * max(0, len(text) - 1)
def font_px(line, serif):
    """The reference line's real font size: the OCR box is ink extents, so solve for the px at which
    the OCR'd text is as wide as the box. Falls back to the box height when the read is too short."""
    x, y, w, h = line["box"]; guess = h * H
    if len(line["text"]) < 4: return guess
    return guess * (w * W) / max(1.0, width_px(line["text"], guess, serif))
for s in slots:
    clip = find_clip(bgs[s["n"]]["clip"]); cw, ch, cd = probe(clip)
    dur = s["dur"]; at = max(0.0, min(bgs[s["n"]].get("at", 0.5) * cd, cd - dur - 0.05)) if cd > dur + 0.05 else 0.0
    sd = min(dur, cd - 0.05)
    sc = max(W/cw, H/ch) / min(W/cw, H/ch)                     # fill the canvas, no bars
    vs = VideoSegment(str(clip), trange(US(s["t0"]), US(sd)), source_timerange=trange(US(at), US(sd)),
                      clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc))
    # the move: this slot's "motion" in backgrounds.json, else the pack's reel default (motion.py presets)
    mv = bgs[s["n"]].get("motion") or sty.get("motion", {}).get("reel_preset") or ("kenburns" if kb > 0 else "none")
    motion.apply(vs, mv, sd, base=sc, canvas=(W, H), full_frame=True,
                 cfg={"kenburns": {"by": kb}, **(sty.get("motion", {}).get("presets") or {})})
    sf.add_segment(vs, "Clips")
    if cd < dur: report.append(f"slot {s['n']}: clip is {cd:.2f}s for a {dur:.2f}s slot - pick a longer one")
t = slots[-1]["t1"]

label = "beat" if units is not slots else "slot"
for u in units:
    ref = u["lines"]; words = copy.get(u["n"], []); dur = u["t1"] - u["t0"]
    pitch = (ref[-1]["box"][1] - ref[-2]["box"][1]) if len(ref) > 1 else (ref[-1]["box"][3]*1.3 if ref else 0.06)
    for k, text in enumerate(words):
        if k < len(ref): x, y, w, h = ref[k]["box"]
        else:
            x, y, w, h = ref[-1]["box"] if ref else (0.08, 0.4, 0.8, 0.05)
            y += pitch * (k - len(ref) + 1)
        accent = re.findall(r"`([^`]+)`", text); plain = censor(text.replace("`", ""))
        # serif only for the two places the style uses it: an eyebrow (a first line clearly smaller
        # than the one under it) and a { note }. Everything else stays sans.
        eyebrow = k == 0 and len(ref) > 1 and h < ref[1]["box"][3] * 0.8
        serif = (eyebrow or plain.lstrip().startswith("{")) and not accent
        src_line = ref[min(k, len(ref)-1)] if ref else {"box": [x, y, w, h], "text": plain}
        fpx = font_px(src_line, serif)
        center_al = u["align"] == "center"
        room = (W - x*W - 0.04*W) if not center_al else 0.92*W
        need = width_px(plain, fpx, serif)
        if need > room:
            fpx *= room / need
            report.append(f"{label} {u['n']} line {k+1}: copy is longer than the reference line, set {room/need:.0%} smaller to fit")
        ranges = []
        for a in accent:
            j = plain.find(censor(a))
            if j >= 0: ranges.append((j, j + len(censor(a))))
        st = TextStyle(size=round(fpx/unit * (SERIF_K if serif else 1.0), 2), color=WHITE,
                       align=1 if center_al else 0,
                       letter_spacing=int(ccar.get("track_serif", 0) if serif else ccar.get("track_sans", -1)),
                       auto_wrapping=False, max_line_width=0.95)
        cy = (y + h/2) * H
        seg = TextSegment(plain, trange(US(u["t0"]), US(dur)), style=st,
                          clip_settings=draft.ClipSettings(transform_y=(H/2 - cy)/(H/2)))
        sf.add_segment(seg, f"Text {k+1}")
        fonts[seg.material_id] = ranges if ranges else serif
        if not center_al: lefts.append(x)
        if y + h > 0.97: report.append(f"{label} {u['n']} line {k+1}: runs off the bottom - shorten the copy")

inset = sorted(lefts)[len(lefts)//2] * W if lefts else None
finish(sf, dst, name, W, H, US(t), sty, text_fonts=fonts, left_inset=inset, box_to_edge=True)
print(f"\n{name}")
print(f"  {len(slots)} shots · {len(units)} {label}s · {t:.2f}s · {sum(len(v) for v in copy.values())} editable text lines · canvas {W}x{H}")
for r in report: print("  !", r)
print(f"  draft: {dst}")
