#!/usr/bin/env python3
"""match_grade.py — fit a .cube LUT that turns the raw footage into the look of a finished edit.

    match_grade.py <edit.mp4> <raw_camera_file> <motion.json> <out.cube> [--cam-offset 5.938] [--frames 48]

Needs the registration from register_motion.py: it says, for every A-roll frame of the edit, which raw
frame it came from and how it was scaled and placed. So each pair is the same pixels before and after
the grade. Those pairs are fitted with a smooth colour model (a 3rd-order polynomial in RGB with cross
terms, which can bend tone curves, saturation and hue the way a LUT does), evaluated on a 33-point
grid, and written as a .cube that CapCut, Premiere, Resolve and ffmpeg all read.

Captions and plates are masked out of the pairs: near-white pixels in the edit and the caption band.
Prints the fit error on frames it was not fitted on.
"""
import json, subprocess, sys, numpy as np, cv2

args = [a for a in sys.argv[1:] if not a.startswith("--")]
EDIT, RAW, MOTION, OUT = args[:4]
OFF = float(sys.argv[sys.argv.index("--cam-offset")+1]) if "--cam-offset" in sys.argv else 0.0
NF = int(sys.argv[sys.argv.index("--frames")+1]) if "--frames" in sys.argv else 48
EW, EH = 1080, 1920

def grab(path, t):
    out = subprocess.run(["ffmpeg","-v","error","-ss",f"{t:.4f}","-i",path,"-frames:v","1","-f","image2pipe","-vcodec","png","-"], capture_output=True).stdout
    return cv2.cvtColor(cv2.imdecode(np.frombuffer(out, np.uint8), cv2.IMREAD_COLOR), cv2.COLOR_BGR2RGB)

rows = [r for r in json.load(open(MOTION)) if r.get("ok") and r.get("inliers", 0) >= 60]
rows.sort(key=lambda r: r["edit_t"])
pick, last = [], -9
for r in rows:
    if r["edit_t"] - last >= 0.9: pick.append(r); last = r["edit_t"]
idx = np.linspace(0, len(pick)-1, min(NF + NF//4, len(pick))).round().astype(int)
pick = [pick[i] for i in idx]
test = pick[2::5]; train = [p for p in pick if p not in test]

def pairs(r):
    e = grab(EDIT, r["edit_t"] + 0.01); raw = grab(RAW, r["src_t"] + OFF + 0.01)
    sh, sw = raw.shape[:2]; fit = min(EW/sw, EH/sh); k = r["scale"] * fit
    cx, cy = EW/2 + r["tx"]*EW/2, EH/2 - r["ty"]*EH/2
    M = np.float32([[k, 0, cx - k*sw/2], [0, k, cy - k*sh/2]])
    w = cv2.warpAffine(raw, M, (EW, EH), flags=cv2.INTER_AREA, borderValue=(0, 0, 0))
    valid = cv2.warpAffine(np.ones((sh, sw), np.uint8), M, (EW, EH), borderValue=0) > 0
    e4 = cv2.resize(e, (EW//4, EH//4), interpolation=cv2.INTER_AREA).astype(np.float32)/255
    w4 = cv2.resize(w, (EW//4, EH//4), interpolation=cv2.INTER_AREA).astype(np.float32)/255
    v4 = cv2.resize(valid.astype(np.uint8), (EW//4, EH//4), interpolation=cv2.INTER_NEAREST) > 0
    yy = np.arange(EH//4)[:, None] / (EH//4)
    m = v4 & ~((yy > 0.10) & (yy < 0.32)) & ~(e4.min(2) > 0.93)          # drop the caption band and white text
    # drop pixels where the two disagree on local structure (misregistered edges)
    ge, gw = cv2.Laplacian(e4.mean(2), cv2.CV_32F), cv2.Laplacian(w4.mean(2), cv2.CV_32F)
    m &= np.abs(ge) < 0.08
    return w4[m], e4[m]

def feats(x):
    r, g, b = x[:, 0], x[:, 1], x[:, 2]
    cols = [np.ones_like(r), r, g, b, r*r, g*g, b*b, r*g, r*b, g*b, r*r*r, g*g*g, b*b*b, r*r*g, r*r*b, g*g*r, g*g*b, b*b*r, b*b*g, r*g*b]
    return np.stack(cols, 1)

X, Y = [], []
for r in train:
    a, b = pairs(r); X.append(a); Y.append(b)
X, Y = np.concatenate(X), np.concatenate(Y)
sel = np.random.default_rng(0).choice(len(X), min(len(X), 600_000), replace=False); X, Y = X[sel], Y[sel]
F = feats(X)
coef = np.linalg.lstsq(F, Y, rcond=None)[0]
# a second pass without the worst 5% (leftover misregistration, specular highlights)
res = np.abs(F @ coef - Y).mean(1); keep = res < np.percentile(res, 95)
coef = np.linalg.lstsq(F[keep], Y[keep], rcond=None)[0]

def apply(x): return np.clip(feats(x) @ coef, 0, 1)
errs = []
for r in test:
    a, b = pairs(r); errs.append(np.abs(apply(a) - b).mean() * 255)
print(f"fitted on {len(train)} frames ({len(X):,} pixel pairs); held-out error {np.mean(errs):.1f}/255 per channel on {len(test)} frames")

N = 33; g = np.linspace(0, 1, N)
B_, G_, R_ = np.meshgrid(g, g, g, indexing="ij")                   # .cube order: red changes fastest
grid = np.stack([R_.ravel(), G_.ravel(), B_.ravel()], 1)
lut = apply(grid)
with open(OUT, "w") as f:
    f.write(f'TITLE "matched from {EDIT.split("/")[-1]}"\nLUT_3D_SIZE {N}\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n')
    for v in lut: f.write(f"{v[0]:.6f} {v[1]:.6f} {v[2]:.6f}\n")
json.dump({"train": len(train), "test": len(test), "held_out_err": float(np.mean(errs))}, open(OUT + ".json", "w"))
print(f"-> {OUT}")
