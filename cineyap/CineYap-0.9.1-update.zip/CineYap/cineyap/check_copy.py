#!/usr/bin/env python3
"""check_copy.py — measure a CapCut export of a copy against the reel it copies, and say what is off.

    ./vu-py cineyap/check_copy.py <job> <export.mov> [--fix-grade]

Scores, each against the reference in projects/<job>/ref/:
  text      every caption line: same frame?, vertical position, size        (compare_text.py)
  motion    zoom and position of every camera frame                          (register_motion.py)
  clicks    each click sound, to the sample
  loudness  integrated LUFS
  grade     colour of matching camera frames (mean RGB, saturation, blacks)
--fix-grade fits a correction from the export to the reel, folds it into build/source_matched.mp4
(re-rendered, ~10 min) and keeps the old file as source_matched.before-fix.mp4. Rebuild the draft after.
Writes check/scorecard.json. The Showin' Up proof scored: text 98% same frame, position error 0.000,
motion 0.0016, clicks 0 ms, loudness equal.
"""
import json, pathlib, re, subprocess, sys, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
sys.path.insert(0, str(PKG/"helpers"))
import config
from capcut_draft import DRAFTS

args = [a for a in sys.argv[1:] if not a.startswith("--")]
job, EXP = args[0], pathlib.Path(args[1]).expanduser().resolve()
J = PROJECTS/job; REF = J/"ref"; CK = J/"check"; CK.mkdir(exist_ok=True)
plan = json.load(open(J/"vertical/plan.json"))
if "_copy_of" in plan: REF = (PKG/plan["_copy_of"]).resolve().parent          # the reference this plan was made from
EDIT = REF/"edit.mp4"; SRC = (J/"build/source_matched.mp4").resolve(); PY = sys.executable; C = PKG/"cineyap"
score = {}

# ---- text
subprocess.run([PY, str(C/"compare_text.py"), str(EDIT), str(EXP), "--step", "0.125"], stdout=open(CK/"text.txt", "w"), stderr=subprocess.STDOUT)
rows = []
for l in open(CK/"text.txt"):
    m = re.match(r"(.{22}) +([\d.]+) +([\d.]+) \| +([\d.]+) +([\d.]+) +([+-][\d.]+) \| +([\d.]+) +([\d.]+)", l)
    if m: rows.append((m.group(1).strip(), float(m.group(2)), float(m.group(3)), float(m.group(6)), float(m.group(7))))
caps_ = [r for r in rows if r[0].replace(" ", "").isascii() and not re.search(r"\d{4}|\+\d", r[0])]
if caps_:
    dt = np.array([r[2] - r[1] for r in caps_]); dy = np.array([r[3] for r in caps_]); w = np.array([r[4] for r in caps_])
    score["text"] = {"lines": len(caps_), "same_frame_pct": round(float(np.mean(abs(dt) < 0.13))*100, 1),
                     "dy_median": round(float(np.median(abs(dy))), 4), "width_median": round(float(np.median(w)), 3),
                     "off": [r for r in caps_ if abs(r[2]-r[1]) >= 0.13 or abs(r[3]) > 0.02 or abs(r[4]-1) > 0.15][:20]}

# ---- motion
d = json.load(open(DRAFTS/f"{job} (Vertical)"/"draft_content.json"))
ar = next(t for t in d["tracks"] if t.get("name") == "A-roll")
json.dump([{"edit_t0": s["target_timerange"]["start"]/1e6, "edit_t1": (s["target_timerange"]["start"] + s["target_timerange"]["duration"])/1e6,
            "wav_t0": s["source_timerange"]["start"]/1e6} for s in ar["segments"]], open(CK/"edl_export.json", "w"))
subprocess.run([PY, str(C/"register_motion.py"), str(EXP), str(SRC), str(CK/"edl_export.json"), str(CK/"motion_export.json"), "--step", "2"],
               capture_output=True)
a = [r for r in json.load(open(REF/"motion.json")) if r.get("ok")]; b = [r for r in json.load(open(CK/"motion_export.json")) if r.get("ok")]
at = np.array([r["edit_t"] for r in a]); M = []
for r in b:
    i = int(np.argmin(abs(at - r["edit_t"])))
    if abs(at[i] - r["edit_t"]) < 0.03: M.append((r["edit_t"], r["scale"] - a[i]["scale"], r["tx"] - a[i]["tx"], r["ty"] - a[i]["ty"]))
M = np.array(M)
if len(M):
    off = M[(abs(M[:, 1]) > 0.02) | (abs(M[:, 2]) > 0.02) | (abs(M[:, 3]) > 0.02)]
    score["motion"] = {"frames": len(M), "scale_err_median": round(float(np.median(abs(M[:, 1]))), 4),
                       "pos_err_median": round(float(np.median(abs(M[:, 2:]))), 4), "frames_off": len(off),
                       "off_at_s": sorted({round(float(x), 1) for x in off[:, 0]})[:30]}

# ---- clicks + loudness
def aud(p): return np.frombuffer(subprocess.run(["ffmpeg","-v","error","-i",str(p),"-ac","1","-ar","48000","-f","f32le","-"], capture_output=True).stdout, np.float32)
clk = config.opt("sfx_click")
if clk:
    from scipy.signal import butter, sosfilt
    sos = butter(4, 3000, "hp", fs=48000, output="sos"); c = sosfilt(sos, aud(clk))
    on = int(np.argmax(np.abs(c) > np.abs(c).max()*0.3)); pre = min(on, 100); k = c[on-pre:on+1200]
    def find(p):
        e = sosfilt(sos, aud(p)); N = 1 << int(np.ceil(np.log2(len(e) + len(k))))
        cc = np.fft.irfft(np.fft.rfft(e, N) * np.conj(np.fft.rfft(k, N)), N)[:len(e)]
        en = np.sqrt(np.convolve(e**2, np.ones(len(k)), "full")[len(k)-1:len(k)-1+len(e)] + 1e-12); sc = cc/(en*np.linalg.norm(k)); out = []
        for j in np.argsort(-sc):
            if sc[j] < 0.6: break
            if all(abs(j - x) > 4800 for x in out): out.append(j)
        return sorted((j + pre)/48000 for j in out)
    ca, cb = find(EDIT), find(EXP)
    score["clicks"] = {"ref": len(ca), "copy": len(cb), "ms_off": [round((min(cb, key=lambda y: abs(y-x)) - x)*1000) for x in ca] if cb else []}
def lufs(p):
    o = subprocess.run(["ffmpeg","-v","info","-i",str(p),"-vn","-af","ebur128","-f","null","-"], capture_output=True, text=True).stderr
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", o); return float(m[-1]) if m else None
score["loudness"] = {"ref_lufs": lufs(EDIT), "copy_lufs": lufs(EXP)}

# ---- grade, on camera frames that show the same source moment at the same zoom
def grab(p, t):
    o = subprocess.run(["ffmpeg","-v","error","-ss",f"{t:.3f}","-i",str(p),"-frames:v","1","-vf","scale=270:480","-f","rawvideo","-pix_fmt","rgb24","-"], capture_output=True).stdout
    return np.frombuffer(o, np.uint8).reshape(480, 270, 3).astype(np.float32)/255
pairs = []
for r in b[::4]:
    cnd = min(a, key=lambda x: abs(x["src_t"] - r["src_t"]))
    if abs(cnd["src_t"] - r["src_t"]) < 0.05 and abs(cnd["scale"] - r["scale"]) < 0.02: pairs.append((cnd["edit_t"], r["edit_t"]))
pairs = pairs[:60]
if pairs:
    import cv2
    A = np.concatenate([grab(EDIT, x)[250:470].reshape(-1, 3) for x, _ in pairs]); B = np.concatenate([grab(EXP, y)[250:470].reshape(-1, 3) for _, y in pairs])
    sat = lambda x: float(cv2.cvtColor((np.clip(x, 0, 1)*255).astype(np.uint8).reshape(1, -1, 3), cv2.COLOR_RGB2HSV)[0][:, 1].mean())
    score["grade"] = {"pairs": len(pairs), "ref_rgb": (A.mean(0)*255).round(1).tolist(), "copy_rgb": (B.mean(0)*255).round(1).tolist(),
                      "ref_sat": round(sat(A), 1), "copy_sat": round(sat(B), 1),
                      "ref_black": round(float(np.percentile(A.mean(1), 5)*255), 1), "copy_black": round(float(np.percentile(B.mean(1), 5)*255), 1)}
    if "--fix-grade" in sys.argv:
        q = np.linspace(0.5, 99.5, 60); curves = []
        for ch in range(3):
            xa = np.r_[0, np.percentile(B[:, ch], q), 1]; ya = np.r_[0, np.percentile(A[:, ch], q), 1]
            xa, idx = np.unique(xa, return_index=True); curves.append((xa, np.maximum.accumulate(ya[idx])))
        cur = lambda x: np.stack([np.interp(x[..., c], *curves[c]) for c in range(3)], -1)
        lum = lambda x: (x*[0.2126, 0.7152, 0.0722]).sum(-1, keepdims=True)
        Bc = cur(B); f = 1.0
        for _ in range(20): f *= (sat(A) / sat(lum(Bc) + (Bc - lum(Bc))*f))**0.7
        g = np.linspace(0, 1, 33); bb, gg, rr = np.meshgrid(g, g, g, indexing="ij"); grid = np.stack([rr.ravel(), gg.ravel(), bb.ravel()], 1)
        v = cur(grid); v = np.clip(lum(v) + (v - lum(v))*f, 0, 1)
        with open(J/"build/correction.cube", "w") as o:
            o.write("LUT_3D_SIZE 33\nDOMAIN_MIN 0 0 0\nDOMAIN_MAX 1 1 1\n"); [o.write(f"{x[0]:.6f} {x[1]:.6f} {x[2]:.6f}\n") for x in v]
        src = J/"build/source_matched.mp4"; inp = src.resolve()
        out = J/"build/source_matched_fixed.mp4" if src.is_symlink() else J/"build/source_matched.fixing.mp4"
        print(f"  grade fix: curves + saturation x{f:.3f}, re-rendering the source...", flush=True)
        subprocess.run(["ffmpeg","-v","error","-y","-i",str(inp),"-vf",f"lut3d={J/'build/correction.cube'}","-c:v","hevc_videotoolbox","-b:v","50M",
                        "-tag:v","hvc1","-pix_fmt","yuv420p","-c:a","copy",str(out)], check=True)
        if src.is_symlink(): src.unlink(); src.symlink_to(out.name)
        else: src.rename(J/"build/source_matched.before-fix.mp4"); out.rename(src)
        score["grade"]["fixed"] = True

# the side-by-side Gabe watches: the reel on the left, the copy on the right, the copy's audio
subprocess.run(["ffmpeg","-v","error","-y","-i",str(EDIT),"-i",str(EXP),"-filter_complex",
    "[0:v]fps=24,scale=540:960,drawtext=text='YOUR REEL':x=12:y=h-40:fontsize=22:fontcolor=white:box=1:boxcolor=black@0.5[a];"
    "[1:v]scale=540:960,drawtext=text='CINEYAP COPY':x=12:y=h-40:fontsize=22:fontcolor=white:box=1:boxcolor=black@0.5[b];[a][b]hstack=2[v]",
    "-map","[v]","-map","1:a?","-c:v","libx264","-crf","20","-preset","fast","-c:a","aac","-b:a","192k","-shortest",str(CK/"side_by_side.mp4")])
json.dump(score, open(CK/"scorecard.json", "w"), indent=1)
t, m, k, l, g = (score.get(x, {}) for x in ("text", "motion", "clicks", "loudness", "grade"))
print(f"\nSCORECARD {job}")
if t: print(f"  text     {t['same_frame_pct']}% of {t['lines']} lines on the same frame, position error {t['dy_median']}, size x{t['width_median']}")
if m: print(f"  motion   scale error {m['scale_err_median']}, position error {m['pos_err_median']}, {m['frames_off']} frames off at {m['off_at_s']}")
if k: print(f"  clicks   {k['copy']} of {k['ref']}, ms off {k['ms_off']}")
print(f"  loudness reel {l.get('ref_lufs')} LUFS, copy {l.get('copy_lufs')} LUFS")
if g: print(f"  grade    reel RGB {g['ref_rgb']} sat {g['ref_sat']} black {g['ref_black']} | copy RGB {g['copy_rgb']} sat {g['copy_sat']} black {g['copy_black']}")
if t.get("off"): print("  text lines off:", t["off"])
print(f"-> {CK/'scorecard.json'}\n-> {CK/'side_by_side.mp4'}")
