#!/usr/bin/env python3
"""copy_plan.py — turn the measurements of a reference edit into a vertical/plan.json that rebuilds it.

    copy_plan.py <ref_dir> <job> [--title-from-ocr]

<ref_dir> holds what the measuring tools wrote about the reference edit (all made from the same take):
  edit.mp4               the reference edit
  edl_exact.json         its cut, recovered by aligning its audio to the raw mic
  motion.json            register_motion.py: its zoom and position, frame by frame
  layers/frames.json     per frame: plate colour, cut strength, A-roll or not
  layers/small.npy       the frames at 72x128 (for the flash)
  layers/ocr_frames.json every frame's text (Apple Vision)
  layers/broll_found.json find_broll.py: which library clip each B-roll span came from

Writes projects/<job>/vertical/plan.json with exact times for everything: the cut, the cards and their
labels, the stack words, the B-roll and its in-points, the flash frames, the click frames, every
caption's words and on/off frames, the title and the CTA. mkvertical.py builds it as a CapCut draft.
"""
import json, re, sys, pathlib, subprocess, numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
sys.path.insert(0, str(PKG/"helpers"))
import config

args = [a for a in sys.argv[1:] if not a.startswith("--")]
REF, job = pathlib.Path(args[0]).expanduser().resolve(), args[1]; J = PROJECTS/job
FPS = 24000/1001
frames = json.load(open(REF/"layers/frames.json")); n = len(frames)
ocr = json.load(open(REF/"layers/ocr_frames.json"))
tr = json.load(open(sorted((J/"edit/transcripts").glob("*.json"))[0]))
WORDS = [w for w in tr["words"] if w.get("type") == "word"]
edl = json.load(open(REF/"edl_exact.json"))
norm = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())
T = lambda i: round(i / FPS, 4)

# ---- the flash: an orange light leak, a one-frame jump in warmth over both neighbours
F = np.load(REF/"layers/small.npy").astype(np.float32)
warm = F[..., 0].mean((1, 2)) - F[..., 2].mean((1, 2)); lum = F.mean((1, 2, 3))
flash = [i for i in range(2, n-2) if warm[i] - max(warm[i-2], warm[i-1]) > 25 and lum[i] > lum[i-1] - 5 and warm[i] > 40]
print(f"  flash frames: {flash}")

# ---- plates: runs of green or cream, small gaps (new words landing) bridged, a flash frame just before
# the run counts as the card's first frame
lab = [f["plate"] for f in frames]
for i in range(1, n-2):
    if lab[i] is None and lab[i-1] and (lab[i+1] == lab[i-1] or lab[i+2] == lab[i-1]): lab[i] = lab[i-1]
cards, i = [], 0
while i < n:
    if lab[i]:
        j = i
        while j+1 < n and lab[j+1] == lab[i]: j += 1
        a = i
        for fl in flash:
            if 0 < i - fl <= 2: a = fl
        if j - i >= 6: cards.append({"type": lab[i], "f0": a, "f1": j+1})
        i = j+1
    else: i += 1

# ---- text per frame: only lines that are words being said (so text inside the footage is ignored)
def said_near(i, k, win=1.5):
    t = i / FPS
    return any(norm(w["text"]) == k for w in WORDS_T if abs(w["t"] - t) < win)
# the transcript on the edit's clock
WORDS_T = []
for s in edl:
    for w in WORDS:
        if s["wav_t0"] - 0.02 <= w["start"] < s["wav_t1"]:
            WORDS_T.append({"t": s["edit_t0"] + w["start"] - s["wav_t0"], "text": w["text"]})
title, title_last, labels, cta = None, 0, {}, None
lines_per_frame = []
for fr in ocr:
    i = fr["i"]; keep = []
    for b in fr["text"]:
        s = b["t"].strip(); k = norm(s)
        if "showin" in k or "keepshow" in k:
            title = title or s; title_last = i; continue
        if re.search(r"(monday|tuesday|wednesday|thursday|friday)\s*[-–]", s.lower()):
            labels.setdefault(i, s); continue
        if s.startswith(("“", '"')) and s.upper() == s:
            cta = cta if cta is not None else i; continue
        toks = [norm(x) for x in s.split() if norm(x)]
        # a line is a caption when its words are being said (numerals count: he writes "30" for "thirty");
        # half is enough, since a caption can carry a word the cut dropped ("your content.")
        ok = [x.isdigit() or said_near(i, x) for x in toks]
        if toks and sum(ok) >= max(1, (len(ok) + 1) // 2) and (ok[0] or len(ok) > 1): keep.append((s, b))
    lines_per_frame.append(keep)

# ---- caption events: a line's first frame to the frame after its last, flicker of <=2 frames bridged
events, live = [], {}
for i, keep in enumerate(lines_per_frame):
    now = {norm(s): (s, b) for s, b in keep}
    for k, (s, b) in now.items():
        if k in live and i - live[k]["last"] <= 3: live[k]["last"] = i
        else:
            live[k] = {"text": s, "f0": i, "last": i, "y": b["y"] + b["h"]/2}; events.append(live[k])
events.sort(key=lambda e: e["f0"])
caps = []
for e in events:
    if e["last"] - e["f0"] < 1: continue                       # one-frame misreads
    # the spelling from the transcript, the grouping from the screen
    # OCR slips: a lone capital I reads as l or |, a short lowercase word as capitals
    txt = " ".join("I" if w in ("l", "|") else (w.lower() if w.isupper() and len(w) <= 3 and w != "I" else w) for w in e["text"].split())
    caps.append({"t0": T(e["f0"]), "t1": T(e["last"] + 1), "text": txt})

# a gap of a few frames between two captions is OCR missing a word's first frames (his captions run
# back to back): the next caption starts where the last one ended
caps.sort(key=lambda c: c["t0"])
fill = []
for x, y in zip(caps, caps[1:]):
    gap = y["t0"] - x["t1"]
    if gap <= 0: continue
    # a word said in the gap that neither neighbour shows is a caption OCR missed: put it back
    said = [w for w in WORDS_T if x["t1"] - 0.05 <= w["t"] < y["t0"] - 0.02
            and norm(w["text"]) not in {norm(v) for v in (x["text"] + " " + y["text"]).split()}]
    if said and gap >= 2/FPS:                               # one word per caption, each on its own timing
        for k, w in enumerate(said):
            a_ = x["t1"] if k == 0 else w["t"]; b_ = said[k+1]["t"] if k+1 < len(said) else y["t0"]
            if b_ - a_ >= 1/FPS: fill.append({"t0": round(a_, 4), "t1": round(b_, 4), "text": w["text"]})
    elif gap <= 4/FPS: y["t0"] = x["t1"]
caps = sorted(caps + fill, key=lambda c: c["t0"])
if fill: print(f"  {len(fill)} caption(s) OCR missed, restored from the transcript: {', '.join(f['text'] for f in fill[:12])}")

# ---- stack cards: a green card in which several caption lines show at once
stack_cards = []
for c in cards:
    if c["type"] != "green": continue
    multi = [lines_per_frame[i] for i in range(c["f0"], c["f1"]) if len(lines_per_frame[i]) >= 2]
    if multi:
        last = max(multi, key=len)
        words = [s for s, b in sorted(last, key=lambda x: x[1]["y"])]
        c["type"] = "stack"; c["stack"] = [norm(w) for w in words[1:]] if len(words) > 2 else [norm(w) for w in words]
        lead = [s for s, b in last if b["y"] + b["h"]/2 > 0.48 and norm(s) not in c["stack"]]
        stack_cards.append(c)

# ---- labels: the day label showing over each green card
def fix_label(s):
    a, b = re.split(r"\s*[-–]\s*", s, maxsplit=1)
    return f"{a.strip()} – {b.strip()}"
for c in cards:
    hits = [labels[i] for i in range(c["f0"], c["f1"]) if i in labels]
    if hits: c["label"] = fix_label(max(set(hits), key=hits.count))

# ---- B-roll spans: runs that are neither A-roll nor plate, split at the cuts
spans, i = [], 0
while i < n:
    if frames[i]["aroll"] is False and not lab[i] and i not in flash:
        j = i
        while j+1 < n and frames[j+1]["aroll"] is not True and not lab[j+1] and frames[j+1]["diff"] < 40: j += 1
        if j - i >= 5: spans.append((i, j+1))
        i = j+1
    else: i += 1
import cv2
_sift = cv2.SIFT_create(2000)
def _gray(p, t, h=960):
    o = subprocess.run(["ffmpeg","-v","error","-ss",f"{max(0,t):.3f}","-i",str(p),"-frames:v","1","-vf",f"scale=-2:{h},format=gray","-f","rawvideo","-"], capture_output=True).stdout
    return np.frombuffer(o, np.uint8).reshape(h, len(o)//h)
def _dims(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height:stream_side_data=rotation","-of","json",str(p)],
                                  capture_output=True, text=True).stdout)["streams"][0]
    rot = next((abs(int(x.get("rotation", 0))) for x in d.get("side_data_list", []) if "rotation" in x), 0)
    return (d["height"], d["width"]) if rot in (90, 270) else (d["width"], d["height"])
def broll_frame(clip, b):
    """the B-roll's framing in the reference: CapCut scale (over contain-fit) and position, and whether it
    moves. Registered on three frames against the library clip itself."""
    EW, EH = 1080, 1920; cw, ch = _dims(clip); fit = min(EW/cw, EH/ch); got = []
    for f in (0.1, 0.5, 0.9):
        t = b["t0"] + (b["t1"] - b["t0"])*f
        e, c = _gray(REF/"edit.mp4", t), _gray(clip, b["in_s"] + t - b["t0"])
        ke, de = _sift.detectAndCompute(e, None); kc, dc = _sift.detectAndCompute(c, None)
        if de is None or dc is None: continue
        m = [x for x, y in cv2.BFMatcher().knnMatch(dc, de, k=2) if x.distance < 0.72*y.distance]
        if len(m) < 12: continue
        M, inl = cv2.estimateAffinePartial2D(np.float32([kc[x.queryIdx].pt for x in m]), np.float32([ke[x.trainIdx].pt for x in m]),
                                             method=cv2.RANSAC, ransacReprojThreshold=2.0)
        if M is None or inl.sum() < 25: continue
        r = EH / e.shape[0]; k = float(np.hypot(M[0, 0], M[1, 0])) * r * (c.shape[0] / ch)
        cx = (M[0,0]*c.shape[1]/2 + M[0,1]*c.shape[0]/2 + M[0,2]) * r; cy = (M[1,0]*c.shape[1]/2 + M[1,1]*c.shape[0]/2 + M[1,2]) * r
        got.append((k/fit, (cx - EW/2)/(EW/2), -(cy - EH/2)/(EH/2)))
    if not got: return {}
    g = np.array(got)
    out = {"scale": round(float(g[0, 0]), 4), "tx": round(float(g[0, 1]), 4), "ty": round(float(g[0, 2]), 4)}
    if np.ptp(g[:, 0]) < 0.01: out["still"] = True
    else: out["scale_end"] = round(float(g[-1, 0]), 4)
    return out
if not (REF/"layers/broll_found.json").exists() and spans and config.opt("broll_clips"):
    # first run: look every B-roll span up in the clip library (find_broll.py, ~5 min for 750 clips)
    subprocess.run([sys.executable, str(pathlib.Path(__file__).parent/"find_broll.py"), str(REF/"edit.mp4"), config.opt("broll_clips"),
                    str(REF/"layers/broll_found.json"), "--spans", ",".join(f"{a/FPS:.3f}-{b/FPS:.3f}" for a, b in spans)], check=True)
found = json.load(open(REF/"layers/broll_found.json")) if (REF/"layers/broll_found.json").exists() else []
broll = []
for a, b in spans:
    hit = max(found, key=lambda h: min(b/FPS, h["span"][1]) - max(a/FPS, h["span"][0]), default=None)
    if not hit or hit["score"] < 40:
        _ov = json.load(open(J/"vertical/overrides.json")).get("broll", []) if (J/"vertical/overrides.json").exists() else []
        if not any(o["t0"] - 0.05 <= a/FPS < o["t1"] for o in _ov):
            print(f"  B-roll {T(a)}-{T(b)}: no library match (name the clip in vertical/overrides.json)")
        continue
    clip = str(pathlib.Path(hit["clip"]).relative_to(pathlib.Path(hit["clip"]).parents[1]))
    entry = {"t0": T(a), "t1": T(b), "clip": clip, "in_s": hit.get("in_s", hit["near_s"])}
    entry.update(broll_frame(hit["clip"], entry))
    broll.append(entry)

# hand corrections: vertical/overrides.json {"broll": [{"t0", "t1", "clip", "in_s", "measure"}]} replaces any
# detected span it overlaps (a shot from another take in the same room fools the motion check; a shot
# from outside the library needs its file named). "measure": true reads its framing off the reference.
ov = json.load(open(J/"vertical/overrides.json")) if (J/"vertical/overrides.json").exists() else {}
for o in ov.get("broll", []):
    broll = [x for x in broll if x["t1"] <= o["t0"] + 0.02 or x["t0"] >= o["t1"] - 0.02]
    if o.get("raw") and not pathlib.Path(o["clip"]).exists():
        # a shot from another raw take: pulled and graded against THIS shot in the reference (pull_shot.py),
        # never through the main take's LUT (another day's light: lips went orange-red that way)
        subprocess.run([sys.executable, str(pathlib.Path(__file__).parent/"pull_shot.py"), str(REF/"edit.mp4"), str(o["t0"]), str(o["t1"]),
                        o["raw"], str(o["raw_t"]), o["clip"]], check=True)
        o["in_s"] = json.load(open(o["clip"].replace(".mp4", ".json")))["in_s"]
    e = {k: v for k, v in o.items() if k not in ("measure", "raw", "raw_t")}
    if o.get("measure"): e.update(broll_frame(o["clip"], e))
    else: e.setdefault("still", True)
    broll.append(e)
broll.sort(key=lambda x: x["t0"])

# ---- clicks: the click sound matched in the reference's audio
clicks = []
click = config.opt("sfx_click")
if click:
    from scipy.signal import butter, sosfilt
    def aud(p): return np.frombuffer(subprocess.run(["ffmpeg","-v","error","-i",str(p),"-ac","1","-ar","48000","-f","f32le","-"],
                                                    capture_output=True).stdout, np.float32)
    sos = butter(4, 3000, "hp", fs=48000, output="sos"); e = sosfilt(sos, aud(REF/"edit.mp4")); c = sosfilt(sos, aud(click))
    on = int(np.argmax(np.abs(c) > np.abs(c).max()*0.3)); pre = min(on, 100); k = c[on-pre:on+1200]
    N = 1 << int(np.ceil(np.log2(len(e) + len(k))))
    cc = np.fft.irfft(np.fft.rfft(e, N) * np.conj(np.fft.rfft(k, N)), N)[:len(e)]
    en = np.sqrt(np.convolve(e**2, np.ones(len(k)), "full")[len(k)-1:len(k)-1+len(e)] + 1e-12)
    sc = cc / (en * np.linalg.norm(k))
    for j in np.argsort(-sc):
        if sc[j] < 0.8: break
        if all(abs(j - x) > 4800 for x in clicks): clicks.append(int(j))
    clicks = sorted(round((j + pre) / 48000, 4) for j in clicks)

# a click with no flash 1-3 frames after it marks a flash the warmth test missed (over a bright card the
# leak barely changes the colour): put it on the cut right there
for ct in clicks:
    fi = int(round(ct * FPS))
    if not any(0 <= f - fi <= 3 for f in flash):
        cut = next((k for k in range(fi, min(n, fi + 4)) if frames[k]["diff"] > 40), fi + 2)
        flash.append(cut)
flash = sorted(flash)
# the title as it reads most often, apostrophes kept
tt = [b["t"] for fr in ocr for b in fr["text"] if "showin" in norm(b["t"])]
if tt: title = max(set(tt), key=lambda x: (tt.count(x) + 1000*("'" in x or "’" in x)))
# ---- the cut: the audio alignment puts each edge within ~0.1s; where the cut is visible (camera on
# both sides) the picture says exactly which frame, and the source in-points move with it
dif = np.array([f["diff"] for f in frames]); cam = lambda k: frames[k]["aroll"] is True and not lab[k]
cut = [dict(x) for x in edl]
for k in range(1, len(cut)):
    i0 = int(round(cut[k]["edit_t0"] * FPS)); w = range(max(2, i0-12), min(n-2, i0+13))   # audio edges in a pause can be 0.5s off
    j = max(w, key=lambda q: dif[q])
    # camera after the cut, camera or B-roll before it (a camera cut on a B-roll edge counts; a card edge does not)
    if dif[j] >= 25 and (cam(j) or cam(j+1)) and not lab[j-1] and j not in flash:
        dt = j/FPS - cut[k]["edit_t0"]
        cut[k]["edit_t0"] += dt; cut[k]["wav_t0"] += dt; cut[k-1]["edit_t1"] = cut[k]["edit_t0"]; cut[k-1]["wav_t1"] += dt
        print(f"  cut {k}: picture cut at {j/FPS:.3f}s ({dt*1000:+.0f} ms from the audio edge)")
(J/"vertical").mkdir(parents=True, exist_ok=True)
json.dump(cut, open(J/"vertical/cut.json", "w"), indent=1)
plan = {
    "_copy_of": str(REF/"edit.mp4"),
    "cut_from": str(J/"vertical/cut.json"),
    "motion_ref": str(REF/"motion.json"),
    "title": (title or "").replace("1o", "To"), "title_until": T(title_last + 1),
    "cards": [{k: v for k, v in dict(c, t0=T(c["f0"]), t1=T(c["f1"])).items() if k not in ("f0", "f1")} for c in cards],
    "broll": broll,
    "flash": [T(i) for i in flash],
    "clicks": clicks,
    "captions": caps,
}
if cta is not None:
    plan["cta"] = {"word": "batch", "t0": T(cta)}
    m = [b["t"] for fr in ocr for b in fr["text"] if b["t"].startswith(("“", '"')) and b["t"].upper() == b["t"]]
    if m: plan["cta"]["word"] = re.sub(r"[^A-Za-z ]", "", m[0]).strip().lower()
(J/"vertical").mkdir(parents=True, exist_ok=True)
json.dump(plan, open(J/"vertical/plan.json", "w"), indent=1, ensure_ascii=False)
print(f"  {len(cards)} cards ({len(stack_cards)} stack), {len(broll)} B-roll, {len(flash)} flashes, {len(clicks)} clicks, {len(caps)} captions")
print(f"  title {plan['title']!r} until {plan['title_until']}s · CTA {plan.get('cta')}")
print(f"-> {J/'vertical/plan.json'}")
