"""frame_fit.py — fit the footage of a framed line into the Frame's window (fx_library.Frame).

The Frame effect draws the plate; the format owns the footage, so this is the format's half: after the
normal finish(), every video clip on the footage tracks whose middle falls in a framed span is shrunk by k
about the frame centre and moved onto the window's centre. The clip's own punch-in, eye-lock and Ken Burns
keyframes are kept and multiplied, never replaced:

    scale      -> scale * k
    position   -> position * k + offset        (CapCut units: half a canvas, y up)

    spans = [frame_span(fr, look, W, H, t0, t1)]       # one per framed line
    fit(dst, spans)                                     # after capcut_draft.finish()

k is chosen so the picture still covers the window. inset and rounded keep the crop the clip had
(k = the window's larger side ratio). letterbox shows the whole 16:9 picture across a vertical canvas:
there the builder passes `cover` (its 16:9-to-vertical cover factor) and k undoes it.
"""
import json, pathlib

US = lambda s: int(round(s * 1_000_000))
TRACKS = ("A-roll", "B-roll", "Subject", "Media", "Hook")

def frame_span(fr, look, W, H, t0, t1, cover=None):
    """(t0_us, t1_us, k, ox, oy, k_other) for one framed line. k is for the take (A-roll, Subject);
    k_other for clips already shaped to the canvas (B-roll, media), which only need to cover the window"""
    if look == "letterbox" and W >= H: look = "inset"          # letterbox is for vertical canvases only
    w = fr.window(look)
    k_other = max(w["w"] / W, w["h"] / H)
    k = k_other
    ox = (w["x"] + w["w"] / 2 - W / 2) / (W / 2)
    oy = -(w["y"] + w["h"] / 2 - H / 2) / (H / 2)
    # letterbox shows the WHOLE 16:9 take: an absolute size (the window's width over the canvas width, in
    # CapCut's contain-fit units, where a 16:9 clip on a portrait canvas is exactly as wide as the canvas),
    # centred on the window, no punch or eye-lock move. Multiplying failed on exact copies, whose scale is
    # the reference's own, not the base cover.
    absolute = (w["w"] / W) if look == "letterbox" else None
    return (US(t0), US(t1), k, ox, oy, k_other, absolute, (w["x"], w["y"], w["w"], w["h"]))

def _dims(sg, mats):
    m = mats.get(sg.get("material_id")) or {}
    return m.get("width") or 0, m.get("height") or 0

def _is_landscape(sg, mats):
    w, h = _dims(sg, mats); return bool(w and h and w > h)

def cover_window(sg, sp, mats, W, H):
    """after the fit: the picture must still cover the window at every keyframe. A take that only just covers
    the canvas (a vertical source on 3:4, a reference's own scale on an exact copy) leaves a strip once it is
    shrunk and moved, so raise the scale to cover the window and clamp the move inside the slack."""
    if len(sp) < 8: return
    mw, mh = _dims(sg, mats)
    if not (mw and mh): return
    bx, by, bw, bh = sp[7]; fitc = min(W / mw, H / mh)
    smin = max(bw / (mw * fitc), bh / (mh * fitc)) * 1.002
    c = sg["clip"]; kls = sg.get("common_keyframes") or []
    sk = [kl for kl in kls if kl["property_type"] in ("KFTypeScaleX", "KFTypeScaleY")]
    c["scale"]["x"] = max(c["scale"]["x"], smin); c["scale"]["y"] = max(c["scale"]["y"], smin)
    for kl in sk:
        for kf in kl["keyframe_list"]: kf["values"] = [max(v, smin) for v in kf["values"]]
    s_use = min([c["scale"]["x"]] + [v for kl in sk for kf in kl["keyframe_list"] for v in kf["values"]]) if sk else c["scale"]["x"]
    cx = (bx + bw / 2 - W / 2) / (W / 2); cy = -(by + bh / 2 - H / 2) / (H / 2)
    mx = max(0.0, (mw * fitc * s_use - bw) / 2) / (W / 2); my = max(0.0, (mh * fitc * s_use - bh) / 2) / (H / 2)
    clampx = lambda v: max(cx - mx, min(cx + mx, v)); clampy = lambda v: max(cy - my, min(cy + my, v))
    c["transform"]["x"] = clampx(c["transform"]["x"]); c["transform"]["y"] = clampy(c["transform"]["y"])
    for kl in kls:
        if kl["property_type"] == "KFTypePositionX":
            for kf in kl["keyframe_list"]: kf["values"] = [clampx(v) for v in kf["values"]]
        elif kl["property_type"] == "KFTypePositionY":
            for kf in kl["keyframe_list"]: kf["values"] = [clampy(v) for v in kf["values"]]

def fit(dst, spans, tracks=TRACKS, text_tracks=()):
    """text_tracks: caption tracks that should move INTO the window with the picture (CineYap's left
    captions). Scaling the text element by k about the frame centre and adding the window offset puts a
    left caption's edge at window.x + inset*k at k times its size, which is the same caption inside the
    smaller picture."""
    if not spans: return 0
    n = 0
    for fn in ("draft_info.json", "draft_content.json"):
        f = pathlib.Path(dst)/fn
        if not f.exists(): continue
        j = json.loads(f.read_text()); n = 0
        CW, CH = j["canvas_config"]["width"], j["canvas_config"]["height"]
        mats = {m["id"]: m for m in j["materials"].get("videos", [])}
        for tr in j["tracks"]:
            is_text = tr.get("type") == "text" and tr.get("name") in text_tracks
            if not is_text and (tr.get("type") != "video" or tr.get("name") not in tracks): continue
            for sg in tr["segments"]:
                tt = sg["target_timerange"]; mid = tt["start"] + tt["duration"] / 2
                sp = next((s for s in spans if s[0] <= mid < s[1]), None)
                if not sp: continue
                k = sp[2] if tr.get("name") in ("A-roll", "Subject") else sp[5]
                if is_text: k = sp[5]
                ox, oy = sp[3], sp[4]; c = sg["clip"]
                if len(sp) > 6 and sp[6] and tr.get("name") in ("A-roll", "Subject") and _is_landscape(sg, mats):
                    A = sp[6]
                    c["scale"]["x"] = c["scale"]["y"] = A; c["transform"]["x"] = ox; c["transform"]["y"] = oy
                    for kl in sg.get("common_keyframes") or []:
                        for kf in kl["keyframe_list"]:
                            if kl["property_type"] in ("KFTypeScaleX", "KFTypeScaleY"): kf["values"] = [A for _ in kf["values"]]
                            elif kl["property_type"] == "KFTypePositionX": kf["values"] = [ox for _ in kf["values"]]
                            elif kl["property_type"] == "KFTypePositionY": kf["values"] = [oy for _ in kf["values"]]
                    cover_window(sg, sp, mats, CW, CH); n += 1; continue
                c["scale"]["x"] *= k; c["scale"]["y"] *= k
                c["transform"]["x"] = c["transform"]["x"] * k + ox; c["transform"]["y"] = c["transform"]["y"] * k + oy
                for kl in sg.get("common_keyframes") or []:
                    pt = kl["property_type"]
                    for kf in kl["keyframe_list"]:
                        if pt in ("KFTypeScaleX", "KFTypeScaleY"): kf["values"] = [v * k for v in kf["values"]]
                        elif pt == "KFTypePositionX": kf["values"] = [v * k + ox for v in kf["values"]]
                        elif pt == "KFTypePositionY": kf["values"] = [v * k + oy for v in kf["values"]]
                if not is_text: cover_window(sg, sp, mats, CW, CH)
                n += 1
        f.write_text(json.dumps(j, ensure_ascii=False))
    return n
