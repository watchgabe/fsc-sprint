#!/usr/bin/env python3
"""Scene-detect every B-roll clip so each real shot becomes an addressable unit.

Solves two problems at once:
  - two picks from the same clip that are actually the same shot (looked like reuse)
  - a pick that spans an internal cut (looked like a glitch)
"""
import json, subprocess, pathlib, re
import sys as _s; _s.path.insert(0, str(__import__("pathlib").Path(__file__).parent))
from config import need as cfg_need
B = cfg_need("broll_root")
FILES = [
 "Content/A Roll Talking.mp4","Content/BTS.mp4",
 "Office/New House B Roll.mp4","Office/Office.mp4","Office/Roof top work.mp4",
 "Office/Working-Office.mp4",
 "Lifestyle/Cliffside.mp4","Lifestyle/Fitness 2026.mp4",
 "Lifestyle/Mexico Lifesttle Shots.mp4","Lifestyle/Kansas.mp4",
 "Travel/Airport.mp4","Travel/Travel 4k.mp4","Travel/Canyon Sequence.mp4",
 "Content/Content Creation.mp4","Content/Conetnt creation.mp4",
 "Lifestyle/Fitness-Lifestyle .mp4","Lifestyle/Snowday B Roll.mp4",
 "Lifestyle/Sequence 01.mp4","Retreats/Creator Retreat.mp4",
]
MIN = 1.6          # a shot shorter than this is not usable on its own
out = []
for rel in FILES:
    p = B / rel
    dur = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
                                "-of","csv=p=0",str(p)],capture_output=True,text=True).stdout)
    r = subprocess.run(["ffmpeg","-hide_banner","-i",str(p),"-vf",
                        "select='gt(scene,0.30)',metadata=print","-an","-f","null","-"],
                       capture_output=True,text=True).stderr
    cuts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", r)]
    bounds = [0.0] + cuts + [dur]
    shots = []
    for i in range(len(bounds)-1):
        a,b = bounds[i], bounds[i+1]
        if b-a >= MIN:
            shots.append({"clip": rel, "path": str(p),
                          "start": round(a+0.25,2), "end": round(b-0.25,2),
                          "dur": round(b-a-0.5,2)})
    print(f"  {rel.split('/')[-1]:32} {dur:6.1f}s -> {len(cuts):3d} cuts, {len(shots):3d} usable shots")
    out += shots
json.dump(out, open("shots.json","w"), indent=1)
print(f"\n  {len(out)} usable shots total")
