#!/usr/bin/env python3
"""Scaffold a new CineYap job.

    ./vu-py cineyap/newjob.py <job-name> <source.mp4> [lut.cube]

Creates projects/<job-name>/ with the per-job files to fill in and
symlinks to the shared pipeline. Prints the exact command sequence to run.
"""
import shutil, sys, pathlib, re

HERE = pathlib.Path(__file__).parent
from _root import PROJECTS as ROOT
sys.path.insert(0, str(HERE))
from config import opt as cfg_opt
DEFAULT_LUT = cfg_opt("lut", "")

if len(sys.argv) < 3:
    sys.exit(__doc__)
name, src = sys.argv[1], str(pathlib.Path(sys.argv[2]).resolve())
lut = sys.argv[3] if len(sys.argv) > 3 else DEFAULT_LUT

job = ROOT / name
(job / "edit").mkdir(parents=True, exist_ok=True)
build = job / "build"; build.mkdir(exist_ok=True)

# No LUT is a legitimate setup (a member who does not grade). Only copy one if there is one.
_src = HERE / "lut.cube" if (HERE / "lut.cube").exists() else (lut or "")
if _src and pathlib.Path(_src).exists():
    shutil.copy(_src, job / "lut.cube")
else:
    print("  note: no LUT configured, so the base render will not be graded.")

t = (HERE / "edl.template.py").read_text().replace("<absolute path to the raw take>", src)
t = t.replace('f"lut3d={pathlib.Path(__file__).parent}/lut.cube"',
              f'f"lut3d={job}/lut.cube"')
(build / "mkedl.py").write_text(t)
shutil.copy(HERE / "regions.template.py", build / "regions.py")

for f in ("build_layers.py", "composite.py", "transitions.py", "shots.json", "detect_shots.py"):
    link = build / f
    if link.exists() or link.is_symlink():
        link.unlink()
    link.symlink_to((HERE / f).resolve())

(build / "words.py").write_text('''import json, pathlib
edl = json.load(open("../edit/edl.json"))
tr  = json.load(open(f"../edit/transcripts/{list(edl['sources'])[0]}.json"))
ws  = [w for w in tr["words"] if w.get("text", "").strip()]
off, out = 0.0, []
for r in edl["ranges"]:
    s, e = r["start"], r["end"]
    for w in ws:
        if s <= w["start"] < e:
            out.append([round(w["start"]-s+off, 2), round(min(w["end"], e)-s+off, 2), w["text"].strip()])
    off += e - s
pathlib.Path("words_out.json").write_text(json.dumps(out))
print(f"{len(out)} words, {off:.2f}s")
''')

print(f"""
job ready: {job}

  1. transcribe        ./vu transcribe.py "{src}" --edit-dir {job}/edit
  2. read it           ./vu pack_transcripts.py --edit-dir {job}/edit
  2.5 SHORTLIST TAKES  cd build && ./vu-py cineyap/rank_takes.py
                       Groups the re-attempts and finds where each take's clean run starts.
                       Read edit/takes_ranked.md instead of all 26 raw takes.
  3. pick the cut      edit build/mkedl.py   then: python3 build/mkedl.py
  3.5 SNAP THE EDGES   cd build && ./vu-py cineyap/snap_edges.py
                       Puts every cut on the sound instead of the transcript stamp. Always run it.
  4. render the base   ./vu render.py {job}/edit/edl.json -o {job}/build/base_clean.mp4
  5. word timeline     cd build && ../../../vu-py words.py
  6. plan the style    edit build/regions.py
  7. build layers      ./vu-py cineyap/build_layers.py
  8. encode layer      N=$(ffprobe -v error -count_frames -select_streams v:0 \\
                            -show_entries stream=nb_read_frames -of csv=p=0 base_clean.mp4)
                       ffmpeg -y -framerate 24000/1001 -i assets/seq/f%06d.png -frames:v $N \\
                         -c:v prores_ks -profile:v 4444 -pix_fmt yuva444p10le layer.mov
  9. composite         ./vu-py cineyap/composite.py
 10. transitions       ./vu-py cineyap/transitions.py <t1> <t2> ...
 11. PREMIERE XML      ./vu-py cineyap/mkxml.py
                       ALWAYS ship this with the render. Gabe finishes in Premiere.

Rules live in the brain: Operations/Video-Text-Style.md
Run detect_shots.py only when the B-roll library changes.
""")
