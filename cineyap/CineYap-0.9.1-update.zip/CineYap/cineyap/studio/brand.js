/* brand.js — the Brand tab: a creator's colors, fonts, handle, LUT and logo, without editing a file.
   Reads and writes cineyap/brand.json through /api/brand. style.py applies it to every build.
   The preview is CSS, drawn from the same five colors and two fonts the builders use. */
(function(){
var COLORS=[
  ["dark","Dark","Cards, bands, and words on light plates"],
  ["light","Light","Cream plates and light words"],
  ["label","Label","The tag, label and pill box"],
  ["ink","Label text","Words on the label. Follows Dark if left empty"],
  ["text","Caption text","Words over your footage"],
  ["accent","Accent color","Optional. Tints the accent word"]];
var STYLES=[["serif-italic","Accent font"],["bold","Bold"],["underline","Underline"],["color","Color only"]];

window.renderBrand=function(page,APP,h,api){
  page.className="wrap wide";page.innerHTML="";
  page.appendChild(h("h1",{class:"pg-title",text:"Brand"}));
  page.appendChild(h("p",{class:"pg-sub",text:"Your colors, fonts, handle and grade. Every video you build from here on uses them, in every format. Videos already built keep their look until you rebuild them from their Board."}));
  var body=h("div",{class:"as-p",text:"Loading…"});page.appendChild(body);
  api("/api/brand").then(function(S){draw(page,body,S,h,api);});
};

function fontUrl(p){return "/file?p="+encodeURIComponent(p);}
function loadFace(name,path){
  var id="bf-"+name,old=document.getElementById(id);if(old)old.remove();
  if(!path)return;
  var st=document.createElement("style");st.id=id;
  st.textContent="@font-face{font-family:'"+name+"';src:url('"+fontUrl(path)+"');font-display:block}";
  document.head.appendChild(st);}

function draw(page,body,S,h,api){
  var B=JSON.parse(JSON.stringify(S.brand));delete B._native;
  B.colors=B.colors||{};B.fonts=B.fonts||{};
  var dirty=false;
  body.className="";body.innerHTML="";
  var grid=h("div",{class:"br-grid"});body.appendChild(grid);
  var form=h("div",{class:"br-form"}),pv=h("div",{class:"br-pv"});grid.appendChild(form);grid.appendChild(pv);

  function touch(){dirty=true;saveBtn.disabled=false;status.textContent="Not saved yet";status.className="note warn";paint();}

  /* -------- presets */
  var pre=h("div",{class:"br-sec"},[h("h3",{text:"Start from"})]);
  var pr=h("div",{class:"br-row"});
  Object.keys(S.presets).forEach(function(n){
    pr.appendChild(h("button",{type:"button",class:"sbtn",text:n,onclick:function(){
      B.colors=Object.assign({},S.presets[n]);syncColors();touch();}}));});
  pre.appendChild(pr);form.appendChild(pre);

  /* -------- who */
  var who=h("div",{class:"br-sec"},[h("h3",{text:"You"})]);
  function field(lbl,key,ph,hint){
    var inp=h("input",{type:"text",value:B[key]||"",placeholder:ph,oninput:function(){B[key]=inp.value.trim();touch();}});
    return h("label",{class:"br-field"},[h("span",{text:lbl}),inp,hint?h("small",{text:hint}):null]);}
  who.appendChild(field("Name","name","Your name or brand",null));
  who.appendChild(field("Handle","handle","@yourhandle","Signs the corner of posters: by @yourhandle"));
  form.appendChild(who);

  /* -------- colors */
  var cs=h("div",{class:"br-sec"},[h("h3",{text:"Colors"})]);var swatches={};
  COLORS.forEach(function(c){
    var k=c[0],val=B.colors[k]||"";
    var pick=h("input",{type:"color",value:val||"#000000"});
    var hex=h("input",{type:"text",value:val,placeholder:k==="accent"||k==="ink"?"none":"#000000",maxlength:"7",class:"hex"});
    pick.addEventListener("input",function(){hex.value=pick.value.toUpperCase();B.colors[k]=hex.value;touch();});
    hex.addEventListener("input",function(){var v=hex.value.trim();
      if(/^#[0-9a-fA-F]{6}$/.test(v)){pick.value=v;B.colors[k]=v.toUpperCase();touch();}
      else if(v===""){B.colors[k]="";touch();}});
    swatches[k]={pick:pick,hex:hex};
    cs.appendChild(h("div",{class:"br-color"},[pick,h("div",{class:"br-cl"},[h("b",{text:c[1]}),h("small",{text:c[2]})]),hex]));});
  function syncColors(){Object.keys(swatches).forEach(function(k){var v=B.colors[k]||"";swatches[k].hex.value=v;swatches[k].pick.value=v||"#000000";});}
  form.appendChild(cs);

  /* -------- fonts */
  var fs=h("div",{class:"br-sec"},[h("h3",{text:"Fonts"})]);
  function fontPick(lbl,key,hint){
    var sel=h("select",{});
    function fill(){sel.innerHTML="";
      sel.appendChild(h("option",{value:"",text:"Keep the default ("+base(S.pack_fonts[key])+")"}));
      var g1=h("optgroup",{label:"Comes with CineYap"}),g2=h("optgroup",{label:"Uploaded"}),g3=h("optgroup",{label:"On this Mac"});
      S.fonts.forEach(function(f){var o=h("option",{value:f.path,text:f.name});
        (f.shipped?g1:(f.path.indexOf("/brand_assets/")>=0?g2:g3)).appendChild(o);});
      [g1,g2,g3].forEach(function(g){if(g.children.length)sel.appendChild(g);});
      sel.value=B.fonts[key]||"";}
    fill();
    sel.addEventListener("change",function(){B.fonts[key]=sel.value;touch();});
    var up=h("label",{class:"sbtn",text:"Upload .ttf or .otf"});
    var fi=h("input",{type:"file",accept:".ttf,.otf",hidden:true});up.appendChild(fi);
    fi.addEventListener("change",function(){var f=fi.files[0];if(!f)return;
      upload(f,function(p){S.fonts.push({name:f.name.replace(/\.(ttf|otf)$/i,"").replace(/-/g," "),path:p,shipped:false});B.fonts[key]=p;fill();touch();});});
    return h("div",{class:"br-field"},[h("span",{text:lbl}),h("div",{class:"br-row"},[sel,up]),h("small",{text:hint})]);}
  fs.appendChild(fontPick("Main font","main","Captions, cards and titles"));
  fs.appendChild(fontPick("Accent font","accent","The one word per line that gets the accent"));
  var segs=h("div",{class:"seg"});
  STYLES.forEach(function(s){segs.appendChild(h("button",{type:"button","data-v":s[0],text:s[1],onclick:function(){B.fonts.accent_style=s[0];markSeg();touch();}}));});
  function markSeg(){Array.prototype.forEach.call(segs.children,function(b){b.setAttribute("aria-pressed",b.getAttribute("data-v")===(B.fonts.accent_style||"serif-italic")?"true":"false");});}
  markSeg();
  fs.appendChild(h("div",{class:"br-field"},[h("span",{text:"Accent style"}),segs,h("small",{text:"How the accent word stands out. Color only needs an Accent color above."})]));
  form.appendChild(fs);

  /* -------- grade */
  var gs=h("div",{class:"br-sec"},[h("h3",{text:"Grade"})]);
  var lutName=h("b",{});
  function lutText(){lutName.textContent=B.lut?base(B.lut):"No LUT. Footage keeps its own color.";}
  lutText();
  var lu=h("label",{class:"sbtn",text:"Choose a .cube LUT"}),lf=h("input",{type:"file",accept:".cube",hidden:true});lu.appendChild(lf);
  lf.addEventListener("change",function(){var f=lf.files[0];if(!f)return;upload(f,function(p){B.lut=p;lutText();touch();});});
  gs.appendChild(h("div",{class:"br-file"},[lutName,h("div",{class:"br-row"},[lu,h("button",{type:"button",class:"sbtn",text:"No LUT",onclick:function(){B.lut="";lutText();touch();}})])]));
  gs.appendChild(h("small",{class:"note",text:"Shoot in log? Add the LUT your camera maker gives for it. iPhone HDR footage is converted for you and skips the LUT."}));
  form.appendChild(gs);

  /* -------- logo */
  var ls=h("div",{class:"br-sec"},[h("h3",{},["Logo ",h("span",{class:"pill",text:"Coming"})])]);
  var logoName=h("b",{text:B.logo?base(B.logo):"No logo yet"});
  var lo=h("label",{class:"sbtn",text:"Choose a PNG"}),lof=h("input",{type:"file",accept:".png,.svg",hidden:true});lo.appendChild(lof);
  lof.addEventListener("change",function(){var f=lof.files[0];if(!f)return;upload(f,function(p){B.logo=p;logoName.textContent=base(p);touch();});});
  ls.appendChild(h("div",{class:"br-file"},[logoName,lo]));
  ls.appendChild(h("small",{class:"note",text:"Saved now, placed on end cards in a coming update."}));
  form.appendChild(ls);

  /* -------- save bar */
  var status=h("span",{class:"note",text:S.saved?"Saved":"Not set up yet. This shows the look your videos use today."});
  var saveBtn=h("button",{type:"button",class:"sbtn pri",text:"Save brand",disabled:true,onclick:function(){
    saveBtn.disabled=true;status.textContent="Saving…";
    api("/api/brand",{brand:B}).then(function(r){dirty=false;status.textContent=r.ok?"Saved. Your next build uses it.":"Could not save";status.className="note"+(r.ok?" good":" warn");})
      .catch(function(){saveBtn.disabled=false;status.textContent="Could not save";});}});
  form.appendChild(h("div",{class:"br-save"},[saveBtn,status]));
  window.addEventListener("beforeunload",function(e){if(dirty){e.preventDefault();e.returnValue="";}});

  /* -------- preview */
  pv.appendChild(h("div",{class:"br-pvh"},[h("h3",{text:"Preview"}),h("small",{class:"note",text:"A sketch of the look. Exact sizes come from the format."})]));
  var stage=h("div",{class:"br-stage"});pv.appendChild(stage);
  stage.innerHTML=
   '<div class="bp bp-wide"><div class="ft"></div><div class="cap">The camera is the <i class="acc">easy</i> part</div></div>'+
   '<div class="bp-row">'+
     '<div class="bp bp-tall bp-card"><div class="lab">Lesson 01</div><div class="ttl">Build it <i class="acc">once</i>, use it every day</div></div>'+
     '<div class="bp bp-tall bp-split"><div class="ft"></div><div class="band"><span class="lab">The roadmap</span><div class="ttl">Four weeks to a <i class="acc">cinematic</i> brand</div></div></div>'+
     '<div class="bp bp-tall bp-cream"><div class="plate"><div class="ttl">Stop posting <i class="acc">slop</i></div><div class="media"></div></div></div>'+
   '</div>'+
   '<div class="bp bp-poster"><div class="ft"></div><div class="ttl">Shot on a phone. Edited in <i class="acc">one</i> afternoon.</div><div class="by"></div></div>';

  function paint(){
    var c=Object.assign({},S.presets["FSCreative"]);  // a missing color falls back to the measured pack, like style.py
    Object.keys(B.colors).forEach(function(k){if(B.colors[k])c[k]=B.colors[k];});
    if(!B.colors.ink&&B.colors.dark)c.ink=B.colors.dark;
    loadFace("BrandMain",B.fonts.main||S.pack_fonts.main);loadFace("BrandAccent",B.fonts.accent||S.pack_fonts.accent);
    var how=B.fonts.accent_style||"serif-italic";
    var s=stage.style;
    s.setProperty("--b-dark",c.dark);s.setProperty("--b-light",c.light);s.setProperty("--b-label",c.label);
    s.setProperty("--b-ink",c.ink);s.setProperty("--b-text",c.text);s.setProperty("--b-acc",B.colors.accent||"inherit");
    stage.setAttribute("data-acc",how);
    stage.querySelector(".by").textContent=B.handle?("by "+B.handle):"by @yourhandle";
  }
  paint();
}

function base(p){return String(p||"").split("/").pop()||"none";}
function upload(f,cb){fetch("/api/brand/upload?name="+encodeURIComponent(f.name),{method:"POST",body:f}).then(function(r){return r.json();}).then(function(r){if(r.path)cb(r.path);});}
})();
