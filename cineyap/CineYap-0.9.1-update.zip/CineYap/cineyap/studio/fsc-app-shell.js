/* FSCreative App shell: Light / Dark switch + phone menu. Pairs with fsc-app.css.
   Light is the default everywhere. There is no Auto. Dark is remembered per device (localStorage key fsc-theme).
   Markup it expects (all optional):
     buttons [data-theme-set="light"] and [data-theme-set="dark"]   the segmented switch
     #rail > #menuBtn + #railMenu                                   the sidebar that becomes a top bar on phones
   Put this one-liner in a script tag in the head, before the CSS, so a saved Dark choice applies with no flash:
     (function(){var t='light';try{if(localStorage.getItem('fsc-theme')==='dark')t='dark';}catch(e){}document.documentElement.setAttribute('data-theme',t);})()
*/
(function(){
  var KEY='fsc-theme', R=document.documentElement;
  function pref(){ try{ return localStorage.getItem(KEY)==='dark'?'dark':'light'; }catch(e){ return 'light'; } }
  function meta(){ var m=document.querySelector('meta[name="theme-color"]'); if(!m){ m=document.createElement('meta'); m.name='theme-color'; document.head.appendChild(m); }
    m.content=(getComputedStyle(R).getPropertyValue('--bg')||'').trim()||'#ffffff'; }
  function setTheme(t,save){
    t=t==='dark'?'dark':'light'; R.setAttribute('data-theme',t);
    if(save){ try{ localStorage.setItem(KEY,t); }catch(e){} }
    document.querySelectorAll('[data-theme-set]').forEach(function(b){ var on=b.dataset.themeSet===t; b.classList.toggle('on',on); b.setAttribute('aria-pressed',on?'true':'false'); });
    meta(); document.dispatchEvent(new CustomEvent('fsc-theme',{detail:t}));
  }
  document.querySelectorAll('[data-theme-set]').forEach(function(b){ b.addEventListener('click',function(){ setTheme(b.dataset.themeSet,true); }); });
  setTheme(pref(),false);
  var rail=document.getElementById('rail'), btn=document.getElementById('menuBtn');
  function menu(open){ if(!rail||!btn) return; rail.classList.toggle('open',!!open); R.classList.toggle('menu-open',!!open);
    btn.setAttribute('aria-expanded',open?'true':'false'); btn.setAttribute('aria-label',open?'Close menu':'Open menu'); }
  if(btn){ btn.addEventListener('click',function(){ menu(!rail.classList.contains('open')); });
    document.addEventListener('keydown',function(e){ if(e.key==='Escape') menu(false); });
    try{ matchMedia('(min-width:761px)').addEventListener('change',function(e){ if(e.matches) menu(false); }); }catch(e){}
    if(rail) rail.querySelectorAll('nav a').forEach(function(a){ a.addEventListener('click',function(){ menu(false); }); }); }
  window.FSCApp={setTheme:setTheme,menu:menu};
})();
