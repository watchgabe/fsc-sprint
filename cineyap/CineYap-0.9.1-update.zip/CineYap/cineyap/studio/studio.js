/* CineYap Studio: the page. Formats, Effects, and a Board for every video in every format.
   Talks to studio.py on this Mac: /api/state, /api/board, /api/apply, /api/open, /api/reveal, /api/library. */
(function(){
"use strict";
var $=function(s,r){return (r||document).querySelector(s);}, $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
var page=$("#page"), APP={state:null,D:null,S:null,lib:null};
function h(tag,attrs,kids){var e=document.createElement(tag);attrs=attrs||{};
  Object.keys(attrs).forEach(function(k){var v=attrs[k];if(v==null||v===false)return;
    if(k==="class")e.className=v;else if(k==="text")e.textContent=v;else if(k==="html")e.innerHTML=v;
    else if(k.slice(0,2)==="on")e.addEventListener(k.slice(2),v);else e.setAttribute(k,v===true?"":v);});
  (kids||[]).forEach(function(c){if(c==null)return;e.appendChild(typeof c==="string"?document.createTextNode(c):c);});return e;}
var I={ /* 16px line icons */
 note:'<path d="M3 3.5h10v7H7l-3 2.5v-2.5H3z"/>', broll:'<rect x="2" y="3.5" width="12" height="9" rx="1.5"/><path d="m6.5 6.2 3.5 1.8-3.5 1.8z"/>',
 zin:'<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3 3M5 7h4M7 5v4"/>', zout:'<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3 3M5 7h4"/>',
 user:'<circle cx="8" cy="5.5" r="2.5"/><path d="M3.5 13.5c.6-2.6 2.4-4 4.5-4s3.9 1.4 4.5 4"/>', sq:'<rect x="3" y="3" width="10" height="10" rx="2"/>',
 bolt:'<path d="M9 1.5 3.5 9H8l-1 5.5L12.5 7H8z"/>', card:'<rect x="2" y="4" width="12" height="8" rx="1.5"/><path d="M5 8h6"/>',
 look:'<path d="M2.5 12.5h11M4 9.5h8M5.5 6.5h5M7 3.5h2"/>', trash:'<path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/>',
 swap:'<path d="M3 5.5h9l-2.5-2.5M13 10.5H4l2.5 2.5"/>', open:'<path d="M9.5 2.5h4v4M13.5 2.5 7.5 8.5M12 9.5v4H2.5V4H6.5"/>',
 finder:'<rect x="2" y="3" width="12" height="10" rx="2"/><path d="M8 3v10M5.5 6v1M10.5 6v1"/>', pen:'<path d="m3 13 1-3.5 6.5-6.5 2.5 2.5L6.5 12z"/>',
 pal:'<circle cx="8" cy="8" r="5.5"/><circle cx="6" cy="6.5" r=".8"/><circle cx="9.5" cy="5.8" r=".8"/><circle cx="10.6" cy="9" r=".8"/>',
 board:'<rect x="2" y="2.5" width="12" height="11" rx="2"/><path d="M2 6h12M6 6v7.5"/>'};
function ic(n){return '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round">'+(I[n]||"")+'</svg>';}
function api(path,body){return fetch(path,body?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}:{}).then(function(r){return r.json();});}
function fmt(s){var m=Math.floor(s/60),x=Math.round(s%60);if(x===60){m++;x=0;}return m+":"+(x<10?"0":"")+x;}
function esc(s){return String(s||"").replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}

/* ---------------------------------------------------------------- formats: what the Library knows, plus the two new ones */
var FMT_INFO={
 cineyap:{lib:"fmt_cineyap"},
 cineyap43:{name:"CineYap 4:3",cat:"4:3",what:"The CineYap cut on a 1440x1080 frame: the same captions, cards, punch-ins and eye lock, with your face kept centered in the narrower frame.",when:"Feed posts that want more height than 16:9. Same Board as CineYap.",status:"built"},
 vertical:{lib:"fmt_vertical"},
 vcineyap:{name:"Vertical CineYap",cat:"9:16",what:"Word captions low in the frame, a high serif run for accents, green cards, a split screen with a Step label, media cards and an opening title.",when:"Your '30 Pieces in 30 Min' style: talking points with steps.",status:"built"},
 panel:{lib:"fmt_panel"}, poster:{lib:"fmt_poster"},
 poster_v:{lib:"fmt_poster",name:"Poster vertical",cat:"9:16",what:"The poster headline and your signature corners on a 1080x1920 frame."},
 carousel:{lib:"fmt_carousel"}, reel:{lib:"fmt_reel"}};
var ORDER=["vertical","vcineyap","cineyap","cineyap43","panel","poster","poster_v","carousel","reel"];
function catFmt(id){var c=(APP.state.catalog||{}).formats||[];return c.filter(function(x){return x.id===id;})[0]||{};}
function fmtInfo(f){var i=FMT_INFO[f]||{},c=i.lib?catFmt(i.lib):{};var o={};Object.keys(c).forEach(function(k){o[k]=c[k];});Object.keys(i).forEach(function(k){o[k]=i[k];});return o;}
function statusPill(st){var m=((APP.state.catalog||{}).status||{})[st]||[st||"",""];return st?h("span",{class:"pill "+(m[1]||""),text:m[0]}):null;}
function testDrafts(f){var out=[];APP.state.jobs.forEach(function(j){j.formats.forEach(function(x){if(x.fmt===f&&(x.draft||x.board))out.push({job:j.job,fmt:f,draft:x.draft,board:x.board,preview:x.preview});});});return out;}

function preview(srcs,alt){var box=h("div",{class:"pv"});
  if(!srcs.length){box.appendChild(h("span",{class:"none",text:"No preview yet"}));return box;}
  var k=0;function show(){box.innerHTML="";var s=srcs[k];
    var el=/\.mp4$/i.test(s)?h("video",{src:s,muted:true,autoplay:true,loop:true,playsinline:true}):h("img",{src:s,alt:alt||"",loading:"lazy"});
    box.appendChild(el);if(srcs.length>1){var d=h("div",{class:"dots"});srcs.forEach(function(_,i){d.appendChild(h("i",{class:i===k?"on":""}));});box.appendChild(d);}}
  show();if(srcs.length>1)box.addEventListener("click",function(){k=(k+1)%srcs.length;show();});return box;}
function draftRow(t){
  var r=h("div",{class:"drow"},[h("span",{class:"nm",text:t.draft||(t.job+" (no draft yet)"),title:t.draft||""})]);
  if(t.draft)r.appendChild(h("button",{class:"sbtn",type:"button",html:ic("open")+"CapCut",title:"Open "+t.draft+" in CapCut",onclick:function(){openDraft(t.draft);}}));
  if(t.board)r.appendChild(h("button",{class:"sbtn pri",type:"button",html:ic("board")+"Board",onclick:function(){location.hash="#v/"+encodeURIComponent(t.job)+"/"+t.fmt;}}));
  return r;}

function renderFormats(){
  page.className="wrap wide";page.innerHTML="";
  page.appendChild(h("h1",{class:"pg-title",text:"Formats"}));
  page.appendChild(h("p",{class:"pg-sub",text:"Every format CineYap builds. Each card lists the CapCut drafts that show it: open one to keep tightening it, or open its Board to change the edit."}));
  var g=h("div",{class:"grid"});
  ORDER.forEach(function(f){var info=fmtInfo(f),td=testDrafts(f);
    var pv=(info.preview||[]).map(function(p){return "/library/previews/"+p+".webp";});
    td.forEach(function(t){if(t.preview)pv.unshift("/file?p="+encodeURIComponent(t.preview));});
    var card=h("div",{class:"fcard"},[preview(pv,info.name),h("div",{class:"bd"},[
      h("h3",{},[info.name||f,h("span",{class:"pill canvas",text:info.cat||""}),statusPill(info.status)]),
      info.what?h("p",{text:info.what}):null, info.when?h("p",{class:"when",text:info.when}):null,
      h("div",{class:"acts"},td.length?td.map(draftRow):[h("p",{class:"note",text:"No test draft on this Mac yet."})])])]);
    g.appendChild(card);});
  page.appendChild(g);}

function renderEffects(){
  page.className="wrap wide";page.innerHTML="";
  page.appendChild(h("h1",{class:"pg-title",text:"Effects"}));
  page.appendChild(h("p",{class:"pg-sub",text:"Every effect is written once and every format calls it. Open a test draft to see one in CapCut, or switch it on per line from a video's Board."}));
  var g=h("div",{class:"grid"}),eff=(APP.state.catalog||{}).effects||[];
  eff.forEach(function(e){
    var pv=(e.preview||[]).map(function(p){return "/library/previews/"+p+".webp";});
    var dr=(e.test_draft||[]).filter(function(d){return APP.state.drafts.indexOf(d)>=0;});
    var card=h("div",{class:"fcard"},[preview(pv,e.name),h("div",{class:"bd"},[
      h("h3",{},[e.name,statusPill(e.status)]), h("p",{text:e.what||""}), e.when?h("p",{class:"when",text:e.when}):null,
      e.note?h("p",{class:"note",text:e.note}):null,
      h("p",{class:"note",text:"In: "+(e.formats||[]).join(", ")}),
      h("div",{class:"acts"},dr.map(function(d){var m=/^(.*) \((.*)\)$/.exec(d)||[];
        var fmt=Object.keys(FMT_SUFFIX).filter(function(k){return FMT_SUFFIX[k]===m[2];})[0];
        return draftRow({draft:d,job:m[1],fmt:fmt,board:!!fmt&&hasBoard(m[1],fmt)});}))])]);
    g.appendChild(card);});
  page.appendChild(g);}
var FMT_SUFFIX={cineyap:"CineYap",cineyap43:"CineYap 4x3",vertical:"Vertical",vcineyap:"Vertical CineYap",panel:"YapMaxxing",poster:"Poster",poster_v:"Poster Vertical",carousel:"Carousel",reel:"Reel"};
function hasBoard(job,f){return APP.state.jobs.some(function(j){return j.job===job&&j.formats.some(function(x){return x.fmt===f&&x.board;});});}

/* ---------------------------------------------------------------- a video */
function renderVideo(job,f){
  var J=APP.state.jobs.filter(function(j){return j.job===job;})[0];
  page.className="wrap wide";page.innerHTML="";
  if(!J){page.appendChild(h("p",{class:"as-p",text:"No video called "+job+"."}));return;}
  if(!f||!J.formats.some(function(x){return x.fmt===f;}))f=(J.formats.filter(function(x){return x.board;})[0]||J.formats[0]).fmt;
  var X=J.formats.filter(function(x){return x.fmt===f;})[0];
  page.appendChild(h("div",{class:"vhead"},[h("div",{class:"t"},[h("div",{class:"note",text:"Video"}),h("h1",{text:job})])]));
  var pills=h("div",{class:"fmt-pills"});
  J.formats.forEach(function(x){pills.appendChild(h("button",{type:"button",class:"as-pill"+(x.fmt===f?" on":""),text:(fmtInfo(x.fmt).name||x.name),onclick:function(){location.hash="#v/"+encodeURIComponent(job)+"/"+x.fmt;}}));});
  page.appendChild(pills);
  var top=h("div",{class:"vtop"});
  var pvs=[];if(X.preview)pvs.push("/file?p="+encodeURIComponent(X.preview));
  top.appendChild(preview(pvs,job));
  var side=h("div",{class:"side"});
  side.appendChild(h("div",{class:"bar-row"},[
    X.draft?h("button",{class:"sbtn pri",type:"button",html:ic("open")+"Open in CapCut",onclick:function(){openDraft(X.draft);}}):h("span",{class:"note",text:"No CapCut draft yet: Send builds it."}),
    X.draft?h("button",{class:"sbtn",type:"button",html:ic("finder")+"Show draft in Finder",onclick:function(){revealDraft(X.draft);}}):null]));
  side.appendChild(h("p",{class:"note",text:"Opening a draft quits CapCut first (it autosaves) and puts this draft on top. Every Send rebuilds the draft the same way, so close any unsaved CapCut work before you send."}));
  var stats=h("div",{class:"stats",id:"vstats"});side.appendChild(stats);top.appendChild(side);page.appendChild(top);
  if(!X.board){page.appendChild(h("div",{class:"as-empty",html:"<b>No Board for this format yet</b>The draft exists, but this video has no plan file for it. Ask Claude to set it up."}));return;}
  var holder=h("div",{id:"boardHolder"},[h("p",{class:"note",text:"Loading the Board…"})]);page.appendChild(holder);
  api("/api/board?job="+encodeURIComponent(job)+"&fmt="+f).then(function(D){if(D.error){holder.innerHTML="";holder.appendChild(h("div",{class:"dw-flags",text:"The Board could not load: "+D.error}));return;}
    APP.D=D;fresh();holder.innerHTML="";D.kind==="items"?renderItems(holder):renderLines(holder);counts();});}
function revealDraft(name){api("/api/reveal",{path:"__draft__"+name});}

/* ---------------------------------------------------------------- Board state */
function fresh(){var D=APP.D,S={lines:{},brolls:{},added:[],cards:{},items:{}};
  (D.takes||[]).forEach(function(k){S.lines[k.n]={cut:false,note:"",open:false,zoom:k.zoom||"wide",behind:!!k.behind,bg:k.bg||"",flash:!!k.flash,
    card:{type:k.card||"",label:k.label||""},frame:{look:(k.frame||{}).look||"",plate:(k.frame||{}).plate||"",clip:(k.frame||{}).clip||""},
    tag:{plate:(k.card_tag||{}).plate||"",tag:(k.card_tag||{}).tag||""},
    pb:{on:!!(k.pullback&&(k.pullback.line1||k.pullback.label)),label:(k.pullback||{}).label||"",line1:(k.pullback||{}).line1||"",line2:(k.pullback||{}).line2||"",serif:(k.pullback||{}).serif||""},
    bold:!!k.bold, sp:{on:k.split!=null&&k.split!==undefined,step:(k.split||{}).step||""}, gs:{on:!!(k.greenscreen||{}).clip,clip:(k.greenscreen||{}).clip||""},
    hook:{on:!!((k.hook||{}).title||(k.hook||{}).sub),title:(k.hook||{}).title||"",serif:(k.hook||{}).serif||"",sub:(k.hook||{}).sub||"",clip:(k.hook||{}).clip||""},look:{look:k.look||"captions",step:k.step||"",media:k.media||""}};});
  (D.brolls||[]).forEach(function(b){S.brolls[b.id]={clip:b.clip,thumb:b.thumb,remove:false};});
  (D.cards||[]).forEach(function(c){S.cards[c.id]={words:c.words.slice(),accent:c.accent.slice(),colour:c.colour,remove:false,edit:false};});
  (D.items||[]).forEach(function(it){var s={fields:{},media:{},note:"",open:false};(it.fields||[]).forEach(function(f){s.fields[f.key]=f.value;});
    (it.media||[]).forEach(function(m){s.media[m.key]={clip:m.clip,thumb:m.thumb};});S.items[it.id]=s;});
  APP.S=S;}
function changes(){var D=APP.D,S=APP.S,n=0,dur=0,kept=0,cut=0;
  (D.takes||[]).forEach(function(k){var s=S.lines[k.n];if(s.cut){n++;cut++;}else{kept++;dur+=k.dur;}if(s.note.trim())n++;
    if(s.zoom!==(k.zoom||"wide"))n++;if(s.behind!==!!k.behind)n++;if(s.bg!==(k.bg||""))n++;if(s.flash!==!!k.flash)n++;
    if(s.card.type!==(k.card||"")||s.card.label!==(k.label||""))n++;
    if(s.look.look!==(k.look||"captions")||s.look.step!==(k.step||"")||s.look.media!==(k.media||""))n++;
    if(s.frame.look!==((k.frame||{}).look||"")||s.frame.plate!==((k.frame||{}).plate||"")||s.frame.clip!==((k.frame||{}).clip||""))n++;
    if(k.n===1&&JSON.stringify(pbOut(s))!==JSON.stringify(k.pullback&&(k.pullback.line1||k.pullback.label)?{label:k.pullback.label||"",line1:k.pullback.line1||"",line2:k.pullback.line2||"",serif:k.pullback.serif||""}:null))n++;
    if(s.bold!==!!k.bold)n++; if(s.sp.on!==(k.split!=null)||(s.sp.on&&s.sp.step!==((k.split||{}).step||"")))n++; if((s.gs.on?s.gs.clip:"")!==((k.greenscreen||{}).clip||""))n++;
    if(JSON.stringify(tagOut(s))!==JSON.stringify(k.card_tag&&k.card_tag.plate?{tag:k.card_tag.tag||"",plate:k.card_tag.plate}:null))n++;
    if(JSON.stringify(hookOut(s))!==JSON.stringify(k.hook&&(k.hook.title||k.hook.sub)?{title:k.hook.title||"",serif:k.hook.serif||"",sub:k.hook.sub||"",clip:k.hook.clip||""}:null))n++;});
  (D.brolls||[]).forEach(function(b){var s=S.brolls[b.id];if(s.remove||s.clip!==b.clip)n++;});
  n+=S.added.filter(function(a){return a.clip;}).length;
  (D.cards||[]).forEach(function(c){var s=S.cards[c.id];if(s.remove||s.words.join(" ")!==c.words.join(" ")||s.colour!==c.colour||s.accent.slice().sort().join()!==c.accent.slice().sort().join())n++;});
  (D.items||[]).forEach(function(it){var s=S.items[it.id];(it.fields||[]).forEach(function(f){if(s.fields[f.key]!==f.value)n++;});
    (it.media||[]).forEach(function(m){if(s.media[m.key].clip!==m.clip)n++;});if(s.note.trim())n++;});
  return {n:n,dur:dur,kept:kept,cut:cut};}
function counts(){var c=changes(),st=$("#vstats");if(st){st.innerHTML="";
    if(APP.D.kind!=="items"){st.appendChild(h("div",{},[h("b",{text:fmt(c.dur)}),h("span",{text:"length"})]));st.appendChild(h("div",{},[h("b",{text:String(c.kept)}),h("span",{text:"lines kept"})]));}
    st.appendChild(h("div",{},[h("b",{text:String(c.n)}),h("span",{text:"changes"})]));}
  var ct=$("#sendCount");if(ct)ct.innerHTML="<b>"+c.n+"</b> change"+(c.n===1?"":"s")+(APP.D.kind!=="items"?" · <b>"+fmt(c.dur)+"</b>":"");
  var m=$("#meter i");if(m){m.style.width=Math.min(100,c.dur/120*100)+"%";m.className=(c.dur>=45&&c.dur<=90)?"good":"";}
  var sb=$("#sendBtn");if(sb)sb.disabled=c.n===0;}

/* ---------------------------------------------------------------- Board: lines */
var LOOKS=["captions","serif","green","split","media"], LOOK_NAME={captions:"Captions",serif:"Serif run",green:"Green card",split:"Split + Step",media:"Media card"};
var CARDS=["","green","cream"];
function pbOut(s){return s.pb.on&&(s.pb.line1||s.pb.label)?{label:s.pb.label,line1:s.pb.line1,line2:s.pb.line2,serif:s.pb.serif}:null;}
function tagOut(s){return s.tag.plate?{tag:s.tag.tag,plate:s.tag.plate}:null;}
function hookOut(s){return s.hook.on&&(s.hook.title||s.hook.sub)?{title:s.hook.title,serif:s.hook.serif,sub:s.hook.sub,clip:s.hook.clip}:null;}
var FRAMES=["","inset","rounded","window","side"], FRAMES_V=["","inset","rounded","letterbox","window","side"], FRAME_NAME={inset:"Frame: inset",rounded:"Frame: rounded",letterbox:"Frame: letterbox",window:"Frame: window",side:"Frame: side"}, PLATES=["cream","white","black","green"];
function tile(icon,label,on,click,title){return h("button",{type:"button",class:"tile","aria-pressed":on?"true":"false",title:title||label,html:ic(icon)+"<span>"+esc(label)+"</span>",onclick:click});}
function renderLines(holder){
  var D=APP.D,S=APP.S,board=h("div",{class:"board"});holder.appendChild(board);
  if(D.copy)holder.insertBefore(h("div",{class:"dw-flags",style:"margin-bottom:10px",text:"This draft is an exact copy of a finished reel. Cards, B-roll and flashes can change here; cut lines in CapCut."}),board);
  function draw(){board.innerHTML="";var focus=null;
    D.takes.forEach(function(k){var s=S.lines[k.n];
      var row=h("div",{class:"ln"+(s.cut?" cut":"")}),tiles=h("div",{class:"tiles"});
      D.caps.forEach(function(c){
        if(c==="note")tiles.appendChild(tile("note","Note",!!(s.note.trim()||s.open),function(){s.open=!s.open;if(s.open)s._f=1;draw();counts();},"Add a note to line "+k.n));
        if(c==="broll")tiles.appendChild(tile("broll","B-roll",false,function(){S.added.push({id:"n"+(S.added.length+1),take:k.n,clip:""});draw();counts();},"Add a B-roll slot to line "+k.n));
        if(c==="zoom")tiles.appendChild(tile(s.zoom==="tight"?"zin":"zout",s.zoom==="tight"?"Punch":"Wide",s.zoom==="tight",function(){s.zoom=s.zoom==="tight"?"wide":"tight";draw();counts();},"Wide or punched in"));
        if(c==="behind")tiles.appendChild(tile("user","Behind",s.behind,function(){s.behind=!s.behind;draw();counts();},"Text behind subject"));
        if(c==="bg")tiles.appendChild(tile("sq",s.bg?"BG "+s.bg:"BG",!!s.bg,function(){s.bg=CARDS[(CARDS.indexOf(s.bg)+1)%3];draw();counts();},"Plain background behind the captions: none, green, cream"));
        if(c==="flash")tiles.appendChild(tile("bolt","Flash",s.flash,function(){s.flash=!s.flash;draw();counts();},"Flash + click at the start of the line"));
        if(c==="card")tiles.appendChild(tile("card",s.card.type?(s.card.type==="green"?"Green card":"Cream card"):"Card",!!s.card.type,function(){s.card.type=CARDS[(CARDS.indexOf(s.card.type)+1)%3];draw();counts();},"A card plate on this line: none, green, cream"));
        if(c==="frame")tiles.appendChild(tile("sq",s.frame.look?FRAME_NAME[s.frame.look]:"Frame",!!s.frame.look,function(){var L=D.canvas==="9:16"?FRAMES_V:FRAMES;s.frame.look=L[(L.indexOf(s.frame.look)+1)%L.length];if(s.frame.look&&!s.frame.plate)s.frame.plate=s.frame.look==="rounded"?"white":"cream";if(!s.frame.look)s.frame.plate="";draw();counts();},"Put this line's footage inside a plain plate: inset, rounded"+(D.canvas==="9:16"?", letterbox":"")));
        if(c==="tag")tiles.appendChild(tile("card",s.tag.plate?"Tag card "+s.tag.plate:"Tag card",!!s.tag.plate,function(){s.tag.plate=CARDS[(CARDS.indexOf(s.tag.plate)+1)%3];draw();counts();},"A full green or cream card with a tag box, the line's words big on it"));
        if(c==="pull"&&k.n===1)tiles.appendChild(tile("zin","Pull-back",s.pb.on,function(){s.pb.on=!s.pb.on;draw();counts();},"The opening cuts in at 1.44x and eases out, a 3-line title riding it"));
        if(c==="split")tiles.appendChild(tile("card","Split",s.sp.on,function(){s.sp.on=!s.sp.on;draw();counts();},"A green band beside you with a Step label, the words big in it"));
        if(c==="bold")tiles.appendChild(tile("user","Bold behind",s.bold,function(){s.bold=!s.bold;draw();counts();},"Huge words behind you, one per beat (the opening)"));
        if(c==="gscreen")tiles.appendChild(tile("broll","Green screen",s.gs.on,function(){s.gs.on=!s.gs.on;draw();counts();},"Another video behind you in a panel, you cut out over it"));
        if(c==="hook")tiles.appendChild(tile("look","Hook",s.hook.on,function(){s.hook.on=!s.hook.on;draw();counts();},"A full-screen title over B-roll, with a flash on both cuts"));
        if(c==="look")tiles.appendChild(tile("look",LOOK_NAME[s.look.look],s.look.look!=="captions",function(){s.look.look=LOOKS[(LOOKS.indexOf(s.look.look)+1)%LOOKS.length];draw();counts();},"What this line looks like: captions, serif run, green card, split screen, media card"));
      });
      var mid=h("div",{class:"mid"}),txt=h("div",{class:"txt"},[h("span",{class:"num",text:String(k.n)}),k.text||"",k.beat?h("span",{class:"beat",text:k.beat}):null]);mid.appendChild(txt);
      if(s.card.type==="green")mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:"Label"}),h("input",{type:"text",value:s.card.label,placeholder:"e.g. Tuesday: Scripting",oninput:function(e){s.card.label=e.target.value;counts();}})]));
      if(s.pb.on&&k.n===1){[["label","Label","the interrogator"],["line1","Line 1","ask better"],["line2","Line 2","questions"],["serif","Serif word","better"]].forEach(function(f){
          mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:f[1]}),h("input",{type:"text",value:s.pb[f[0]],placeholder:f[2],oninput:function(e){s.pb[f[0]]=e.target.value;counts();}})]));});}
      if(s.sp.on)mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:"Pill"}),h("input",{type:"text",value:s.sp.step,placeholder:"Step #1",oninput:function(e){s.sp.step=e.target.value;counts();}})]));
      if(s.gs.on)mid.appendChild(slotEl({label:"Green screen video",clip:s.gs.clip,thumb:s.gs.clip?"/thumb?p="+encodeURIComponent(s.gs.clip)+"&t=1":""},function(clip){s.gs.clip=clip;draw();counts();},null));
      if(s.tag.plate)mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:"Tag"}),h("input",{type:"text",value:s.tag.tag,placeholder:"external source (first word goes serif)",oninput:function(e){s.tag.tag=e.target.value;counts();}})]));
      if(s.hook.on){mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:"Title"}),h("input",{type:"text",value:s.hook.title,placeholder:"Bulk Creation",oninput:function(e){s.hook.title=e.target.value;counts();}}),
          h("input",{type:"text",value:s.hook.serif,placeholder:"serif word",style:"max-width:140px",oninput:function(e){s.hook.serif=e.target.value;counts();}})]));
        mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:"Under it"}),h("input",{type:"text",value:s.hook.sub,placeholder:"How to capture your life cinematically",oninput:function(e){s.hook.sub=e.target.value;counts();}})]));
        mid.appendChild(slotEl({label:"Hook B-roll",clip:s.hook.clip,thumb:s.hook.clip?"/thumb?p="+encodeURIComponent(s.hook.clip)+"&t=1":""},function(clip){s.hook.clip=clip;draw();counts();},null));}
      if(s.frame.look==="side")mid.appendChild(slotEl({label:"Clip in the side window",clip:s.frame.clip,thumb:s.frame.clip?"/thumb?p="+encodeURIComponent(s.frame.clip)+"&t=1":""},function(clip){s.frame.clip=clip;draw();counts();},null));
      if(s.frame.look){var pr=h("div",{class:"extra"},[h("span",{class:"note",text:"Plate"})]);PLATES.forEach(function(pl){pr.appendChild(h("button",{type:"button",class:"as-pill"+(s.frame.plate===pl?" on":""),text:pl,onclick:function(){s.frame.plate=pl;draw();counts();}}));});mid.appendChild(pr);}
      if(s.look.look==="split")mid.appendChild(h("div",{class:"extra"},[h("span",{class:"note",text:"Pill"}),h("input",{type:"text",value:s.look.step,placeholder:"Step #1",oninput:function(e){s.look.step=e.target.value;counts();}})]));
      if(s.look.look==="media")mid.appendChild(slotEl({label:"Picture in the card",clip:s.look.media,thumb:s.look.media?"/thumb?p="+encodeURIComponent(s.look.media)+"&t=1":""},function(clip){s.look.media=clip;draw();counts();},null));
      if(s.open){var ta=h("textarea",{class:"noteta",placeholder:"What should change here (Claude reads these)",oninput:function(e){s.note=e.target.value;counts();}});ta.value=s.note;mid.appendChild(ta);if(s._f){focus=ta;s._f=0;}}
      (D.brolls||[]).concat(S.added).filter(function(b){return b.take===k.n;}).forEach(function(b){var isNew=!S.brolls[b.id],bs=S.brolls[b.id]||b;
        mid.appendChild(slotEl({label:b.id,clip:bs.clip,thumb:bs.thumb,removed:bs.remove,times:b.t0!=null&&!isNew?fmt(b.t0)+" to "+fmt(b.t1):""},
          function(clip,thumb){bs.clip=clip;bs.thumb=thumb;draw();counts();},
          function(){if(isNew)S.added=S.added.filter(function(a){return a!==b;});else bs.remove=!bs.remove;draw();counts();}));});
      (D.cards||[]).filter(function(c){return c.take===k.n;}).forEach(function(c){mid.appendChild(cardEl(c,draw));});
      row.appendChild(tiles);row.appendChild(mid);
      row.appendChild(h("div",{class:"right"},[h("span",{class:"dur",text:k.dur+"s"}),
        h("button",{type:"button",class:"ibtn"+(s.cut?" on":""),title:(s.cut?"Restore":"Cut")+" line "+k.n,"aria-label":(s.cut?"Restore":"Cut")+" line "+k.n,html:ic("trash"),onclick:function(){s.cut=!s.cut;draw();counts();}})]));
      board.appendChild(row);});
    if(focus)focus.focus();}
  draw();holder.appendChild(sendBar());}
function slotEl(o,onpick,onremove){
  var el=h("div",{class:"slot"+(o.removed?" rm":"")});
  var th=h("div",{class:"th"+(o.clip?"":" empty"),title:"Pick a clip, or drop one from Finder"});
  if(o.clip&&o.thumb)th.appendChild(h("img",{src:o.thumb,alt:""}));else th.innerHTML=o.clip?esc(o.clip.split("/").pop()):"Drop your B-roll<br>or pick one";
  th.addEventListener("click",function(){picker(onpick);});
  dropTarget(el,onpick);el.appendChild(th);
  el.appendChild(h("div",{class:"nm"},[h("b",{text:o.clip?o.clip.split("/").pop():(o.label||"Empty slot")}),h("span",{text:o.times||(o.clip?o.clip:"")})]));
  if(o.clip)el.appendChild(h("button",{type:"button",class:"ibtn",title:"Swap this clip","aria-label":"Swap this clip",html:ic("swap"),onclick:function(){picker(onpick);}}));
  if(o.clip)el.appendChild(h("button",{type:"button",class:"ibtn",title:"Show in Finder","aria-label":"Show in Finder",html:ic("finder"),onclick:function(){api("/api/reveal",{path:o.clip});}}));
  if(onremove)el.appendChild(h("button",{type:"button",class:"ibtn"+(o.removed?" on":""),title:o.removed?"Keep":"Remove","aria-label":o.removed?"Keep":"Remove",html:ic("trash"),onclick:onremove}));
  return el;}
function cardEl(c,redraw){var cs=APP.S.cards[c.id],D=APP.D;
  var el=h("div",{class:"cardrow"+(cs.remove?" rm":"")},[h("span",{class:"sw",style:"background:"+(cs.colour==="green"?"#2f5d3a":"#f1e8d6"),title:cs.colour+" card"})]);
  if(cs.edit){el.appendChild(h("input",{type:"text",value:cs.words.join(" "),style:"flex:1;min-width:160px",class:"extra",
    oninput:function(e){cs.words=e.target.value.split(/\s+/).filter(Boolean);cs.accent=cs.accent.filter(function(i){return i<cs.words.length;});counts();},
    onkeydown:function(e){if(e.key==="Enter"){cs.edit=false;redraw();}}}));}
  else{var chips=h("div",{class:"chips"});cs.words.forEach(function(w,i){var on=cs.accent.indexOf(i)>=0;
      chips.appendChild(h("button",{type:"button",class:"wchip"+(on?" on":"")+(on&&D.accent.treatment==="serif-italic"?" serif":""),text:w,title:on?"Accent on: click to clear":"Click to make this an accent word",
        onclick:function(){var j=cs.accent.indexOf(i);if(j>=0)cs.accent.splice(j,1);else cs.accent.push(i);redraw();counts();}}));});el.appendChild(chips);}
  el.appendChild(h("button",{type:"button",class:"ibtn"+(cs.edit?" on":""),title:"Edit the words","aria-label":"Edit the words of card "+c.id,html:ic("pen"),onclick:function(){cs.edit=!cs.edit;redraw();}}));
  el.appendChild(h("button",{type:"button",class:"ibtn",title:"Flip green / cream","aria-label":"Flip card "+c.id+" color",html:ic("pal"),onclick:function(){cs.colour=cs.colour==="green"?"cream":"green";redraw();counts();}}));
  el.appendChild(h("button",{type:"button",class:"ibtn"+(cs.remove?" on":""),title:cs.remove?"Keep":"Remove","aria-label":(cs.remove?"Keep":"Remove")+" card "+c.id,html:ic("trash"),onclick:function(){cs.remove=!cs.remove;redraw();counts();}}));
  return el;}

/* ---------------------------------------------------------------- Board: items (poster, carousel, reel, YapMaxxing) */
function renderItems(holder){var D=APP.D,S=APP.S;
  if(D.help)holder.appendChild(h("p",{class:"note",style:"margin:0 0 10px",text:D.help}));
  var g=h("div",{class:"items"});holder.appendChild(g);
  function draw(){g.innerHTML="";D.items.forEach(function(it){var s=S.items[it.id];
    var card=h("div",{class:"item"},[h("h4",{},[it.title,h("span",{text:it.sub||""})])]);
    (it.fields||[]).forEach(function(f){var inp=f.multi?h("textarea",{oninput:function(e){s.fields[f.key]=e.target.value;counts();}}):h("input",{type:"text",oninput:function(e){s.fields[f.key]=e.target.value;counts();}});
      inp.value=s.fields[f.key]||"";card.appendChild(h("div",{class:"ifield"},[h("label",{text:f.label}),inp]));});
    (it.media||[]).forEach(function(m){var cur=s.media[m.key];card.appendChild(slotEl({label:m.label,clip:cur.clip,thumb:cur.thumb},function(clip,thumb){s.media[m.key]={clip:clip,thumb:thumb};draw();counts();},null));});
    var nb=h("button",{type:"button",class:"sbtn",html:ic("note")+(s.note.trim()?"Note added":"Add a note"),onclick:function(){s.open=!s.open;draw();}});card.appendChild(nb);
    if(s.open){var ta=h("textarea",{class:"noteta",placeholder:"Anything that should change here",oninput:function(e){s.note=e.target.value;counts();}});ta.value=s.note;card.appendChild(ta);}
    g.appendChild(card);});}
  draw();holder.appendChild(sendBar());}

/* ---------------------------------------------------------------- Send */
function sendBar(){return h("div",{class:"sendbar"},[h("div",{class:"ct",id:"sendCount"}),APP.D.kind!=="items"?h("div",{class:"meter",id:"meter",title:"45 to 90 seconds is the target"},[h("i")]):null,
  h("button",{type:"button",class:"sbtn",text:"Reset",onclick:function(){fresh();route();}}),
  h("button",{type:"button",class:"sbtn go",id:"sendBtn",text:"Send and rebuild",onclick:send})]);}
function compile(){var D=APP.D,S=APP.S,J={notes:{}};
  if(D.kind==="items"){J.fields={};J.media={};
    D.items.forEach(function(it){var s=S.items[it.id];(it.fields||[]).forEach(function(f){if(s.fields[f.key]!==f.value){(J.fields[it.id]=J.fields[it.id]||{})[f.key]=s.fields[f.key];}});
      (it.media||[]).forEach(function(m){if(s.media[m.key].clip!==m.clip){(J.media[it.id]=J.media[it.id]||{})[m.key]=s.media[m.key].clip;}});
      if(s.note.trim())J.notes[it.title]=s.note.trim();});return J;}
  J.cut=[];J.zoom={};J.behind=[];J.bg={};J.flash=[];J.card={};J.look={};J.frame={};J.card_tag={};J.hook={};J.bold_behind=[];J.greenscreen={};J.split={};J.pullback={};J.broll={swap:{},remove:[],add:[]};J.cards={};
  D.takes.forEach(function(k){var s=S.lines[k.n];if(s.cut)J.cut.push(k.n);if(s.note.trim())J.notes[k.n]=s.note.trim();
    if(s.zoom!==(k.zoom||"wide"))J.zoom[k.n]=s.zoom;if(s.behind)J.behind.push(k.n);if(s.bg)J.bg[k.n]=s.bg;if(s.flash)J.flash.push(k.n);
    if(s.card.type!==(k.card||"")||s.card.label!==(k.label||""))J.card[k.n]={type:s.card.type,label:s.card.label};
    if(s.frame.look)J.frame[k.n]=s.frame.look==="side"?{look:"side",plate:s.frame.plate,clip:s.frame.clip}:{look:s.frame.look,plate:s.frame.plate};
    if(k.n===1)J.pullback=pbOut(s)||{};
    if(s.sp.on)J.split[k.n]={step:s.sp.step||"Step #1"};
    if(s.bold)J.bold_behind.push(k.n); if(s.gs.on&&s.gs.clip)J.greenscreen[k.n]={clip:s.gs.clip};
    if(tagOut(s))J.card_tag[k.n]=tagOut(s); if(hookOut(s))J.hook[k.n]=hookOut(s);
    if(s.look.look!==(k.look||"captions")||s.look.step!==(k.step||"")||s.look.media!==(k.media||""))J.look[k.n]={look:s.look.look,step:s.look.step,media:s.look.media};});
  (D.brolls||[]).forEach(function(b){var s=S.brolls[b.id];if(s.remove)J.broll.remove.push(b.id);else if(s.clip!==b.clip)J.broll.swap[b.id]=s.clip;});
  S.added.forEach(function(a){if(a.clip)J.broll.add.push({take:a.take,clip:a.clip});});
  (D.cards||[]).forEach(function(c){var s=S.cards[c.id];if(s.remove){J.cards[c.id]={remove:true};return;}
    if(s.words.join(" ")!==c.words.join(" ")||s.colour!==c.colour||s.accent.slice().sort().join()!==c.accent.slice().sort().join())
      J.cards[c.id]={words:s.words,accent:s.accent.slice().sort(function(x,y){return x-y;}),colour:s.colour};});
  if(D.caps.indexOf("behind")<0)delete J.behind; if(D.caps.indexOf("bg")<0)delete J.bg; if(D.caps.indexOf("flash")<0)delete J.flash; if(D.caps.indexOf("frame")<0)delete J.frame; if(D.caps.indexOf("tag")<0)delete J.card_tag; if(D.caps.indexOf("hook")<0)delete J.hook; if(D.caps.indexOf("bold")<0)delete J.bold_behind; if(D.caps.indexOf("gscreen")<0)delete J.greenscreen; if(D.caps.indexOf("split")<0)delete J.split; if(D.caps.indexOf("pull")<0)delete J.pullback;
  return J;}
function send(){var D=APP.D,J=compile();
  showRun("Sending "+changes().n+" change(s) to "+D.draft+"…");
  api("/api/apply",{job:D.job,fmt:D.fmt,edits:J}).then(function(r){if(r.run)poll(r.run,function(ok){if(ok){load().then(route);}});else logLine("Could not start: "+(r.error||"unknown"),"bad");});}
function openDraft(name){showRun("Opening "+name+" in CapCut…");api("/api/open",{draft:name}).then(function(r){if(r.run)poll(r.run);});}

/* ---------------------------------------------------------------- run log */
function showRun(first){var rl=$("#runlog");rl.hidden=false;$("pre",rl).innerHTML="";logLine(first);}
function logLine(t,cls){var pre=$("#runlog pre");var s=h("span",{class:cls||"",text:t+"\n"});pre.appendChild(s);pre.scrollTop=pre.scrollHeight;}
function poll(id,done){var seen=0;(function tick(){api("/api/run?id="+id).then(function(r){
  for(;seen<r.log.length;seen++){var l=r.log[seen];logLine(l,/^STOPPED|failed|FAIL|Error/.test(l)?"bad":(/^Done|opened|CLEAN|clean/.test(l)?"ok":""));}
  if(r.done){if(done)done(r.ok);}else setTimeout(tick,900);});})();}
$("#runlog .runlog-head button").addEventListener("click",function(){$("#runlog").hidden=true;});

/* ---------------------------------------------------------------- clip picker (the B-roll library) */
var pickCb=null,lib=$("#lib"),libFolder="";
function picker(cb){pickCb=cb;lib.classList.add("open");lib.setAttribute("aria-hidden","false");
  if(APP.lib)drawLib();else api("/api/library").then(function(L){APP.lib=L;drawLib();});}
function closePicker(){lib.classList.remove("open");lib.setAttribute("aria-hidden","true");pickCb=null;}
$(".lib-x",lib).addEventListener("click",closePicker);
document.addEventListener("keydown",function(e){if(e.key==="Escape")closePicker();});
$(".lib-search input",lib).addEventListener("input",drawLib);
var io=("IntersectionObserver" in window)?new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){var im=e.target;im.src=im.dataset.src;io.unobserve(im);}});},{root:$(".lib-grid",lib)}):null;
function drawLib(){var L=APP.lib,fol=$(".lib-folders",lib),grid=$(".lib-grid",lib),q=$(".lib-search input",lib).value.toLowerCase().trim();
  fol.innerHTML="";var names=Object.keys(L.folders||{});if(!libFolder&&names.length)libFolder=names[0];
  names.forEach(function(n){fol.appendChild(h("button",{type:"button",class:"as-pill"+(n===libFolder&&!q?" on":""),text:n+" · "+L.folders[n].length,onclick:function(){libFolder=n;$(".lib-search input",lib).value="";drawLib();}}));});
  grid.innerHTML="";var list=q?[].concat.apply([],names.map(function(n){return L.folders[n];})).filter(function(c){return c.toLowerCase().indexOf(q)>=0;}):(L.folders[libFolder]||[]);
  if(!list.length)grid.appendChild(h("p",{class:"note",text:L.root?"Nothing matches.":"No B-roll folder is set up yet."}));
  list.slice(0,240).forEach(function(c){var src="/thumb?p="+encodeURIComponent(c)+"&t=1";var im=h("img",{alt:"","data-src":src});if(io)io.observe(im);else im.src=src;
    var b=h("button",{type:"button",class:"lclip",title:c,onclick:function(){if(pickCb)pickCb(c,src);closePicker();}},[im,h("span",{text:c.split("/").pop()})]);
    var v=null;b.addEventListener("mouseenter",function(){v=h("video",{src:"/file?p="+encodeURIComponent(c),muted:true,autoplay:true,loop:true,playsinline:true});b.replaceChild(v,b.firstChild);});
    b.addEventListener("mouseleave",function(){if(v){b.replaceChild(im,v);if(!im.src)im.src=src;v=null;}});
    grid.appendChild(b);});}
function upload(file,cb){var D=APP.D;
  fetch("/api/upload?job="+encodeURIComponent(D.job)+"&name="+encodeURIComponent(file.name),{method:"POST",body:file}).then(function(r){return r.json();})
    .then(function(r){if(r.clip)cb(r.clip,"/thumb?p="+encodeURIComponent(r.clip)+"&t=1");});}
function dropTarget(el,cb){el.addEventListener("dragover",function(e){e.preventDefault();el.classList.add("drag");});
  el.addEventListener("dragleave",function(){el.classList.remove("drag");});
  el.addEventListener("drop",function(e){e.preventDefault();el.classList.remove("drag");var f=e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files[0];if(f)upload(f,cb);});}
(function(){var d=$(".lib-drop",lib);d.addEventListener("dragover",function(e){e.preventDefault();d.classList.add("drag");});d.addEventListener("dragleave",function(){d.classList.remove("drag");});
  d.addEventListener("drop",function(e){e.preventDefault();d.classList.remove("drag");var f=e.dataTransfer.files[0];if(f&&pickCb){var cb=pickCb;upload(f,function(c,t){cb(c,t);closePicker();});}});})();

/* ---------------------------------------------------------------- nav + routing */
function navJobs(){var nav=$("#jobNav");nav.innerHTML="";APP.state.jobs.forEach(function(j){
  nav.appendChild(h("a",{href:"#v/"+encodeURIComponent(j.job),"data-nav":"v/"+j.job,html:ic("board")+"<span>"+esc(j.job)+"</span>"}));});}
function route(){var hs=decodeURIComponent(location.hash.replace(/^#/,""))||"formats";
  $$(".rail nav a").forEach(function(a){var n=a.getAttribute("data-nav");a.classList.toggle("on",n===hs||(n&&hs.indexOf(n+"/")===0)||(n&&n.indexOf("v/")===0&&hs.split("/").slice(0,2).join("/")===n));});
  if(hs==="brand"&&typeof window.renderBrand==="function")return window.renderBrand(page,APP,h,api);
  if(hs==="effects")return (typeof window.renderEffects==="function")?window.renderEffects(page,APP,h,api):renderEffects();
  if(hs.indexOf("v/")===0){var p=hs.split("/");return renderVideo(p[1],p[2]);}
  if(typeof window.renderFormats==="function")return window.renderFormats(page,APP,h,api);
  renderFormats();}
function load(){return api("/api/state").then(function(st){APP.state=st;navJobs();});}
$$("[data-go]").forEach(function(b){b.addEventListener("click",function(){location.hash=b.getAttribute("data-go");});});
window.addEventListener("hashchange",route);
window.CineYapStudio={APP:APP,h:h,api:api,openDraft:function(n){openDraft(n);},poll:function(id,done){poll(id,done);},showRun:function(t){showRun(t);},reload:function(){return load().then(route);}};
load().then(route).catch(function(e){page.innerHTML="";page.appendChild(h("div",{class:"dw-flags",text:"The Studio server is not answering. Start it with ./vu-py cineyap/studio.py"}));});
})();
