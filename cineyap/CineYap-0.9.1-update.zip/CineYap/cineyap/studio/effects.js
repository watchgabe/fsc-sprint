/* CineYap Studio: the Library pages, Effects and Formats, in the Launch HQ Queue layout (a sticky filter column,
   a grid of cards whose preview plays on hover, a drawer with the details and Add). Owned by the Library session;
   studio.js calls window.renderEffects / window.renderFormats.
   Data: /api/state -> catalog (cineyap/library/catalog.json) and jobs. Previews: /library/previews/<name>.mp4,
   per canvas when exported ("exports": {"9:16": "<name>"}), else the reference clip, else .webp frames. */
(function(){
"use strict";
var FMT_OF={"Vertical":["vertical","vertical34"],"CineYap 16:9":["cineyap","cineyap43"],"Vertical CineYap":["vcineyap","vcineyap34"]};
var FMT_NAME={cineyap:"CineYap",cineyap43:"CineYap 4:3",vertical:"Vertical",vertical34:"Vertical 3:4",vcineyap:"Vertical CineYap",vcineyap34:"Vertical CineYap 3:4",panel:"YapMaxxing",
  poster:"Poster",poster_v:"Poster vertical",carousel:"Video carousel",reel:"Reel template"};
var FMT_AR={vertical:"9:16",vertical34:"3:4",vcineyap:"9:16",vcineyap34:"3:4",panel:"9:16",poster_v:"9:16",reel:"9:16",cineyap:"16:9",cineyap43:"4:3",poster:"4:3",carousel:"4:3"};
var FMT_CAT={vertical:"fmt_vertical",vertical34:"fmt_vertical",vcineyap:"fmt_vcine",vcineyap34:"fmt_vcine",cineyap:"fmt_cineyap",cineyap43:"fmt_cine43",panel:"fmt_panel",poster:"fmt_poster",
  poster_v:"fmt_poster_v",carousel:"fmt_carousel",reel:"fmt_reel"};
var ARS=["9:16","3:4","4:3","16:9"], AR_CSS={"9:16":"9/16","3:4":"3/4","4:3":"4/3","16:9":"16/9"};
var READY=/^(locked|built|auto)$/;
var F={e:{ar:"",cat:"",st:""},f:{ar:"",st:""}};

/* ---------------------------------------------------------------- Add: how each effect lands on each format's Board */
function edits(id,fmt,n,text,cur){
  var c43=fmt==="cineyap"||fmt==="cineyap43", o={};
  if(id==="flash"){
    if(c43)return {add:{flash:[n]}};
    if(/^(vertical|vcineyap)/.test(fmt)){var l=(cur.takes||[]).filter(function(t){return t.flash;}).map(function(t){return t.n;});
      if(l.indexOf(n)<0)l.push(n);return {flash:l.sort(function(a,b){return a-b;})};}}
  if(id==="frame"){var f={};(cur.takes||[]).forEach(function(t){if(t.frame&&t.frame.look)f[t.n]=t.frame;});
    f[n]={look:/^(vertical|vcineyap)/.test(fmt)?(text.look||"inset"):(text.look==="letterbox"?"inset":(text.look||"inset")),plate:text.plate||"cream"};return {frame:f};}
  if(id==="cardtag"){if(c43){var ct={};(cur.takes||[]).forEach(function(t){if(t.card_tag&&t.card_tag.tag)ct[t.n]=t.card_tag;});
      ct[n]={tag:text.tag||"",plate:text.plate||"green"};return {card_tag:ct};}
    if(/^vertical/.test(fmt)){o[n]={type:text.plate||"green",label:text.tag||""};return {card:o};}}
  if(id==="fullhook"){var hk={};(cur.takes||[]).forEach(function(t){if(t.hook&&t.hook.title)hk[t.n]=t.hook;});
    hk[n]={title:text.title||"",serif:text.serif||"",sub:text.sub||"",clip:text.clip||""};return {hook:hk};}
  if(id==="greenscreen"&&(c43||/^vcineyap/.test(fmt))){var g={};(cur.takes||[]).forEach(function(t){if(t.greenscreen&&t.greenscreen.clip)g[t.n]=t.greenscreen;});g[n]={clip:text||""};return {greenscreen:g};}
  if(id==="boldbehind"&&(c43||/^vcineyap/.test(fmt))){var bl=(cur.takes||[]).filter(function(t){return t.bold;}).map(function(t){return t.n;});if(bl.indexOf(n)<0)bl.push(n);return {bold_behind:bl.sort(function(a,b){return a-b;})};}
  if(id==="split"&&c43){var sp={};(cur.takes||[]).forEach(function(t){if(t.split&&t.split.step)sp[t.n]=t.split;});sp[n]={step:text||"Step #1"};return {split:sp};}
  if(id==="hookzoom"&&(c43||/^vcineyap/.test(fmt)))return {pullback:text};
  if(id==="media"&&/^vcineyap/.test(fmt)){o[n]={look:"media",media:text||""};return {look:o};}
  if(id==="sidewindow"){var sw={};(cur.takes||[]).forEach(function(t){if(t.frame&&t.frame.look)sw[t.n]=t.frame;});sw[n]={look:"side",plate:"white",clip:text||""};return {frame:sw};}
  if(id==="typeinterrogator"&&(c43||/^vcineyap/.test(fmt)))return {caption_style:"interrogator"};
  if(id==="punch"&&c43){o[n]="tight";return {zoom:o};}
  if(id==="behind"&&c43)return {add:{behind:[n]}};
  if(id==="bg"&&c43){o[n]="green";return {add:{bg:o}};}
  if(id==="green"&&/^vertical/.test(fmt)){o[n]={type:"green",label:text||""};return {card:o};}
  if(id==="cream"&&/^vertical/.test(fmt)){o[n]={type:"cream"};return {card:o};}
  if(id==="green"&&/^vcineyap/.test(fmt)){o[n]={look:"green"};return {look:o};}
  if(id==="split"&&/^vcineyap/.test(fmt)){o[n]={look:"split",step:text||"Step #1"};return {look:o};}
  return null;}
var NEEDS_FETCH={vertical:1,vertical34:1,vcineyap:1,vcineyap34:1};

function S(){return window.CineYapStudio||{};}
function runlog(first){if(S().showRun)return S().showRun(first);
  var rl=document.getElementById("runlog");if(!rl)return;rl.hidden=false;rl.querySelector("pre").textContent=first+"\n";}
function line(t){var pre=document.querySelector("#runlog pre");if(pre){pre.textContent+=t+"\n";pre.scrollTop=pre.scrollHeight;}}
function follow(api,id,done){if(S().poll)return S().poll(id,done);var seen=0;
  (function tick(){api("/api/run?id="+id).then(function(r){for(;seen<r.log.length;seen++)line(r.log[seen]);
    if(r.done){if(done)done(r.ok);}else setTimeout(tick,900);});})();}
function openDraft(api,name){if(S().openDraft)return S().openDraft(name);
  runlog("Opening "+name+" in CapCut…");api("/api/open",{draft:name}).then(function(r){if(r.run)follow(api,r.run);});}
function copy(t,btn){var ok=function(){var was=btn.textContent;btn.textContent="Copied. Paste it to Claude";setTimeout(function(){btn.textContent=was;},2200);};
  try{navigator.clipboard.writeText(t).then(ok,function(){window.prompt("Copy this and paste it to Claude:",t);});}catch(e){window.prompt("Copy this and paste it to Claude:",t);}}

function targets(APP,e){var fm=[];(e.formats||[]).forEach(function(f){(FMT_OF[f]||[]).forEach(function(x){fm.push(x);});});
  var out=[];(APP.state.jobs||[]).forEach(function(j){(j.formats||[]).forEach(function(x){
    if(fm.indexOf(x.fmt)>=0&&x.board)out.push({job:j.job,fmt:x.fmt});});});return out;}

function addBox(h,api,APP,e){
  var say=e.say||"", tg=targets(APP,e), wrap=h("div",{class:"fx-add"});
  if(e.status==="auto"){wrap.appendChild(h("p",{class:"fx-on",text:"Always on. Nothing to add."}));return wrap;}
  if(!say){wrap.appendChild(h("p",{class:"fx-on",text:e.note||"Not ready yet."}));return wrap;}
  var sel=h("select",{"aria-label":"Video for "+e.name});
  tg.forEach(function(t,i){sel.appendChild(h("option",{value:i,text:t.job+" · "+(FMT_NAME[t.fmt]||t.fmt)}));});
  if(!tg.length)sel.appendChild(h("option",{value:"",text:"No video in this format yet"}));
  var ln=say.indexOf("{line}")>=0?h("input",{type:"number",min:"1",step:"1",placeholder:"Line","aria-label":"Line number"}):null;
  var tx=say.indexOf("{text}")>=0&&e.id!=="frame"?h("input",{type:"text",placeholder:e.hint||(e.id==="green"?"Day label":e.id==="split"?"Step label":"Words"),"aria-label":"Words"}):null;
  var lk=null,pl=null,ex=null;
  if(e.id==="cardtag"){tx=h("input",{type:"text",placeholder:"Tag words, like external source","aria-label":"Tag words"});
    pl=h("select",{"aria-label":"Card color"});["green","cream"].forEach(function(v){pl.appendChild(h("option",{value:v,text:v}));});}
  if(e.id==="hookzoom"){ln=null;tx=null;ex={label:h("input",{type:"text",placeholder:"Label, like Day 111 of 200","aria-label":"Label"}),line1:h("input",{type:"text",placeholder:"Line 1","aria-label":"Line 1"}),
    line2:h("input",{type:"text",placeholder:"Line 2","aria-label":"Line 2"}),serif:h("input",{type:"text",placeholder:"Serif word","aria-label":"Serif word"})};}
  if(e.id==="fullhook"){tx=null;ex={title:h("input",{type:"text",placeholder:"Title (bold)","aria-label":"Hook title"}),serif:h("input",{type:"text",placeholder:"Serif word","aria-label":"Serif word"}),
    sub:h("input",{type:"text",placeholder:"Subtitle","aria-label":"Subtitle"}),clip:h("input",{type:"text",placeholder:"B-roll clip, like Travel/Travel 4k_14.mp4","aria-label":"B-roll clip"})};}
  if(e.id==="frame"){lk=h("select",{"aria-label":"Frame look"});["inset","rounded","window","letterbox"].forEach(function(v){lk.appendChild(h("option",{value:v,text:v==="letterbox"?"letterbox (vertical)":v}));});
    pl=h("select",{"aria-label":"Plate color"});["cream","white","black","green"].forEach(function(v){pl.appendChild(h("option",{value:v,text:v}));});}
  var err=h("p",{class:"fx-err"}), go=h("button",{type:"button",class:"fx-go",text:"Add to video"});
  [ln,tx].forEach(function(i){if(i)i.addEventListener("input",function(){err.textContent="";});});
  go.addEventListener("click",function(){
    var t=tg[+sel.value], n=ln?parseInt(ln.value,10):0, words=tx?tx.value.trim():"";
    if(lk)words={look:lk.value,plate:pl.value};
    if(e.id==="cardtag"){if(!tx.value.trim()){err.textContent="Enter the tag words first.";tx.focus();return;}words={tag:tx.value.trim(),plate:pl.value};}
    if(ex&&e.id==="hookzoom"){words={label:ex.label.value.trim(),line1:ex.line1.value.trim(),line2:ex.line2.value.trim(),serif:ex.serif.value.trim()};n=1;
      if(!words.line1){err.textContent="Enter line 1 first.";ex.line1.focus();return;}}
    else if(ex){words={title:ex.title.value.trim(),serif:ex.serif.value.trim(),sub:ex.sub.value.trim(),clip:ex.clip.value.trim()};
      if(!words.title){err.textContent="Enter the hook title first.";ex.title.focus();return;}}
    if(ln&&!(n>=1)){err.textContent="Enter the line number from that video's Board.";ln.focus();return;}
    if(tx&&!words&&e.id!=="green"&&e.id!=="split"&&e.id!=="cardtag"){err.textContent="Enter the words first.";tx.focus();return;}
    var ask="Library: "+say.replace("{line}",n).replace("{text}",typeof words==="object"?Object.keys(words).map(function(k){return words[k];}).filter(Boolean).join(" · "):words)+(t?" in "+t.job+" ("+(FMT_NAME[t.fmt]||t.fmt)+")":"");
    var fire=function(cur){var E=t&&edits(e.id,t.fmt,n,words,cur||{});
      if(!E){copy(ask,go);err.textContent="No Board button for this yet, so the request is on your clipboard for Claude.";return;}
      runlog("Adding "+e.name+" to line "+n+" of "+t.job+" ("+(FMT_NAME[t.fmt]||t.fmt)+")…");
      api("/api/apply",{job:t.job,fmt:t.fmt,edits:E}).then(function(r){
        if(r.run)follow(api,r.run,function(ok){if(ok&&S().reload)S().reload();});else line("Could not start: "+(r.error||"unknown"));});};
    if(!t){copy(ask,go);return;}
    if((NEEDS_FETCH[t.fmt]||e.id==="frame"||e.id==="cardtag"||e.id==="fullhook"||e.id==="greenscreen"||e.id==="boldbehind"||e.id==="split"||e.id==="sidewindow")&&edits(e.id,t.fmt,n,words,{}))api("/api/board?job="+encodeURIComponent(t.job)+"&fmt="+t.fmt).then(fire);else fire({});});
  wrap.appendChild(h("div",{class:"fx-row"},[sel]));
  if(lk)wrap.appendChild(h("div",{class:"fx-row"},[lk,pl]));
  if(e.id==="cardtag")wrap.appendChild(h("div",{class:"fx-row"},[pl]));
  if(ex&&e.id==="hookzoom"){wrap.appendChild(h("div",{class:"fx-row"},[ex.label]));wrap.appendChild(h("div",{class:"fx-row"},[ex.line1,ex.line2]));wrap.appendChild(h("div",{class:"fx-row"},[ex.serif]));}
  else if(ex){wrap.appendChild(h("div",{class:"fx-row"},[ex.title,ex.serif]));wrap.appendChild(h("div",{class:"fx-row"},[ex.sub]));wrap.appendChild(h("div",{class:"fx-row"},[ex.clip]));}
  wrap.appendChild(h("div",{class:"fx-row"},[ln,tx,go]));wrap.appendChild(err);return wrap;}

/* ---------------------------------------------------------------- previews: still until hovered, then play */
function canvases(e){if(e.canvases)return e.canvases;var o=[];(e.formats||[]).forEach(function(f){
  var m={"Vertical":["9:16","3:4"],"CineYap 16:9":["16:9","4:3"],"Vertical CineYap":["9:16","3:4"]}[f]||(ARS.indexOf(f)>=0?[f]:[]);
  m.forEach(function(a){if(o.indexOf(a)<0)o.push(a);});});return o;}
function srcFor(e,ar){var ex=e.exports||{}, x=ar?ex[ar]:(ex["9:16"]||ex["16:9"]||ex["3:4"]||ex["4:3"]);if(x)return "/library/previews/"+x+".mp4";
  if(e.clip)return "/library/previews/"+e.clip+".mp4";return "";}
function media(h,src,still){var box=h("div",{class:"q-img"});
  if(src){var v=h("video",{src:src+"#t=0.4",muted:true,loop:true,playsinline:true,preload:"metadata"});v.muted=true;box.appendChild(v);
    box.addEventListener("mouseenter",function(){var p=v.play();if(p&&p.catch)p.catch(function(){});});
    box.addEventListener("mouseleave",function(){v.pause();try{v.currentTime=0.4;}catch(x){}});}
  else if(still)box.appendChild(h("img",{src:still,alt:"",loading:"lazy"}));
  else box.appendChild(h("span",{class:"q-none",text:"Preview coming"}));
  return box;}
function stillFor(e){return (e.preview||[]).length?"/library/previews/"+e.preview[0]+".webp":"";}

/* ---------------------------------------------------------------- drawer */
function drawer(h,title,kids){var old=document.getElementById("fxDrawer");if(old)old.remove();
  var close=function(){d.remove();document.removeEventListener("keydown",esc);}, esc=function(ev){if(ev.key==="Escape")close();};
  var d=h("aside",{id:"fxDrawer",class:"fx-dw",role:"dialog","aria-label":title},[
    h("div",{class:"fx-dw-head"},[h("b",{text:title}),h("button",{type:"button",class:"fx-dw-x","aria-label":"Close",text:"✕",onclick:close})]),
    h("div",{class:"fx-dw-body"},kids)]);
  document.body.appendChild(d);document.addEventListener("keydown",esc);return d;}
function pillFor(h,st,key){var s=st[key]||[key,""];return h("span",{class:"pill "+(s[1]||""),text:s[0]});}

/* ---------------------------------------------------------------- filter column (the Queue side column) */
function side(h,secs,redraw){var el=h("aside",{class:"q-side","aria-label":"Filter"});
  secs.forEach(function(s){var fs=h("div",{class:"q-fs"});
    s.items.forEach(function(it){var on=s.get()===it.v;
      fs.appendChild(h("button",{type:"button",class:"q-f"+(on?" on":"")+(it.n?"":" zero"),"aria-pressed":on?"true":"false",
        onclick:function(){s.set(on&&it.v!==""?"":it.v);redraw();}},[h("span",{text:it.l}),h("b",{text:String(it.n)})]));});
    el.appendChild(h("div",{class:"q-sec"},[h("h4",{text:s.title}),fs]));});
  return el;}

/* ---------------------------------------------------------------- Effects */
window.renderEffects=function(page,APP,h,api){
  var cat=APP.state.catalog||{}, eff=cat.effects||[], st=cat.status||{}, f=F.e;
  page.className="wrap wide";page.innerHTML="";
  var sub=h("p",{class:"as-sub q-sub"}), lay=h("div",{class:"q-lay side"}), sideEl, main=h("div",{class:"q-main"});
  page.appendChild(h("div",{class:"q-top"},[h("h1",{class:"pg-title",text:"Effects"})]));page.appendChild(sub);page.appendChild(lay);
  var cats=[];eff.forEach(function(e){if(cats.indexOf(e.cat)<0)cats.push(e.cat);});
  function pass(e,skip){return (skip==="ar"||!f.ar||canvases(e).indexOf(f.ar)>=0)&&(skip==="cat"||!f.cat||e.cat===f.cat)
    &&(skip==="st"||!f.st||(f.st==="ready"?READY.test(e.status):!READY.test(e.status)));}
  function draw(){
    var shown=eff.filter(function(e){return pass(e);}), ready=eff.filter(function(e){return READY.test(e.status);}).length;
    sub.textContent=eff.length+" effects · "+ready+" ready · "+(eff.length-ready)+" in progress"+(shown.length<eff.length?" · showing "+shown.length:"");
    var n=function(k,v){return eff.filter(function(e){var o={};o[k]=v;var save=f[k];f[k]=v;var r=pass(e);f[k]=save;return r;}).length;};
    var ns=side(h,[
      {title:"Aspect",get:function(){return f.ar;},set:function(v){f.ar=v;},items:[{v:"",l:"All",n:n("ar","")}].concat(ARS.map(function(a){return {v:a,l:a,n:n("ar",a)};}))},
      {title:"Type",get:function(){return f.cat;},set:function(v){f.cat=v;},items:[{v:"",l:"All",n:n("cat","")}].concat(cats.map(function(c){return {v:c,l:c,n:n("cat",c)};}))},
      {title:"Status",get:function(){return f.st;},set:function(v){f.st=v;},items:[{v:"",l:"All",n:n("st","")},{v:"ready",l:"Ready",n:n("st","ready")},{v:"wip",l:"In progress",n:n("st","wip")}]}],draw);
    if(sideEl)lay.replaceChild(ns,sideEl);else lay.appendChild(ns);sideEl=ns;
    main.innerHTML="";var grid=h("div",{class:"q-grid"});
    shown.forEach(function(e){var cv=canvases(e), ar=f.ar||cv[0]||"9:16";
      var m=media(h,srcFor(e,f.ar),stillFor(e));if(f.ar)m.style.aspectRatio=AR_CSS[f.ar];
      m.appendChild(h("span",{class:"q-badge",text:(st[e.status]||[e.status])[0]}));
      grid.appendChild(h("div",{class:"q-card",tabindex:"0",role:"button","aria-label":e.name,onclick:function(){open(e);},
        onkeydown:function(ev){if(ev.key==="Enter")open(e);}},[m,h("div",{class:"q-cb"},[h("b",{text:e.name}),
        h("span",{text:e.cat}),h("div",{class:"q-chips"},cv.map(function(a){return h("span",{text:a});}))])]));});
    main.appendChild(shown.length?grid:h("p",{class:"note q-none",text:"Nothing matches these filters."}));
    if(!main.parentNode)lay.appendChild(main);}
  function open(e){var cv=canvases(e), dr=(e.test_draft||[]).filter(function(d){return (APP.state.drafts||[]).indexOf(d)>=0;});
    var big=media(h,srcFor(e,f.ar),stillFor(e));big.classList.add("fx-big");
    var v=big.querySelector("video");if(v){v.autoplay=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}
    drawer(h,e.name,[big,
      h("div",{class:"fx-dw-meta"},[pillFor(h,st,e.status),h("span",{class:"fx-tag",text:e.cat})].concat(cv.map(function(a){return h("span",{class:"fx-tag",text:a});}))),
      h("p",{class:"fx-what",text:e.what||""}),
      h("div",{class:"fx-sec"},[h("span",{class:"fx-eb",text:"When to use"}),h("p",{text:e.when||""})]),
      e.say?h("div",{class:"fx-sec"},[h("span",{class:"fx-eb say",text:"Say"}),h("p",{class:"fx-say",text:e.say.replace("{line}","N").replace("{text}","…")})]):null,
      e.note&&e.say?h("p",{class:"fx-note",text:e.note}):null,
      addBox(h,api,APP,e),
      dr.length?h("div",{class:"fx-drafts"},[h("span",{class:"fx-eb",text:"Test drafts in CapCut"})].concat(dr.map(function(d){return h("button",{type:"button",class:"fx-draft",title:"Open "+d+" in CapCut",text:d,onclick:function(){openDraft(api,d);}});}))):null]);}
  draw();};

/* ---------------------------------------------------------------- Formats */
window.renderFormats=function(page,APP,h,api){
  var cat=APP.state.catalog||{}, st=cat.status||{}, f=F.f, byId={};(cat.formats||[]).forEach(function(x){byId[x.id]=x;});
  var jobs=APP.state.jobs||[];
  var list=Object.keys(FMT_AR).map(function(k){var c=byId[FMT_CAT[k]]||{}, vids=[];
    jobs.forEach(function(j){(j.formats||[]).forEach(function(x){if(x.fmt===k&&(x.draft||x.board))vids.push({job:j.job,fmt:k,draft:x.draft,board:x.board,preview:x.preview});});});
    var pv=vids.filter(function(v){return /\.mp4$/i.test(v.preview||"");})[0];
    return {k:k,name:FMT_NAME[k],ar:FMT_AR[k],status:c.status||(vids.length?"built":"measured"),what:c.what||"",when:c.when||"",
      src:pv?"/file?p="+encodeURIComponent(pv.preview):(c.clip?"/library/previews/"+c.clip+".mp4":""),
      still:(vids.filter(function(v){return /\.jpe?g$|\.png$/i.test(v.preview||"");})[0]||{}).preview?"/file?p="+encodeURIComponent(vids.filter(function(v){return /\.jpe?g$|\.png$/i.test(v.preview||"");})[0].preview):((c.preview||[]).length?"/library/previews/"+c.preview[0]+".webp":""),
      vids:vids};});
  list.sort(function(a,b){return ARS.indexOf(a.ar)-ARS.indexOf(b.ar);});
  page.className="wrap wide";page.innerHTML="";
  var sub=h("p",{class:"as-sub q-sub"}), lay=h("div",{class:"q-lay side"}), sideEl, main=h("div",{class:"q-main"});
  page.appendChild(h("div",{class:"q-top"},[h("h1",{class:"pg-title",text:"Formats"})]));page.appendChild(sub);page.appendChild(lay);
  function pass(x,skip){return (skip==="ar"||!f.ar||x.ar===f.ar)&&(skip==="st"||!f.st||(f.st==="ready"?READY.test(x.status):!READY.test(x.status)));}
  function draw(){var shown=list.filter(function(x){return pass(x);});
    sub.textContent=list.length+" formats · "+list.reduce(function(a,x){return a+x.vids.length;},0)+" videos"+(shown.length<list.length?" · showing "+shown.length:"");
    var n=function(k,v){var save=f[k];f[k]=v;var r=list.filter(function(x){return pass(x);}).length;f[k]=save;return r;};
    var ns=side(h,[
      {title:"Aspect",get:function(){return f.ar;},set:function(v){f.ar=v;},items:[{v:"",l:"All",n:n("ar","")}].concat(ARS.map(function(a){return {v:a,l:a,n:n("ar",a)};}))},
      {title:"Status",get:function(){return f.st;},set:function(v){f.st=v;},items:[{v:"",l:"All",n:n("st","")},{v:"ready",l:"Ready",n:n("st","ready")},{v:"wip",l:"In progress",n:n("st","wip")}]}],draw);
    if(sideEl)lay.replaceChild(ns,sideEl);else lay.appendChild(ns);sideEl=ns;
    main.innerHTML="";var grid=h("div",{class:"q-grid"});
    shown.forEach(function(x){var m=media(h,x.src,x.still);m.style.aspectRatio=x.ar==="9:16"?"9/16":"4/5";
      m.appendChild(h("span",{class:"q-badge",text:x.ar}));
      grid.appendChild(h("div",{class:"q-card",tabindex:"0",role:"button","aria-label":x.name,onclick:function(){open(x);},
        onkeydown:function(ev){if(ev.key==="Enter")open(x);}},[m,h("div",{class:"q-cb"},[h("b",{text:x.name}),
        h("span",{text:(st[x.status]||[x.status])[0]}),h("div",{class:"q-chips"},[h("span",{text:x.vids.length+" video"+(x.vids.length===1?"":"s")})])])]));});
    main.appendChild(shown.length?grid:h("p",{class:"note q-none",text:"Nothing matches these filters."}));
    if(!main.parentNode)lay.appendChild(main);}
  function open(x){var big=media(h,x.src,x.still);big.classList.add("fx-big");big.style.aspectRatio=AR_CSS[x.ar];
    var v=big.querySelector("video");if(v){v.autoplay=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}
    drawer(h,x.name,[big,
      h("div",{class:"fx-dw-meta"},[pillFor(h,st,x.status),h("span",{class:"fx-tag",text:x.ar})]),
      x.what?h("p",{class:"fx-what",text:x.what}):null,
      x.when?h("div",{class:"fx-sec"},[h("span",{class:"fx-eb",text:"When to use"}),h("p",{text:x.when})]):null,
      h("div",{class:"fx-sec"},[h("span",{class:"fx-eb",text:"Videos in this format"})].concat(x.vids.length?x.vids.map(function(vd){
        return h("div",{class:"fx-vrow"},[h("span",{class:"nm",text:vd.job}),
          vd.draft?h("button",{type:"button",class:"fx-draft",text:"CapCut",title:"Open "+vd.draft+" in CapCut",onclick:function(){openDraft(api,vd.draft);}}):null,
          vd.board?h("button",{type:"button",class:"fx-go",text:"Board",onclick:function(){var d=document.getElementById("fxDrawer");if(d)d.remove();location.hash="#v/"+encodeURIComponent(vd.job)+"/"+vd.fmt;}}):null]);})
        :[h("p",{class:"fx-on",text:"No video in this format yet."})]))]);}
  draw();};
})();
