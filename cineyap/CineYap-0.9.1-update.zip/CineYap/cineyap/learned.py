#!/usr/bin/env python3
"""learned.py — the preferences the pipeline carries between videos.

    learned.py list
    learned.py fields
    learned.py add <field> <value> "<what Gabe said>" [--job JOB]
    learned.py forget <n>
    learned.py get <field>

TWO RULES, both learned the hard way by the product this idea came from:

  1. NOTHING COUNTS AS LEARNED UNLESS A BUILD READS IT. Every field below names the file that
     consumes it. A preference with no consumer is a note, not a setting, and writing one would be
     telling Gabe something was learned when no build afterwards behaves differently. `add` refuses
     a field that is not in FIELDS.

  2. SOME THINGS ARE DELIBERATELY NOT LEARNABLE. They are listed in NOT_LEARNABLE with the reason.
     A hook is written against what THIS video is doing. An exact on-screen position is measured on
     THIS footage - a number that sat above his head in one video lands on his forehead in the next.

Store: Video-Studio/learned.json in the brain, so it is backed up and he can read it.
"""
import json, pathlib, sys, datetime

from _root import PKG
STORE = PKG/"learned.json"   # travels with the install, readable, backed up with the folder

#  field            consumer                       validate/clamp
FIELDS = {
 "drop_leading":  ("cineyap/rank_takes.py",        "list of phrases trimmed off the front of a cut"),
 "small_words":   ("cineyap/build_layers.py",      "words per A-roll caption chunk (1-4)"),
 "min_insert_s":  ("cineyap/build_layers.py",      "shortest B-roll insert in seconds (1.0-5.0)"),
 "retired_shots": ("cineyap/build_layers.py",      "clips never to use again, by library path"),
 "target_lufs":   ("delivery level step",          "integrated loudness to match (-20..-8)"),
 "serif_budget":  ("cineyap/build_layers.py",      "max Instrument Serif words per video (0-8)"),
}
NOT_LEARNABLE = {
 "the hook":        "written against what THIS video is doing; a remembered hook is a wrong hook",
 "caption position":"measured on THIS footage every build; a fixed number lands on his face next time",
 "which takes":     "a story decision for THAT video",
 "register":        "teaching vs confessional is asked per video, never assumed",
}

def clamp(field, v):
    if field == "small_words":   return max(1, min(4, int(v)))
    if field == "min_insert_s":  return max(1.0, min(5.0, float(v)))
    if field == "serif_budget":  return max(0, min(8, int(v)))
    if field == "target_lufs":   return max(-20.0, min(-8.0, float(v)))
    if field in ("drop_leading", "retired_shots"):
        return [s.strip() for s in (v if isinstance(v, list) else str(v).split(",")) if s.strip()]
    return v

def load():
    if STORE.exists(): return json.loads(STORE.read_text())
    return {"version": 1, "entries": []}

def save(d):
    STORE.parent.mkdir(parents=True, exist_ok=True)
    STORE.write_text(json.dumps(d, indent=1))

def get(field, default=None):
    """What the builders call."""
    d = load()
    for e in reversed(d["entries"]):
        if e["field"] == field: return e["value"]
    return default

def main(a):
    if not a or a[0] == "fields":
        print("LEARNABLE (field -> what reads it):")
        for k,(c,desc) in FIELDS.items(): print(f"  {k:14s} {c:28s} {desc}")
        print("\nNOT LEARNABLE, on purpose:")
        for k,v in NOT_LEARNABLE.items(): print(f"  {k:18s} {v}")
        return
    cmd = a[0]; d = load()
    if cmd == "list":
        if not d["entries"]: print("nothing learned yet"); return
        for i,e in enumerate(d["entries"],1):
            print(f"{i:2d}. {e['field']:14s} = {e['value']!r}\n    \"{e['said']}\"  ({e['job']}, {e['date']})")
    elif cmd == "add":
        field, value, said = a[1], a[2], (a[3] if len(a)>3 else "")
        if field not in FIELDS:
            print(f"'{field}' is not learnable. Run `learned.py fields`.", file=sys.stderr); sys.exit(2)
        job = a[a.index("--job")+1] if "--job" in a else pathlib.Path.cwd().parent.name
        d["entries"].append({"field": field, "value": clamp(field, value), "said": said,
                             "job": job, "date": str(datetime.date.today())})
        save(d); print(f"learned: {field} = {clamp(field,value)!r}  (read by {FIELDS[field][0]})")
    elif cmd == "forget":
        n = int(a[1]); e = d["entries"].pop(n-1); save(d); print(f"forgot: {e['field']} = {e['value']!r}")
    elif cmd == "get":
        print(json.dumps(get(a[1])))
    else:
        sys.exit(__doc__)

if __name__ == "__main__": main(sys.argv[1:])
