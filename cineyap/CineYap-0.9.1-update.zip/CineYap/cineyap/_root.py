"""Where the package is, found from this file - never from a hardcoded path.

Everything resolves off PKG so the folder can live anywhere and be renamed.
"""
import pathlib, sys
PKG      = pathlib.Path(__file__).resolve().parent.parent   # the CineYap folder
CINEYAP  = PKG / "cineyap"
HELPERS  = PKG / "helpers"
PROJECTS = PKG / "projects"                                  # jobs live inside the package
PY       = PKG / ".venv/bin/python"
for p in (str(CINEYAP), str(HELPERS)):
    if p not in sys.path:
        sys.path.insert(0, p)
