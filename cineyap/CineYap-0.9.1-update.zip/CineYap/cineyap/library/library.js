(function(){
var cards=[].slice.call(document.querySelectorAll("[data-card]"));
[].forEach.call(document.querySelectorAll("[data-chip]"),function(c){c.addEventListener("click",function(){
 [].forEach.call(document.querySelectorAll("[data-chip]"),function(o){o.setAttribute("aria-pressed",o===c?"true":"false");o.style.background=o===c?"var(--text-primary)":"";o.style.color=o===c?"var(--surface-2)":"";});
 var k=c.getAttribute("data-chip");cards.forEach(function(el){el.hidden=!(k==="All"||el.getAttribute("data-cat")===k);});});});
var first=document.querySelector('[data-chip="All"]');if(first)first.click();
var still=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;
if(!still)[].forEach.call(document.querySelectorAll("[data-flip]"),function(f){var im=f.querySelectorAll("img");if(im.length<2)return;var i=0;
 setInterval(function(){im[i].style.opacity=0;i=(i+1)%im.length;im[i].style.opacity=1;},700);});
function block(board,line,text){var b={};
 if(board==="flash")b={add:{flash:[line]}};else if(board==="behind")b={add:{behind:[line]}};
 else if(board==="bg")b={add:{bg:{}}},b.add.bg[line]="green";else if(board==="zoom")b={zoom:{}},b.zoom[line]="tight";else return "";
 return "\n```board\n"+JSON.stringify(b)+"\n```";}
cards.forEach(function(el){var add=el.querySelector("[data-add]");
 if(add)add.addEventListener("click",function(){var say=el.getAttribute("data-say"),err=el.querySelector("[data-err]"),L=el.querySelector("[data-line]"),T=el.querySelector("[data-text]");
  var line=L?parseInt(L.value,10):0,text=T?T.value.trim():"";
  if(L&&!(line>=1)){err.textContent="Enter the line number from the Board first.";L.focus();return;}
  if(T&&!text){err.textContent="Enter the words first.";T.focus();return;}
  err&&(err.textContent="");
  var msg="Library: "+say.replace("{line}",line).replace("{text}",text);
  if(L)msg+=block(el.getAttribute("data-board"),line,text);
  sendPrompt(msg);});
 [].forEach.call(el.querySelectorAll("input"),function(i){i.addEventListener("input",function(){var e=el.querySelector("[data-err]");if(e)e.textContent="";});});
 [].forEach.call(el.querySelectorAll("[data-draft]"),function(b){b.addEventListener("click",function(){sendPrompt('Library: open the CapCut test draft "'+b.getAttribute("data-draft")+'" so I can see '+el.getAttribute("data-name"));});});});
})();
