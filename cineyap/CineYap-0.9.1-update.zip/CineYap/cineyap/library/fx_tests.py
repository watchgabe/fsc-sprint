#!/usr/bin/env python3
"""fx_tests.py — prove every effect on every canvas with a real CapCut export, and cut the Library's previews from it.

    CINEYAP_OWNER=effects-studio ./vu-py cineyap/library/fx_tests.py [test ...]     # all tests, or the named ones
    ./vu-py cineyap/library/fx_tests.py --cut-only [test ...]                        # re-cut previews from existing exports

Each test is one job and format with the effects placed on known lines. It applies the edits (rebuilding the
draft), exports the draft through export_draft.py (which holds _local/capcut.lock and only clicks when CapCut
is in front), then cuts one short loop per effect from the export into cineyap/library/previews/<effect>_<W>x<H>.mp4
and records it in catalog.json under the effect's "exports" by aspect ratio. A preview is never cut from
anything but a CapCut export.

The test jobs are clones (cp -c) of real jobs: fx-cineyap (from ladder-test) and fx-vertical (from showin-up-copy).
"""
import json, os, pathlib, subprocess, sys
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from _root import PROJECTS
import boards, open_draft, export_draft

OWNER = os.environ.setdefault("CINEYAP_OWNER", "effects-studio")
CAT = HERE/"catalog.json"; PREV = HERE/"previews"

CINE = {"card_tag": {"12": {"tag": "external source", "plate": "green"}},
        "hook": {"1": {"title": "Beat", "serif": "imposter", "sub": "Day 111 of 200", "clip": "Travel/Travel 4k_14.mp4"}},
        "behind": [3], "flash": [8, 13, 15], "bg": {"7": "green"}, "zoom": {},
        "frame": {"4": {"look": "inset", "plate": "cream"}, "5": {"look": "rounded", "plate": "white"},
                  "10": {"look": "rounded", "plate": "black"}, "16": {"look": "inset", "plate": "green"}}}
CINE_CLIPS = [  # (effect, line, how): "start" = 2.6 s from the line's start, "cut" = 1.2 s either side of the line's start
    # lines 2, 6, 9, 11 and 15 carry B-roll, so A-roll effects sit on the others
    ("cardtag", 12, ("line", -0.3, 1.9)), ("fullhook", 1, ("line", 0, 3.0)), ("leftcap", 14, "start"), ("behind", 3, "start"), ("punch", 14, "cut"), ("eyelock", 14, "cut"),
    ("frame", 5, "cut"), ("frame_inset_cream", 4, "cut"), ("frame_rounded_white", 5, "cut"),
    ("frame_rounded_black", 10, "cut"), ("frame_inset_green", 16, "cut"),
    ("bg", 7, "cut"), ("flash", 8, "flash"), ("broll", 6, "start")]
VERT = {"frame": {}, "hook": {"20": {"title": "Batch", "serif": "everything", "sub": "One day, a week of content", "clip": "Travel/Travel 4k_14.mp4"}}}
VERT_CLIPS = [("flash", 5, "flash"), ("punch", 13, "cut"), ("riding", 1, "open"), ("words", 3, "start"),
              ("stack", 2, "start"), ("cream", 2, ("t", 4.0, 5.3)), ("green", 4, "start"), ("broll", 6, "start"), ("cta", 21, "end"), ("cardtag", 4, "start"), ("fullhook", 20, ("line", 0, 3.0))]
VFRAME = {"frame": {"20": {"look": "window", "plate": "green"}, "21": {"look": "side", "plate": "white", "clip": "Travel/Travel 4k_14.mp4"},
                    "3": {"look": "inset", "plate": "cream"}, "8": {"look": "rounded", "plate": "white"},
                    "12": {"look": "letterbox", "plate": "cream"}, "13": {"look": "rounded", "plate": "black"},
                    "18": {"look": "inset", "plate": "green"}}}
VFRAME_CLIPS = [("frame", 8, "cut"), ("frame_inset_cream", 3, "start"), ("frame_rounded_white", 8, "cut"),
                ("frame_letterbox_cream", 12, "cut"), ("frame_rounded_black", 13, "cut"), ("frame_inset_green", 18, "cut"),
                ("frame_window_green", 20, "cut"), ("sidewindow", 21, "start")]

CINE2 = {"greenscreen": {"4": {"clip": "Travel/Travel 4k_14.mp4"}}, "bold_behind": [1]}
CINE2_CLIPS = [("boldbehind", 1, ("line", 0, 3.2)), ("greenscreen", 4, ("line", -0.3, 2.6))]

CINE3 = {"split": {"3": {"step": "Step #1"}},
         "pullback": {"label": "Day 111 of 200", "line1": "Beat imposter", "line2": "syndrome", "serif": "syndrome"}}
CINE3_CLIPS = [("hookzoom", 1, ("line", 0, 3.4)), ("split", 3, "start")]
VCINE = {"greenscreen": {"2": {"clip": "Travel/Travel 4k_14.mp4"}}, "bold_behind": [1], "caption_style": "interrogator"}
VCINE_CLIPS = [("boldbehind", 1, ("line", 0, 1.5)), ("greenscreen", 2, "start"), ("split", 4, "start"), ("media", 5, "start"), ("typeinterrogator", 6, "start")]

CINE4 = {"caption_style": "interrogator",
         "frame": {"4": {"look": "window", "plate": "cream"}, "5": {"look": "window", "plate": "green"},
                   "10": {"look": "side", "plate": "white", "clip": "Travel/Travel 4k_14.mp4"}}}
CINE4_CLIPS = [("typeinterrogator", 1, "start"), ("frame_window_cream", 4, "cut"), ("frame_window_green", 5, "cut"),
               ("sidewindow", 10, "start")]

TESTS = {
    "cine169": ("fx-cineyap", "cineyap", CINE, CINE_CLIPS),
    "cine43":  ("fx-cineyap", "cineyap43", CINE, CINE_CLIPS),
    "vert916": ("fx-vertical", "vertical", VERT, VERT_CLIPS),
    "vert34":  ("fx-vertical", "vertical34", VERT, VERT_CLIPS),
    "c2_169":  ("fx-cine2", "cineyap", CINE2, CINE2_CLIPS),
    "c2_43":   ("fx-cine2", "cineyap43", CINE2, CINE2_CLIPS),
    "c3_169":  ("fx-cine3", "cineyap", CINE3, CINE3_CLIPS),
    "c3_43":   ("fx-cine3", "cineyap43", CINE3, CINE3_CLIPS),
    "vc916":   ("fx-vcine", "vcineyap", VCINE, VCINE_CLIPS),
    "vc34":    ("fx-vcine", "vcineyap34", VCINE, VCINE_CLIPS),
    "c4_169":  ("fx-cine4", "cineyap", CINE4, CINE4_CLIPS),
    "c4_43":   ("fx-cine4", "cineyap43", CINE4, CINE4_CLIPS),
    "vframe916": ("fx-vframe", "vertical", VFRAME, VFRAME_CLIPS),
    "vframe34":  ("fx-vframe", "vertical34", VFRAME, VFRAME_CLIPS),
}

def probe(f):
    o = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", str(f)],
                       capture_output=True, text=True).stdout.strip().split(",")
    return int(o[0]), int(o[1])

def ar_of(w, h):
    r = w / h
    return min({"9:16": 9/16, "3:4": 3/4, "4:3": 4/3, "16:9": 16/9}.items(), key=lambda kv: abs(kv[1] - r))[0]

def window(t, how):
    a, b = t["t0"], t["t1"]
    if isinstance(how, (tuple, list)):
        if how[0] == "line": return max(0, a + how[1]), min(b + 0.6, a + how[2])   # ("line", from, to): relative to the line start
        return how[1], how[2]                                                       # ("t", start, end): exact seconds
    if how == "cut": return max(0, a - 1.2), a + 1.2
    if how == "flash": return max(0, a - 0.6), a + 0.9
    if how == "open": return 0, min(b + 0.5, 3.0)
    if how == "end": return max(a, b - 2.5), b
    return a, min(b, a + 2.6)

def cut(export, model, clips):
    W, H = probe(export); ar = ar_of(W, H); takes = {t["n"]: t for t in model["takes"]}
    cat = json.loads(CAT.read_text()); E = {e["id"]: e for e in cat["effects"]}; made = []
    for eff, n, how in clips:
        if n not in takes: print(f"  skip {eff}: no line {n}"); continue
        a, b = window(takes[n], how); name = f"{eff}_{W}x{H}"; out = PREV/f"{name}.mp4"
        scale = "scale=-2:540" if H > W else "scale=540:-2"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{a:.3f}", "-t", f"{b - a:.3f}", "-i", str(export), "-an", "-vf", f"{scale},fps=24",
                        "-c:v", "libx264", "-crf", "26", "-preset", "slow", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)], check=True)
        base = eff.split("_")[0] if eff.startswith("frame_") else eff
        if base in E:
            ex = E[base].setdefault("exports", {})
            if eff == base or ar not in ex: ex[ar] = name
            if eff != base: E[base].setdefault("looks_exports", {}).setdefault(ar, {})[eff[len(base) + 1:]] = name
        made.append(name)
    CAT.write_text(json.dumps(cat, indent=1, ensure_ascii=False) + "\n")
    print(f"  {len(made)} previews at {W}x{H} ({ar}): {', '.join(made)}")

def run(key, cut_only=False):
    job, fmt, edits, clips = TESTS[key]
    model = boards.model(job, fmt); draft = model["draft"]
    exp = pathlib.Path.home()/"Movies/CapCut"/draft/f"{draft}.mov"
    if not cut_only:
        if not open_draft.take_lock(OWNER): sys.exit("CapCut is locked by another session")
        try:
            log = []; print(f"{key}: applying to {draft}"); boards.apply(job, fmt, json.loads(json.dumps(edits)), log)
            print("\n".join("  " + l for l in log[-6:]))
        finally: open_draft.release_lock(OWNER)
        path, err = export_draft.export(draft)
        if not path: sys.exit(f"{key}: export failed: {err}")
        exp = pathlib.Path(path)
        model = boards.model(job, fmt)
    if not exp.exists(): sys.exit(f"{key}: no export at {exp}")
    cut(exp, model, clips)

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    for k in (args or list(TESTS)): run(k, "--cut-only" in sys.argv)
