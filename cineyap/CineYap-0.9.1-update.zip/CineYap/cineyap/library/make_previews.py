#!/usr/bin/env python3
"""make_previews.py — cut the Library's motion previews from real CapCut exports.

    ./vu-py cineyap/library/make_previews.py            # every clip below whose export exists
    ./vu-py cineyap/library/make_previews.py flash      # just one

Writes cineyap/library/previews/<id>.mp4: a short silent loop, 540px tall for vertical and 540px wide
for 16:9, small enough to autoplay on the Studio's Effects tab. Each clip is cut from an export CapCut
made, never from a mock-up, so a preview shows exactly what the effect builds. Add a row when a new
export shows an effect better; the catalog's "clip" field names the file.
"""
import pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from _root import PKG, PROJECTS

OUT = PKG/"cineyap/library/previews"
SHOWIN = PROJECTS/"showin-up-copy/check/export7.mov"     # Gabe's Showin' Up, rebuilt and matched by measurement

#      id            source   start   seconds   what the loop shows
CLIPS = {
    "flash":      (SHOWIN,  9.70,  1.20),   # green card, the flash hits, back to camera
    "punch":      (SHOWIN, 32.60,  1.60),   # wide, cut to tight, eyes on the same line
    "eyelock":    (SHOWIN, 37.10,  1.40),   # a jump cut with the eyes held
    "riding":     (SHOWIN,  0.00,  2.90),   # the opening zoom with the title riding it
    "words":      (SHOWIN,  5.90,  1.80),   # word-by-word captions
    "stack":      (SHOWIN,  3.00,  1.20),   # Batch / Record landing
    "green":      (SHOWIN,  8.20,  1.60),   # green card with the day label
    "cream":      (SHOWIN,  4.10,  1.00),   # cream card
    "broll":      (SHOWIN, 12.60,  1.60),   # B-roll held still, caption mid-frame
    "cta":        (SHOWIN, 72.20,  2.00),   # the CTA word held
    "fmt_vertical": (SHOWIN, 0.00, 4.00),   # the format at a glance
}

def cut(key):
    src, t0, d = CLIPS[key]
    if not pathlib.Path(src).exists(): print(f"  skip {key}: no {src}"); return
    w = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                        "-of", "csv=p=0", str(src)], capture_output=True, text=True).stdout.strip().split(",")
    scale = "scale=-2:540" if int(w[1]) > int(w[0]) else "scale=540:-2"
    out = OUT/f"{key}.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t0}", "-t", f"{d}", "-i", str(src), "-an", "-vf", f"{scale},fps=24",
                    "-c:v", "libx264", "-crf", "26", "-preset", "slow", "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out)],
                   check=True)
    print(f"  {key:13} {out.stat().st_size // 1024:4d} KB  {d:.1f}s")

OUT.mkdir(parents=True, exist_ok=True)
for k in (sys.argv[1:] or CLIPS):
    cut(k)
