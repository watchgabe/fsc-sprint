#!/usr/bin/env python3
"""analyze_reel.py — take a reference reel apart into a template: where it cuts, and what text sits where.

    ./vu-py cineyap/analyze_reel.py <video.mp4 | URL> <job> [--threshold 0.30]

For the format where a reel is N different clips with text over them. Drop in one you like (a file,
or a link, which is downloaded with yt-dlp), and this writes projects/<job>/template/:

  template.json     canvas, duration, and one SLOT per shot: start, length, and every line of on-screen
                    text with its box (fractions of the frame), its height, and its alignment
  CUTS.png          contact sheet: each shot's middle frame, its time, and the text read off it
  COPY.txt          one ## SLOT block per shot, prefilled with the text it read. Rewrite it in your words.
  backgrounds.json  one entry per slot, clip empty. Pick from your library (or ask Claude to).

Then cineyap/mkreel.py <job> builds it in your style: same cut rhythm, same text placement, your clips,
your fonts, as a CapCut draft with editable text.

Everything runs on this Mac: ffmpeg's scene detection for the cuts, Apple's Vision framework for the
text. Nothing is uploaded anywhere.
"""
import json, pathlib, re, shutil, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS

args = [a for a in sys.argv[1:] if not a.startswith("--")]
if len(args) < 2: sys.exit("usage: analyze_reel.py <video.mp4 | URL> <job> [--threshold 0.30]")
src, job = args[0], args[1]
TH = float(sys.argv[sys.argv.index("--threshold")+1]) if "--threshold" in sys.argv else 0.30
OUT = PROJECTS/job/"template"; OUT.mkdir(parents=True, exist_ok=True)
FR = OUT/"frames"; FR.mkdir(exist_ok=True)

# ---- the video: a file, or a link pulled with yt-dlp
if re.match(r"https?://", src):
    if not shutil.which("yt-dlp"): sys.exit("A link needs yt-dlp (brew install yt-dlp), or download the reel and pass the file.")
    dl = OUT/"reference.mp4"
    subprocess.run(["yt-dlp", "-q", "-f", "mp4/bestvideo+bestaudio", "--merge-output-format", "mp4", "-o", str(dl), src], check=True)
    src = dl
src = pathlib.Path(src).expanduser().resolve()
if not src.exists(): sys.exit(f"not found: {src}")
if src.parent != OUT: shutil.copy2(src, OUT/"reference.mp4")

def probe(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
        "stream=width,height,r_frame_rate:format=duration","-of","json",str(p)], capture_output=True, text=True).stdout)
    s = d["streams"][0]; a, b = s["r_frame_rate"].split("/")
    return int(s["width"]), int(s["height"]), float(a)/float(b), float(d["format"]["duration"])
W, H, FPS, DUR = probe(src)

# ---- cuts: ffmpeg scene score above the threshold. A cut closer than 0.25s to the previous one is a
# flash or a transition's second half, not a new shot.
log = subprocess.run(["ffmpeg","-hide_banner","-i",str(src),"-vf",f"select='gt(scene,{TH})',metadata=print",
                      "-an","-f","null","-"], capture_output=True, text=True).stderr
cuts = []
for m in re.finditer(r"pts_time:([0-9.]+)", log):
    t = float(m.group(1))
    if t > 0.1 and t < DUR - 0.1 and (not cuts or t - cuts[-1] > 0.25): cuts.append(round(t, 3))
bounds = [0.0] + cuts + [round(DUR, 3)]

# ---- text: Apple Vision OCR on frames inside each shot
import Vision, Quartz
from Foundation import NSURL
def ocr(path):
    img = Quartz.CGImageSourceCreateImageAtIndex(Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(path)), None), 0, None)
    req = Vision.VNRecognizeTextRequest.alloc().init()
    req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate); req.setUsesLanguageCorrection_(True)
    Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None).performRequests_error_([req], None)
    out = []
    for o in req.results() or []:
        c = o.topCandidates_(1)[0]; bb = o.boundingBox()
        x, y, w, h = bb.origin.x, bb.origin.y, bb.size.width, bb.size.height
        if c.confidence() < 0.5 or len(str(c.string()).strip()) < 3: continue   # lamps and logos read as 2-letter junk
        out.append({"text": str(c.string()), "x": round(x, 4), "y": round(1 - y - h, 4), "w": round(w, 4), "h": round(h, 4)})
    return sorted(out, key=lambda r: (round(r["y"], 2), r["x"]))

def main_block(lines):
    """Captions sit together; a shirt print or a sign sits apart. Keep the largest run of lines whose
    vertical gaps are under 1.5 line-heights and drop the rest."""
    if len(lines) < 2: return lines
    ls = sorted(lines, key=lambda r: r["y"]); runs, cur = [], [ls[0]]
    for a, b in zip(ls, ls[1:]):
        gap = b["y"] - (a["y"] + a["h"])
        if gap < 1.5 * max(a["h"], b["h"]): cur.append(b)
        else: runs.append(cur); cur = [b]
    runs.append(cur)
    return max(runs, key=lambda r: (len(r), sum(x["h"] * x["w"] for x in r)))

def grab(t, path):
    subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{t:.3f}","-i",str(src),"-frames:v","1",str(path)], check=True)

def align(lines):
    if not lines: return None
    lefts = [l["x"] for l in lines]; centres = [l["x"] + l["w"]/2 for l in lines]
    # centred first: centred lines of similar width also share a left edge, and read as "left" otherwise
    if all(abs(c - 0.5) < 0.04 for c in centres): return "center"
    if len(lines) > 1 and max(lefts) - min(lefts) < 0.02: return "left"
    return "left" if min(lefts) < 0.35 else "center"

slots = []
for n, (a, b) in enumerate(zip(bounds, bounds[1:]), 1):
    d = b - a
    picks = [a + d*0.5] if d < 0.8 else [a + d*0.2, a + d*0.5, a + d*0.85]
    reads = []
    for k, t in enumerate(picks):
        f = FR/f"slot_{n:02d}_{k}.png"; grab(t, f); reads.append(main_block(ocr(f)))
    mid = reads[len(reads)//2]
    texts = [" ".join(r["text"] for r in rd) for rd in reads]
    # OCR jitters over a moving background ("Type 1" / "Typel"), so compare reads by similarity, not
    # equality. Text that genuinely changes inside a shot (word-by-word reveals) differs a lot more.
    from difflib import SequenceMatcher
    nz = [t for t in texts if t]
    changes = any(SequenceMatcher(None, x, y).ratio() < 0.75 for i, x in enumerate(nz) for y in nz[i+1:]) \
              or (0 < len(nz) < len(texts))
    slots.append({"n": n, "t0": round(a, 3), "t1": round(b, 3), "dur": round(d, 3),
                  "frame": str((FR/f"slot_{n:02d}_{len(reads)//2}.png").relative_to(OUT)),
                  "align": align(mid),
                  "lines": [{"text": r["text"], "box": [r["x"], r["y"], r["w"], r["h"]], "size_frac": r["h"]} for r in mid],
                  "text_changes_in_shot": changes,
                  "reads": texts if changes else None})

# A caption usually outlives the shot it starts on. Group consecutive shots whose text reads alike
# (OCR jitter allowed) into one BEAT; its text is the read that agrees best with the others.
from difflib import SequenceMatcher as _SM
def joined(sl): return " ".join(l["text"] for l in sl["lines"])
beats = []
for sl in slots:
    j = joined(sl)
    if beats and ((not j and not beats[-1]["text"]) or (j and beats[-1]["text"] and _SM(None, j, beats[-1]["text"]).ratio() > 0.8)):
        beats[-1]["slots"].append(sl["n"]); beats[-1]["t1"] = sl["t1"]; beats[-1]["_members"].append(sl)
    else:
        beats.append({"n": len(beats)+1, "slots": [sl["n"]], "t0": sl["t0"], "t1": sl["t1"], "text": j, "_members": [sl]})
for b in beats:
    ms = b.pop("_members")
    best = max(ms, key=lambda m: sum(_SM(None, joined(m), joined(o)).ratio() for o in ms))
    b.update({"lines": best["lines"], "align": best["align"], "text": joined(best)})
tpl = {"source": src.name, "canvas": [W, H], "fps": round(FPS, 3), "duration": round(DUR, 3),
       "threshold": TH, "cuts": cuts, "slots": slots, "beats": beats}
(OUT/"template.json").write_text(json.dumps(tpl, indent=1, ensure_ascii=False))

# ---- COPY.txt: prefilled with what it read, one block per slot
cp = ["# Reel copy. One ## SLOT per shot, prefilled with the text read off the reference.",
      "# Rewrite each in your words. TEXT lines keep the reference's line breaks and placement.",
      "# `backticks` = accent word. An empty SLOT is a clip with no text.", ""]
cp[0] = "# Reel copy. One ## BEAT per caption (a beat can span several shots), prefilled with the text read off the reference."
for b in beats:
    sl = f"shot {b['slots'][0]}" if len(b["slots"]) == 1 else f"shots {b['slots'][0]}-{b['slots'][-1]}"
    cp.append(f"## BEAT {b['n']}   ({sl}, {b['t0']:.2f}-{b['t1']:.2f}s, {b['align'] or 'no text'})")
    for l in b["lines"]: cp.append(f"TEXT: {l['text']}")
    cp.append("")
if not (OUT/"COPY.txt").exists(): (OUT/"COPY.txt").write_text("\n".join(cp))
if not (OUT/"backgrounds.json").exists():
    (OUT/"backgrounds.json").write_text(json.dumps([{"n": s["n"], "clip": "", "at": 0.5, "why": ""} for s in slots], indent=1))

# ---- contact sheet
from PIL import Image, ImageDraw, ImageFont
cols = 4 if len(slots) > 6 else 3; tw = 360; th = int(tw * H / W); pad = 70
rows = -(-len(slots) // cols)
sheet = Image.new("RGB", (cols*tw, rows*(th+pad)), (18, 18, 18)); dr = ImageDraw.Draw(sheet)
try: f1 = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 18, index=1); f2 = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 14)
except Exception: f1 = f2 = ImageFont.load_default()
for i, s in enumerate(slots):
    x, y = (i % cols)*tw, (i // cols)*(th+pad)
    im = Image.open(OUT/s["frame"]).convert("RGB").resize((tw, th)); sheet.paste(im, (x, y))
    d2 = ImageDraw.Draw(sheet)
    for l in s["lines"]:
        bx, by, bw, bh = l["box"]; d2.rectangle([x+bx*tw, y+by*th, x+(bx+bw)*tw, y+(by+bh)*th], outline=(232, 89, 12), width=2)
    dr.text((x+8, y+th+6), f"{s['n']}  {s['t0']:.2f}-{s['t1']:.2f}s  ({s['dur']:.2f}s)", font=f1, fill=(255, 255, 255))
    t = " / ".join(l["text"] for l in s["lines"]) or "(no text)"
    dr.text((x+8, y+th+32), (t[:52] + "…") if len(t) > 52 else t, font=f2, fill=(190, 190, 190))
sheet.save(OUT/"CUTS.png")

print(f"{src.name}: {W}x{H} @ {FPS:.2f}fps, {DUR:.2f}s")
print(f"  {len(cuts)} cut(s) -> {len(slots)} slot(s); median shot {sorted(s['dur'] for s in slots)[len(slots)//2]:.2f}s")
print(f"  {len(beats)} caption beat(s) across {len(slots)} shots")
print(f"  text read on {sum(bool(s['lines']) for s in slots)} of {len(slots)} slots; "
      f"text changes inside {sum(s['text_changes_in_shot'] for s in slots)} shot(s)")
print(f"  {OUT}/template.json · CUTS.png · COPY.txt · backgrounds.json")
