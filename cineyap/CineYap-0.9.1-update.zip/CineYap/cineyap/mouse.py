#!/usr/bin/env python3
"""mouse.py — real mouse events, because System Events' synthesized click bounces off CapCut.
    mouse.py click X Y [n]   n clicks at X,Y (2 = double-click)
    mouse.py key NAME [n]    press a key n times (left/right = one frame in CapCut)
"""
import sys, time
import Quartz as Q
def click(x, y, n=1):
    for i in range(n):
        for kind, ev in ((Q.kCGEventLeftMouseDown, Q.kCGEventLeftMouseDown), (Q.kCGEventLeftMouseUp, Q.kCGEventLeftMouseUp)):
            e = Q.CGEventCreateMouseEvent(None, ev, (x, y), Q.kCGMouseButtonLeft)
            Q.CGEventSetIntegerValueField(e, Q.kCGMouseEventClickState, i + 1)
            Q.CGEventPost(Q.kCGHIDEventTap, e)
            time.sleep(0.03)
        time.sleep(0.12)
KEYS = {"left": 123, "right": 124, "up": 126, "down": 125, "space": 49, "home": 115, "escape": 53}
def key(name, n=1):
    for _ in range(n):
        for down in (True, False):
            Q.CGEventPost(Q.kCGHIDEventTap, Q.CGEventCreateKeyboardEvent(None, KEYS[name], down)); time.sleep(0.02)
        time.sleep(0.05)
if __name__ == "__main__":
    if sys.argv[1] == "key":
        key(sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else 1); sys.exit()
    _, cmd, x, y, *rest = sys.argv
    Q.CGEventPost(Q.kCGHIDEventTap, Q.CGEventCreateMouseEvent(None, Q.kCGEventMouseMoved, (float(x), float(y)), 0))
    time.sleep(0.1)
    click(float(x), float(y), int(rest[0]) if rest else 1)
