#!/usr/bin/env python3
"""broll_sort.py — turn a pile of B-roll exports into a sorted, named, one-shot-per-file library.

Three steps. Claude does the looking in the middle one; the script does everything mechanical.

    broll_sort.py split  <export file or folder> <library folder>   chop every shot into its own file
    broll_sort.py sheets <library folder>                            contact sheets for Claude to look at
    broll_sort.py apply  <library folder>                            rename + file into buckets from sort.json

split   Finds every hard cut (ffmpeg scene detection), keeps shots at least --min seconds long, trims a
        few frames off each end so no clip carries a frame of its neighbour, and writes each shot to
        <library>/_unsorted/ starting at exactly 0.000s (a late start previews black in Finder and shows
        a blank first frame in editors). Native resolution, nothing upscaled. If the export is a folder of
        files named by category ("Office.mp4", "Travel.mp4"), that name rides along as a hint.
sheets  One image per 10 shots: three frames each (start, middle, end) with the shot's id burned in.
apply   Reads <library>/sort.json {"<id>": {"bucket": "Office", "name": "laptop on rooftop at sunset"}},
        moves each shot to <library>/<bucket>/<name>.mp4, writes INDEX.md, and writes shots.json so
        CineYap's B-roll picker and the Board can use the library straight away. Shots marked
        {"bucket": "_reject"} go to _reject/ (blurry, accidental, unusable), never deleted.
"""
import argparse, json, pathlib, re, shutil, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

VIDEO = {".mp4", ".mov", ".m4v", ".mxf"}

def probe(p, entries, stream="v:0"):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", stream, "-show_entries", entries,
                        "-of", "json", str(p)], capture_output=True, text=True)
    j = json.loads(r.stdout or "{}")
    return (j.get("streams") or [{}])[0] | (j.get("format") or {})

def fps_of(p):
    n, d = (probe(p, "stream=r_frame_rate").get("r_frame_rate") or "24/1").split("/")
    return float(n) / float(d or 1)

def duration_of(p):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                                capture_output=True, text=True).stdout.strip() or 0)

def cuts_in(p, threshold):
    err = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(p), "-vf", f"select='gt(scene,{threshold})',metadata=print",
                          "-an", "-f", "null", "-"], capture_output=True, text=True).stderr
    return [float(m) for m in re.findall(r"pts_time:([0-9.]+)", err)]

def slug(s):
    s = re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()
    return re.sub(r"\s+", " ", s)[:70] or "shot"

# --------------------------------------------------------------------------------------------- split
def split(args):
    src, lib = pathlib.Path(args.src).expanduser(), pathlib.Path(args.library).expanduser()
    files = [src] if src.is_file() else sorted(f for f in src.rglob("*") if f.suffix.lower() in VIDEO and not f.name.startswith("."))
    if not files: sys.exit(f"no video files in {src}")
    out = lib / "_unsorted"; out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((lib / "manifest.json").read_text()) if (lib / "manifest.json").exists() else {}
    nxt = 1 + max([int(k) for k in manifest] or [0])
    for f in files:
        if any(m["source"] == str(f) for m in manifest.values()):
            print(f"  already split: {f.name}"); continue
        fps, dur = fps_of(f), duration_of(f)
        trim = args.trim_frames / fps
        bounds = [0.0] + cuts_in(f, args.threshold) + [dur]
        hint = f.stem if src.is_dir() else ""
        w, h = (probe(f, "stream=width,height").get(k) for k in ("width", "height"))
        kbps = int(max(12000, min(60000, 60000 * (w * h) / (3840 * 2160))))   # 60 Mbps at 4K, scaled by pixels
        made = 0
        for a, b in zip(bounds, bounds[1:]):
            a2, b2 = a + trim, b - trim
            if b2 - a2 < args.min: continue
            sid = f"{nxt:04d}"; nxt += 1
            dst = out / f"{sid}.mp4"
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{a2:.3f}", "-i", str(f), "-t", f"{b2-a2:.3f}",
                            "-vf", "setpts=PTS-STARTPTS", "-af", "asetpts=PTS-STARTPTS",
                            "-c:v", "h264_videotoolbox", "-b:v", f"{kbps}k", "-pix_fmt", "yuv420p",
                            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(dst)], check=True)
            manifest[sid] = {"source": str(f), "hint": hint, "in": round(a2, 3), "out": round(b2, 3),
                             "dur": round(b2 - a2, 2), "size": f"{w}x{h}", "file": str(dst.relative_to(lib))}
            made += 1
        print(f"  {f.name}: {len(bounds)-1} shots found, {made} kept (>= {args.min:g}s)")
        (lib / "manifest.json").write_text(json.dumps(manifest, indent=1))
    print(f"{len(manifest)} shots in {lib/'_unsorted'}. Next: broll_sort.py sheets \"{lib}\"")

# -------------------------------------------------------------------------------------------- sheets
def sheets(args):
    lib = pathlib.Path(args.library).expanduser()
    manifest = json.loads((lib / "manifest.json").read_text())
    todo = [k for k, m in sorted(manifest.items()) if not m.get("sorted")]
    outd = lib / "_sheets"; shutil.rmtree(outd, ignore_errors=True); outd.mkdir()
    TW, TH, PER = 320, 180, 10
    try: font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 22)
    except Exception: font = ImageFont.load_default()
    paths = []
    for n in range(0, len(todo), PER):
        batch = todo[n:n + PER]
        sheet = Image.new("RGB", (TW * 3 + 140, TH * len(batch)), (18, 18, 18)); d = ImageDraw.Draw(sheet)
        for r, sid in enumerate(batch):
            m = manifest[sid]; p = lib / m["file"]; dur = m["dur"]
            d.text((10, r * TH + 10), sid, fill=(255, 210, 0), font=font)
            d.text((10, r * TH + 40), f"{dur:.1f}s", fill=(200, 200, 200), font=font)
            if m.get("hint"): d.text((10, r * TH + 70), m["hint"][:10], fill=(140, 200, 140), font=font)
            for c, t in enumerate((0.15, dur / 2, max(0.15, dur - 0.2))):
                raw = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", str(p), "-frames:v", "1",
                                      "-vf", f"scale={TW}:{TH}:force_original_aspect_ratio=decrease,pad={TW}:{TH}:(ow-iw)/2:(oh-ih)/2",
                                      "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True).stdout
                if len(raw) == TW * TH * 3:
                    sheet.paste(Image.frombytes("RGB", (TW, TH), raw), (140 + c * TW, r * TH))
        sp = outd / f"sheet_{n // PER + 1:03d}.jpg"; sheet.save(sp, quality=82); paths.append(sp)
    print(f"{len(todo)} shots on {len(paths)} sheet(s):")
    for sp in paths: print(f"  {sp}")
    print(f"Look at each sheet, then write {lib/'sort.json'} and run: broll_sort.py apply \"{lib}\"")

# --------------------------------------------------------------------------------------------- apply
def apply(args):
    lib = pathlib.Path(args.library).expanduser()
    manifest = json.loads((lib / "manifest.json").read_text())
    sort = json.loads((lib / "sort.json").read_text())
    missing = [k for k, m in manifest.items() if not m.get("sorted") and k not in sort]
    if missing and not args.partial: sys.exit(f"sort.json is missing {len(missing)} shot(s): {', '.join(missing[:12])}...  (--partial to file the rest anyway)")
    moved = 0
    for sid, s in sort.items():
        m = manifest.get(sid)
        if not m or m.get("sorted"): continue
        src = lib / m["file"]
        if not src.exists(): print(f"  ! {sid} missing on disk"); continue
        bucket = s.get("bucket", "_unsorted").strip("/ ") or "_unsorted"
        base = slug(s.get("name", sid)); dst = lib / bucket / f"{base}.mp4"; k = 2
        while dst.exists(): dst = lib / bucket / f"{base} {k}.mp4"; k += 1
        dst.parent.mkdir(parents=True, exist_ok=True); shutil.move(src, dst)
        m.update(file=str(dst.relative_to(lib)), bucket=bucket, name=dst.stem, tags=s.get("tags", []), sorted=True); moved += 1
    (lib / "manifest.json").write_text(json.dumps(manifest, indent=1))
    # the human index
    by = {}
    for sid, m in sorted(manifest.items()):
        if m.get("sorted") and m["bucket"] != "_reject": by.setdefault(m["bucket"], []).append(m)
    rows = ["# B-roll library", "", f"{sum(len(v) for v in by.values())} shots, sorted by what is in them. "
            "Every file is one continuous shot, starts at 0.000s, native resolution.", ""]
    rows += ["| Bucket | Shots | Minutes |", "|---|---|---|"] + [f"| {b} | {len(v)} | {sum(x['dur'] for x in v)/60:.1f} |" for b, v in sorted(by.items())]
    for b, v in sorted(by.items()):
        rows += ["", f"## {b}", "", "| File | Length | Size | Tags |", "|---|---|---|---|"]
        rows += [f"| `{x['name']}.mp4` | {x['dur']:.1f}s | {x['size']} | {', '.join(x.get('tags', []))} |" for x in sorted(v, key=lambda x: x["name"])]
    (lib / "INDEX.md").write_text("\n".join(rows) + "\n")
    # CineYap's picker reads shots.json: one entry per usable shot
    shots = [{"clip": m["file"], "path": str(lib / m["file"]), "start": 0.0, "end": m["dur"], "dur": m["dur"],
              "bucket": m["bucket"], "name": m["name"], "tags": m.get("tags", [])}
             for m in manifest.values() if m.get("sorted") and m["bucket"] != "_reject"]
    (lib / "shots.json").write_text(json.dumps(shots, indent=1))
    left = [k for k, m in manifest.items() if not m.get("sorted")]
    print(f"{moved} shots filed into {len(by)} bucket(s). INDEX.md and shots.json written in {lib}.")
    if left: print(f"{len(left)} still unsorted - run sheets again for those.")
    if not any((lib / "_unsorted").iterdir()): (lib / "_unsorted").rmdir()

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
sub = ap.add_subparsers(dest="cmd", required=True)
a = sub.add_parser("split"); a.add_argument("src"); a.add_argument("library")
a.add_argument("--min", type=float, default=2.0, help="shortest shot to keep, seconds (default 2)")
a.add_argument("--threshold", type=float, default=0.15, help="scene-change sensitivity, lower finds more cuts (default 0.15: catches cuts between dark night shots that 0.30 misses, without splitting moving shots)")
a.add_argument("--trim-frames", type=int, default=4, help="frames shaved off each end (default 4)")
a.set_defaults(fn=split)
b = sub.add_parser("sheets"); b.add_argument("library"); b.set_defaults(fn=sheets)
c = sub.add_parser("apply"); c.add_argument("library"); c.add_argument("--partial", action="store_true"); c.set_defaults(fn=apply)
args = ap.parse_args(); args.fn(args)
