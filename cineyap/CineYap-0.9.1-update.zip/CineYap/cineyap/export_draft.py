#!/usr/bin/env python3
"""export_draft.py — export a CapCut draft the way a person would, and keep a small preview of it.

    ./vu-py cineyap/export_draft.py "<draft name>"               -> ~/Movies/CapCut/<draft>/<draft>.mov
    CINEYAP_OWNER=<name> ...                                      who holds _local/capcut.lock while it runs
    ./vu-py cineyap/export_draft.py "<draft name>" --preview <job> <fmt>
                                                                 + projects/<job>/previews/<fmt>.mp4 and .jpg

Opens the draft (open_draft.py), clicks Export, accepts the dialog as it stands (1080p, audio on, "Sync
exported videos to space" OFF: never tick it, it uploads to CapCut's cloud), waits for the file to stop
growing, then closes the share sheet without sharing. Real mouse events, on a CapCut window placed at
{0,25} 1920x1055 by open_draft. Only run it when nobody is using the Mac.
"""
import pathlib, subprocess, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PROJECTS
import open_draft

def glob_escape(s):
    import glob
    return glob.escape(s)

def click(x, y):
    if not open_draft.safe_click(x, y): raise SystemExit("stopped: another app is in front, so nothing was clicked")

import os
OWNER = os.environ.get("CINEYAP_OWNER", "studio-pipeline")
def export(name, timeout=900):
    if not open_draft.take_lock(OWNER): return None, "CapCut is locked by another session (_local/capcut.lock)"
    try: return _export(name, timeout)
    finally: open_draft.release_lock(OWNER)

def _export(name, timeout=900):
    if not open_draft.screen_ok():
        return None, ("Automatic export needs a main screen of at least 1920x1080. Open the draft in CapCut and use "
                      "Export (top right) yourself: 1080p, audio on, 'Sync exported videos to space' off.")
    root = pathlib.Path.home()/"Movies/CapCut"
    msg = open_draft.open_draft(name)
    if not msg.startswith("opened"): return None, msg
    started = time.time()
    time.sleep(2); click(1873, 48); time.sleep(4)          # Export (top right) -> the export dialog
    click(1267, 858)                                       # the dialog's Export button
    # CapCut writes <name>/<name>.mov, or <name>(2)/<name>(2).mov when that folder already exists
    def newest():
        c = [p for p in root.glob(f"{glob_escape(name)}*/*.mov") if p.stat().st_mtime >= started - 1]
        return max(c, key=lambda p: p.stat().st_mtime) if c else None
    t0, last, out = time.time(), -1, None
    while time.time() - t0 < timeout:
        time.sleep(3)
        out = newest()
        if out:
            sz = out.stat().st_size
            # finished = same size twice AND the file reads as a whole movie (CapCut writes the index last)
            if sz == last and sz > 0 and subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
                    "-of","csv=p=0",str(out)], capture_output=True, text=True).stdout.strip():
                time.sleep(4)
                if out.stat().st_size == sz: break
            last = sz
    else:
        return None, "the export did not finish in time"
    time.sleep(2); click(1187, 841)                        # Close the share sheet (never Share)
    return out, f"exported {out}"

def preview(mov, job, fmt):
    d = PROJECTS/job/"previews"; d.mkdir(parents=True, exist_ok=True)
    mp4, jpg = d/f"{fmt}.mp4", d/f"{fmt}.jpg"
    subprocess.run(["ffmpeg","-v","error","-y","-i",str(mov),"-vf","scale='if(gt(iw,ih),960,-2)':'if(gt(iw,ih),-2,960)'",
                    "-c:v","libx264","-crf","26","-preset","veryfast","-pix_fmt","yuv420p","-c:a","aac","-b:a","96k",
                    "-movflags","+faststart",str(mp4)], check=True)
    dur = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(mov)],
                               capture_output=True, text=True).stdout.strip() or 2)
    subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{dur*0.35:.2f}","-i",str(mp4),"-frames:v","1",str(jpg)], check=True)
    return mp4

if __name__ == "__main__":
    if len(sys.argv) < 2: sys.exit(__doc__)
    mov, msg = export(sys.argv[1]); print(msg)
    if mov and "--preview" in sys.argv:
        i = sys.argv.index("--preview"); print("preview:", preview(mov, sys.argv[i+1], sys.argv[i+2]))
