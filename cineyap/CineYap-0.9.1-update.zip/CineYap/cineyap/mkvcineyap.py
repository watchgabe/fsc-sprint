#!/usr/bin/env python3
"""mkvcineyap.py — Vertical CineYap ("30 Pieces in 30 Min" style) as a 1080x1920 CapCut draft, editable text.

    ./vu-py cineyap/mkvcineyap.py <job>          -> draft "<job> (Vertical CineYap)"

Every number is in the style pack's `vertical_cineyap` block, measured off Gabe's "30 Pieces in 30 Min"
(Sequence 04_3.mp4) by OCR every 0.5s plus pixel sampling. Each LINE of the cut gets one look:

  captions   word-by-word (1-3 words) white Helvetica Bold, centered, low (0.68)        the default
  serif      the same words set HIGH in Instrument Serif italic over the head (0.21)    an accent run
  green      full-frame green plate, one big white word at a time (0.50)
  split      green top section to 0.393 with a cream "Step #N" pill and the words big and white in it;
             the talking head below with the eyes at 0.49
  media      full-frame cream plate, a picture or clip inset (x .186-.813, y .064-.619), the words big
             and black under it (0.729)

plus B-roll over whole lines (captions stay low), the flash + click (fx.py) at the start of any line in
`flash`, and an opening title (small label + two-line headline, `backticks` = serif accent) held to 4.4s.

ONE CLOCK. Every A-roll clip is a whole number of frames (edit/clips_graded), so the line edges here are
read from the rendered clips, the same clock the plates, B-roll and captions use. A caption never runs
past its own line, and a line's first caption starts ON the cut, so the picture, the plate and the
caption style always change on the same frame.

Inputs:
  edit/edl.json, edit/transcripts/*.json, edit/clips_graded/   the cut (render.py)
  build/zones.json                                              eyes per clip (subject_zones.py)
  build/graded_master.mp4                                       the 4K take, graded (make_master.py)
  vcineyap/plan.json                                            the looks, written the first time:
     {"title": {"label": "Day 023/200", "lines": ["The one phrase", "to `adopt`"], "clip": "Vertical/x.mp4"},
      "lines": {"3": {"look": "green"}, "5": {"look": "split", "step": "Step #1"},
                "7": {"look": "media", "media": "Content/BTS_01.mp4"}, "2": {"look": "serif"}},
      "broll": [{"line": 4, "clip": "Vertical/Working-Office Vertical_04.mp4"}],
      "flash": [3, 6]}
"""
import json, pathlib, re, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
sys.path.insert(0, str(PKG/"helpers"))
import config
import numpy as np

if len(sys.argv) < 2: sys.exit("usage: mkvcineyap.py <job> [--3x4]")
job = sys.argv[1]; J = PROJECTS/job; B = J/"build"; P = J/"vcineyap"; P.mkdir(exist_ok=True)
sty = __import__("style").load()
V = sty["vertical_cineyap"]; W, H = V["canvas"]; FPS = 24000/1001
THREE4 = "--3x4" in sys.argv          # 1080x1440: pack positions are fractions, type scales with the width
if THREE4: H = int(round(W * 4 / 3))
mo = sty.get("motion", {})
edl = json.load(open(J/"edit/edl.json")); stem = pathlib.Path(list(edl["sources"].values())[0]).stem
tr = sorted((J/"edit/transcripts").glob("*.json"))
WORDS = [w for w in json.load(open(tr[0]))["words"] if w.get("type") == "word"]
pf = P/"plan.json"
if not pf.exists():
    json.dump({"title": {}, "lines": {}, "broll": [], "flash": []}, open(pf, "w"), indent=1)
    print(f"  wrote an empty plan: {pf} (every line plain captions). Fill it in, or use the Board.")
plan = json.load(open(pf))
LOOK = {int(k): v for k, v in (plan.get("lines") or {}).items()}
def look(n): return (LOOK.get(n) or {}).get("look", "captions")

def run(*a): return subprocess.run([str(x) for x in a], capture_output=True, text=True).stdout.strip()
def nframes(f):
    o = run("ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=nb_frames","-of","csv=p=0",f)
    return int(o) if o.isdigit() else None
def dims(f):
    w, h = run("ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height","-of","csv=p=0",f).split(",")[:2]
    return int(w), int(h)
def dur(f): return float(run("ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",f) or 0)

# ---- the lines on the picture clock
segs, t = [], 0
for i, r in enumerate(edl["ranges"]):
    n = nframes(J/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4")
    if not n: sys.exit(f"edit/clips_graded/seg_{i:02d}_{stem}.mp4 missing - render the cut first (render.py)")
    segs.append({"n": i + 1, "t0": t / FPS, "t1": (t + n) / FPS, "s0": r["start"], "beat": r.get("beat", "")}); t += n
TOTAL = t / FPS
words = []
for s in segs:
    span = s["t1"] - s["t0"]
    for w in WORDS:
        if w["start"] >= s["s0"] - 0.02 and w["end"] <= s["s0"] + span + 0.05:
            a = s["t0"] + w["start"] - s["s0"]; words.append({"t0": max(a, s["t0"]), "t1": min(s["t1"], s["t0"] + w["end"] - s["s0"]), "w": w["text"], "n": s["n"]})

# ---- the source and the framing: cover the 9:16 frame, eyes on one height
SRC = B/"graded_master.mp4" if (B/"graded_master.mp4").exists() else B/"graded_source.mp4"
if not SRC.exists(): sys.exit("no build/graded_master.mp4 - run cineyap/make_master.py <job> first")
sw, sh = dims(SRC); FIT = min(W/sw, H/sh); COVER = max(W/sw, H/sh) / FIT          # CapCut contain-fits first
ZON = json.load(open(B/"zones.json")) if (B/"zones.json").exists() else {"samples": [], "clips": []}
Z_W, Z_T = float(mo.get("zoom_wide", 1.06)), float(mo.get("zoom_tight", 1.25)); PMIN = float(mo.get("punch_min_clip_s", 2.0))
def eyes(a, b):
    xs = [(z["eye_x"], z["eye_y"]) for z in ZON["samples"] if a <= z["t"] <= b]
    if not xs: xs = [(z["eye_x"], z["eye_y"]) for z in ZON["samples"]] or [(0.5, 0.35)]
    return float(np.median([x for x, _ in xs])), float(np.median([y for _, y in xs]))
def frame(a, b, S, eye_y):
    """scale and position putting this clip's eyes at the frame's center x and at eye_y, no edge showing"""
    ex, ey = eyes(a, b); sc = COVER * S; dW, dH = sw*FIT*sc, sh*FIT*sc
    dx = -(ex - 0.5) * dW; dx = max(-(dW - W)/2, min((dW - W)/2, dx))
    dy = (H/2 + (ey - 0.5) * dH) - eye_y * H; dy = max(-(dH - H)/2, min((dH - H)/2, dy))
    return sc, dx / (W/2), dy / (H/2)

# ---- the draft
import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, TextBackground, trange, KeyframeProperty as KP
from capcut_draft import start, finish, US
from PIL import Image
name = f"{job} (Vertical CineYap 3x4)" if THREE4 else f"{job} (Vertical CineYap)"
sf, dst = start(name, J, W, H)
for k, nm in enumerate(("A-roll", "Plates", "B-roll"), 0): sf.add_track(draft.TrackType.video, nm, relative_index=k)
sf.add_track(draft.TrackType.video, "Media", relative_index=6)   # above the MediaFrame plate (5), under the Split cutout (8)
for k, nm in enumerate(("Captions", "Big words", "Pill", "Title label", "Title", "Title 2"), 5): sf.add_track(draft.TrackType.text, nm, relative_index=k)
from fx import FlashClick
fc = FlashClick(sf, J, sty.get("vertical_batch", {}), flash_track="FX", flash_index=16500, sfx_index=1, canvas=(W, H))
# FRAME (fx_library.Frame): a line's footage inside a plain plate. plan lines[n]["frame"] = {"look", "plate"}
FRM = {n: L["frame"] for n, L in LOOK.items() if (L.get("frame") or {}).get("look")}
fr_fx = None
if FRM:
    import fx
    from frame_fit import frame_span
    fr_fx = fx.Frame(sf, J, sty, canvas=(W, H))
FSPANS, FCAP, SIDE = [], {}, {}
# Library effects (fx_library, one implementation each): Split, MediaFrame, FullscreenHook. They draw their
# own plates and words; this builder owns the footage (the cutout, the media window, the hook clip).
import fx
SPLIT = {n for n in LOOK if look(n) == "split"}
MEDIA = {n for n in LOOK if look(n) == "media"}
HOOK = {n: L["hook"] for n, L in LOOK.items() if (L.get("hook") or {}).get("title") or (L.get("hook") or {}).get("sub")}
GSCR = {n: L["greenscreen"] for n, L in LOOK.items() if (L.get("greenscreen") or {}).get("clip")}
BOLD = sorted({int(n) for n in plan.get("bold_behind") or []})
PULL = plan.get("pullback") or {}
if not (PULL.get("line1") or PULL.get("label") or PULL.get("line2")): PULL = {}
gs_fx = fx.GreenScreen(sf, J, sty, canvas=(W, H)) if GSCR else None
bb_fx = fx.BoldBehind(sf, J, sty, canvas=(W, H)) if BOLD else None
hp_fx = fx.HookPullback(sf, J, sty, canvas=(W, H)) if PULL else None
if BOLD or GSCR: sf.add_track(draft.TrackType.video, "Subject top", relative_index=16000)   # the cutout in front of every word
if GSCR: sf.add_track(draft.TrackType.video, "Panel", relative_index=4)
sp_fx = fx.Split(sf, J, sty, canvas=(W, H)) if SPLIT else None
mf_fx = fx.MediaFrame(sf, J, sty, canvas=(W, H)) if MEDIA else None
fh_fx = fx.FullscreenHook(sf, J, sty, canvas=(W, H)) if HOOK else None
if SPLIT: sf.add_track(draft.TrackType.video, "Subject", relative_index=8)   # the cutout over the band, under the words

levels = []
for s in segs:
    d = s["t1"] - s["t0"]
    lv = "wide" if not levels else (levels[-1] if d < PMIN else ("tight" if levels[-1] == "wide" else "wide"))
    lv = ((plan.get("framing") or {}).get(str(s["n"]))) or lv
    levels.append(lv)
    S = Z_T if lv == "tight" else Z_W
    sc, tx, ty = frame(s["t0"], s["t1"], S, V["eyes_y"])          # the head never moves for a split (Gabe)
    s["clip"] = (sc, tx, ty)
    DU = US(s["t1"]) - US(s["t0"])          # end minus start: US(d) can round 1us into the next clip
    if s["n"] in SPLIT or s["n"] in GSCR or s["n"] in BOLD:
        # the picture under a cutout comes from the same rendered clip the cutout was cut from, so both sit on
        # CapCut's frame grid the same way (a cutout over a different file showed two heads on fast moves)
        own = J/f"edit/clips_graded/seg_{s['n']-1:02d}_{stem}.mp4"
        vs = VideoSegment(str(own), trange(US(s["t0"]), DU - 1000), source_timerange=trange(0, DU - 1000),
                          clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc, transform_x=tx, transform_y=ty))
        if hp_fx and s["n"] == 1:
            for tt, kk in hp_fx.keys(0.0):
                if US(tt) < DU - 1000: vs.add_keyframe(KP.uniform_scale, US(tt), sc * kk)
        sf.add_segment(vs, "A-roll")
    else:
        vs = VideoSegment(str(SRC), trange(US(s["t0"]), DU), source_timerange=trange(US(s["s0"]), DU),
                          clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc, transform_x=tx, transform_y=ty))
        if hp_fx and s["n"] == 1:      # HOOK PULL-BACK: 1.44 -> 1.0 on the measured curve, on top of this clip's framing
            for tt, kk in hp_fx.keys(0.0):
                if US(tt) < DU: vs.add_keyframe(KP.uniform_scale, US(tt), sc * kk)
        sf.add_segment(vs, "A-roll")
print(f"  framing: cover {COVER:.2f}x, eyes at {V['eyes_y']}; punch {sum(l == 'tight' for l in levels)} of {len(segs)} clips")

for n, v in sorted(FRM.items()):
    s = next((x for x in segs if x["n"] == n), None)
    if not s: continue
    fr_fx.add(s["t0"], s["t1"], look=v["look"], plate=v.get("plate"))
    c = fr_fx.caption(v["look"], v.get("plate"))
    if c["where"] in ("below", "above", "left"): FCAP[n] = c   # letterbox / window: under the picture; side: above it
    if v["look"] == "side":
        SIDE[n] = v; continue                             # a dropped-in clip fills the window (placed with the media)
    FSPANS.append(frame_span(fr_fx, v["look"], W, H, s["t0"], s["t1"], cover=COVER))
if FRM: print(f"  frame: {len(FSPANS)} line(s) inside a plate")

# ---- plates
col = sty["colors"]; plate = {}
for k, c, hh in (("green", col["ink"], H), ("cream", col["paper"], H), ("split", col["ink"], int(round(V["split"]["plate_y1"] * H)))):
    f = P/f"plate_{k}_{W}x{H}.png"
    if not f.exists(): Image.fromarray(np.tile(np.array(list(c[:3]) + [255], np.uint8), (hh, W, 1))).save(f)
    plate[k] = f
for s in segs:
    L = look(s["n"]); d = s["t1"] - s["t0"]
    if L == "green":
        sf.add_segment(VideoSegment(str(plate["green"]), trange(US(s["t0"]), US(s["t1"]) - US(s["t0"]))), "Plates")
# the cutout on every split / green screen / bold behind line (local background removal, cached per line)
for n in sorted(SPLIT | set(GSCR) | set(BOLD)):
    s = next((x for x in segs if x["n"] == n), None)
    if not s: continue
    mov = B/"assets"/"behind"/f"sub_line{n:02d}.mov"
    if not mov.exists():
        print(f"  cutting out the subject on line {n} (local, ~0.2s a frame)")
        subprocess.run([sys.executable, str(PKG/"cineyap/make_behind.py"), job, str(n), "--no-mark"], check=True, capture_output=True)
    d = min(s["t1"] - s["t0"], dur(mov)) - 0.001; sc, tx, ty = s["clip"]
    sf.add_segment(VideoSegment(str(mov), trange(US(s["t0"]), US(d)), source_timerange=trange(0, US(d)),
                                clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc, transform_x=tx, transform_y=ty)),
                   "Subject" if n in SPLIT else "Subject top")

# ---- B-roll and media, at native resolution (cropped to shape, never upscaled)
roots = [pathlib.Path(r) for r in (config.opt("broll_clips"), config.opt("broll_root")) if r]
def find(rel):
    p = pathlib.Path(rel)
    if p.is_absolute() and p.exists(): return p
    if (J/"board_media"/p.name).exists(): return J/"board_media"/p.name
    for r in roots:
        if (r/rel).exists(): return r/rel
    print(f"  NOTE: clip not found, skipped: {rel} (set broll_clips in config.json, or pick another on the Board)")
    return None
def shaped(p, aspect, key, need):
    """the clip cropped to `aspect` (w/h) at its own resolution, long enough for `need` seconds"""
    out = P/"assets"/f"{key}.mp4"; out.parent.mkdir(exist_ok=True)
    if not out.exists() or out.stat().st_mtime < p.stat().st_mtime:
        subprocess.run(["ffmpeg","-v","error","-y","-i",str(p),"-t",f"{need + 1.0:.2f}","-an","-vf",
                        f"crop='min(iw,ih*{aspect:.5f})':'min(ih,iw/{aspect:.5f})',fps=24000/1001",
                        "-c:v","libx264","-crf","16","-pix_fmt","yuv420p",str(out)], check=True)
    return out
def place(path, a, b, box, track):
    """a clip filling box (x0,y0,x1,y1 in frame fractions), held still"""
    if path is None: return False
    x0, y0, x1, y1 = box; bw, bh = (x1 - x0) * W, (y1 - y0) * H
    # the cache name carries the clip, the shape and the canvas: the 9:16 and 3:4 builds share this folder,
    # and a crop cached for one shape was reused by the other (the media ran past its window)
    q = shaped(path, bw / bh, f"{track.lower()}_{int(a*1000):07d}_{path.stem[:24].replace(' ', '_')}_{round(bw)}x{round(bh)}_{W}x{H}", b - a)
    qw, qh = dims(q); sc = (bw / qw) / min(W/qw, H/qh)
    cx, cy = (x0 + x1) / 2 * W, (y0 + y1) / 2 * H
    d = min(b - a, dur(q) - 0.05)
    sf.add_segment(VideoSegment(str(q), trange(US(a), US(d)), source_timerange=trange(0, US(d)),
                                clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc, transform_x=(cx - W/2)/(W/2), transform_y=(H/2 - cy)/(H/2))), track)

def shape_of(path):
    w_, h_ = dims(path); r = w_ / h_
    return min((("9:16", 9/16), ("4:5", 4/5), ("4:3", 4/3), ("16:9", 16/9)), key=lambda x: abs(x[1] - r))[0]
for s in segs:
    if s["n"] in MEDIA and (LOOK[s["n"]].get("media")):
        mp = find(LOOK[s["n"]]["media"])
        if mp is None: continue
        bx = mf_fx.window(shape_of(mp))
        place(mp, s["t0"], s["t1"], (bx["x"]/W, bx["y"]/H, (bx["x"]+bx["w"])/W, (bx["y"]+bx["h"])/H), "Media")
for n, v in sorted(SIDE.items()):                    # FRAME side: the dropped-in clip, muted, in the 9:16 window
    s = next((x for x in segs if x["n"] == n), None)
    if s and v.get("clip"):
        bx = fr_fx.window("side"); place(find(v["clip"]), s["t0"], s["t1"], (bx["x"]/W, bx["y"]/H, (bx["x"]+bx["w"])/W, (bx["y"]+bx["h"])/H), "Media")
for n, v in sorted(GSCR.items()):                    # GREEN SCREEN: the panel video behind the cutout
    s = next((x for x in segs if x["n"] == n), None)
    if s:
        bx = gs_fx.window(); place(find(v["clip"]), s["t0"], s["t1"], (bx["x"]/W, bx["y"]/H, (bx["x"]+bx["w"])/W, (bx["y"]+bx["h"])/H), "Panel")
for n, v in sorted(HOOK.items()):                    # the hook's own full-frame clip
    s = next((x for x in segs if x["n"] == n), None)
    if s and v.get("clip"): place(find(v["clip"]), s["t0"], s["t1"], (0, 0, 1, 1), "B-roll")
title = {} if PULL else (plan.get("title") or {})          # a pull-back IS the opening title
# the title holds to the line edge nearest the measured 4.4s, so it leaves on a cut (one clock)
T_END = min(float(title.get("until_s") or V["title"]["until_s"]), TOTAL)     # the plan may hold it shorter
_near = min((s["t1"] for s in segs), key=lambda e: abs(e - T_END))
if abs(_near - T_END) < 1.5: T_END = _near
if title.get("clip"):                       # the opening title sits on B-roll
    place(find(title["clip"]), 0.0, T_END, (0, 0, 1, 1), "B-roll")
broll_lines = set()
for b in plan.get("broll", []):
    s = next((x for x in segs if x["n"] == int(b["line"])), None)
    if not s: print(f"  NOTE: B-roll on line {b['line']} skipped - no such line"); continue
    if s["n"] in HOOK and HOOK[s["n"]].get("clip"): continue      # the hook's own clip is the B-roll there
    a = max(s["t0"], T_END) if title.get("clip") else s["t0"]
    if s["t1"] - a < 0.5: print(f"  NOTE: B-roll on line {b['line']} skipped - the opening title's clip covers that line"); continue
    if place(find(b["clip"]), a, s["t1"], (0, 0, 1, 1), "B-roll") is not False: broll_lines.add(s["n"])

# ---- text
unit = 11.1 * W / 1920
WHITE = (1.0, 1.0, 1.0); INK = tuple(v/255 for v in col["ink"][:3])
fonts = {}
def text(track, s, t0, t1, px, cy, color=WHITE, serif=False, ranges=None, bg=None):
    if t1 - t0 < 0.04: return
    st = TextStyle(size=round(px/unit, 2), color=color, align=1, letter_spacing=0 if serif else -1, auto_wrapping=False, max_line_width=0.95)
    seg = TextSegment(s, trange(US(t0), US(t1) - US(t0)), style=st, background=bg, clip_settings=draft.ClipSettings(transform_y=(H/2 - cy*H)/(H/2)))
    sf.add_segment(seg, track); fonts[seg.material_id] = ranges if ranges else serif
norm = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())
# captions: 1-3 words; a short word rides with the next; never across a line; a line's first caption starts on the cut
caps = []
for s in segs:
    lw = [w for w in words if w["n"] == s["n"]]; L = look(s["n"]); i = 0
    one = L in ("green", "split", "media")              # the big-word looks show one word at a time
    while i < len(lw):
        g = [lw[i]]
        while not one and i + len(g) < len(lw) and len(g) < 3 and len(norm(g[-1]["w"])) <= 3 and \
              lw[i+len(g)]["t0"] - g[-1]["t1"] < 0.15 and sum(len(x["w"]) for x in g) + len(lw[i+len(g)]["w"]) <= 14:
            g.append(lw[i+len(g)])
        caps.append([g[0]["t0"], None, " ".join(x["w"] for x in g), s]); i += len(g)
for k, c in enumerate(caps):
    s = c[3]; nxt = caps[k+1][0] if k + 1 < len(caps) and caps[k+1][3] is s else s["t1"]
    c[1] = min(nxt, s["t1"])
    if k == 0 or caps[k-1][3] is not s:
        if c[0] - s["t0"] < 0.6: c[0] = s["t0"]          # on the cut, so the style changes with the picture
ti_fx = fx.TypeInterrogator(sf, J, sty, canvas=(W, H)) if plan.get("caption_style") == "interrogator" else None
owned = SPLIT | MEDIA | set(HOOK) | set(BOLD)
for n in sorted(owned):
    s = next((x for x in segs if x["n"] == n), None)
    if not s: continue
    ws = [(t0, t1, s_) for t0, t1, s_, sg in caps if sg is s]
    if n in HOOK:
        h_ = HOOK[n]; fonts.update(fh_fx.add(s["t0"], s["t1"], title=h_.get("title", ""), serif=h_.get("serif", ""), sub=h_.get("sub", "")))
    elif n in SPLIT: fonts.update(sp_fx.add(s["t0"], s["t1"], step=(LOOK[n].get("step") or "Step #1"), words=ws))
    elif n in MEDIA: fonts.update(mf_fx.add(s["t0"], s["t1"], words=ws))
    elif n in BOLD: fonts.update(bb_fx.add(s["t0"], s["t1"], words=ws))
if hp_fx and segs:
    fonts.update(hp_fx.add(segs[0]["t0"], segs[0]["t1"], label=PULL.get("label", ""), line1=PULL.get("line1", ""),
                           line2=PULL.get("line2", ""), serif_word=PULL.get("serif", "")))
for t0, t1, s_, sg in caps:
    if t0 < T_END and title: continue                    # the title owns the opening
    if sg["n"] in owned: continue
    if sg["n"] in GSCR:                                  # green screen: the captions above the head, in its style
        cs = gs_fx.caption_style(); hx = cs["color"].lstrip("#")
        text("Captions", s_, t0, t1, cs["px"], cs["cy"] / H, color=tuple(int(hx[i:i+2], 16)/255 for i in (0, 2, 4))); continue
    L = look(sg["n"])
    if L == "serif":   text("Captions", s_, t0, t1, V["caption_high"]["px"], V["caption_high"]["y"], serif=True)
    elif L == "green": text("Big words", s_, t0, t1, V["card"]["px"], V["card"]["y"])
    elif L == "split": text("Big words", s_, t0, t1, V["split"]["word"]["px"], V["split"]["word"]["y"])
    elif L == "media": text("Big words", s_, t0, t1, V["media_card"]["word"]["px"], V["media_card"]["word"]["y"], color=INK)
    elif sg["n"] in FCAP:
        fc_ = FCAP[sg["n"]]; ink = tuple(int(fc_["color"].lstrip("#")[i:i+2], 16)/255 for i in (0, 2, 4)) if fc_.get("color") else WHITE
        text("Captions", s_, t0, t1, V["caption"]["px"], fc_["center_y"] / H, color=ink)
    elif ti_fx:                                          # TYPE INTERROGATOR: chest-low on A-roll, mid on B-roll
        ts = ti_fx.style("broll" if sg["n"] in broll_lines else "aroll"); hx = ts["color"].lstrip("#")
        text("Captions", s_, t0, t1, ts["px"], ts["cy"] / H, color=tuple(int(hx[i:i+2], 16)/255 for i in (0, 2, 4)))
    else:              text("Captions", s_, t0, t1, V["caption"]["px"], V["caption"]["y"])
if title:
    TL = V["title"]
    if title.get("label"): text("Title label", title["label"], 0.0, T_END, TL["label"]["px"], TL["label"]["y"])
    for k, ln in enumerate((title.get("lines") or [])[:2]):
        clean = ln.replace("`", ""); rngs = []; pos = 0
        for m in re.finditer(r"`([^`]+)`", ln):
            a = m.start() - 2 * len(rngs); rngs.append((a, a + len(m.group(1))))
        text("Title" if k == 0 else "Title 2", clean, 0.0, T_END, TL["lines"][k]["px"], TL["lines"][k]["y"], ranges=rngs or None)

# ---- flash + click on the cut that starts each listed line
fl = sorted({int(n) for n in plan.get("flash", [])})
for n in fl:
    s = next((x for x in segs if x["n"] == n), None)
    if s: fc.add(s["t0"])
for n in sorted(HOOK):                                 # the hook flashes in and out (fx_library FullscreenHook)
    s = next((x for x in segs if x["n"] == n), None)
    if s:
        if n not in fl: fc.add(s["t0"])
        if s["t1"] < TOTAL - 0.05 and (n + 1) not in fl: fc.add(s["t1"])
fl = sorted(set(fl) | set(HOOK))
if PULL and segs:
    fc.add(segs[0]["t0"])
    if len(segs) > 1: fc.add(segs[0]["t1"])
finish(sf, dst, name, W, H, US(TOTAL), sty, text_fonts=fonts, left_inset=None)
if fl: print(f"  flash: {len(fl)} at the start of line(s) {fl}; Screen blend on {fc.finish(dst)}")
if FSPANS:
    from frame_fit import fit
    print(f"  frame: {fit(dst, FSPANS)} clip(s) fitted into the window")
json.dump(levels, open(P/"framing.json", "w"))
cnt = {}
for s in segs: cnt[look(s["n"])] = cnt.get(look(s["n"]), 0) + 1
print(f"\n{name}\n  {TOTAL:.1f}s · {len(segs)} lines ({', '.join(f'{v} {k}' for k, v in cnt.items())}) · {len(broll_lines)} B-roll · {len(caps)} captions")
print(f"  draft: {dst}")
