#!/usr/bin/env python3
"""config.py — everything about THIS machine, in one place.

The pipeline used to hardcode four absolute paths into Gabe's SSD. On anyone else's machine every
one of them failed, which is why the pipeline could not ship. They live here now.

`config.json` sits beside this file, is written by `install-video.sh`, and is never shipped — the
package carries `config.example.json` instead. A missing or empty value fails with a sentence that
says what to do, not a traceback.
"""
import json, pathlib, sys

HERE = pathlib.Path(__file__).parent
PATH = HERE / "config.json"
EXAMPLE = HERE / "config.example.json"

KEYS = {
 "broll_root":        "the folder holding your B-roll library",
 "broll_clips":       "the split one-shot-per-file library the review picker lists (optional; falls back to broll_root)",
 "lut":               "a .cube LUT for the grade, or \"\" for no grade",
 "sfx_flash_overlay": "the flash overlay clip used by transitions.py, or \"\" to skip flashes",
 "sfx_click":         "the click that rides each flash, or \"\"",
 "look":              "which text style module to render captions with (default: gabe_text)",
}

def load() -> dict:
    if not PATH.exists():
        sys.exit(f"No config.json yet.\n  Run ./install-video.sh, or copy {EXAMPLE.name} to "
                 f"config.json and fill it in.\n  Keys: " + ", ".join(KEYS))
    try:
        return json.loads(PATH.read_text())
    except json.JSONDecodeError as e:
        sys.exit(f"config.json is not valid JSON ({e}). Fix it or re-run ./install-video.sh.")

def opt(key, default=None):
    """A value that is allowed to be unset."""
    v = load().get(key, default)
    return v if v not in ("", None) else default

def need(key) -> pathlib.Path:
    """A path that must exist. Says what is wrong in one sentence."""
    v = load().get(key, "")
    if not v:
        sys.exit(f"config.json has no '{key}'.\n  It is {KEYS.get(key,'required')}.\n"
                 f"  Set it in {PATH}")
    p = pathlib.Path(v).expanduser()
    if not p.exists():
        sys.exit(f"config.json points '{key}' at a path that is not there:\n    {p}\n"
                 f"  If it lives on an external drive, plug it in. Otherwise fix {PATH}")
    return p

if __name__ == "__main__":
    c = load()
    print(f"config: {PATH}")
    for k, why in KEYS.items():
        v = c.get(k, "")
        state = "unset" if not v else ("OK " if pathlib.Path(str(v)).expanduser().exists() or k == "look" else "MISSING")
        print(f"  {state:8s} {k:19s} {v or '-'}")
