#!/usr/bin/env python3
"""mkcapcut.py — emit the finished cut as a CapCut draft with EDITABLE TEXT.

    cd projects/<job>/build && ../../../vu-py cineyap/mkcapcut.py            # 16:9, "<job> (CineYap)"
    cd projects/<job>/build && ../../../vu-py cineyap/mkcapcut.py --4x3      # 1440x1080, "<job> (CineYap 4x3)"

WHY THIS IS THE PRIMARY OUTPUT. The Premiere XML carries captions as PNG overlays, so changing a word
means coming back here and re-rendering. In CapCut a caption is a real text object: click it, type.
Change a cut and fix the caption in the same place, in the same minute.

  A-roll     the cut, one clip per EDL segment, pointing at graded_source.mp4 so every cut has handles
  B-roll     the inserts (with Ken Burns keyframes)
  Cards      the green / cream plates (edges already snapped by cut_guard.py)
  Captions   every caption as an editable CapCut text object, styled from the active pack

🔴 CAPCUT MUST BE QUIT. The shared writer (capcut_draft.py) refuses to run otherwise and explains why.
"""
import json, pathlib, subprocess, sys
import numpy as np
from _root import PKG
import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, trange, KeyframeProperty as KP
from capcut_draft import start, finish, US

B   = pathlib.Path.cwd()
JOB = B.parent
if not (B/"base_clean.mp4").exists():
    sys.exit("run this from the job's build/ directory")

# ---- job data
sty  = __import__("style").load()
cc   = sty.get("capcut", {})
edl  = json.load(open(JOB/"edit/edl.json"))
stem = list(edl["sources"])[0]
cues = json.load(open(B/"cues.json")) if (B/"cues.json").exists() else []
ins  = json.load(open(B/"inserts.json")) if (B/"inserts.json").exists() else []

def probe(p, *ent):
    return subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-count_frames",
        "-show_entries","stream="+",".join(ent),"-of","csv=p=0",str(p)],
        capture_output=True,text=True).stdout.strip().split(",")
W,H,NF = (int(x) for x in probe(B/"base_clean.mp4","width","height","nb_read_frames"))
if H > W:
    sys.exit("This take is vertical (shot on a phone held upright). CineYap 16:9 and 4:3 need a horizontal take.\n"
             "  Build it as Vertical, Vertical CineYap or YapMaxxing instead (they are made for vertical footage).")
FPS = 24000/1001
# 4:3. The same cut on a 1440x1080 canvas. CapCut fits a 16:9 clip INSIDE a 4:3 frame (bars top and
# bottom), so every picture is scaled by F = (16/9)/(4/3) to fill it; the eye-lock maths is unchanged
# because at F the picture is exactly as tall as the frame, the same as 16:9 at 1.0. The face is kept in
# the middle of the narrower frame from zones.json. Type keeps its pixel size (CapCut sizes text by
# canvas WIDTH, so sizes are scaled by 1920/W) and the left inset scales with the width.
FOUR3 = "--4x3" in sys.argv
F = 1.0
if FOUR3:
    F = (W / H) / (4 / 3); W = int(round(H * 4 / 3)); W += W % 2

GS = B/"graded_source.mp4"
# The 4K master when it exists: CapCut fits it to the 1080 frame at 100%, so punch-ins stay sharp up to
# 200%. The 1080 copy is the fallback (and what Premiere's XML still uses).
if (B/"graded_master.mp4").exists():
    GS = B/"graded_master.mp4"; print(f"  A-roll from the native-resolution master ({GS.name})")
if not GS.exists():
    sys.exit("graded_source.mp4 missing. Run cineyap/mkxml.py once first - it builds it, and the\n"
             "  CapCut draft needs the same handles.")

# ---- the A-roll cut, with its real source times so every edge can be dragged
segs, t = [], 0
for i, r in enumerate(edl["ranges"]):
    n = int(probe(JOB/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4","nb_read_frames")[0])
    segs.append({"t0": t/FPS, "t1": (t+n)/FPS, "s0": r["start"], "s1": r["start"]+n/FPS, "beat": r.get("beat","")})
    t += n
assert t == NF, f"segments sum to {t}, base is {NF}"

name = f"{JOB.name} (CineYap 4x3)" if FOUR3 else f"{JOB.name} (CineYap)"
sf, dst = start(name, JOB, W, H)

# relative_index is the stacking order: higher draws on top. Cards sit UNDER the captions or a
# full-frame plate hides the word it is behind.
sf.add_track(draft.TrackType.video, "A-roll",   relative_index=0)
sf.add_track(draft.TrackType.video, "B-roll",   relative_index=1)
sf.add_track(draft.TrackType.video, "Cards",    relative_index=2)
sf.add_track(draft.TrackType.text,  "Captions", relative_index=3)

# ---- effects the Board asked for, per line. build/effects.json, e.g. {"behind": [{"take": 1}]}
# "behind" = text behind subject: the line's captions go big and centred, and a cutout of the subject
# (alpha ProRes 4444 from cineyap/make_behind.py) sits on a track ABOVE the captions, so the words
# pass behind the head. The cutout carries the same push keyframes as the A-roll under it, or it
# would drift off the person it was cut from.
EFX = json.load(open(B/"effects.json")) if (B/"effects.json").exists() else {}
# Library effects that also need the subject cut out (fx_library): BOLD BEHIND (huge words behind the whole
# subject, the opening) and GREEN SCREEN (another video in a panel, the subject cut out over it). They share
# the text-behind cutout and its frame-grid rules; only the words and the panel differ.
BOLD = sorted({int(n) for n in EFX.get("bold_behind") or []})
GSCR = {int(n): v for n, v in (EFX.get("greenscreen") or {}).items() if v and v.get("clip")}
SPLT = {int(n): (v or {}) for n, v in (EFX.get("split") or {}).items()}
PULL = EFX.get("pullback") or {}            # HOOK PULL-BACK on the opening line: {label, line1, line2, serif}
if not (PULL.get("line1") or PULL.get("label") or PULL.get("line2")): PULL = {}          # SPLIT: green band left, cutout over it
CUTK = {int(e["take"]): "behind" for e in EFX.get("behind", [])}
CUTK.update({n: "bold" for n in BOLD}); CUTK.update({n: "green" for n in GSCR}); CUTK.update({n: "split" for n in SPLT})
for n, kind in CUTK.items():
    mov = B/"assets"/"behind"/f"sub_line{n:02d}.mov"
    if kind != "behind" and not mov.exists() and 0 < n <= len(segs):
        print(f"  cutting out the subject on line {n} for the {kind} effect (local, ~0.2s a frame)")
        subprocess.run([sys.executable, str(PKG/"cineyap/make_behind.py"), JOB.name, str(n), "--no-mark"], check=True, capture_output=True)
behind = []; behind_kind = {}
for n_, kind in sorted(CUTK.items()):
    k = n_ - 1
    mov = B/"assets"/"behind"/f"sub_line{k+1:02d}.mov"
    _cov = sum(max(0, min(o["t1"], segs[k]["t1"]) - max(o["t0"], segs[k]["t0"])) for o in ins) if 0 <= k < len(segs) else 0
    if 0 <= k < len(segs) and _cov > 0.8 * (segs[k]["t1"] - segs[k]["t0"]):
        print(f"  NOTE: text behind subject on line {k+1} skipped - B-roll covers that line, so you are not on screen"); continue
    if 0 <= k < len(segs) and mov.exists(): behind.append((segs[k]["t0"], segs[k]["t1"], mov)); behind_kind[k] = kind
    else: print(f"  NOTE: text-behind on line {k+1} skipped - run cineyap/make_behind.py {JOB.name} {k+1} first")
if behind:
    # Stacking is render_index = type base + relative_index, and text's base is 15000, video's 0. So a
    # video track with relative_index 4 still draws UNDER every caption. The cutout has to clear the
    # text band to sit in front of the words.
    sf.add_track(draft.TrackType.video, "Subject", relative_index=16000)
def in_behind(t):                    # the caption treatment for TEXT-behind lines only
    return any(a - 1e-3 <= t < b - 1e-3 for k, (a, b, _) in enumerate(behind) if behind_kind.get(_line_of(a)) == "behind")
def _line_of(a): return next((i for i, s in enumerate(segs) if abs(s["t0"] - a) < 1e-3), -1)

# BG: a plain plate behind a whole line's captions (the Board's "BG" button). Own track, under the text.
BGL = {int(n): c for n, c in (EFX.get("bg") or {}).items()}
def bg_at(t):
    for n, c in BGL.items():
        if 0 < n <= len(segs) and segs[n-1]["t0"] - 1e-3 <= t < segs[n-1]["t1"] - 1e-3: return c   # 1ms: the guard rounds to 4 places
    return None
if BGL: sf.add_track(draft.TrackType.video, "Background", relative_index=3)

# FLASH: the flash + click transition from the effects library (fx.py), the same one every format uses:
# the original leak clip with CapCut's Screen blend, the click 2 frames ahead, export-safe audio.
FLASH = sorted({int(n) for n in EFX.get("flash") or []})
# Library effects that own a whole line (fx_library): a TAGGED CARD (plate + tag, the line's words big on it)
# and a FULL-SCREEN HOOK (a title block over full-frame B-roll, a flash on both cuts). Their lines' words are
# drawn by the effect, so the caption loop skips them.
CTAG = {int(n): v for n, v in (EFX.get("card_tag") or {}).items() if v}
HOOK = {int(n): v for n, v in (EFX.get("hook") or {}).items() if v and (v.get("title") or v.get("sub"))}
fc = None
if FLASH or HOOK:
    from fx import FlashClick
    fc = FlashClick(sf, JOB, sty.get("vertical_batch", {}), flash_track="FX", flash_index=16500, sfx_index=1, canvas=(W, H),
                   # Measured on CapCut exports (2026-10-03): the 16:9 draft runs on 23.976, and with the
                   # click on that grid and a 1-frame lead the snap lands 2 frames before the flash, as in
                   # the vertical's locked spec. (24 grid + 2: -2.5/-1.8 frames; 23.976 + 2: -3.00 on both.)
                   fps=float(__import__("os").environ.get("CINEYAP_FLASH_FPS", 24000/1001)),
                   lead_frames=int(__import__("os").environ.get("CINEYAP_CLICK_LEAD", 1)))
    if not fc.flash: print("  NOTE: flash asked for but no sfx_flash_overlay in config - skipped")

# FRAME: the footage inside a plain plate (fx_library.Frame, the Library's effect). The plate goes on its
# own track over the line; frame_fit.py shrinks that line's footage into the window after finish().
FRM = {int(n): v for n, v in (EFX.get("frame") or {}).items() if v and v.get("look")}
fr_fx = None
if FRM:
    import fx
    fr_fx = fx.Frame(sf, JOB, sty, canvas=(W, H))

# ---- motion: a slow push on long A-roll clips, Ken Burns on every insert, as editable keyframes.
# Scale is about the frame centre, which drifts the eyes upward on a push; position_y walks the frame
# down by the same amount so the eye line holds (unit: half a canvas height, up positive).
mo = sty.get("motion", {})
punch, minc = float(mo.get("punch", 0.10)), float(mo.get("min_clip_s", 5.0))
eye, kb     = float(mo.get("eye_y", 0.35)), float(mo.get("kenburns", 0.12))
def push(seg, dur_us, amount):
    seg.add_keyframe(KP.uniform_scale, 0, F); seg.add_keyframe(KP.uniform_scale, dur_us, F * (1.0 + amount))
    seg.add_keyframe(KP.position_y, 0, 0.0);    seg.add_keyframe(KP.position_y, dur_us, -eye * amount)
# ---- EYE LOCK. zones.json says where the eyes are, 4 times a second. Each A-roll clip gets a scale and
# a vertical position at its first and last frame so the eye line lands on ONE height (the pack's
# eye_line, or this video's median) - no jump on a cut, no drift through a push-in. A move needs room:
# shifting a frame exposes its edge unless it is scaled up at least as much, so the clip zooms just
# enough (capped at max_lock_scale). CapCut position_y is in half-frame-heights, up positive.
ZON = json.load(open(B/"zones.json"))["samples"] if (B/"zones.json").exists() and mo.get("eye_lock", True) else []
if ZON:
    T_EYE = float(mo["eye_line"]) if mo.get("eye_line") is not None else float(np.median([z["eye_y"] for z in ZON]))
    CAP = float(mo.get("max_lock_scale", 1.25))
def eye_at(a, b):
    v = [z["eye_y"] for z in ZON if a <= z["t"] <= b]
    return float(np.median(v)) if v else None
def lock(y, S):
    """scale >= S and position putting eye height y on T_EYE without exposing an edge."""
    while True:
        p = 2 * (0.5 + (y - 0.5) * S - T_EYE)
        if abs(p) <= S - 1 + 1e-9 or S >= CAP:
            return S, max(-(S - 1), min(S - 1, p))
        S += 0.005
CLIPZ = json.load(open(B/"zones.json")).get("clips", []) if ZON else []
Z_WIDE, Z_TIGHT = float(mo.get("zoom_wide", 1.06)), float(mo.get("zoom_tight", 1.32))
PMIN = float(mo.get("punch_min_clip_s", 2.0))
def place(seg, a, b, amount, level):
    """PUNCH-IN WITH THE EYE LINE HELD. The clip sits at one fixed size for its whole length - wide or
    tight, nothing in between - and its exact first and last frames put the eyes on T_EYE, so a punch
    on the cut changes the size and nothing else. (First version: every clip got its own small zoom
    from the eye fix plus a 10% creep. Gabe: 'it looks like a twitch, a glitch'.)"""
    D = US(b - a); S = Z_TIGHT if level == "tight" else Z_WIDE
    seg.add_keyframe(KP.uniform_scale, 0, F * S); seg.add_keyframe(KP.uniform_scale, D, F * S)
    if FOUR3:               # the face in the middle of the narrower frame, never showing an edge
        ex = [z["eye_x"] for z in ZON if a <= z["t"] <= b]
        if ex:
            px = max(-(F*S - 1), min(F*S - 1, -2 * (float(np.median(ex)) - 0.5) * F * S))
            seg.add_keyframe(KP.position_x, 0, px); seg.add_keyframe(KP.position_x, D, px)
    c = next((c for c in CLIPZ if abs(c["t0"] - a) < 0.02), None)
    if not c or c["eye_start"] is None or c["eye_end"] is None:
        return (S, S, [(0, 0.0), (D, 0.0)], D, None, None)
    pv = lambda y: max(-(S-1), min(S-1, 2*(0.5 + (y-0.5)*S - T_EYE)))
    p0, p1 = pv(c["eye_start"]), pv(c["eye_end"])
    seg.add_keyframe(KP.position_y, 0, p0); seg.add_keyframe(KP.position_y, D, p1)
    land = lambda y, p: 0.5 + (y-0.5)*S - p/2
    return (S, S, [(0, p0), (D, p1)], D, land(c["eye_start"], p0), land(c["eye_end"], p1))
locks = {}

import numpy as np
pushed = 0; levels = []
# On a text-behind line the picture UNDER the cutout must come from the same file the cutout was cut
# from. CapCut snaps every source start to its own 24fps grid; a cutout starting at 0 and a picture
# starting 11.035s into the full take land on that grid differently, so CapCut can show them a frame
# apart - two heads on any fast move. Same file, same start, same grid: they cannot separate.
behind_take = set(behind_kind) if behind else set()
for i, s in enumerate(segs):
    d = s["t1"] - s["t0"]
    if i in behind_take:
        own = JOB/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4"
        vs = VideoSegment(str(own), trange(US(s["t0"]), US(d - 0.001)), source_timerange=trange(0, US(d - 0.001)),
                          clip_settings=draft.ClipSettings(scale_x=F, scale_y=F))
    else:
        # duration as end-minus-start in microseconds: US(d) can round 1us past the next clip's start
        vs = VideoSegment(str(GS), trange(US(s["t0"]), US(s["t1"]) - US(s["t0"])), source_timerange=trange(US(s["s0"]), US(s["t1"]) - US(s["t0"])),
                          clip_settings=draft.ClipSettings(scale_x=F, scale_y=F))
    # alternate wide / tight on every cut the viewer sees; a short bite keeps the previous framing
    if i == 0: level = "wide"
    elif d < PMIN: level = levels[-1]
    else: level = "tight" if levels[-1] == "wide" else "wide"
    level = EFX.get("framing", {}).get(str(i + 1), level)      # the Board's zoom toggle wins
    levels.append(level)
    k = place(vs, s["t0"], s["t1"], 0.0, level) if ZON else None
    if k: locks[i] = k
    if level == "tight": pushed += 1
    sf.add_segment(vs, "A-roll")
if not FOUR3: json.dump(levels, open(B/"framing.json", "w"))                 # the Board reads this to show each line's framing
print(f"  punch-in: {pushed} of {len(segs)} A-roll clips tight ({Z_TIGHT:.0%}), the rest wide ({Z_WIDE:.0%}); "
      f"framing per clip: {' '.join('T' if l == 'tight' else 'w' for l in levels)}")
if ZON:
    jumps = [abs(locks[i+1][4] - locks[i][5]) for i in range(len(segs)-1)
             if i in locks and i+1 in locks and locks[i][5] is not None and locks[i+1][4] is not None]
    print(f"  eye lock: {len(locks)} of {len(segs)} clips; eye line {T_EYE:.3f}; jump at the cuts now "
          f"mean {np.mean(jumps)*100:.1f}%, worst {max(jumps)*100:.1f}% of frame height" if jumps else "  eye lock: no clips")
for a, b2, mov in behind:
    d = b2 - a
    real = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(mov)],
                                capture_output=True, text=True).stdout.strip() or d)
    d = min(d, real) - 0.001          # pycapcut rejects a range even 1us past the material's own length
    ms = VideoSegment(str(mov), trange(US(a), US(d)), source_timerange=trange(0, US(d)))
    ki = next((i for i, s in enumerate(segs) if abs(s["t0"] - a) < 1e-3), None)
    if ki in locks:                         # same scale and position as the picture under it, to the keyframe
        S0, S1, pos, dd = locks[ki][:4]
        ms.add_keyframe(KP.uniform_scale, 0, F * S0); ms.add_keyframe(KP.uniform_scale, dd, F * S1)
        if FOUR3:
            ex = [z["eye_x"] for z in ZON if a <= z["t"] <= b2]
            if ex:
                px = max(-(F*S0 - 1), min(F*S0 - 1, -2 * (float(np.median(ex)) - 0.5) * F * S0))
                ms.add_keyframe(KP.position_x, 0, px); ms.add_keyframe(KP.position_x, dd, px)
        for tt, pv in pos: ms.add_keyframe(KP.position_y, tt, pv)
    elif punch > 0 and (b2 - a) >= minc: push(ms, US(d), punch)
    sf.add_segment(ms, "Subject")
if behind: print(f"  text behind subject on {len(behind)} line(s)")

def hook_line_of(a, b):
    for n in HOOK:
        if 0 < n <= len(segs) and min(b, segs[n-1]["t1"]) - max(a, segs[n-1]["t0"]) > 0.05: return n
    return None
for o in ins:
    if HOOK and hook_line_of(o["t0"], o["t1"]) and HOOK[hook_line_of(o["t0"], o["t1"])].get("clip"):
        continue                                   # the hook's own clip replaces any B-roll on its line
    p = (B/o["file"]).resolve()
    # the asset carries handles; asset_in is where the region starts inside it. Clamp to what exists.
    real = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(p)],
                                capture_output=True, text=True).stdout.strip() or 0)
    ain = float(o.get("asset_in", 0.0)); want = o["t1"] - o["t0"]
    dur = min(want, real - ain) if real else want
    if dur <= 0: continue
    bs = VideoSegment(str(p), trange(US(o["t0"]), US(dur)), source_timerange=trange(US(ain), US(dur)),
                      clip_settings=draft.ClipSettings(scale_x=F, scale_y=F))
    fr = (EFX.get("broll_frame") or {}).get(o.get("id", ""))
    if fr:          # reframed from a note: a steady zoom + sideways shift, the Ken Burns push on top of it
        S0 = F * float(fr.get("scale", 1.0)); tx = float(fr.get("x", 0.0)); ty = float(fr.get("y", 0.0))
        bs.add_keyframe(KP.uniform_scale, 0, S0); bs.add_keyframe(KP.uniform_scale, US(dur), S0 * (1 + kb))
        bs.add_keyframe(KP.position_x, 0, tx);   bs.add_keyframe(KP.position_x, US(dur), tx)
        bs.add_keyframe(KP.position_y, 0, ty);   bs.add_keyframe(KP.position_y, US(dur), ty)
    elif kb > 0: push(bs, US(dur), kb)
    sf.add_segment(bs, "B-roll")

# ---- card plates: the full-frame green / cream behind a card word
from PIL import Image
import numpy as np
PLATES = B/"assets"/"split"; PLATES.mkdir(parents=True, exist_ok=True)
plate = {}
for k, c in (("green", sty["colors"]["ink"]), ("cream", sty["colors"]["paper"])):
    f = PLATES/f"BG_{k}.png"
    if not f.exists():
        Image.fromarray(np.tile(np.array(c[:4] if len(c) > 3 else list(c)+[255], np.uint8), (H, W, 1))).save(f)
    plate[k] = f
if (B/"plates.json").exists():
    cards = [[q["colour"], q["t0"], q["t1"]] for q in json.load(open(B/"plates.json"))]
    print("  card plates from plates.json (cut guard applied)")
else:
    print("  NOTE: plates.json missing - run cineyap/cut_guard.py first so plate edges land on the cuts")
    cards = []
    for i, c in enumerate(cues):
        if c["kind"] != "card": continue
        t0 = c["t"]; t1 = cues[i+1]["t"] if i+1 < len(cues) else NF/FPS
        col = "green" if c.get("colour") == "green" else "cream"
        if cards and cards[-1][0] == col and abs(cards[-1][2] - t0) < 0.08: cards[-1][2] = t1
        else: cards.append([col, t0, t1])
for col, a, b2 in cards:
    sf.add_segment(VideoSegment(str(plate[col]), trange(US(a), US(b2-a))), "Cards")
for n, col in sorted(BGL.items()):
    if 0 < n <= len(segs) and col in plate:
        sf.add_segment(VideoSegment(str(plate[col]), trange(US(segs[n-1]["t0"]), US(segs[n-1]["t1"] - segs[n-1]["t0"]))), "Background")
if BGL: print(f"  background: {len(BGL)} line(s) on a plain plate")
FSPANS, FSPANS_MOVE, FCAPS = [], [], []          # FCAPS: lines whose captions move (under the window, beside it)
if fr_fx:
    from frame_fit import frame_span
    for n, v in sorted(FRM.items()):
        if 0 < n <= len(segs):
            look = v["look"] if v["look"] != "letterbox" else "inset"       # letterbox is vertical-only
            a_, b_ = segs[n-1]["t0"], segs[n-1]["t1"]
            fr_fx.add(a_, b_, look=look, plate=v.get("plate"))
            cap = fr_fx.caption(look, v.get("plate"))
            if cap["where"] != "over": FCAPS.append((a_, b_, cap))
            if look == "side":
                # SIDE: a dropped-in clip, muted, fills the 9:16 window; the take is hidden behind the plate
                if v.get("clip"):
                    sys.path.insert(0, str(PKG/"cineyap")); from boards import resolve_clip
                    src = resolve_clip(v["clip"], JOB.name); win = fr_fx.window("side")
                    if src:
                        out = B/"assets"/f"side_{n:02d}.mp4"
                        subprocess.run(["ffmpeg","-v","error","-y","-i",str(src),"-t",f"{b_ - a_ + 1:.2f}","-an","-vf",
                                        f"crop='min(iw,ih*{win['w']/win['h']:.5f})':'min(ih,iw/{win['w']/win['h']:.5f})',fps=24000/1001",
                                        "-c:v","libx264","-crf","16","-pix_fmt","yuv420p",str(out)], check=True)
                        pw, ph = (int(x) for x in probe(out, "width", "height")[:2])
                        sc = (win["w"] / pw) / min(W / pw, H / ph)
                        real = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(out)],
                                                    capture_output=True, text=True).stdout.strip() or 0)
                        dU = min(US(b_) - US(a_), US(real - 0.01))
                        if "Side" not in sf.tracks: sf.add_track(draft.TrackType.video, "Side", relative_index=11)
                        sf.add_segment(VideoSegment(str(out), trange(US(a_), dU), source_timerange=trange(0, dU), volume=0.0,
                                                    clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc,
                                                        transform_x=(win["x"] + win["w"]/2 - W/2)/(W/2), transform_y=(H/2 - win["y"] - win["h"]/2)/(H/2))), "Side")
                    else: print(f"  NOTE: side clip '{v['clip']}' on line {n} not found")
                continue
            (FSPANS if cap["where"] == "over" else FSPANS_MOVE).append(frame_span(fr_fx, look, W, H, a_, b_))
    print(f"  frame: {len(FRM)} line(s) inside a plate")
for n, v in sorted(HOOK.items()):
    if not (0 < n <= len(segs)): continue
    a, b2 = segs[n-1]["t0"], segs[n-1]["t1"]
    if v.get("clip"):                              # the hook's B-roll: native resolution, cropped to the frame's shape
        import pathlib as _pl, sys as _sys
        _sys.path.insert(0, str(PKG/"cineyap")); from boards import resolve_clip
        src = resolve_clip(v["clip"], JOB.name)
        if src:
            out = B/"assets"/f"hook_{n:02d}.mp4"
            subprocess.run(["ffmpeg","-v","error","-y","-i",str(src),"-t",f"{b2 - a + 1:.2f}","-an","-vf",
                            f"crop='min(iw,ih*{W/H:.5f})':'min(ih,iw/{W/H:.5f})',scale='if(lt(iw,{W}),{W},iw)':-2,fps=24000/1001",
                            "-c:v","libx264","-crf","16","-pix_fmt","yuv420p",str(out)], check=True)
            real = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(out)],
                                        capture_output=True, text=True).stdout.strip() or 0)
            d = min(b2 - a, real - 0.01)
            dU = min(US(b2) - US(a), US(real - 0.01))
            # its own track above the B-roll: a neighbour's held tail or handle can reach into this line,
            # and the full-frame hook clip simply covers it
            if "Hook" not in sf.tracks: sf.add_track(draft.TrackType.video, "Hook", relative_index=4)
            sf.add_segment(VideoSegment(str(out), trange(US(a), dU), source_timerange=trange(0, dU)), "Hook")
        else: print(f"  NOTE: hook clip '{v['clip']}' on line {n} not found - the title sits on whatever is there")
    if fc:
        fc.add(a)
        if b2 < NF/FPS - 0.05: fc.add(b2)
if HOOK: print(f"  hook: full-screen title on line(s) {sorted(HOOK)}")
gs_fx = None
if GSCR:
    import fx
    sys.path.insert(0, str(PKG/"cineyap")); from boards import resolve_clip
    gs_fx = fx.GreenScreen(sf, JOB, sty, canvas=(W, H)); win = gs_fx.window()
    sf.add_track(draft.TrackType.video, "Panel", relative_index=5)          # above the A-roll, under the cutout
    for n, v in sorted(GSCR.items()):
        if not (0 < n <= len(segs)): continue
        src = resolve_clip(v["clip"], JOB.name)
        if not src: print(f"  NOTE: green screen clip '{v['clip']}' on line {n} not found"); continue
        a, b2 = segs[n-1]["t0"], segs[n-1]["t1"]
        out = B/"assets"/f"panel_{n:02d}.mp4"
        subprocess.run(["ffmpeg","-v","error","-y","-i",str(src),"-t",f"{b2 - a + 1:.2f}","-an","-vf",
                        f"crop='min(iw,ih*{win['w']/win['h']:.5f})':'min(ih,iw/{win['w']/win['h']:.5f})',fps=24000/1001",
                        "-c:v","libx264","-crf","16","-pix_fmt","yuv420p",str(out)], check=True)
        pw, ph = (int(x) for x in probe(out, "width", "height")[:2])
        sc = (win["w"] / pw) / min(W / pw, H / ph)
        real = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(out)],
                                    capture_output=True, text=True).stdout.strip() or 0)
        dU = min(US(b2) - US(a), US(real - 0.01))
        sf.add_segment(VideoSegment(str(out), trange(US(a), dU), source_timerange=trange(0, dU),
                                    clip_settings=draft.ClipSettings(scale_x=sc, scale_y=sc,
                                        transform_x=(win["x"] + win["w"]/2 - W/2)/(W/2), transform_y=(H/2 - win["y"] - win["h"]/2)/(H/2))), "Panel")
    print(f"  green screen on line(s) {sorted(GSCR)}")
if PULL and segs:
    if not fc:
        from fx import FlashClick
        fc = FlashClick(sf, JOB, sty.get("vertical_batch", {}), flash_track="FX", flash_index=16500, sfx_index=1, canvas=(W, H),
                        fps=24000/1001, lead_frames=1)
    fc.add(segs[0]["t0"])
    if len(segs) > 1: fc.add(segs[0]["t1"])
if fc:
    for n in FLASH:
        if 0 < n <= len(segs): fc.add(segs[n-1]["t0"])
    print(f"  flash: {len(FLASH)} transition(s) at the start of line(s) {FLASH}")

# ---- the captions: real, editable text
rgb01 = lambda c: tuple(v/255 for v in c[:3])
TS = 1920.0 / W if FOUR3 else 1.0          # CapCut sizes text by canvas width: keep the 16:9 pixel size
INK, WHITE = sty["colors"]["ink"], sty["colors"]["white"]
made, fonts = 0, {}
owned = []                                         # (t0, t1) of lines whose words an effect draws
if CTAG or HOOK:
    import fx
def line_cues(n):
    a, b2 = segs[n-1]["t0"], segs[n-1]["t1"]; out = []
    for i, c in enumerate(cues):
        t0 = c["t"]; t1 = cues[i+1]["t"] if i+1 < len(cues) else NF/FPS
        if a - 1e-3 <= t0 < b2 - 1e-3: out.append((t0, min(t1, b2), c["text"]))
    return out
if CTAG:
    tc = fx.TaggedCard(sf, JOB, sty, canvas=(W, H))
    for n, v in sorted(CTAG.items()):
        if 0 < n <= len(segs):
            fonts.update(tc.add(segs[n-1]["t0"], segs[n-1]["t1"], tag=v.get("tag", ""), plate=v.get("plate", "green"), words=line_cues(n)))
            owned.append((segs[n-1]["t0"], segs[n-1]["t1"]))
    print(f"  tagged card on line(s) {sorted(CTAG)}")
if BOLD:
    import fx
    bb = fx.BoldBehind(sf, JOB, sty, canvas=(W, H))
    for n in BOLD:
        if 0 < n <= len(segs) and (n - 1) in behind_kind:
            fonts.update(bb.add(segs[n-1]["t0"], segs[n-1]["t1"], words=line_cues(n)))
            owned.append((segs[n-1]["t0"], segs[n-1]["t1"]))
    print(f"  bold behind on line(s) {[n for n in BOLD if (n - 1) in behind_kind]}")
GS_SPANS = [(segs[n-1]["t0"], segs[n-1]["t1"]) for n in GSCR if 0 < n <= len(segs)]
if SPLT:
    import fx
    sp_fx = fx.Split(sf, JOB, sty, canvas=(W, H))
    for n, v in sorted(SPLT.items()):
        if 0 < n <= len(segs):
            ws = [(a, b, w_) for a, b, w_ in line_cues(n)]
            fonts.update(sp_fx.add(segs[n-1]["t0"], segs[n-1]["t1"], step=v.get("step") or "Step #1", words=ws))
            owned.append((segs[n-1]["t0"], segs[n-1]["t1"]))
    print(f"  split on line(s) {sorted(SPLT)}")
hp_fx = None
if PULL and segs:
    import fx
    hp_fx = fx.HookPullback(sf, JOB, sty, canvas=(W, H))
    fonts.update(hp_fx.add(segs[0]["t0"], segs[0]["t1"], label=PULL.get("label", ""), line1=PULL.get("line1", ""),
                           line2=PULL.get("line2", ""), serif_word=PULL.get("serif", "")))
    print("  hook pull-back on the opening line")
if HOOK:
    fh = fx.FullscreenHook(sf, JOB, sty, canvas=(W, H))
    for n, v in sorted(HOOK.items()):
        if 0 < n <= len(segs):
            fonts.update(fh.add(segs[n-1]["t0"], segs[n-1]["t1"], title=v.get("title", ""), serif=v.get("serif", ""), sub=v.get("sub", "")))
            owned.append((segs[n-1]["t0"], segs[n-1]["t1"]))
ti_fx = None
if EFX.get("caption_style") == "interrogator":          # TYPE INTERROGATOR (fx_library): a whole-video caption look
    import fx
    ti_fx = fx.TypeInterrogator(sf, JOB, sty, canvas=(W, H)); print("  captions: the Interrogator style")
for i, c in enumerate(cues):
    t0 = c["t"]; t1 = cues[i+1]["t"] if i+1 < len(cues) else NF/FPS
    if t1 - t0 < 0.04: continue
    if any(a - 1e-3 <= t0 < b - 1e-3 for a, b in owned): continue
    fcp = next((cp for a, b, cp in FCAPS if a - 1e-3 <= t0 < b - 1e-3), None)
    if fcp:                                            # a framed line whose caption sits under or beside the picture
        hx = (fcp.get("color") or "#FFFFFF").lstrip("#")
        left = fcp.get("align") == "left"
        st_ = TextStyle(size=TS * cc.get("size_small", 9.0), color=tuple(int(hx[k:k+2], 16)/255 for k in (0, 2, 4)),
                        align=0 if left else 1, letter_spacing=cc.get("track_small", -40), auto_wrapping=not left, max_line_width=0.82)
        seg = TextSegment(c["text"], trange(US(t0), US(t1-t0)), style=st_, clip_settings=draft.ClipSettings(transform_y=(H/2 - fcp["center_y"])/(H/2)))
        sf.add_segment(seg, "Captions"); fonts[seg.material_id] = bool(c.get("serif")); made += 1; continue
    if ti_fx and not in_behind(t0) and not (gs_fx and any(a - 1e-3 <= t0 < b - 1e-3 for a, b in GS_SPANS)):
        _bgc = bg_at(t0); plate_c = None
        where = "plate" if (c["kind"] == "card" or _bgc) else ("broll" if c["kind"] == "big" else "aroll")
        if where == "plate":
            cname = _bgc or (c.get("colour") or "green")
            plate_c = "#%02X%02X%02X" % tuple(sty["colors"]["paper" if cname == "cream" else "ink"][:3])
        ts = ti_fx.style(where, plate_c); hx = ts["color"].lstrip("#")
        st_ = TextStyle(size=round(ts["px"] / (11.1 * W / 1920), 2), color=tuple(int(hx[k:k+2], 16)/255 for k in (0, 2, 4)),
                        align=1, letter_spacing=cc.get("track_serif", -40) if c.get("serif") else cc.get("track_big", -80),
                        auto_wrapping=True, max_line_width=min(0.95, ts["max_w"] / W))
        seg = TextSegment(c["text"], trange(US(t0), US(t1-t0)), style=st_, clip_settings=draft.ClipSettings(transform_y=(H/2 - ts["cy"])/(H/2)))
        sf.add_segment(seg, "Captions"); fonts[seg.material_id] = bool(c.get("serif")); made += 1; continue
    if gs_fx and any(a - 1e-3 <= t0 < b - 1e-3 for a, b in GS_SPANS):       # green screen: captions above the head
        cs = gs_fx.caption_style(); hx = cs["color"].lstrip("#")
        st_ = TextStyle(size=round(cs["px"] / (11.1 * W / 1920), 2), color=tuple(int(hx[i:i+2], 16)/255 for i in (0, 2, 4)),
                        align=1, letter_spacing=cc.get("track_big", -80), auto_wrapping=True, max_line_width=0.82)
        seg = TextSegment(c["text"], trange(US(t0), US(t1-t0)), style=st_,
                          clip_settings=draft.ClipSettings(transform_x=(cs["cx"] - W/2)/(W/2), transform_y=(H/2 - cs["cy"])/(H/2)))
        sf.add_segment(seg, "Captions"); fonts[seg.material_id] = False; made += 1; continue
    _bg = bg_at(t0)
    _ink = any(0 < int(n) <= len(segs) and segs[int(n)-1]["t0"] - 1e-3 <= t0 < segs[int(n)-1]["t1"] - 1e-3 for n in (EFX.get("ink") or []))
    big, serif = c["kind"] in ("big", "card") or in_behind(t0) or bool(_bg), bool(c.get("serif"))
    on_paper = (_bg == "cream") if _bg else (c.get("colour") == "cream" or (c["kind"] == "card" and c.get("colour") != "green"))
    clip = draft.ClipSettings(
        transform_x = cc.get("x_big", 0.0) if big else cc.get("x_small", 0.0),
        transform_y = ((0.5 - T_EYE) * 2 if (ZON and in_behind(t0)) else
                       (cc.get("y_serif", cc.get("y_big", 0.0)) if serif else (cc.get("y_big", 0.0) if big else cc.get("y_small", 0.0)))))
    style = TextStyle(
        size          = TS * (cc.get("size_serif", 22.0) if serif else (cc.get("size_big", 22.0) if big else cc.get("size_small", 9.0))),
        color         = rgb01(INK if (on_paper or _ink) else WHITE),
        align         = cc.get("align_big", 1) if big else cc.get("align_small", 0),
        letter_spacing= cc.get("track_serif", -40) if serif else (cc.get("track_big", -80) if big else cc.get("track_small", -40)),
        # OFF on the left captions: wrapping shrinks the box to the text and makes left alignment invisible
        auto_wrapping = big, max_line_width = 0.82)
    seg = TextSegment(c["text"], trange(US(t0), US(t1-t0)), style=style, clip_settings=clip)
    sf.add_segment(seg, "Captions"); fonts[seg.material_id] = serif; made += 1

finish(sf, dst, name, W, H, US(NF/FPS), sty, text_fonts=fonts,
       left_inset=float(sty["horizontal"].get("small_left_x") or 160) * (W / 1920.0 if FOUR3 else 1.0))
if fc: print(f"  Screen blend on {fc.finish(dst)} flash(es)")
if hp_fx:
    # the opening clip's scale follows the pull-back curve (1.44 -> 1.0 over 2.952s on the measured bezier),
    # multiplied onto its punch/eye-lock scale. Keyframes are timed from the clip's source in-point, so the
    # new ones are offset from the first existing key.
    import copy as _cp, uuid as _uu
    ks = hp_fx.keys(0.0)
    for fn in ("draft_info.json", "draft_content.json"):
        jj = json.loads((dst/fn).read_text())
        ar = next(tr for tr in jj["tracks"] if tr.get("name") == "A-roll"); sg = ar["segments"][0]
        dur_us = sg["target_timerange"]["duration"]
        for kl in sg.get("common_keyframes") or []:
            if kl["property_type"] != "KFTypeScaleX": continue
            k0 = kl["keyframe_list"][0]; base, t_base = k0["values"][0], int(k0["time_offset"])
            new = []
            for tt, kk in ks:
                if US(tt) > dur_us: break
                e = _cp.deepcopy(k0); e["id"] = str(_uu.uuid4()).upper(); e["time_offset"] = t_base + US(tt); e["values"] = [base * kk]; new.append(e)
            last = kl["keyframe_list"][-1]
            if int(last["time_offset"]) > new[-1]["time_offset"]: new.append(last)
            kl["keyframe_list"] = new
        (dst/fn).write_text(json.dumps(jj, ensure_ascii=False))
if FSPANS:
    from frame_fit import fit
    print(f"  frame: {fit(dst, FSPANS, text_tracks=('Captions',))} clip(s) and captions fitted into the window")
if FSPANS_MOVE:
    from frame_fit import fit
    print(f"  frame: {fit(dst, FSPANS_MOVE)} clip(s) fitted into the window (captions moved under or beside it)")

print(f"\n{name}")
print(f"  A-roll {len(segs)} clips · B-roll {len(ins)} · cards {len(cards)} · captions {made} (EDITABLE)")
print(f"  {dst}")
print("  Open CapCut and it is on the home screen.")
