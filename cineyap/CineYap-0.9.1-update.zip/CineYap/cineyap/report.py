#!/usr/bin/env python3
"""report.py ["what happened"] — bundle what is needed to see when something breaks, into one zip.

    ./vu-py cineyap/report.py "the vertical build stopped"   -> ~/Desktop/CineYap-report-<date>.zip

In the zip: the version, this Mac (macOS, chip, screen, CapCut version, Python, ffmpeg), the setup check,
the install/update logs, the Studio log, and for the most recent videos their build notes (the EDL, the
plan files, effects.json, board notes; the cut list quotes the kept lines) and the last lines of their
logs. NOT in the zip: video, audio, full transcripts, .env or any API key. Nothing is sent anywhere; the person sends the zip themselves.
"""
import json, pathlib, platform, subprocess, sys, time, zipfile
ROOT = pathlib.Path(__file__).resolve().parent.parent
what = " ".join(sys.argv[1:]).strip()
def sh(cmd):
    try: return subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30).stdout.strip()
    except Exception as e: return f"({e})"
info = {
    "when": time.strftime("%Y-%m-%d %H:%M"), "what_happened": what,
    "version": json.loads((ROOT/"product.json").read_text()).get("version") if (ROOT/"product.json").exists() else "?",
    "macos": platform.mac_ver()[0], "chip": platform.machine(),
    "screens": sh("system_profiler SPDisplaysDataType | grep -i resolution"),
    "capcut": sh("defaults read /Applications/CapCut.app/Contents/Info.plist CFBundleShortVersionString"),
    "python": sh(f"'{ROOT}/.venv/bin/python' --version"), "ffmpeg": sh("ffmpeg -version | head -1"),
    "node": sh("node --version"), "git": sh(f"git -C '{ROOT}' log --oneline -1"),
    "config_keys_set": sorted(k for k, v in json.loads((ROOT/'cineyap/config.json').read_text()).items() if v) if (ROOT/'cineyap/config.json').exists() else [],
}
SAFE = ("edl.json", "plan.json", "effects.json", "board_notes.md", "framing.json", "poster.json", "panel.json",
        "COPY.txt", "backgrounds.json", "template.json", "plates.json", "inserts.json", "board_edits.applied.json")
out = pathlib.Path.home()/"Desktop"/f"CineYap-report-{time.strftime('%Y%m%d-%H%M')}.zip"
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("about.json", json.dumps(info, indent=1))
    z.writestr("check-setup.txt", sh(f"cd '{ROOT}' && bash ./check-setup.sh"))
    for f in ("_local/update.log", "_local/studio.log", "_local/install.log"):
        if (ROOT/f).exists(): z.writestr(f, "\n".join((ROOT/f).read_text(errors="replace").splitlines()[-400:]))
    jobs = sorted([p for p in (ROOT/"projects").iterdir() if p.is_dir()], key=lambda p: -p.stat().st_mtime)[:3] if (ROOT/"projects").exists() else []
    for J in jobs:
        for p in J.rglob("*"):
            if p.is_file() and p.name in SAFE and "transcripts" not in p.parts:
                z.write(p, f"projects/{p.relative_to(ROOT/'projects')}")
        for p in J.rglob("*.log"):
            z.writestr(f"projects/{p.relative_to(ROOT/'projects')}", "\n".join(p.read_text(errors="replace").splitlines()[-200:]))
print(f"{out}\nPost this file in the CineYap testers space in Circle with one line about what you were doing. It has no video, audio or keys (the cut lists quote the lines you kept).")
