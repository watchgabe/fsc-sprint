#!/usr/bin/env python3
"""mkposter.py — the 4:3 poster format: a talking head with a magazine-style title over it.

    ./vu-py cineyap/mkposter.py <job>              1440x1080
    ./vu-py cineyap/mkposter.py <job> --vertical   1080x1920, same poster.json

Takes a finished CineYap cut (edit/edl.json) and lays it out at 1440x1080: the A-roll filled to 4:3 and
framed by face detection, and a poster held for the whole video. A two-column headline (left words
left-aligned, right words right-aligned, mirrored margins), a tiny centred credit line under it, and a
two-line footer bottom-left. Every line is an editable CapCut text object. Layout in the pack's
"poster" block, measured off a reference reel.

projects/<job>/poster/poster.json (written with placeholders the first time, then edit it):
  {"L1": "", "L2": "", "R1": "", "R2": "", "tagline": "", "footer": ["", ""]}
  The headline reads L1 L2 R1 R2: L1 over L2 on the left, R1 over R2 on the right.
"""
import json, pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
import config

args = [a for a in sys.argv[1:] if not a.startswith("--")]
if not args: sys.exit("usage: mkposter.py <job> [--vertical]")
job = args[0]; JOB = PROJECTS/job; B = JOB/"build"; P = JOB/"poster"; P.mkdir(exist_ok=True)
sty = __import__("style").load()
VERT = "--vertical" in sys.argv
PS = sty["poster_vertical" if VERT else "poster"]; W, H = PS["canvas"]; FPS = 24000/1001
edl = json.load(open(JOB/"edit/edl.json")); stem = list(edl["sources"])[0]
SRC = B/"graded_source_4k.mp4" if (B/"graded_source_4k.mp4").exists() else B/"graded_source.mp4"

cfg_path = P/"poster.json"
if not cfg_path.exists():
    _h = (__import__("style").brand().get("handle") or "").strip()
    cfg_path.write_text(json.dumps({"L1": "", "L2": "", "R1": "", "R2": "", "tagline": "", "footer": ["©2026", "ALL RIGHTS RESERVED"],
        "corner_left": f"by **{_h}**" if _h else "",
        "_note": "Headline reads L1 L2 R1 R2. Short words on the right top (R1) look best. Copy goes through the brain's writing rules."}, indent=1))
    sys.exit(f"wrote {cfg_path} - fill in the headline, then run this again")
cfg = json.load(open(cfg_path))

def probe(p):
    d = json.loads(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height",
                                   "-of","json",str(p)], capture_output=True, text=True).stdout)
    return int(d["streams"][0]["width"]), int(d["streams"][0]["height"])
def frames(p):
    return int(subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-count_frames","-show_entries",
        "stream=nb_read_frames","-of","csv=p=0",str(p)], capture_output=True, text=True).stdout.strip())

segs, t = [], 0
for i, r in enumerate(edl["ranges"]):
    n = frames(JOB/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4")
    segs.append({"t0": t/FPS, "t1": (t+n)/FPS, "s0": r["start"]}); t += n
TOTAL = t/FPS

# ---- framing: match the reference's eye line, face size and offset (Apple Vision on the first take)
import Vision, Quartz
from Foundation import NSURL
fr = P/"_face.png"
subprocess.run(["ffmpeg","-v","error","-y","-ss",f"{segs[0]['s0']+1.0:.2f}","-i",str(SRC),"-frames:v","1",str(fr)], check=True)
img = Quartz.CGImageSourceCreateImageAtIndex(Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(fr)), None), 0, None)
req = Vision.VNDetectFaceRectanglesRequest.alloc().init()
Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None).performRequests_error_([req], None)
cw, ch = probe(SRC)
fit, fill = min(W/cw, H/ch), max(W/cw, H/ch)
FR = PS["framing"]
if req.results():
    b = max(req.results(), key=lambda o: o.boundingBox().size.width).boundingBox()
    fx, fy, fh = b.origin.x + b.size.width/2, 1-(b.origin.y+b.size.height*0.62), b.size.height
    z_face = FR["face_h"] / (fh * (ch*fill) / H)                       # zoom that matches the face size
    # moving the eyes UP needs room below the frame (bottom edge), DOWN needs room above (top edge)
    t_ = FR["eyes_y"]
    z_eyes = (1 - t_) / (1 - fy) if fy > t_ else (t_ / fy if fy < t_ else 1.0)
    # the eye line wins over face size (it is what makes the frame read like the reference), capped so a
    # low-sitting subject is not blown up
    z = max(1.0, z_face, min(z_eyes, float(FR.get("max_zoom", 1.25))))
else:
    fx, fy, fh, z = 0.5, 0.4, None, 1.0; print("  NOTE: no face found - centre framing")
dW, dH = cw*fill*z, ch*fill*z
dx = W*FR["face_x"] - (W/2 + (fx-0.5)*dW); dx = max(-(dW-W)/2, min((dW-W)/2, dx))
dy = H*FR["eyes_y"] - (H/2 + (fy-0.5)*dH); dy = max(-(dH-H)/2, min((dH-H)/2, dy))
eyes_at = (H/2 + (fy-0.5)*dH + dy) / H
print(f"  framing: face h {fh and fh*(ch*fill*z)/H:.3f} (target {FR['face_h']}), eyes at {eyes_at:.2f} (target {FR['eyes_y']}), zoom {z:.2f}")

import pycapcut as draft
from pycapcut import VideoSegment, TextSegment, TextStyle, trange
from capcut_draft import start, finish, US
name = f"{job} (Poster{' Vertical' if VERT else ''})"
sf, dst = start(name, JOB, W, H)
sf.add_track(draft.TrackType.video, "A-roll", relative_index=0)
for k, nm in enumerate(("Headline L1", "Headline L2", "Headline R1", "Headline R2", "Tagline", "Footer 1", "Footer 2", "Corner left", "Corner right"), 1):
    sf.add_track(draft.TrackType.text, nm, relative_index=k)
for s in segs:
    d = s["t1"] - s["t0"]
    sf.add_segment(VideoSegment(str(SRC), trange(US(s["t0"]), US(d)), source_timerange=trange(US(s["s0"]), US(d)),
                                clip_settings=draft.ClipSettings(scale_x=fill/fit*z, scale_y=fill/fit*z,
                                                                 transform_x=dx/(W/2), transform_y=-dy/(H/2))), "A-roll")

# ---- the poster. Each line gets a box anchored at its edge, so left lines start on the left margin and
# right lines end on the right margin whatever the words are.
unit = float(sty["carousel"]["capcut"].get("px_per_unit_1920w", 11.1)) * (W/1920)
WHITE = (1.0, 1.0, 1.0)
place, fonts = {}, {}
def line(track, text, px, y, align, anchor_x, box_w):
    if not text: return
    text = text.upper() if PS["headline"].get("caps") else text
    st = TextStyle(size=round(px/unit, 2), color=WHITE, align=align, letter_spacing=-1, auto_wrapping=False, max_line_width=0.95)
    seg = TextSegment(text, trange(0, US(TOTAL)), style=st, clip_settings=draft.ClipSettings(transform_y=(H/2 - y*H)/(H/2)))
    sf.add_segment(seg, track); fonts[seg.material_id] = False
    centre = anchor_x*W + box_w/2 if align == 0 else (anchor_x*W - box_w/2 if align == 2 else W/2)
    place[seg.material_id] = (box_w, centre)
HL = PS["headline"]; half = (HL["right_x"] - HL["left_x"]) * W
line("Headline L1", cfg.get("L1"), HL["px"], HL["rows_y"][0], 0, HL["left_x"], half)
line("Headline L2", cfg.get("L2"), HL["px"], HL["rows_y"][1], 0, HL["left_x"], half)
line("Headline R1", cfg.get("R1"), HL["px"], HL["rows_y"][0], 2, HL["right_x"], half)
line("Headline R2", cfg.get("R2"), HL["px"], HL["rows_y"][1], 2, HL["right_x"], half)
line("Tagline", cfg.get("tagline"), PS["tagline"]["px"], PS["tagline"]["y"], 1, 0.5, 0.8*W)
FT = PS["footer"]; foot = cfg.get("footer") or ["", ""]
line("Footer 1", foot[0] if len(foot) > 0 else "", FT["px"], FT["rows_y"][0], 0, FT["x"], 0.5*W)
line("Footer 2", foot[1] if len(foot) > 1 else "", FT["px"], FT["rows_y"][1], 0, FT["x"], 0.5*W)

# ---- the signature corners: "**bold** regular" markup, one text object per corner
import re as _re
CR = PS.get("corners", {}); REG = CR.get("regular_font", "/System/Library/Fonts/Helvetica.ttc")
def marked(text):
    """'by **@watch.gabe**' -> plain text + (start, end, regular_font) for every NON-bold run."""
    plain, runs, pos = "", [], 0
    for k, part in enumerate(_re.split(r"\*\*", text)):
        if part and k % 2 == 0: runs.append((pos, pos + len(part), REG))
        plain += part; pos += len(part)
    return plain, runs
def corner(track, text, px, y, align, anchor_x, box_w):
    if not text: return
    plain, runs = marked(text)
    st = TextStyle(size=round(px/unit, 2), color=WHITE, align=align, letter_spacing=0, auto_wrapping=False, max_line_width=0.95)
    seg = TextSegment(plain, trange(0, US(TOTAL)), style=st, clip_settings=draft.ClipSettings(transform_y=(H/2 - y*H)/(H/2)))
    sf.add_segment(seg, track); fonts[seg.material_id] = runs
    centre = anchor_x*W + box_w/2 if align == 0 else anchor_x*W - box_w/2
    place[seg.material_id] = (box_w, centre)
if cfg.get("corner_left"):
    corner("Corner left", cfg["corner_left"], CR["left"]["px"], CR["left"]["y"], CR["left"].get("align", 0), CR["left"]["x"], 0.45*W)
if cfg.get("corner_right"):
    n = cfg["corner_right"].count("\n") + 1; R = CR["right"]
    corner("Corner right", cfg["corner_right"], R["px"], R["y_last"] - R["pitch"]*(n-1)/2, R.get("align", 2), R["x"], 0.45*W)

finish(sf, dst, name, W, H, US(TOTAL), sty, text_fonts=fonts, left_inset=None)

# Every poster line gets a fixed-width box (CapCut otherwise shrink-wraps the text and centres it, which
# makes left and right alignment invisible), positioned by its centre. The box factor is the one the
# carousel calibrated, scaled to this canvas width.
k = (1674.0/643.0) * (W/1920.0)
for fn in ("draft_info.json", "draft_content.json"):
    jj = json.loads((dst/fn).read_text())
    for tm in jj["materials"]["texts"]:
        if tm["id"] in place:
            tm["fixed_width"] = place[tm["id"]][0] / k; tm["force_apply_line_max_width"] = True
    for tr in jj["tracks"]:
        if tr["type"] != "text": continue
        for sg in tr["segments"]:
            if sg["material_id"] in place:
                sg["clip"]["transform"]["x"] = (place[sg["material_id"]][1] - W/2) / (W/2)
                sg["clip"]["scale"] = {"x": 1.0, "y": 1.0}
    (dst/fn).write_text(json.dumps(jj, ensure_ascii=False))

print(f"\n{name}\n  {TOTAL:.1f}s · {len(segs)} A-roll clips · {len(place)} poster lines held for the whole video · {W}x{H}")
print(f"  A-roll source: {SRC.name}\n  draft: {dst}\n  edit poster/poster.json to change the words, then run this again")
