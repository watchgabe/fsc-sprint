#!/usr/bin/env python3
"""make_master.py <job> — the whole take, graded, at its NATIVE resolution, for the CapCut timeline.

Gabe shoots 4K and edits on a 1080 timeline. The A-roll in the draft used to be graded_source.mp4, a
1080 copy, so every punch-in past 100% enlarged a 1080 picture and went soft. This writes
build/graded_master.mp4 at the source's own size (3840x2160 for 4K) with the same LUT and the same
frames, frame for frame, as graded_source.mp4. CapCut fits it to the 1080 frame at 100%, so a punch
up to 200% is still sharp. mkcapcut.py uses it whenever it exists. A few minutes for a 7-minute take.
"""
import json, pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PROJECTS
job = sys.argv[1]; J = PROJECTS/job; B = J/"build"
src = list(json.load(open(J/"edit/edl.json"))["sources"].values())[0]
lut = J/"lut.cube"; out = B/"graded_master.mp4"; tmp = B/"graded_master.building.mp4"
# iPhone footage is HDR (HLG) by default, and many cameras shoot PQ. Without tone mapping an 8-bit copy keeps
# the HDR tags and every player and CapCut shows it washed out or blown. Tone map to Rec.709 first. A log LUT
# is for log footage: on HDR footage it blows the picture out, so it is skipped there (and said so).
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent/"helpers"))
from render import is_hdr_source, TONEMAP_CHAIN
HDR = is_hdr_source(pathlib.Path(src))
chain = []
if HDR:
    chain.append(TONEMAP_CHAIN); print("  HDR footage (iPhone or PQ): tone mapped to Rec.709")
    if lut.exists(): print("  NOTE: the LUT was skipped - it is for log footage, and this take is HDR")
elif lut.exists(): chain.append(f"lut3d=file={lut}")
vf = ",".join(chain) or "null"
tmp.unlink(missing_ok=True)
r = subprocess.run(["ffmpeg","-v","error","-y","-i",src,"-vf",vf,"-c:v","h264_videotoolbox","-b:v","60M",
                    "-pix_fmt","yuv420p","-color_primaries","bt709","-color_trc","bt709","-colorspace","bt709","-c:a","aac","-b:a","192k","-movflags","+faststart",str(tmp)])
if r.returncode: tmp.unlink(missing_ok=True); sys.exit("master encode failed - is the original take reachable?")
tmp.rename(out)
w = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=width,height,nb_frames",
                    "-of","csv=p=0",str(out)], capture_output=True, text=True).stdout.strip()
print(f"{out.name}: {w}  ({out.stat().st_size/1e9:.2f} GB)")
