#!/usr/bin/env python3
"""package.py <version> [notes] — build the CineYap zip testers install, from the last commit.

    ./vu-py cineyap/package.py 0.9.1 "Brand tab, iPhone footage"
        -> ~/Developer/CineYap-package/CineYap-<version>.zip          the install, with samples/ (for testers)
           ~/Developer/CineYap-package/CineYap-<version>-update.zip   code only, what /update downloads
           ~/Developer/CineYap-package/version.json                  the feed, pointing at the update zip

Built from `git archive HEAD`, so only committed code ships (never config.json, brand.json, .env, projects/).
Adds the Library's preview clips (ignored by git as *.mp4) and drops the measurement references.
Then host the update zip and version.json at fscreative.live/cineyap/ (~/code/fsc-sprint/cineyap/, commit, push,\nvercel deploy --prod --yes). The install zip goes to testers directly.
"""
import json, pathlib, shutil, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent.parent
if len(sys.argv) < 2: sys.exit(__doc__)
ver, notes = sys.argv[1], (sys.argv[2] if len(sys.argv) > 2 else "")
OUT = pathlib.Path.home()/"Developer/CineYap-package"; OUT.mkdir(exist_ok=True)
pj = json.loads((ROOT/"product.json").read_text())
if pj["version"] != ver: sys.exit(f"product.json says {pj['version']}: set it to {ver} and commit first")
st = OUT/"_staging"; shutil.rmtree(st, ignore_errors=True); st.mkdir()
subprocess.run(f"git -C '{ROOT}' archive --prefix=CineYap/ HEAD | tar -x -C '{st}'", shell=True, check=True)
pkg = st/"CineYap"
for d in ("cineyap/library/refs", "cineyap/library/previews_in"): shutil.rmtree(pkg/d, ignore_errors=True)
for p in (ROOT/"cineyap/library/previews").glob("*.mp4"): shutil.copy2(p, pkg/"cineyap/library/previews"/p.name)
for d in ("projects", "inbox"): (pkg/d).mkdir(exist_ok=True)
def zipit(z):
    z.unlink(missing_ok=True)
    subprocess.run(["ditto", "-c", "-k", "--norsrc", "--noextattr", "--keepParent", str(pkg), str(z)], check=True)
    return z
# the update zip: code only. update.py never touches samples/, so updates do not carry them.
up = zipit(OUT/f"CineYap-{ver}-update.zip")
# the install zip: the update plus the two sample takes /try edits (ROOT/samples, ignored by git)
if (ROOT/"samples").is_dir():
    (pkg/"samples").mkdir(exist_ok=True)
    for p in (ROOT/"samples").glob("*.mp4"): shutil.copy2(p, pkg/"samples"/p.name)
full = zipit(OUT/f"CineYap-{ver}.zip")
base = pj["update_url"].rsplit("/", 1)[0]
(OUT/"version.json").write_text(json.dumps({"version": ver, "released": time.strftime("%Y-%m-%d"), "notes": notes,
                                             "download": f"{base}/{up.name}"}, indent=1))
shutil.rmtree(st)
print(f"install  {full}  ({full.stat().st_size/1e6:.1f} MB)  -> testers (Circle)")
print(f"update   {up}  ({up.stat().st_size/1e6:.1f} MB)  + {OUT/'version.json'}  -> host both at {base}/")
