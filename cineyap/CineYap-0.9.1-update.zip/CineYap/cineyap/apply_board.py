#!/usr/bin/env python3
"""apply_board.py <job> — apply what the Board sent, rebuild the CapCut draft, verify, print the table.

The Board's Send message ends with a fenced ```board json block. Save that block to
projects/<job>/edit/board_edits.json and run this. Every button lands the same way every time:

  cut      [N, ...]                 lines removed from the edit (edl.json), then re-render
  zoom     {"N": "tight"|"wide"}    framing for that line            -> effects.json "framing"
  behind   [N, ...]                 text behind subject              -> make_behind.py + effects "behind"
  bg       {"N": "green"|"cream"}   plain plate behind the captions  -> effects "bg"
  flash    [N, ...]                 flash + click at the line start  -> effects "flash"
  broll    {"swap": {"b2": "<file>"}, "remove": ["b5"], "add": [{"take": N, "clip": "<file>"}]}
  cards    {"c1": {"words": [...], "accent": [i, ...], "colour": "green"|"cream", "remove": bool}}
  notes    {"N": "text"}            free text: printed for Claude, never applied blindly
  add      {"flash": [N], "behind": [N], "bg": {"N": "green"}}   from the Library: merged, never replaces

All of it is stored in build/effects.json, the Board's memory for this video, so a rebuild for any
other reason keeps every choice. B-roll names from the Board are bare filenames (a browser never
reveals a path); they are found under config broll_clips, then broll_root.
"""
import json, pathlib, shutil, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
import config

if len(sys.argv) < 2: sys.exit("usage: apply_board.py <job>")
job = sys.argv[1]; J = PROJECTS/job; B = J/"build"; E = J/"edit"
src = E/"board_edits.json"
if "--recut" in sys.argv and not src.exists(): src.write_text("{}")
if not src.exists(): sys.exit(f"no {src} - save the ```board block from the Board's message there first")
ed = json.load(open(src))
PY = str(PKG/".venv/bin/python")
def run(args, cwd=None, label=""):
    print(f"  > {label or ' '.join(map(str, args[-2:]))}")
    r = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    if r.returncode:
        sys.stdout.write(r.stdout[-2000:]); sys.stderr.write(r.stderr[-2000:])
        sys.exit(f"stopped: {label} failed")
    return r.stdout

efx = json.load(open(B/"effects.json")) if (B/"effects.json").exists() else {}

# ---- B-roll names -> files
roots = [pathlib.Path(p) for p in (config.opt("broll_clips"), config.opt("broll_root")) if p]
def find_clip(name):
    p = pathlib.Path(name)
    if p.is_absolute() and p.exists(): return p
    stem = pathlib.Path(name).name
    for r in roots:
        hits = [h for h in r.rglob(stem)] if r.exists() else []
        if not hits and "/" in name: hits = [r/name] if (r/name).exists() else []
        if hits: return hits[0]
    sys.exit(f"B-roll '{name}' not found under {', '.join(map(str, roots))} - tell Claude which folder it is in")
def cut_asset(path, key, need=12.0):
    """the clip at delivery size with room to spare, so the cut guard can hold it to a cut"""
    out = B/"assets"/f"board_{key}.mp4"; out.parent.mkdir(parents=True, exist_ok=True)
    W, H = 1920, 1080          # the canvas; the clip keeps its own resolution (only cropped to the shape)
    run(["ffmpeg","-y","-v","error","-i",str(path),"-t",f"{need}","-an","-vf",
         f"crop='min(iw,ih*{W/H:.4f})':'min(ih,iw/{W/H:.4f})',scale='if(lt(iw,{W}),{W},iw)':-2,fps=24000/1001",
         "-c:v","libx264","-crf","16","-pix_fmt","yuv420p",str(out)], label=f"B-roll {key}: {path.name}")
    d = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",str(out)],
                             capture_output=True, text=True).stdout.strip() or 0)
    return str(out), d

br = efx.setdefault("broll", {"swap": {}, "remove": [], "add": []})
if "--recut" in sys.argv:                      # re-cut every clip the Board placed (e.g. after a change to how assets are cut)
    for bid, sw in br.get("swap", {}).items(): sw["file"], sw["asset_dur"] = cut_asset(find_clip(sw["clip"]), bid)
    for k, a in enumerate(br.get("add", []), 1): a["file"], a["asset_dur"] = cut_asset(find_clip(a["clip"]), f"add{k}")
for bid, name in (ed.get("broll", {}).get("swap") or {}).items():
    f, d = cut_asset(find_clip(name), bid); br["swap"][bid] = {"file": f, "asset_dur": d, "clip": find_clip(name).name}
for bid in ed.get("broll", {}).get("remove") or []:
    if bid not in br["remove"]: br["remove"].append(bid)
for k, a in enumerate(ed.get("broll", {}).get("add") or [], 1):
    if any(x["take"] == int(a["take"]) and x["clip"] == pathlib.Path(a["clip"]).name for x in br["add"]): continue   # a retry, not a second clip
    key = f"add{len(br['add'])+1}"; f, d = cut_asset(find_clip(a["clip"]), key)
    br["add"].append({"take": int(a["take"]), "file": f, "asset_dur": d, "clip": find_clip(a["clip"]).name})

for n, lvl in (ed.get("zoom") or {}).items(): efx.setdefault("framing", {})[str(n)] = lvl
# BG, flash and behind arrive as the Board's FULL current state for those buttons: replace, never merge,
# so switching one off on the Board takes it off the video.
if "bg" in ed: efx["bg"] = {str(n): c for n, c in ed["bg"].items() if c}
if "flash" in ed: efx["flash"] = sorted({int(n) for n in ed["flash"]})
for cid, c in (ed.get("cards") or {}).items(): efx.setdefault("cards", {})[cid] = c
if "behind" in ed: efx["behind"] = [{"take": int(n)} for n in ed["behind"]]
if "frame" in ed: efx["frame"] = {str(n): v for n, v in ed["frame"].items() if v and v.get("look")}   # full state, like bg
if "card_tag" in ed: efx["card_tag"] = {str(n): v for n, v in ed["card_tag"].items() if v}          # full state
if "caption_style" in ed: efx["caption_style"] = ed["caption_style"] or ""      # "interrogator" or "" (the pack's own)
if "pullback" in ed: efx["pullback"] = ed["pullback"] or {}              # the opening line only
if "split" in ed: efx["split"] = {str(n): (v or {}) for n, v in ed["split"].items()}
if "greenscreen" in ed: efx["greenscreen"] = {str(n): v for n, v in ed["greenscreen"].items() if v and v.get("clip")}
if "bold_behind" in ed: efx["bold_behind"] = sorted({int(n) for n in ed["bold_behind"]})
if "hook" in ed: efx["hook"] = {str(n): v for n, v in ed["hook"].items() if v and (v.get("title") or v.get("sub"))}
# "add" comes from the Library: one effect on one line, merged into what the video already has.
add = ed.get("add") or {}
if add.get("flash"): efx["flash"] = sorted(set(efx.get("flash", [])) | {int(n) for n in add["flash"]})
for n in add.get("behind") or []:
    if int(n) not in [e["take"] for e in efx.get("behind", [])]: efx.setdefault("behind", []).append({"take": int(n)})
for n, c in (add.get("bg") or {}).items(): efx.setdefault("bg", {})[str(n)] = c

# ---- cuts: renumber every per-line choice, then re-render the edit
cuts = sorted({int(n) for n in ed.get("cut") or []}, reverse=True)
if cuts:
    # An interrupted run leaves edl.before-board.json behind: start from it, or the cut is applied twice.
    bk = E/"edl.before-board.json"
    if not bk.exists(): shutil.copy(E/"edl.json", bk)
    edl = json.load(open(bk))
    for n in cuts: del edl["ranges"][n-1]
    json.dump(edl, open(E/"edl.json", "w"), indent=2)
    def renum(n):
        n = int(n); return n - sum(1 for c in cuts if c < n) if n not in cuts else None
    for key in ("framing", "bg", "frame", "card_tag", "hook", "greenscreen", "split"):
        efx[key] = {str(renum(k)): v for k, v in efx.get(key, {}).items() if renum(k)}
    efx["flash"] = sorted({renum(n) for n in efx.get("flash", []) if renum(n)})
    efx["bold_behind"] = sorted({renum(n) for n in efx.get("bold_behind", []) if renum(n)})
    efx["behind"] = [{"take": renum(e["take"])} for e in efx.get("behind", []) if renum(e["take"])]
    br["add"] = [dict(a, take=renum(a["take"])) for a in br["add"] if renum(a["take"])]
    print(f"cut line(s) {sorted(cuts)}: re-rendering the edit")
    run([str(PKG/"vu"), "render.py", str(E/"edl.json"), "-o", str(B/"base_clean.mp4")], label="render the cut")
    run([PY, "words.py"], cwd=B, label="word timeline")
    run([PY, "build_layers.py"], cwd=B, label="captions and B-roll from the plan")
    for f in ("cues.json.bak", "inserts.json.bak", "plates.json"): (B/f).unlink(missing_ok=True)
    for f in (B/"assets"/"behind").glob("sub_line*.mov"): f.unlink()     # line numbers moved: re-cut every subject
    for f in (B/"assets"/"behind").glob("sub_line*.webm"): f.unlink()
    run([PY, str(PKG/"cineyap/subject_zones.py"), job], label="find the subject")
json.dump(efx, open(B/"effects.json", "w"), indent=1)

# ---- text behind subject: a cutout for every behind line that does not have one yet
for e in efx.get("behind", []):
    mov = B/"assets"/"behind"/f"sub_line{int(e['take']):02d}.mov"
    if not mov.exists(): run([PY, str(PKG/"cineyap/make_behind.py"), job, str(e["take"])], label=f"cut out the subject on line {e['take']}")

# ---- rebuild and verify
run([PY, str(PKG/"cineyap/cut_guard.py")], cwd=B, label="cut guard")
import os as _os
_scratch = bool(_os.environ.get("CINEYAP_DRAFTS"))     # building into a scratch folder: leave CapCut alone
if not _scratch: subprocess.run(["osascript","-e",'tell application "CapCut" to quit'], capture_output=True)
for _ in range(0 if _scratch else 30):
    if subprocess.run(["pgrep","-x","CapCut"], capture_output=True).returncode: break
    subprocess.run(["sleep","0.5"])
if not _scratch and not subprocess.run(["pgrep","-x","CapCut"], capture_output=True).returncode:
    subprocess.run(["killall","CapCut"], capture_output=True); subprocess.run(["sleep","3"])   # CapCut autosaves; it sometimes answers quit with 'user canceled'
if not _scratch and not subprocess.run(["pgrep","-x","CapCut"], capture_output=True).returncode:
    sys.exit("CapCut is still open and would overwrite the new draft. Quit it and run this again.")
F43 = ["--4x3"] if "--4x3" in sys.argv else []        # the same edits on the 1440x1080 draft
out = run([PY, str(PKG/"cineyap/mkcapcut.py")] + F43, cwd=B, label="build the CapCut draft")
print("\n".join(l for l in out.splitlines() if l.strip().startswith(("punch", "eye", "text behind", "flash", "background", "board", "NOTE"))))
v = subprocess.run([PY, str(PKG/"cineyap/verify_cuts.py"), job] + F43, capture_output=True, text=True)
print(v.stdout.strip().splitlines()[-1] if v.stdout.strip() else v.stderr[-400:])
notes = ed.get("notes") or {}
if notes:
    print("\nNOTES FOR CLAUDE (not applied automatically):")
    for n, t in notes.items(): print(f"  line {n}: {t}")
src.rename(E/f"board_edits.applied.json")
if (E/"edl.before-board.json").exists():           # applied: the next Board round starts from this edit
    import time; (E/"edl.before-board.json").rename(E/f"edl.before-board.{time.strftime('%Y%m%d-%H%M%S')}.json")
print()
print(subprocess.run([PY, str(PKG/"cineyap/build_review.py"), job, "--table"], capture_output=True, text=True).stdout)
