#!/usr/bin/env python3
"""compare_text.py — read the on-screen text of two edits and line them up word by word.

    compare_text.py <reference.mp4> <mine.mov> [--step 0.25] [--until 80] [--json out.json]

Both videos are OCR'd (Apple Vision, on this Mac) at the same instants. Each word that appears in both
is matched in order of appearance, and for every match it prints the reference's box next to yours:
centre y, width and height as fractions of the frame, and the size ratio. A ratio of 1.00 and a y
difference near 0 means that piece of text is a copy. Cuts can differ: matching is by word, not time.
"""
import json, re, subprocess, sys, pathlib, tempfile
import Vision, Quartz
from Foundation import NSURL

args = [a for a in sys.argv[1:] if not a.startswith("--")]
REF, MINE = args[:2]
opt = lambda k, d: type(d)(sys.argv[sys.argv.index(k)+1]) if k in sys.argv else d
STEP, UNTIL, OUT = opt("--step", 0.25), opt("--until", 80.0), opt("--json", "")

def ocr(path):
    img = Quartz.CGImageSourceCreateImageAtIndex(Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(path)), None), 0, None)
    req = Vision.VNRecognizeTextRequest.alloc().init()
    req.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate); req.setUsesLanguageCorrection_(False)
    Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(img, None).performRequests_error_([req], None)
    out = []
    for o in req.results() or []:
        c = o.topCandidates_(1)[0]; bb = o.boundingBox()
        if c.confidence() < 0.5: continue
        out.append({"t": str(c.string()), "x": bb.origin.x, "y": 1 - bb.origin.y - bb.size.height, "w": bb.size.width, "h": bb.size.height})
    return out

def scan(video):
    tmp = pathlib.Path(tempfile.mkdtemp())
    subprocess.run(["ffmpeg", "-v", "error", "-i", video, "-t", str(UNTIL), "-vf", f"fps=1/{STEP},scale=540:-2",
                    str(tmp/"f%05d.png")], check=True)
    rows = []
    for i, f in enumerate(sorted(tmp.glob("f*.png"))):
        rows.append({"t": round(i*STEP, 3), "text": [b for b in ocr(f) if b["h"] > 0.012]})
    return rows

norm = lambda s: re.sub(r"[^a-z0-9]", "", s.lower())
def events(rows):
    """each distinct appearance of a line: the first frame it shows, its box there"""
    ev, live = [], {}
    for r in rows:
        now = {}
        for b in r["text"]:
            k = norm(b["t"])
            if len(k) < 2: continue
            now[k] = b
            if k not in live: ev.append({"t": r["t"], "key": k, "text": b["t"], "cy": b["y"] + b["h"]/2, "w": b["w"], "h": b["h"]})
        live = now
    return ev

R, M = scan(REF), scan(MINE)
er, em = events(R), events(M)
used, pairs = set(), []
for a in er:
    best = None
    for j, b in enumerate(em):
        if j in used or b["key"] != a["key"]: continue
        if abs(b["t"] - a["t"]) > 8: continue
        if best is None or abs(b["t"] - a["t"]) < abs(em[best]["t"] - a["t"]): best = j
    if best is not None: used.add(best); pairs.append((a, em[best]))
print(f"{'word':22s} {'ref t':>6s} {'mine t':>6s} | {'ref y':>6s} {'mine y':>6s} {'dy':>6s} | {'w ratio':>7s} {'h ratio':>7s}")
for a, b in pairs:
    print(f"{a['text'][:22]:22s} {a['t']:6.2f} {b['t']:6.2f} | {a['cy']:6.3f} {b['cy']:6.3f} {b['cy']-a['cy']:+6.3f} | {b['w']/a['w']:7.2f} {b['h']/a['h']:7.2f}")
miss_r = [a["text"] for a in er if not any(a is p[0] for p in pairs)]
miss_m = [b["text"] for j, b in enumerate(em) if j not in used]
print(f"\n{len(pairs)} matched · only in reference: {len(miss_r)} · only in mine: {len(miss_m)}")
print("  ref only:", ", ".join(miss_r[:60]))
print("  mine only:", ", ".join(miss_m[:60]))
if OUT: json.dump({"ref": R, "mine": M, "pairs": pairs}, open(OUT, "w"))
