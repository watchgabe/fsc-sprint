#!/usr/bin/env python3
"""capcut_draft.py — everything it takes to write a CapCut draft this Mac's CapCut will open.

Shared by mkcapcut.py (the CineYap cut) and mkcarousel.py (the video carousel). The format facts in
here were each paid for with a failed build on 2026-10-02; the runbook section "CapCut draft: the
format facts" says how every one was measured. Nothing here is hardcoded from a guess: the folder
shape, the video material and the video segment all come from drafts CapCut itself wrote, cached in
the package the first time one is seen.

    from capcut_draft import start, finish
    sf, dst = start(name, job_dir)            # CapCut closed, template copied, draft loaded
    ... add tracks and segments with pycapcut ...
    finish(sf, dst, name, W, H, total_us, sty, text_fonts=[...], left_inset=160)
"""
import json, os, pathlib, re, shutil, subprocess, sys, time, uuid, copy
from _root import PKG

US = lambda s: int(round(s * 1_000_000))        # CapCut works in microseconds

_alt = os.environ.get("CINEYAP_DRAFTS")
DRAFTS = pathlib.Path(_alt) if _alt else pathlib.Path.home()/"Movies/CapCut/User Data/Projects/com.lveditor.draft"
CACHE    = PKG/"cineyap/_capcut_template"
REFMAT   = PKG/"cineyap/_capcut_ref_material.json"
REFSEG   = PKG/"cineyap/_capcut_ref_segment.json"


def require_closed():
    """CapCut keeps an open draft in memory and rewrites the files on quit; a draft written while it
    runs silently vanishes. Only matters when writing where CapCut looks."""
    if not _alt and subprocess.run(["pgrep", "-x", "CapCut"], capture_output=True).returncode == 0:
        sys.exit("CapCut is running. Quit it first.\n"
                 "  It holds an open draft in memory and overwrites the files on disk when it exits, so a\n"
                 "  draft written now would silently vanish. Quit CapCut, then run this again.")
    DRAFTS.mkdir(parents=True, exist_ok=True)


def _find_template(name):
    """Captured ONCE, then the package's cache is used forever. Re-scanning every build let another
    tool's empty draft ('ig-dduix (Reel)', a vertical reel) become the template and overwrite the cache
    on 2026-10-02. Only a project the member made in CapCut qualifies: never one of our own builds."""
    t = __import__("config").opt("capcut_template", "")
    if t: return t
    if CACHE.is_dir(): return ""
    best = None
    for d in DRAFTS.iterdir():
        f = d/"draft_info.json"
        if not (d.is_dir() and f.is_file() and (d/"timeline_layout.json").is_file()): continue
        if d.name.endswith((" (CineYap)", " (Reel)", " (Carousel)")): continue
        try: j = json.load(open(f))
        except Exception: continue
        if d.name == name: continue
        if not j.get("tracks"):
            size = sum(x.stat().st_size for x in d.rglob("*") if x.is_file())
            if best is None or size < best[0]: best = (size, d.name)
    return best[1] if best else ""


def start(name, job_dir, W=1920, H=1080):
    """Copy CapCut's own empty draft (cached in the package) to a new draft folder and load it.
    Keeps the previous draft's timeline at <job>/edit/capcut_last_edit.json so a hand edit can
    still be learned after the rebuild replaces it."""
    from pycapcut import DraftFolder
    require_closed()
    folder = DraftFolder(str(DRAFTS))
    template = _find_template(name)
    if template and (DRAFTS/template).is_dir():
        if CACHE.exists(): shutil.rmtree(CACHE)
        shutil.copytree(DRAFTS/template, CACHE)
        print(f"  cached CapCut's empty draft '{template}' into the package (used from here on)")
    src = (DRAFTS/template) if (template and (DRAFTS/template).is_dir()) else (CACHE if CACHE.is_dir() else None)
    dst = DRAFTS/name
    if src is None:
        sf = folder.create_draft(name, W, H, fps=24, allow_replace=True)
        print("  WARNING: no empty CapCut draft to template from. Make a new empty project in CapCut,\n"
              "  close it, and run this again - otherwise CapCut may refuse the draft.")
        return sf, dst
    if src.resolve() == dst.resolve():
        sys.exit(f"The template resolved to the draft being written ('{template}'). Make a new empty\n"
                 "  project in CapCut, quit, and run this again.")
    if dst.exists():
        keep = pathlib.Path(job_dir)/"edit"/"capcut_last_edit.json"
        if (dst/"draft_info.json").exists():
            keep.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(dst/"draft_info.json", keep); print(f"  kept the previous draft's timeline at {keep.name}")
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    if not (dst/"draft_content.json").exists() and (dst/"draft_info.json").exists():
        shutil.copy(dst/"draft_info.json", dst/"draft_content.json")      # pycapcut reads this name
    for junk in ("draft_info.json.bak", "template.tmp", "template-2.tmp", "draft_cover.jpg"):
        (dst/junk).unlink(missing_ok=True)
    sf = folder.load_template(name)
    print(f"  built from CapCut's own empty draft '{src.name}' (inherits this CapCut's folder layout)")
    return sf, dst


def _accent(st, sty, sans):
    """the brand's accent treatment on one accent-word range (brand.json fonts.accent_style, colors.accent):
    serif-italic = the accent font (the default), bold = the main font in bold, underline = the main font
    underlined, color = the main font in the accent color. A set accent color tints every treatment."""
    acc = sty.get("accent") or {}; how = acc.get("treatment") or "serif-italic"
    if how in ("bold", "underline", "color"): st["font"]["path"] = sans
    if how == "bold": st["bold"] = True
    if how == "underline": st["underline"] = True
    col = acc.get("color")
    if isinstance(col, str) and len(col) == 7 and col.startswith("#"):
        rgb = [int(col[i:i+2], 16) / 255 for i in (1, 3, 5)]
        st.setdefault("fill", {}).setdefault("content", {}).setdefault("solid", {})["color"] = rgb

def _font(sty, cc, key, base):
    """The pack may name a font the member does not own. Fall back to the base font and say so."""
    want = os.path.expanduser(cc.get(key) or "")
    if want and os.path.exists(want): return want
    have = os.path.expanduser(sty["fonts"][base])
    if not os.path.exists(have) or have.endswith(".ttc"):
        # a .ttc collection lets CapCut pick the wrong weight; the package's own free font is exact
        have = str(PKG/"fonts"/("InstrumentSerif-Italic.ttf" if base == "serif" else "Inter-Bold.ttf"))
    if want: print(f"  NOTE: {key} {want} is not installed - using {pathlib.Path(have).name}")
    return have


def _reference(kind, name):
    """A video material / segment from a draft that OPENS, as the template for ours. CapCut drops a
    clip whose material is missing fields it expects (69 in a real one, 17 from the library)."""
    for d in sorted(DRAFTS.iterdir(), key=lambda q: -q.stat().st_mtime):
        if not d.is_dir() or d.name == name: continue
        f = d/"draft_info.json"
        if not f.is_file(): continue
        try: j = json.load(open(f))
        except Exception: continue
        if kind == "material":
            for v in j.get("materials", {}).get("videos", []):
                if v.get("type") == "video" and len(v) > 40: return v
        else:
            for t in j.get("tracks", []):
                if t.get("type") == "video" and t.get("segments") and len(t["segments"][0]) > 30:
                    return t["segments"][0]
    return None


def finish(sf, dst, name, W, H, total_us, sty, text_fonts, left_inset=None, box_k=1674.0/643.0, box_to_edge=False, fps=24000/1001, text_props=None):
    """Save and make the draft openable. text_fonts: one entry per text material in creation order:
    True/False for serif/sans, or a list of (start, end) character ranges to set in the serif face
    (the rest sans). left_inset: pixel inset for alignment-0 captions (their box is sized so the
    left edge lands there; see the runbook for the 2.6x calibration)."""
    cc = sty.get("capcut", {})
    draft_id = str(uuid.uuid4()).upper()
    sf.save()
    content = dst/"draft_content.json"
    info    = dst/"draft_info.json"
    j = json.loads(content.read_text())

    # ---- fonts: a real path wins over CapCut's library id
    sans, serif = _font(sty, cc, "sans_path", "sans"), _font(sty, cc, "serif_path", "serif")
    # pycapcut writes text materials grouped by TRACK, not in creation order, so a list only lines up
    # when there is one text track. A dict keyed by material id is always right.
    for i, tmat in enumerate(j.get("materials", {}).get("texts", [])):
        spec = (text_fonts.get(tmat["id"], False) if isinstance(text_fonts, dict)
                else (text_fonts[i] if i < len(text_fonts) else False))
        c = json.loads(tmat["content"])
        base = j_styles = c.get("styles", [])
        if isinstance(spec, list):                      # per-range accent
            tmat["font_path"] = sans
            tmpl = copy.deepcopy(j_styles[0]) if j_styles else {}
            n = len(c["text"]); bounds = sorted({0, n} | {r[0] for r in spec} | {r[1] for r in spec})
            new = []
            for a, b in zip(bounds, bounds[1:]):
                st = copy.deepcopy(tmpl); st["range"] = [a, b]
                st.setdefault("font", {}); st["font"]["id"] = ""
                hit = next((r for r in spec if r[0] <= a and b <= r[1]), None)
                st["font"]["path"] = (os.path.expanduser(hit[2]) if hit and len(hit) > 2 else serif) if hit else sans
                if hit and not (len(hit) > 2): _accent(st, sty, sans)
                new.append(st)
            c["styles"] = new
        else:
            f = serif if spec else sans
            tmat["font_path"] = f
            for st in j_styles:
                st.setdefault("font", {}); st["font"]["path"] = f; st["font"]["id"] = ""
        tmat["content"] = json.dumps(c, ensure_ascii=False)

    # ---- keyframe time base. CapCut times a video segment's keyframes from the start of its SOURCE
    # media (measured 2026-10-02 off keyframes Gabe set by hand: a clip starting at 0:00 whose footage
    # begins 22.14s into the take carried keyframes at 22.17s and 24.46s). pycapcut writes them from
    # the segment start, so on any clip that does not begin at its media's first frame every keyframe
    # landed before the footage and the clip held one size. Shift by the source in-point.
    for tr_ in j.get("tracks", []):
        if tr_.get("type") != "video": continue
        for sg in tr_.get("segments", []):
            src_in = (sg.get("source_timerange") or {}).get("start", 0) or 0
            if not src_in: continue
            for kl in sg.get("common_keyframes") or []:
                for kp in kl.get("keyframe_list", []):
                    if not kp.get("_src"): kp["time_offset"] = int(kp["time_offset"]) + int(src_in)
    # ---- eased keyframes: a keyframe dict may carry "_ease": "out" | "in" | "inout". CapCut's own format,
    # read off Gabe's hand-set curve: the start key FreeCurveIn with no handle, the end key FreeCurveOut
    # with its incoming handle flat across the whole move (x = -duration in microseconds, y = 0).
    for tr_ in j.get("tracks", []):
        for sg in tr_.get("segments", []):
            for kl in sg.get("common_keyframes") or []:
                ks = kl.get("keyframe_list", [])
                for a_, b_ in zip(ks, ks[1:]):
                    ease = b_.pop("_ease", None)
                    if not ease: continue
                    dur = int(b_["time_offset"]) - int(a_["time_offset"])
                    a_["curveType"] = "FreeCurveIn"; b_["curveType"] = "FreeCurveOut"
                    a_["right_control"] = {"x": float(dur) if ease in ("in", "inout") else 0.0, "y": 0.0}
                    b_["left_control"] = {"x": -float(dur) if ease in ("out", "inout") else 0.0, "y": 0.0}
                    b_["right_control"] = {"x": 1.0, "y": 0.0}
                for k_ in ks: k_.pop("_src", None); k_.pop("_ease", None)

    # ---- canvas
    j.setdefault("canvas_config", {})
    j["canvas_config"].update({"width": W, "height": H, "ratio": "original"})

    # ---- media lives inside the draft, at absolute paths (tokens did not resolve; see runbook)
    res = dst/"Resources"; res.mkdir(exist_ok=True)
    copied, total, seen = 0, 0, {}
    for bucket in j.get("materials", {}).values():
        if not isinstance(bucket, list): continue
        for mat in bucket:
            src = mat.get("path")
            if not src or src.startswith("##_") or not pathlib.Path(src).exists(): continue
            sp = pathlib.Path(src)
            if sp not in seen:
                dest = res/sp.name; n = 1
                while dest.exists() and dest.stat().st_size != sp.stat().st_size:
                    dest = res/f"{sp.stem}_{n}{sp.suffix}"; n += 1
                if not dest.exists():
                    try: os.link(sp, dest)                    # same disk: a hard link, no 2 GB copy per build
                    except OSError: shutil.copy2(sp, dest)
                    copied += 1; total += sp.stat().st_size
                seen[sp] = dest.name
            mat["path"] = f"{dst}/Resources/{seen[sp]}"
    print(f"  copied {copied} media file(s) into the draft ({total/1e9:.2f} GB) and re-pointed every path")

    # ---- every video material and segment completed from a working one (cached in the package)
    ref = _reference("material", name)
    if ref and len(ref) > 40: REFMAT.write_text(json.dumps(ref, ensure_ascii=False))
    elif REFMAT.is_file(): ref = json.loads(REFMAT.read_text())
    if ref:
        for i, mat in enumerate(j.get("materials", {}).get("videos", [])):
            mine = copy.deepcopy(ref); src = mat.get("path", "")
            mine.update({"path": src, "material_name": pathlib.Path(src.split("/")[-1]).name,
                         "duration": mat.get("duration", mine.get("duration")),
                         "width": mat.get("width", mine.get("width")), "height": mat.get("height", mine.get("height")),
                         "has_audio": mat.get("has_audio", mine.get("has_audio")), "type": mat.get("type", "video"),
                         "id": mat.get("id"), "unique_id": uuid.uuid4().hex, "material_id": "", "local_material_id": ""})
            if mat.get("crop"): mine["crop"] = mat["crop"]
            j["materials"]["videos"][i] = mine
        print(f"  {len(j['materials']['videos'])} video material(s) rebuilt from a working one ({len(ref)} fields each)")
    else:
        print("  WARNING: no working draft to copy a video material from - CapCut may drop the clips.")
    rseg = _reference("segment", name)
    if rseg and len(rseg) > 40: REFSEG.write_text(json.dumps(rseg, ensure_ascii=False))
    elif REFSEG.is_file(): rseg = json.loads(REFSEG.read_text())
    if rseg:
        n_fixed = 0
        for t in j.get("tracks", []):
            if t.get("type") != "video": continue
            for i, seg in enumerate(t["segments"]):
                merged = copy.deepcopy(rseg); merged.update(seg); t["segments"][i] = merged; n_fixed += 1
        print(f"  {n_fixed} video segment(s) completed from a working one ({len(rseg)} fields)")

    # ---- left-aligned text needs a box to align in (fixed_width, calibrated; tx stays 0)
    n_left = 0
    if left_inset is not None:
        # box_k was measured on a 1920-wide canvas; CapCut's text layout space scales with the canvas,
        # so a 1440 canvas gets 1440/1920 of it (seen: lines re-wrapping at ~1100px with the 1920 factor).
        k = box_k * (W / 1920.0)
        # box_to_edge: the box is the full canvas width starting at the inset, i.e. it runs past the right
        # edge, so CapCut never wraps a line the build already wrapped.
        real_w = float(W) if box_to_edge else (W - 2*float(left_inset))
        box_w = real_w / k
        # a box that is not mirrored about the centre has to be shifted so its LEFT edge still lands
        # on the inset: transform.x is in half-widths
        tx = ((float(left_inset) + real_w/2) - W/2) / (W/2) if box_to_edge else 0.0
        ids = set()
        for tmat in j.get("materials", {}).get("texts", []):
            if tmat.get("alignment") == 0:
                tmat["fixed_width"] = box_w; tmat["force_apply_line_max_width"] = True
                ids.add(tmat["id"]); n_left += 1
        for tr in j.get("tracks", []):
            if tr.get("type") != "text": continue
            for seg in tr.get("segments", []):
                if seg.get("material_id") in ids:
                    seg["clip"]["transform"]["x"] = tx
                    seg["clip"]["scale"]["x"] = 1.0; seg["clip"]["scale"]["y"] = 1.0
        print(f"  {n_left} left-aligned text(s): {box_w:.0f} box, left edge at {float(left_inset):.0f}px")

    # ---- exact per-text values copied from a layout the user set by hand in CapCut (carousel styles):
    # {material_id: {"material": {...fields}, "transform": (x, y), "scale": s}}. Applied last, so they
    # win over everything above. This is how a hand-built slide becomes a style: measure, then stamp.
    for tmat in j.get("materials", {}).get("texts", []):
        pr = (text_props or {}).get(tmat["id"])
        if pr: tmat.update(pr.get("material", {}))
    for tr in j.get("tracks", []):
        if tr.get("type") != "text": continue
        for seg in tr.get("segments", []):
            pr = (text_props or {}).get(seg.get("material_id"))
            if not pr: continue
            if "transform" in pr: seg["clip"]["transform"]["x"], seg["clip"]["transform"]["y"] = pr["transform"]
            if "scale" in pr: seg["clip"]["scale"]["x"] = seg["clip"]["scale"]["y"] = pr["scale"]

    # ---- any leftover path tokens become absolute, and both timeline names get the same bytes
    # The project frame rate MUST equal the content's. The empty template CapCut made is 30fps; on a
    # 30fps grid CapCut rounds every 23.976 boundary and accumulates the rounding across the
    # back-to-back A-roll clips, so by 31s the picture cut sat 4 frames from its overlays: the
    # frame-to-frame triple switch, manufactured inside CapCut from a clean plan.
    j["fps"] = round(float(fps), 3)
    txt = json.dumps(j, ensure_ascii=False)
    txt, n_tok = re.subn(r"##_draftpath_placeholder_[0-9A-Fa-f-]+_##", str(dst).replace("\\", "/"), txt)
    for f in (info, content): f.write_text(txt)

    # ---- identity: the template's name and folder came along in the copy; CapCut refuses a mismatch
    meta = dst/"draft_meta_info.json"
    if meta.exists():
        mj = json.loads(meta.read_text())
        mj.update({"draft_name": name, "draft_id": draft_id, "draft_fold_path": str(dst),
                   "draft_root_path": str(DRAFTS), "tm_duration": int(total_us)})
        mj = json.loads(re.sub(r"##_draftpath_placeholder_[0-9A-Fa-f-]+_##", str(dst).replace("\\", "/"),
                               json.dumps(mj, ensure_ascii=False)))
        meta.write_text(json.dumps(mj, ensure_ascii=False))

    # ---- the project list is what the home screen reads; tm_duration 0 there means "will not open"
    root = DRAFTS/"root_meta_info.json"
    if root.exists():
        rj = json.loads(root.read_text()); store = rj.setdefault("all_draft_store", [])
        hit = next((e for e in store if e.get("draft_name") == name), None)
        if hit is None and store:
            hit = copy.deepcopy(store[0]); store.insert(0, hit)
        if hit is not None:
            hit.update({"draft_name": name, "draft_fold_path": str(dst), "draft_id": draft_id,
                        "tm_duration": int(total_us), "draft_json_file": str(dst/"draft_info.json"),
                        "tm_draft_create": int(time.time()*1e6), "tm_draft_modified": int(time.time()*1e6)})
            root.write_text(json.dumps(rj, ensure_ascii=False))
            print(f"  registered in CapCut's project list ({total_us/1e6:.1f}s)")
    return {"left": n_left, "tokens": n_tok, "media": copied}
