#!/usr/bin/env python3
"""learn_capcut.py — read a caption you restyled in CapCut back into the style pack.

CapCut's "apply to all" cannot tell a small left caption from a big centred one, so restyling by hand
either wrecks the other kind or means touching 130 captions. The pack can tell them apart. So: change
ONE caption of a kind in CapCut, run this, and the pack learns the new size / tracking / position for
that kind. Rebuild and every caption of that kind has it.

    learn_capcut.py <job>            show what changed and update the pack
    learn_capcut.py <job> --check    show only

A kind is: small (left-aligned sans), big (centred sans), serif (centred italic accent). A field is
learned when every edited caption of a kind agrees on the new value and it differs from the pack; a
field where edited captions disagree is listed and left alone, because that is two different intents.
"""
import json, pathlib, sys, collections, os
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG
import config

if len(sys.argv) < 2: sys.exit("usage: learn_capcut.py <job> [--check]")
job, check = sys.argv[1], "--check" in sys.argv
_alt = os.environ.get("CAPCUT_DRAFTS")
DRAFTS = pathlib.Path(_alt) if _alt else pathlib.Path.home()/"Movies/CapCut/User Data/Projects/com.lveditor.draft"
D = DRAFTS/f"{job} (CineYap)"
SRC = D/"draft_info.json"
if "--last" in sys.argv:            # the timeline mkcapcut.py kept before its last rebuild
    SRC = PKG/"projects"/job/"edit"/"capcut_last_edit.json"
if not SRC.exists(): sys.exit(f"no CapCut draft at {SRC}")
look = config.opt("look", "gabe")
PACK = PKG/"cineyap/styles"/f"{look}.json"
pack = json.loads(PACK.read_text()); cc = pack.setdefault("capcut", {})

j = json.load(open(SRC))
texts = {t["id"]: t for t in j["materials"]["texts"]}
rows = []
for t in j["tracks"]:
    if t["type"] != "text": continue
    for s in t["segments"]:
        m = texts[s["material_id"]]; c = json.loads(m["content"]); st = (c.get("styles") or [{}])[0]
        font = (st.get("font") or {}).get("path", "")
        serif = os.path.basename(font) == os.path.basename(os.path.expanduser(cc.get("serif_path") or pack["fonts"]["serif"]))
        kind = "serif" if serif else ("small" if m.get("alignment") == 0 else "big")
        rows.append(dict(kind=kind, text=c["text"], size=st.get("size"), track=round((m.get("letter_spacing") or 0)*20),
                         x=round(s["clip"]["transform"]["x"], 4), y=round(s["clip"]["transform"]["y"], 4)))

# pack field per kind per property
FIELD = {("small","size"):"size_small", ("big","size"):"size_big", ("serif","size"):"size_serif",
         ("small","track"):"track_small", ("big","track"):"track_big", ("serif","track"):"track_serif",
         ("small","x"):"x_small", ("big","x"):"x_big", ("small","y"):"y_small", ("big","y"):"y_big"}
DEFAULT = {"size_small":9.0,"size_big":22.0,"size_serif":22.0,"track_small":-1,"track_big":-1,"track_serif":-1,
           "x_small":0.0,"x_big":0.0,"y_small":0.0,"y_big":0.0}
changed, skipped = [], []
for (kind, prop), field in FIELD.items():
    vals = [r[prop] for r in rows if r["kind"] == kind and r[prop] is not None]
    if not vals: continue
    if prop == "x" and kind == "small": continue   # x on small captions is the inset box, owned by the build
    # The baseline is what the BUILD wrote, i.e. the value most captions of this kind still carry. The
    # pack is not the baseline: once it has learned an edit, every untouched caption would look edited.
    have = collections.Counter(vals).most_common(1)[0][0]
    edited = [v for v in vals if abs(v - have) > 1e-6]
    if not edited: continue
    distinct = sorted(set(edited))
    n = len(edited)
    if len(distinct) == 1:
        changed.append((field, have, distinct[0], n, len(vals)))
        if not check: cc[field] = distinct[0]
    else:
        skipped.append((field, have, distinct, n))

print(f"{job}: {len(rows)} captions read from CapCut; pack = {PACK.name}")
for f, a, b, n, tot in changed:
    print(f"  {f:12} {a!s:>7} -> {b!s:<7}  (from {n} of {tot} {f.split('_')[1]} captions you edited)")
for f, a, d, n in skipped:
    print(f"  {f:12} left at {a}: {n} edited captions disagree {d}")
if not changed and not skipped: print("  nothing differs from the pack")
if changed and not check:
    PACK.write_text(json.dumps(pack, indent=2, ensure_ascii=False) + "\n")
    print(f"  pack updated - rebuild (cineyap/mkcapcut.py) and every caption of that kind gets it")
