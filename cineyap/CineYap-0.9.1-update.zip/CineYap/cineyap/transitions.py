#!/usr/bin/env python3
"""Screen-blend flash transitions + their click, applied to the finished cut.

The overlay is a black-background flash. Screen blend keeps the bright pixels
and drops the black, which is the same thing Premiere's screen opacity does.
The source is vertical, so it is rotated 90 degrees to work on a 16:9 canvas.
"""
import subprocess, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from config import opt as cfg_opt
FX  = cfg_opt("sfx_flash_overlay")
SFX = cfg_opt("sfx_click")
if not FX:
    # Flashes are Gabe's section-break treatment and need his overlay clip. Without it the
    # cut is finished and fine; it just has no flashes. Copy through rather than fail.
    import shutil as _sh, sys as _s
    print("  no flash overlay configured - skipping transitions, the cut is unchanged.")
    _sh.copy("out.mp4", "final.mp4"); _s.exit(0)
AT  = [float(x) for x in sys.argv[1:]] or [5.51]
SRC, OUT = "out.mp4", "final.mp4"

# The overlay ships vertical (1080x1920). Rotate it only for a 16:9 canvas.
_p = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
                     "stream=width,height","-of","csv=p=0",SRC],
                    capture_output=True, text=True).stdout.strip().split(",")
CW, CH = int(_p[0]), int(_p[1])
_rot = "transpose=1," if CW > CH else ""
vf = ("[1:v]" + _rot + f"scale={CW}:{CH}:force_original_aspect_ratio=increase,"
      f"crop={CW}:{CH},fps=24000/1001,format=gbrp,setpts=PTS-STARTPTS+{{t}}/TB[fx{{i}}]")
parts, cur = [], "[0:v]"
cmd = ["ffmpeg","-y","-v","error","-i",SRC]
for i,t in enumerate(AT):
    cmd += ["-i",FX]
for i,t in enumerate(AT):
    cmd += ["-i",SFX]
for i,t in enumerate(AT):
    parts.append(vf.format(t=t,i=i))
    parts.append(f"{cur}format=gbrp[bg{i}];[bg{i}][fx{i}]blend=all_mode=screen:"
                 f"enable='between(t,{t},{t+0.46})'[v{i}]")
    cur = f"[v{i}]"
parts.append(f"{cur}format=yuv420p[outv]")
n = len(AT)
# -itsoffset is DISCARDED by amix. Measured 2026-09-23: a click asked for at
# 3.00s landed at 0.06s. It had been at the head of every video. Use adelay.
for i,t in enumerate(AT):
    parts.append(f"[{1+n+i}:a]adelay={int(t*1000)}|{int(t*1000)}[sfx{i}]")
amix = "".join(f"[sfx{i}]" for i in range(n))
# amix divides by the number of inputs, so restore the gain and then limit.
# A raw volume boost here clipped the mix at 0.0 dBFS (caught 2026-09-23).
parts.append(f"[0:a]afade=t=in:st=0:d=0.90[a0];[a0]{amix}amix=inputs={n+1}:duration=first:dropout_transition=0,"
             f"volume={n+1},alimiter=limit=0.891:level=disabled[outa]")
cmd += ["-filter_complex",";".join(parts),"-map","[outv]","-map","[outa]",
        "-c:v","libx264","-preset","medium","-crf","17","-pix_fmt","yuv420p",
        "-c:a","aac","-b:a","192k","-movflags","+faststart",OUT]
print(f"applying {n} flash transition(s) at {AT}")
subprocess.run(cmd,check=True)
print("done ->",OUT)
