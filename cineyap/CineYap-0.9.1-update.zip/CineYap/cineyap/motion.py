#!/usr/bin/env python3
"""motion.py — named moves as a few CapCut keyframes each: simple to see, simple to drag.

Measured off a reference reel (instagram.com/p/Dd6tRTFKIZv, 2026-10-02) by tracking the size and
position of every panel and photo card frame by frame. Every move is a short ease and then a hold.

    settle      starts zoomed in, eases back to full size        1.12 -> 1.00 over 0.8s
    slam        starts very big, lands hard                      2.20 -> 1.00 over 0.6s
    push        zooms in on a beat, then holds                   1.00 -> 1.08 over 0.8s, at 35% in
    pop         a photo card arriving                            0.96 -> 1.00 and 15px rise, 0.5s
    slide_out   exits sliding left, speeding up                  13% of the width over the last 0.3s
    kenburns    the old slow creep                               1.00 -> 1.00+kb over the whole clip
    none        holds still

Combine with "+": "settle+slide_out", "pop+slide_out", "push+slide_out".

CapCut keyframes are linear between points, so each ease is three points: the ease-out reaches 70% of
its change at 30% of its time (fast start, soft landing), the ease-in the mirror. That reads as an ease
on screen and stays three draggable points per move.

    from motion import apply
    apply(seg, "settle+slide_out", dur_s, base=fill_scale, canvas=(W, H), full_frame=True)
"""
from pycapcut import KeyframeProperty as KP

US = lambda s: int(round(s * 1_000_000))

DEFAULTS = {
    "settle":    {"from": 1.12, "over": 0.8},
    "slam":      {"from": 2.20, "over": 0.6},
    "push":      {"by": 0.08, "over": 0.8, "at": 0.35},
    "pop":       {"from": 0.96, "rise_px": 15, "over": 0.5},
    "slide_out": {"width_frac": 0.13, "over": 0.3},
    "kenburns":  {"by": 0.12},
}

def _ease_out(t0, t1, v0, v1):
    return [(t0, v0), (t0 + 0.3*(t1 - t0), v0 + 0.7*(v1 - v0)), (t1, v1)]

def _ease_in(t0, t1, v0, v1):
    return [(t0, v0), (t0 + 0.7*(t1 - t0), v0 + 0.3*(v1 - v0)), (t1, v1)]

def plan(preset, dur, base=1.0, canvas=(1080, 1920), full_frame=True, cfg=None, anchor=None):
    """Keyframe points per property for a preset, in seconds and CapCut units. Pure, so it can be
    printed, tested, or written by any builder. Returns {"scale": [(t, v)], "x": [...], "y": [...]}."""
    cfg = {k: {**v, **((cfg or {}).get(k) or {})} for k, v in DEFAULTS.items()}
    W, H = canvas
    pts = {"scale": [], "x": [], "y": []}
    names = [p for p in (preset or "none").split("+") if p and p != "none"]
    exit_t = cfg["slide_out"]["over"] if "slide_out" in names else 0.0
    body_end = max(0.05, dur - exit_t)                 # the entrance and the beat move live before the exit
    s_end = base
    for n in names:
        c = cfg.get(n, {})
        if n in ("settle", "slam"):
            T = min(c["over"], body_end)
            pts["scale"] += _ease_out(0.0, T, base*c["from"], base)
            s_end = base
        elif n == "push":
            a = min(max(0.0, c["at"] * dur), max(0.0, body_end - 0.1)); T = min(c["over"], body_end - a)
            pts["scale"] += [(0.0, base)] + _ease_out(a, a + T, base, base*(1 + c["by"]))
            s_end = base*(1 + c["by"])
        elif n == "pop":
            T = min(c["over"], body_end)
            # under 100% shows the frame's edge on a full-frame clip; mirror it (0.96 -> 1.04) so it still pops
            f = c["from"] if (not full_frame or c["from"] >= 1) else 2 - c["from"]
            pts["scale"] += _ease_out(0.0, T, base*f, base)
            pts["y"] += _ease_out(0.0, T, -c["rise_px"]/(H/2), 0.0)      # starts lower, rises (up = +)
            s_end = base
        elif n == "kenburns":
            pts["scale"] += [(0.0, base), (body_end, base*(1 + c["by"]))]
            s_end = base*(1 + c["by"])
    if exit_t:
        c = cfg["slide_out"]; d = c["width_frac"] * 2               # position_x is in half-widths
        t0 = max(0.0, dur - exit_t)
        pts["x"] += [(0.0, 0.0)] + _ease_in(t0, dur, 0.0, -d)
        if full_frame:
            # a full-frame clip sliding left would show its own right edge; grow it just enough to cover
            pts["scale"] += _ease_in(t0, dur, s_end, s_end*(1 + d))
    for k in pts:                                                  # hold the last value to the end
        if pts[k] and pts[k][-1][0] < dur - 1e-3: pts[k].append((dur, pts[k][-1][1]))
    if anchor and pts["scale"]:
        # ZOOM ON THE FACE, NOT THE MIDDLE. CapCut scales about the frame centre, so on a talking head the
        # eyes (above centre) fly upward on every zoom and a slam pushes the head out of shot. Hold the
        # anchor point (fractions of the frame, from the top-left) still by moving the frame against the
        # zoom: offset = 2*(f - 0.5)*(S - base), in CapCut's half-frame units (x right +, y up +).
        ax, ay = anchor
        def interp(lst, t):
            if not lst: return 0.0
            lst = sorted(lst)
            if t <= lst[0][0]: return lst[0][1]
            for (t0, v0), (t1, v1) in zip(lst, lst[1:]):
                if t <= t1: return v0 + (v1 - v0) * (t - t0) / max(1e-9, t1 - t0)
            return lst[-1][1]
        for key, f, sign in (("x", ax, -1), ("y", ay, +1)):
            times = sorted({t for t, _ in pts["scale"]} | {t for t, _ in pts[key]})
            pts[key] = [(t, interp(pts[key], t) + sign * 2 * (f - 0.5) * (interp(pts["scale"], t) - base)) for t in times]
            if all(abs(v) < 1e-6 for _, v in pts[key]): pts[key] = []
    return pts

def apply(seg, preset, dur, base=1.0, canvas=(1080, 1920), full_frame=True, cfg=None, anchor=None):
    """Write the preset onto a pycapcut segment. dur in seconds. Returns the plan."""
    p = plan(preset, dur, base, canvas, full_frame, cfg, anchor)
    if not p["scale"] and base != 1.0: p["scale"] = [(0.0, base), (dur, base)]
    prop = {"scale": KP.uniform_scale, "x": KP.position_x, "y": KP.position_y}
    for k, kp in prop.items():
        seen = set()
        for t, v in sorted(p[k]):
            tu = US(t)
            if tu in seen: continue
            seen.add(tu); seg.add_keyframe(kp, tu, float(v))
    return p

PRESETS = ["kenburns", "settle", "slam", "push", "pop", "settle+slide_out", "push+slide_out", "pop+slide_out", "none"]

if __name__ == "__main__":
    for name in PRESETS:
        p = plan(name, 3.0, base=1.0)
        print(f"{name:18}", " | ".join(f"{k}: " + ", ".join(f"{t:.2f}s={v:.3f}" for t, v in v_) for k, v_ in p.items() if v_))
