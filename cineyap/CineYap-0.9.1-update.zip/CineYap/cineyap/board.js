function tile(icon,label,active,on,title){var b=document.createElement("button");b.type="button";b.setAttribute("aria-pressed",active?"true":"false");b.title=title||label;
 b.innerHTML='<i class="ti ti-'+icon+'" aria-hidden="true" style="font-size:14px"></i><span>'+label+'</span>';
 b.style.cssText="display:flex;align-items:center;gap:5px;padding:4px 7px;font-size:12px;line-height:1.2;width:100%;white-space:nowrap;justify-content:flex-start;"+(active?"border-color:var(--border-accent);color:var(--text-accent);background:var(--bg-accent);":"");
 b.addEventListener("click",on);return b;}
function pickFile(onpick){var fi=document.createElement("input");fi.type="file";fi.accept="video/*";fi.style.display="none";root.appendChild(fi);
 fi.addEventListener("change",function(e){var f=e.target.files&&e.target.files[0];if(f){var u="";try{u=URL.createObjectURL(f);}catch(x){}onpick(f.path||f.name,u);}fi.remove();});fi.click();}
function dropBox(onpick){var box=document.createElement("button");box.type="button";box.title="Drop a clip here, or click to select it in Finder";
 box.style.cssText="width:128px;height:72px;flex:0 0 auto;border-radius:6px;border:1px dashed var(--border-strong);background:var(--surface-1);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:1px;font-size:11px;line-height:1.3;color:var(--text-secondary);padding:4px;";
 box.innerHTML='<i class="ti ti-download" style="font-size:16px" aria-hidden="true"></i><span>Drop your B-roll</span><span style="color:var(--text-muted)">or select in Finder</span>';
 box.addEventListener("click",function(){pickFile(onpick);});
 box.addEventListener("dragover",function(e){e.preventDefault();box.style.borderColor="var(--border-accent)";});
 box.addEventListener("dragleave",function(){box.style.borderColor="var(--border-strong)";});
 box.addEventListener("drop",function(e){e.preventDefault();e.stopPropagation();var f=e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files[0];if(f){var u="";try{u=URL.createObjectURL(f);}catch(x){}onpick(f.path||f.name,u);}});
 return box;}
function preview(bs,b){var box=document.createElement("div");box.style.cssText="width:128px;height:72px;flex:0 0 auto;border-radius:6px;overflow:hidden;background:var(--surface-1);";
 if(bs.url){var v=document.createElement("video");v.src=bs.url;v.muted=true;v.autoplay=true;v.loop=true;v.playsInline=true;v.style.cssText="width:100%;height:100%;object-fit:cover;display:block;";
  v.addEventListener("error",function(){box.innerHTML='<div style="font-size:11px;color:var(--text-muted);padding:6px;">preview blocked here</div>';});box.appendChild(v);}
 else if(b.thumb&&!bs.changed){var im=document.createElement("img");im.src=b.thumb;im.alt="";im.style.cssText="width:100%;height:100%;object-fit:cover;display:block;";box.appendChild(im);}
 return box;}
var BG=["","green","cream"];
function render(){var rows=q("[data-rows]");rows.innerHTML="";var focus=null;
 D.takes.forEach(function(k){var s=S.takes[k.n];
  var row=document.createElement("div");row.style.cssText="display:flex;align-items:flex-start;gap:12px;padding:10px 12px;border:0.5px solid var(--border);border-radius:var(--radius);background:var(--surface-2);"+(s.cut?"opacity:.5;":"");
  var left=document.createElement("div");left.style.cssText="display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:4px;flex:0 0 168px;";
  left.appendChild(tile("message","Note",!!(s.note.trim()||s.open),function(){s.open=!s.open;if(s.open)s._f=1;render();},"Add a note to line "+k.n));
  left.appendChild(tile("movie","B-roll",false,function(){S.added.push({id:"n"+(S.added.length+1),take:k.n,clip:""});render();},"Add a B-roll slot to line "+k.n));
  left.appendChild(tile(s.zoom==="tight"?"zoom-in":"zoom-out",s.zoom==="tight"?"Punch":"Wide",s.zoom==="tight",function(){s.zoom=s.zoom==="tight"?"wide":"tight";render();counts();},"Wide or punched in. Click to switch."));
  left.appendChild(tile("user","Behind",s.behind,function(){s.behind=!s.behind;render();counts();},"Text behind subject"));
  left.appendChild(tile("square",s.matte?("BG "+s.matte):"BG",!!s.matte,function(){s.matte=BG[(BG.indexOf(s.matte)+1)%BG.length];render();counts();},"Plain background behind the captions: none, green, cream"));
  left.appendChild(tile("bolt","Flash",s.flash,function(){s.flash=!s.flash;render();counts();},"Flash + click transition at the start of the line"));
  var mid=document.createElement("div");mid.style.cssText="flex:1 1 auto;min-width:0;";
  var line=document.createElement("div");line.style.cssText="font-size:14px;line-height:1.5;"+(s.cut?"text-decoration:line-through;color:var(--text-muted);":"color:var(--text-primary);");
  var num=document.createElement("span");num.textContent=k.n;num.style.cssText="color:var(--text-muted);margin-right:8px;";line.appendChild(num);line.appendChild(document.createTextNode(k.text));
  if(k.beat){var bt=document.createElement("span");bt.textContent=k.beat.toLowerCase();bt.style.cssText="margin-left:8px;font-size:11px;color:var(--text-muted);";line.appendChild(bt);}
  mid.appendChild(line);
  if(s.open){var ta=document.createElement("textarea");ta.rows=2;ta.value=s.note;ta.placeholder="what should change here";ta.style.cssText="width:100%;margin-top:8px;font-size:13px;resize:vertical;";ta.addEventListener("input",function(e){s.note=e.target.value;counts();});mid.appendChild(ta);if(s._f){focus=ta;s._f=0;}}
  D.brolls.concat(S.added).filter(function(b){return b.take===k.n;}).forEach(function(b){var bs=S.brolls[b.id]||b;var isNew=!S.brolls[b.id];
   var br=document.createElement("div");br.style.cssText="margin-top:8px;padding:8px;border:0.5px solid var(--border);border-radius:var(--radius);background:var(--surface-1);font-size:13px;display:flex;align-items:center;gap:10px;"+(bs.remove?"opacity:.5;text-decoration:line-through;":"");
   var set=function(v,u){bs.clip=v;bs.url=u;bs.changed=true;render();counts();};
   if(!bs.clip){br.appendChild(dropBox(set));var ph=document.createElement("span");ph.style.cssText="flex:1;color:var(--text-muted);font-size:12px;";ph.textContent="B-roll for line "+k.n;br.appendChild(ph);}
   else{br.appendChild(preview(bs,b));
    var lbl=document.createElement("div");lbl.style.cssText="flex:1;min-width:0;line-height:1.4;";
    var nm=document.createElement("div");nm.textContent=bs.clip.split("/").pop();nm.style.cssText="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;";lbl.appendChild(nm);
    if(b.t0!=null){var tm=document.createElement("div");tm.textContent=fmt(b.t0)+" – "+fmt(b.t1);tm.style.cssText="font-size:12px;color:var(--text-muted);";lbl.appendChild(tm);}
    br.appendChild(lbl);
    br.appendChild(btn("switch-horizontal","Swap this clip (opens Finder)",function(){pickFile(set);},!isNew&&bs.clip!==b.clip));
    br.addEventListener("dragover",function(e){e.preventDefault();br.style.borderColor="var(--border-accent)";});
    br.addEventListener("dragleave",function(){br.style.borderColor="var(--border)";});
    br.addEventListener("drop",function(e){e.preventDefault();var f=e.dataTransfer&&e.dataTransfer.files&&e.dataTransfer.files[0];if(f){var u="";try{u=URL.createObjectURL(f);}catch(x){}set(f.path||f.name,u);}});
    br.title="drop a clip here to swap it";}
   br.appendChild(btn("trash",(bs.remove?"Keep":"Remove")+" this B-roll",function(){if(isNew){S.added=S.added.filter(function(a){return a!==b;});}else{bs.remove=!bs.remove;}render();counts();},bs.remove));
   mid.appendChild(br);});
  D.cards.filter(function(c){return c.take===k.n;}).forEach(function(c){var cs=S.cards[c.id];
   var cr=document.createElement("div");cr.style.cssText="margin-top:8px;padding:8px 10px;border:0.5px solid var(--border);border-radius:var(--radius);font-size:13px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;"+(cs.remove?"opacity:.5;text-decoration:line-through;":"");
   var sw=document.createElement("span");sw.style.cssText="width:14px;height:14px;border-radius:3px;flex:0 0 auto;border:0.5px solid var(--border-strong);background:"+(cs.colour==="green"?"#2f5d3a":"#f1e8d6")+";";sw.title=cs.colour+" card";cr.appendChild(sw);
   if(cs.edit){var ct=document.createElement("input");ct.type="text";ct.value=cs.words.join(" ");ct.style.cssText="flex:1;min-width:160px;font-size:13px;height:30px;";
    ct.addEventListener("input",function(e){cs.words=e.target.value.split(/\s+/).filter(Boolean);cs.accent=cs.accent.filter(function(i){return i<cs.words.length;});counts();});
    ct.addEventListener("keydown",function(e){if(e.key==="Enter"){cs.edit=false;render();}});cr.appendChild(ct);}
   else{var wb=document.createElement("div");wb.style.cssText="flex:1;min-width:160px;display:flex;flex-wrap:wrap;gap:4px;";
    cs.words.forEach(function(w,i){var on=cs.accent.indexOf(i)>=0;var ch=document.createElement("button");ch.type="button";ch.textContent=w;ch.title=on?"accent on, click to clear":"click to make this an accent word";
     var look="padding:2px 7px;font-size:14px;line-height:1.4;border-radius:999px;border:0.5px solid "+(on?"var(--border-accent)":"var(--border)")+";background:"+(on?"var(--bg-accent)":"transparent")+";";
     if(on){var t=D.accent.treatment;if(t==="serif-italic")look+="font-family:var(--font-voice);font-style:italic;";else if(t==="bold")look+="font-weight:500;";else if(t==="underline")look+="text-decoration:underline;";if(D.accent.color)look+="color:"+D.accent.color+";";}
     ch.style.cssText=look;ch.addEventListener("click",function(){var j=cs.accent.indexOf(i);if(j>=0)cs.accent.splice(j,1);else cs.accent.push(i);render();counts();});wb.appendChild(ch);});
    cr.appendChild(wb);}
   cr.appendChild(btn("pencil",(cs.edit?"Done editing":"Edit the words of")+" card "+c.id,function(){cs.edit=!cs.edit;render();},cs.edit));
   cr.appendChild(btn("palette","Flip card "+c.id+" colour",function(){cs.colour=cs.colour==="green"?"cream":"green";render();counts();},cs.colour!==c.colour));
   cr.appendChild(btn("trash",(cs.remove?"Keep":"Remove")+" card "+c.id,function(){cs.remove=!cs.remove;render();counts();},cs.remove));mid.appendChild(cr);});
  var right=document.createElement("div");right.style.cssText="display:flex;align-items:center;gap:8px;flex:0 0 auto;";
  var d=document.createElement("span");d.textContent=k.dur+"s";d.style.cssText="font-size:12px;color:var(--text-secondary);min-width:34px;text-align:right;";right.appendChild(d);
  right.appendChild(btn("trash",(s.cut?"Restore":"Cut")+" line "+k.n,function(){s.cut=!s.cut;render();counts();},s.cut));
  row.appendChild(left);row.appendChild(mid);row.appendChild(right);rows.appendChild(row);});
 if(focus)focus.focus();}
