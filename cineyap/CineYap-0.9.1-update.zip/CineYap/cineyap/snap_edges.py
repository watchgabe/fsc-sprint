#!/usr/bin/env python3
"""snap_edges.py — put every cut edge on the SOUND, not on the transcript's stamp.

    cd <job>/build && ./vu-py cineyap/snap_edges.py

WHY. The cut picks WORDS from the transcript, but a transcript keeps its own clock. Scribe stamps a
word's start after the sound has already begun, and its end after the sound has stopped. A fixed pad
cannot correct a varying error: measured on C1644, 10 of 17 in-points and 2 of 17 out-points landed
INSIDE speech, so the cut shaved the attack off a word.

WHAT IT DOES. It never changes WHICH words survive — mkedl.py already decided that. It only moves the
edge around them, and only to a place it has measured on the raw audio:

    in-point   = real onset  - 40 ms
    out-point  = real offset + 50 ms

Both margins are wider than half a frame at 23.976 fps (20.9 ms), so the renderer's frame snap cannot
round the cut back inside the word. Every move is clamped to the neighbouring words so an edge can never
eat into the take beside it, and when the boundary sits in running speech with no quiet to find, the
edge is left exactly as it was and reported.

IDEMPOTENT. Edges are re-derived from the transcript word each run, never from the previous output, so
running it twice changes nothing the second time.
"""
import json, pathlib, subprocess, sys
import numpy as np
import scipy.io.wavfile as wf

FRAME   = 0.005          # 5 ms envelope
PRE     = 0.040          # how far before the onset the in-point sits
POST    = 0.050          # how far after the offset the out-point sits
HOLD    = 0.015          # speech must persist this long to count as the onset
QUIET   = 0.030          # quiet must persist this long to count as a real gap
SEARCH  = 0.50           # how far either side of the stamp we look
OVER_DB = 10.0           # dB over the noise floor that counts as speech

B = pathlib.Path.cwd()
JOB = B.parent
edl_path = JOB/"edit/edl.json"
if not edl_path.exists(): sys.exit("no edit/edl.json - run mkedl.py first")
edl = json.load(open(edl_path))
stem, src = list(edl["sources"].items())[0]
words = [w for w in json.load(open(JOB/f"edit/transcripts/{stem}.json"))["words"]
         if w.get("text","").strip()]

probe = B/"_edges_probe.wav"
if not probe.exists():
    subprocess.run(["ffmpeg","-v","error","-y","-i",src,"-ac","1","-ar","16000",
                    "-c:a","pcm_s16le",str(probe)], check=True)
sr, x = wf.read(probe); x = x.astype(np.float32)/32768
n = int(sr*FRAME); m = len(x)//n
db = 20*np.log10(np.maximum(np.sqrt((x[:m*n].reshape(m,n)**2).mean(1)), 1e-6))
floor = float(np.percentile(db, 20)); thr = floor + OVER_DB
loud = db > thr
F = lambda t: int(round(t/FRAME))
T = lambda i: i*FRAME
HOLD_N, QUIET_N = max(1,int(HOLD/FRAME)), max(1,int(QUIET/FRAME))

def onset(stamp):
    """The first sound after the last held silence before `stamp`.

    A speech onset is a RAMP, not a step: at one real edge the level climbed from -44 dB to
    -20 dB over 200 ms. So asking for hard silence in the frame right before the onset finds
    nothing. Instead find the GAP and take the first sound after it, which is ramp-proof.
    """
    lo, hi = max(0, F(stamp-SEARCH)), min(len(loud), F(stamp)+1)
    run = 0
    for i in range(hi-1, lo-1, -1):
        if not loud[i]:
            run += 1
            if run >= QUIET_N:
                return T(i+run)          # first loud frame after the held gap
        else:
            run = 0
    return None

def offset(stamp):
    """Where the sound stops: the start of the first held silence after `stamp`."""
    lo, hi = max(0, F(stamp)), min(len(loud), F(stamp+SEARCH))
    run = 0
    for i in range(lo, hi):
        if not loud[i]:
            run += 1
            if run >= QUIET_N:
                return T(i-run+1)        # the frame the silence began on
        else:
            run = 0
    return None

def nearest(t, key):
    best, bd = None, 1e9
    for i,w in enumerate(words):
        d = abs(w[key]-t)
        if d < bd: best, bd = i, d
    return best if bd <= SEARCH else None

moved = kept = 0
for r in edl["ranges"]:
    a0, b0 = r["start"], r["end"]
    ia, ib = nearest(a0,"start"), nearest(b0,"end")
    # ---- in-point
    if ia is not None and (o := onset(words[ia]["start"])) is not None:
        a = o - PRE
        if ia > 0: a = max(a, words[ia-1]["end"])        # never eat the previous word
        r["start"] = round(a, 3)
    else:
        kept += 1
    # ---- out-point
    if ib is not None and (f := offset(words[ib]["end"])) is not None:
        b = f + POST
        if ib+1 < len(words): b = min(b, words[ib+1]["start"])
        r["end"] = round(b, 3)
    else:
        kept += 1
    if (r["start"], r["end"]) != (a0, b0): moved += 1

edl["total_duration_s"] = round(sum(r["end"]-r["start"] for r in edl["ranges"]), 2)
edl["edges_snapped"] = True
edl_path.write_text(json.dumps(edl, indent=2))
print(f"floor {floor:.1f} dB, speech above {thr:.1f} dB")
print(f"{moved}/{len(edl['ranges'])} ranges moved; {kept} edges left alone (no quiet to measure)")
print(f"total {edl['total_duration_s']}s")
