# The effects library

**Formats** are layouts: canvas, caption system, where the talking head sits (CineYap 16:9, vertical,
YapMaxxing, Poster, Carousel, Reel template). **Effects** are moments that drop into any format: a flash,
a stacked title, a green card. The format decides WHEN; the effect owns HOW. That is how one style moves
between formats: write the effect once, and every format can call it.

Rule for every effect: one implementation (in `cineyap/fx.py` once it is shared), its numbers in the style
pack, a page in this folder, and proof on a CapCut export.

| Effect | Status | Lives in | Formats today | Measured from |
|---|---|---|---|---|
| **Flash + Click** transition | **Locked**, shared | `fx.py` `FlashClick`, page `flash-click.md` | Vertical, CineYap 16:9 | Showin' Up (Batch_2) |
| **Opening zoom + riding text** (the adjustment-layer look: title and hook words scale with the zoom) | Built | `mkvertical.py` `open_k` / `ride` | Vertical | Showin' Up |
| **Punch-in** (hard cut to 1.336x / 1.48x, captions stay put) | Built | `mkvertical.py` motion, `mkcapcut.py` | Vertical, CineYap 16:9 | Showin' Up |
| **Green card** (full green plate, cream day label, big white word) | Built | `mkvertical.py` cards | Vertical | Showin' Up |
| **Bold Stack** (green card, list words land one per line: "Batch / Record") | Built as the stack card, not yet a named effect | `mkvertical.py` card `type: stack` | Vertical | Showin' Up |
| **Cream card** (cream plate, word in green-black) | Built | `mkvertical.py` cards | Vertical | Showin' Up |
| **Matte background** (a line on a plain green or cream plate) | Built | review widget, `mkcapcut.py` | CineYap 16:9 | Gabe's request |
| **Text behind subject** | Built | `make_behind.py`, review widget | CineYap 16:9 | Gabe's request |
| **Ken Burns / slow push** on B-roll | Built, OFF for the Showin' Up style (its B-roll holds still) | builders | CineYap 16:9 | measured |
| **Split screen** with `Step #N` label | Measured, not built | pack `vertical_cineyap.split` | none yet | 30 Pieces in 30 Min |
| **Media card** (cream card holding a picture) | Measured, not built | pack `vertical_cineyap.media_card` | none yet | 30 Pieces in 30 Min |
| **Green screen** (Gabe keyed over footage or a screen recording) | Idea | | | Gabe, 2026-10-02 |
| **Bold Stack title** (the stack used as an opening title) | Idea | | | Gabe, 2026-10-02 |

## Next, in Gabe's words (2026-10-02)

"Bold Stack" as its own effect, a transition set, split-screen, and green-screen, pulled from the same
kind of effects library the Homewell engine has (learn the look; never copy its code). Each one gets built
the way Flash + Click was: measured off a real example, shared in `fx.py`, proven on an export.
