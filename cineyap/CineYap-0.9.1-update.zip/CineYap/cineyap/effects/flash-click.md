# Effect: Flash + Click transition

**Status: LOCKED 2026-10-02.** Gabe: "the sound effect that you created is perfect now." Measured off his
reel "How To Keep Showin' Up" and proven on CapCut exports (every click within 1 ms of the reference).

**Code:** `cineyap/fx.py` → `FlashClick`. Every format calls this one class. Never re-implement the flash
or the click inside a format builder; change it here and every format gets the change.

## What it is

An orange light-leak flash over a cut, with a short click sound that lands just before it.

| Part | Value |
|---|---|
| Flash clip | `Overlay 1.mp4` (config `sfx_flash_overlay`), the ORIGINAL file |
| Blend | CapCut **Screen** (a `mix_mode` effect record, cached at `cineyap/_capcut_mix_screen.json`) |
| Flash timing | starts ON the cut frame, 0.45s long. Its first frame is the brightest, so it covers the cut |
| Flash framing | covers the canvas; on a landscape canvas the portrait leak is turned 90 degrees |
| Click sound | Quick Click (config `sfx_click`) |
| Click timing | the click's snap lands **2 frames before** the flash frame (pack `sfx.click_lead_frames`) |
| Click level | volume **0.35** against a voice at -16.7 LUFS (pack `sfx.click_volume`) |
| Where it goes | into the hook card, out of the cream card, out of green cards back to camera, and on a B-roll-to-camera cut when the plan names one. Not on every cut. |

## How to use it

```python
from fx import FlashClick
fc = FlashClick(sf, job_dir, pack, canvas=(W, H))   # adds the Flash and SFX tracks
fc.add(t)                                           # flash on the cut at t, click 2 frames ahead
fc.add_click(t)                                     # a click alone, snap on the sample t
finish(sf, dst, ...)                                # the normal capcut_draft finish
fc.finish(dst)                                      # Screen blend onto every flash
```

Formats wired: vertical (`mkvertical.py`, cards decide where), 16:9 CineYap (`mkcapcut.py`, the review
widget's flash toggle per line). New formats: create one `FlashClick` and call `add()` at each transition.

## Why it is built this way (each one cost a failed export)

1. **Original clip + Screen, never an alpha-converted copy.** Turning the leak's brightness into alpha and
   un-premultiplying an 8-bit clip lifts its dark compression blocks into visible bands ("pixelated").
2. **CapCut drops audio clips under 0.1s from the exported mix** (they still play in the editor). The
   0.1s Quick Click exported silent. It is padded with silence to half a second.
3. **CapCut rounds an audio clip's start AND its head-trim UP to whole frames.** Placing the click at its
   exact time came out 0-41 ms late; trimming its head came out 41-ms-minus-trim early. So each click sits
   exactly on a frame and carries its own sub-frame lead-in as silence: one tiny wav per click in
   `projects/<job>/fx/clicks/`. Result: 0 ms on all six clicks.
4. The click file has 64 ms of lead-in before its snap. The onset is measured from the file, so the snap,
   not the file start, lands on the time asked for.

## Checking it

`check_copy.py <job> <export.mov>` reports every click's offset against the reference in ms. For a new
video with no reference, open the export and look at the waveform: the snap should sit 2 frames before
the flash frame.
