#!/usr/bin/env python3
"""rank_takes.py — group the takes that say the same thing, and rank them.

    cd <job>/build && ./vu-py cineyap/rank_takes.py

THE PROBLEM THIS SOLVES. Gabe does not do one clean read. C1644 was 7.5 minutes and 26 takes, with the
same line attempted three to five times, and the job of writing mkedl.py started with reading all 26 and
holding them in your head. That is the slowest human step in the pipeline.

WHAT IT DOES. Splits the transcript into takes on silence, groups the takes that are near-duplicates of
each other, scores each one, and writes a shortlist. It does NOT write the cut: which take serves the
story is a judgment call, and a take that scores badly is sometimes the one you want. It removes the
reading, not the deciding.

HOW THE SCORE WORKS, and why each part is there:
  completeness   more words of the same idea usually means he got further before stopping
  closed         ends on . ? or ! rather than trailing off mid-clause
  no stammer     penalises repeated 3-grams INSIDE the take ("And so / And next / And next")
  clean head     there is real silence before it, so it can be cut into without clipping
  later          ties break toward the later take, because he works toward the phrasing he wants

Writes `takes_ranked.md` next to the transcript.
"""
import json, pathlib, re, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from learned import get as learned


GAP      = 1.5     # silence that separates one take from the next
# Calibrated on C1644 against pairs known by hand to be re-attempts. SequenceMatcher is the
# wrong measure here - two real attempts at the ladder line score 0.17 on it because the
# wording drifts. CONTAINMENT (shared words / the smaller take) separates cleanly: known
# duplicates 0.89 and 1.00, unrelated-but-adjacent ideas 0.41-0.52. Jaccard is the second
# guard, and MIN_W stops a one-word take ("No.") being trivially contained in everything.
CONTAIN  = 0.70
JACCARD  = 0.35
MIN_W    = 8
B   = pathlib.Path.cwd()
JOB = B.parent
# Runs at step 2.5, BEFORE the EDL exists - so find the transcript directly, never via edl.json.
_tr = sorted((JOB/"edit/transcripts").glob("*.json")) if (JOB/"edit/transcripts").exists() else []
if not _tr:
    raise SystemExit(f"No transcript in {JOB/'edit/transcripts'}.\n"
                     "  Transcribe first:  ./vu transcribe.py \"<the take>\" --edit-dir "
                     f"{JOB/'edit'}")
if len(_tr) > 1:
    _tr = sorted(_tr, key=lambda p: p.stat().st_mtime)
stem = _tr[-1].stem
W = [w for w in json.load(open(_tr[-1]))["words"] if w.get("text","").strip()]

# ---- split into takes
takes, cur = [], [W[0]]
for a, b in zip(W, W[1:]):
    if b["start"] - a["end"] > GAP:
        takes.append(cur); cur = [b]
    else:
        cur.append(b)
takes.append(cur)

def text(t):   return " ".join(w["text"].strip() for w in t)
def norm(s):   return re.sub(r"[^a-z0-9 ]", "", s.lower())

def clean_start(t):
    """Where the LAST clean run begins inside a take.

    Gabe restarts by going back to the top of the sentence: "And so if you were to visualize a
    ladder, at the bottom is a complete beginner as / And so if you are / And so if you were to
    just visualize a ladder...". Scribe transcribes every attempt, so the restarts are visible in
    the text. The last time the take's own opening phrase reappears is where the keeper begins.
    Validated on C1644: this reproduces the in-points picked by hand for takes 4, 7 and 8.
    """
    g = norm(text(t)).split()
    for k in (4, 3, 2):
        if len(g) < k * 2: continue
        head = g[:k]
        hits = [i for i in range(1, len(g) - k + 1) if g[i:i+k] == head]
        if hits:
            return hits[-1], " ".join(head)
    return None, None


def stammer(t):
    """repeated 3-grams inside one take — the 'And so / And next / And next' signature"""
    g = norm(text(t)).split()
    tri = [" ".join(g[i:i+3]) for i in range(len(g)-2)]
    return len(tri) - len(set(tri))

recs = []
for i, t in enumerate(takes):
    head = t[0]["start"] - (takes[i-1][-1]["end"] if i else 0)
    ci, phrase = clean_start(t)
    # LEARNED: Gabe trims a leading connective off the front of a cut (observed on C1644:
    # the tool said 48.36 / 83.60, he picked 48.58 / 83.82, each dropping an "And so").
    if ci is not None:
        for lead in learned("drop_leading", []):
            toks = norm(lead).split()
            if norm(text(t[ci:])).split()[:len(toks)] == toks:
                ci += len(toks)
                break
    recs.append({"i": i+1, "t0": t[0]["start"], "t1": t[-1]["end"], "n": len(t),
                 "text": text(t), "stammer": stammer(t), "head": head,
                 "closed": text(t).rstrip()[-1:] in ".?!",
                 "clean_t": t[ci]["start"] if ci else None,
                 "clean_i": ci, "restart_phrase": phrase,
                 "clean_text": text(t[ci:]) if ci else None})

# ---- group near-duplicates (union-find, so a chain of three attempts lands in one group)
def tok(r): return set(norm(r["text"]).split())
parent = {r["i"]: r["i"] for r in recs}
def find(a):
    while parent[a] != a: parent[a] = parent[parent[a]]; a = parent[a]
    return a
def union(a, b): parent[find(a)] = find(b)
for i, a in enumerate(recs):
    for b in recs[i+1:]:
        ta, tb = tok(a), tok(b)
        if min(len(ta), len(tb)) < MIN_W: continue
        if not ta or not tb: continue
        contain = len(ta & tb) / min(len(ta), len(tb))
        jac     = len(ta & tb) / len(ta | tb)
        if contain >= CONTAIN and jac >= JACCARD:
            union(a["i"], b["i"])
bucket = {}
for r in recs: bucket.setdefault(find(r["i"]), []).append(r)
groups = list(bucket.values())

def score(r, g):
    best_n = max(x["n"] for x in g)
    s  = 40 * (r["n"] / best_n)          # completeness, relative to the fullest in the group
    s += 15 if r["closed"] else 0
    s -= 8 * r["stammer"]
    s += 10 if r["head"] >= 0.8 else 0   # real silence in front of it
    s += 5 * (r["i"] / len(recs))        # he works toward it
    return round(s, 1)

out = [f"# Take shortlist — {stem}", "",
       f"{len(takes)} takes, {len(groups)} distinct ideas. "
       f"**Ranked, not decided** — pick the one that serves the story.", ""]
groups.sort(key=lambda g: min(x["t0"] for x in g))
for n, g in enumerate(groups, 1):
    for r in g: r["score"] = score(r, g)
    g.sort(key=lambda r: -r["score"])
    out.append(f"## {n}. {g[0]['text'][:72]}{'…' if len(g[0]['text'])>72 else ''}")
    if len(g) == 1:
        out.append(f"- only take · `{g[0]['t0']:.2f}-{g[0]['t1']:.2f}` · {g[0]['n']}w")
    else:
        out.append(f"{len(g)} attempts:")
        for k, r in enumerate(g):
            mark = "**PICK**" if k == 0 else "       "
            flags = []
            if r["stammer"]: flags.append(f"{r['stammer']} repeat")
            if not r["closed"]: flags.append("trails off")
            if r["head"] < 0.8: flags.append("tight head")
            out.append(f"- {mark} take {r['i']:2d} · `{r['t0']:7.2f}-{r['t1']:7.2f}` · "
                       f"{r['n']:3d}w · score {r['score']:5.1f}"
                       + (f" · {', '.join(flags)}" if flags else ""))
    out.append("")
    b = g[0]
    if b["clean_t"]:
        out.append(f"- ⚠️ restarts inside it. **Clean run begins `{b['clean_t']:.2f}`** "
                   f"(the {b['restart_phrase']!r} that sticks). Cut from there, not from "
                   f"`{b['t0']:.2f}`.")
        out.append("")
        out.append(f"> ~~{b['text'][:b['text'].find(b['clean_text'][:24]) if b['clean_text'][:24] in b['text'] else 0]}~~"
                   f"**{b['clean_text'][:260]}**{'…' if len(b['clean_text'])>260 else ''}")
    else:
        out.append(f"> {b['text'][:300]}{'…' if len(b['text'])>300 else ''}")
    out.append("")

p = JOB/"edit/takes_ranked.md"; p.write_text("\n".join(out))
print(f"{len(takes)} takes -> {len(groups)} ideas -> {p}")
