#!/usr/bin/env python3
"""Step 11 - emit the finished cut as an EDITABLE Premiere timeline.

    ./vu-py cineyap/mkxml.py

Gabe finishes in Premiere, so nothing may arrive flattened:

  V1  the A-roll cut as ONE CLIP PER EDL SEGMENT, cut from graded_source.mp4
      (the whole take, graded) so every cut point has real handles to drag into.
      Linked to A1, so dragging a cut moves picture and sound together.
  V2  each B-roll insert as its own clip
  V3  card BACKGROUNDS as solid colour plates - recolour or replace them
  V4  captions, text only with alpha. Card text is separated from its background
      by un-compositing the rendered PNG, so the two arrive on different tracks.
  A1  the audio, segmented and linked to V1

Timeline positions come from the per-segment frame counts in edit/clips_graded/,
never from the EDL's nominal durations - per-segment frame rounding drifts about
half a second over seventeen cuts.

FCP7 XML (xmeml v5): Premiere Pro, Resolve, Final Cut.
"""
import json, pathlib, subprocess, urllib.parse, sys
import numpy as np
from PIL import Image

B = pathlib.Path.cwd()
if not (B/"base_clean.mp4").exists(): sys.exit("run this from the job's build/ directory")
JOB, FPS = B.parent, 24000/1001
f   = lambda s:int(round(s*FPS))
url = lambda p:"file://localhost"+urllib.parse.quote(str(p))
def nf(p):
    """Counted video frames, or 0 if the file will not probe (truncated / not yet complete)."""
    out = subprocess.run(["ffprobe","-v","error","-count_frames","-select_streams","v:0",
        "-show_entries","stream=nb_read_frames","-of","csv=p=0",str(p)],
        capture_output=True,text=True).stdout.strip()
    return int(out) if out.isdigit() else 0
def dims(p):
    o=subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
        "stream=width,height","-of","csv=p=0",str(p)],capture_output=True,text=True).stdout.strip().split(",")
    return int(o[0]),int(o[1])

W,H = dims(B/"base_clean.mp4"); NF = nf(B/"base_clean.mp4")
GREEN=np.array([9,26,20],float); CREAM=np.array([245,240,234],float); WHITE=np.array([255,255,255],float)

# ---------- 1. split every card frame into a plate + transparent text ----------
A=B/"assets"; SP=A/"split"; SP.mkdir(exist_ok=True)
for nm,c in (("BG_green",GREEN),("BG_cream",CREAM)):
    if not (SP/f"{nm}.png").exists():
        Image.fromarray(np.tile(np.append(c,255).astype(np.uint8),(H,W,1))).save(SP/f"{nm}.png")
CARD={}                                   # cue stem -> "green" | "cream"
for p in sorted(A.glob("cue*.png")):
    a=np.array(Image.open(p).convert("RGBA"))
    if (a[...,3]>250).mean()<=0.99: continue
    green=np.linalg.norm(a[5,5,:3].astype(float)-GREEN)<12
    CARD[p.stem]="green" if green else "cream"
    out=SP/f"txt_{p.stem}.png"
    if out.exists(): continue
    bg,fg=(GREEN,WHITE) if green else (CREAM,GREEN)
    alpha=np.clip(np.linalg.norm(a[...,:3].astype(float)-bg,axis=-1)/np.linalg.norm(fg-bg),0,1)
    o=np.zeros((H,W,4),np.uint8); o[...,:3]=fg.astype(np.uint8); o[...,3]=(alpha*255).astype(np.uint8)
    Image.fromarray(o).save(out)

# ---------- 2. A-roll segments, with handles ----------
edl=json.load(open(JOB/"edit/edl.json")); stem=list(edl["sources"])[0]
GS=B/"graded_source.mp4"
def _usable(p):
    """Present is not the same as finished. An encode killed part-way leaves a file with no moov
    atom, and a plain exists() check would reuse that corpse forever."""
    if not p.exists() or p.stat().st_size < 1_000_000: return False
    return subprocess.run(["ffprobe","-v","error","-select_streams","v:0",
                           "-show_entries","stream=duration","-of","csv=p=0",str(p)],
                          capture_output=True, text=True).returncode == 0
if not _usable(GS):
    GS.unlink(missing_ok=True)
    # V1's clips need HANDLES - material either side of every cut - so they point at the whole
    # take, graded, at delivery size. base_clean has no handles: the gaps were thrown away.
    # Deterministic from the source + LUT, so build it rather than make it a manual step.
    src = list(json.load(open(JOB/"edit/edl.json"))["sources"].values())[0]
    lut = JOB/"lut.cube"
    vf = (f"lut3d=file={lut}," if lut.exists() else "") + f"scale={W}:{H}"
    print(f"  building graded_source.mp4 (the whole take at {W}x{H}) - this takes a few minutes…")
    # Build to a TEMP name and rename only on success. An interrupted ffmpeg leaves a partial
    # file, and a partial with the right name is worse than none: the next run sees it, skips
    # the build, and dies probing a file with no moov atom. Rename is atomic, so the real name
    # only ever exists complete.
    tmp = GS.with_suffix(".building.mp4")
    tmp.unlink(missing_ok=True)
    r = subprocess.run(["ffmpeg","-v","error","-y","-i",src,"-vf",vf,
                        "-c:v","h264_videotoolbox","-b:v","12M","-pix_fmt","yuv420p",
                        "-c:a","aac","-b:a","192k","-movflags","+faststart",str(tmp)])
    if r.returncode or not tmp.exists():
        tmp.unlink(missing_ok=True)
        sys.exit("could not build graded_source.mp4 - is the original take reachable?")
    if not nf(tmp):                      # readable end to end, not a fragment
        tmp.unlink(missing_ok=True)
        sys.exit("graded_source.mp4 built but will not probe - the render was interrupted. Re-run.")
    tmp.rename(GS)
GSF=nf(GS)
segs=[]; t=0
for i,r in enumerate(edl["ranges"]):
    n=nf(JOB/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4")
    s0=f(r["start"])
    segs.append({"i":i+1,"t0":t,"t1":t+n,"s0":s0,"s1":s0+n,"beat":r.get("beat","")}); t+=n
assert t==NF, f"segments sum to {t}, base is {NF}"

R="<rate><timebase>24</timebase><ntsc>TRUE</ntsc></rate>"
ASC="<samplecharacteristics><depth>16</depth><samplerate>48000</samplerate></samplecharacteristics>"
TC=f"<timecode>{R}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>"
OUTS=("<outputs><group><index>1</index><numchannels>2</numchannels><downmix>0</downmix>"
      "<channel><index>1</index></channel><channel><index>2</index></channel></group></outputs>")
def vfile(fid,p,frames,alpha=False,audio=False):
    al="<alphatype>straight</alphatype>" if alpha else ""
    au=f"<audio>{ASC}<channelcount>2</channelcount></audio>" if audio else ""
    return (f'<file id="{fid}"><name>{pathlib.Path(p).name}</name><pathurl>{url(p)}</pathurl>{R}'
            f'<duration>{frames}</duration>{TC}<media><video><samplecharacteristics>{R}'
            f'<width>{W}</width><height>{H}</height>{al}</samplecharacteristics></video>{au}</media></file>')
FGS_REF = '<file id="fgs"/>'   # kept out of the f-string: py3.11 rejects a backslash inside one

def link(i):
    return (f'<link><linkclipref>v{i}</linkclipref><mediatype>video</mediatype>'
            f'<trackindex>1</trackindex><clipindex>{i}</clipindex></link>'
            f'<link><linkclipref>a{i}</linkclipref><mediatype>audio</mediatype>'
            f'<trackindex>1</trackindex><clipindex>{i}</clipindex></link>')

V1="".join(f'\n     <clipitem id="v{s["i"]}"><name>{s["i"]:02d} {s["beat"]}</name>{R}'
    f'<duration>{GSF}</duration><start>{s["t0"]}</start><end>{s["t1"]}</end>'
    f'<in>{s["s0"]}</in><out>{s["s1"]}</out><enabled>TRUE</enabled>'
    f'{vfile("fgs",GS,GSF,audio=True) if s["i"]==1 else FGS_REF}{link(s["i"])}</clipitem>' for s in segs)
A1="".join(f'\n     <clipitem id="a{s["i"]}"><name>{s["i"]:02d} {s["beat"]}</name>{R}'
    f'<duration>{GSF}</duration><start>{s["t0"]}</start><end>{s["t1"]}</end>'
    f'<in>{s["s0"]}</in><out>{s["s1"]}</out><enabled>TRUE</enabled>'
    f'<file id="fgs"/><sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>'
    f'{link(s["i"])}</clipitem>' for s in segs)

# ---------- 3. inserts ----------
ins=json.load(open(B/"inserts.json")) if (B/"inserts.json").exists() else []
V2="".join(f'\n     <clipitem id="ins{i}"><name>{o.get("key","insert")} - {(o.get("why") or "")[:40]}</name>{R}'
    f'<duration>{f(o["t1"])-f(o["t0"])}</duration><start>{f(o["t0"])}</start><end>{f(o["t1"])}</end>'
    f'<in>{f(o.get("asset_in",0.0))}</in><out>{f(o.get("asset_in",0.0))+f(o["t1"])-f(o["t0"])}</out><enabled>TRUE</enabled>'
    f'{vfile(f"fins{i}",(B/o["file"]).resolve(),f(o["t1"])-f(o["t0"]))}</clipitem>'
    for i,o in enumerate(ins,1))

# ---------- 4. cue runs off the rendered sequence ----------
seq=sorted((A/"seq").glob("f*.png"))[:NF]
runs=[]
for i,fr in enumerate(seq):
    tgt=pathlib.Path(fr).resolve()
    if runs and runs[-1][0]==tgt: runs[-1][2]=i+1
    else: runs.append([tgt,i,i+1])
caps=[r for r in runs if "blank" not in r[0].name]

# V3: background plates - merge adjacent card runs of the same colour
bgruns=[]
for tgt,a,b in caps:
    col=CARD.get(tgt.stem)
    if not col: continue
    if bgruns and bgruns[-1][0]==col and bgruns[-1][2]==a: bgruns[-1][2]=b
    else: bgruns.append([col,a,b])
V3="".join(f'\n     <clipitem id="bg{i}"><name>{c} card</name>{R}<duration>2400</duration>'
    f'<start>{a}</start><end>{b}</end><in>0</in><out>{b-a}</out><enabled>TRUE</enabled>'
    f'{vfile(f"fbg{i}",SP/f"BG_{c}.png",2400)}</clipitem>' for i,(c,a,b) in enumerate(bgruns,1))

# V4: the text, always transparent
V4=""
for i,(tgt,a,b) in enumerate(caps,1):
    p = SP/f"txt_{tgt.stem}.png" if tgt.stem in CARD else tgt
    V4+=(f'\n     <clipitem id="cap{i}"><name>{tgt.stem}</name>{R}<duration>2400</duration>'
         f'<start>{a}</start><end>{b}</end><in>0</in><out>{b-a}</out><enabled>TRUE</enabled>'
         f'{vfile(f"fcap{i}",p,2400,alpha=True)}</clipitem>')

name=JOB.name
def track(body): return f'\n    <track><enabled>TRUE</enabled><locked>FALSE</locked>{body}\n    </track>'
xml=f'''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE xmeml>
<xmeml version="5">
 <sequence id="{name}">
  <name>{name} - editable</name><duration>{NF}</duration>{R}{TC}
  <media>
   <video>
    <format><samplecharacteristics>{R}<width>{W}</width><height>{H}</height>
      <pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></format>{track(V1)}{track(V2)}{track(V3)}{track(V4)}
   </video>
   <audio><format>{ASC}</format>{OUTS}{track(A1)}
   </audio>
  </media>
 </sequence>
</xmeml>'''
out=JOB/"edit"/f"{name}-editable.xml"; out.write_text(xml)
print(f"V1 {len(segs)} A-roll cuts (handles from graded_source) | V2 {len(ins)} inserts | "
      f"V3 {len(bgruns)} card plates | V4 {len(caps)} captions | A1 {len(segs)} linked")
print(f"-> {out}")
