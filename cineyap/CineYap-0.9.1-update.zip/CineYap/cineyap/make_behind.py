#!/usr/bin/env python3
"""make_behind.py <job> <line> [--no-mark] — cut the subject out of one A-roll line for text-behind-subject.

Runs HyperFrames' local background removal (u2net_human_seg on CoreML, no upload) on that line's
rendered clip, then converts the VP9-alpha WebM to ProRes 4444 with alpha, which CapCut imports with
its transparency intact. Writes build/assets/behind/sub_lineNN.mov and adds the line to effects.json.
Slow: about 0.2s a frame, so a 6-second line takes ~40s.
"""
import json, pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PROJECTS
job, line = sys.argv[1], int(sys.argv[2])
J = PROJECTS/job; B = J/"build"; OUT = B/"assets"/"behind"; OUT.mkdir(parents=True, exist_ok=True)
edl = json.load(open(J/"edit/edl.json")); stem = pathlib.Path(list(edl["sources"].values())[0]).stem
src = J/f"edit/clips_graded/seg_{line-1:02d}_{stem}.mp4"
webm, mov = OUT/f"sub_line{line:02d}.webm", OUT/f"sub_line{line:02d}.mov"
if not webm.exists() or webm.stat().st_size == 0:
    subprocess.run(["npx","--yes","hyperframes@latest","remove-background",str(src),"-o",str(webm),"--quality","best"], check=True)
# The cutout model writes 1199/50 fps (23.98); the picture is 24000/1001 (23.976). Close is not equal:
# CapCut picks frames by time, so near a frame boundary the cutout showed the NEXT frame over the
# current picture, and on a fast hand move that reads as a doubled, delayed subject. Re-stamp it
# frame for frame onto the picture's exact rate (no frames added or dropped).
subprocess.run(["ffmpeg","-y","-v","error","-c:v","libvpx-vp9","-i",str(webm),
                "-vf","setpts=N/(24000/1001)/TB","-r","24000/1001","-c:v","prores_ks","-profile:v","4444",
                "-pix_fmt","yuva444p10le","-an",str(mov)], check=True)
if "--no-mark" in sys.argv:                 # just the cutout (Split, GreenScreen, BoldBehind use it too)
    print(f"{mov.name} written"); sys.exit(0)
efx = json.load(open(B/"effects.json")) if (B/"effects.json").exists() else {}
lst = efx.setdefault("behind", [])
if not any(int(e["take"]) == line for e in lst): lst.append({"take": line})
json.dump(efx, open(B/"effects.json","w"), indent=1)
print(f"{mov.name} written; line {line} marked text-behind-subject in effects.json")
