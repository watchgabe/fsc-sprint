#!/usr/bin/env python3
"""subject_zones.py <job> — find where the subject is, a few times a second, across the whole cut.

Run once after the cut is rendered (build/base_clean.mp4 exists). Writes build/zones.json:

    {"rate": 4, "samples": [{"t": 1.25, "eye_x": .51, "eye_y": .36, "chin_y": .55,
                             "face": [x0, y0, x1, y1]}, ...]}

All positions are fractions of the frame, 0 = top / left. `t` is on the picture clock (the rendered
cut), the same clock CapCut and cut_guard.py use. A sample where no face was found is left out.

Read by:
  mkcapcut.py   EYE LOCK - every A-roll clip is placed so the eye line sits on one height for the whole
                video, through cuts and push-ins
                TEXT BEHIND SUBJECT - the line's words are centred on the eye line, so only the head
                covers them, not the shoulders and hands
Local model (OpenCV YuNet face detector, MIT, cineyap/models/). No upload, no key.
"""
import json, pathlib, subprocess, sys
import numpy as np
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS

if len(sys.argv) < 2: sys.exit("usage: subject_zones.py <job> [rate]")
job = sys.argv[1]; RATE = float(sys.argv[2]) if len(sys.argv) > 2 else 4.0
B = PROJECTS/job/"build"; SRC = B/"base_clean.mp4"
if not SRC.exists(): sys.exit(f"no {SRC} - render the cut first")
MODEL = PKG/"cineyap/models/face_detection_yunet_2023mar.onnx"
if not MODEL.exists(): sys.exit(f"missing {MODEL} - re-run install.sh")

# OpenCV YuNet (MIT): face box + 5 points (both eyes, nose, mouth corners), CPU, no GPU service needed.
# (MediaPipe was tried first; on this Mac it demands a Metal service even in CPU mode and aborts.)
import cv2
W, H = 640, 360                                  # detection size; positions come back as fractions
det = cv2.FaceDetectorYN.create(str(MODEL), "", (W, H), 0.7)
cmd = ["ffmpeg", "-v", "error", "-i", str(SRC), "-vf", f"fps={RATE},scale={W}:{H}", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
out, n = [], 0
while True:
    buf = proc.stdout.read(W * H * 3)
    if len(buf) < W * H * 3: break
    img = np.frombuffer(buf, np.uint8).reshape(H, W, 3)
    t = round(n / RATE, 3); n += 1
    _, faces = det.detect(img)
    if faces is None or not len(faces): continue
    f = max(faces, key=lambda r: r[2] * r[3])    # the biggest face is the subject
    x, y, w, h = f[:4]; rex, rey, lex, ley = f[4:8]
    out.append({"t": t,
                "eye_x": round(float((rex + lex) / 2 / W), 4),
                "eye_y": round(float((rey + ley) / 2 / H), 4),
                "chin_y": round(float((y + h) / H), 4),
                "face": [round(float(x / W), 4), round(float(y / H), 4), round(float((x + w) / W), 4), round(float((y + h) / H), 4)]})
proc.wait()

# ---- exact eye height on the first and last frames of every A-roll clip, at full detection size. The
# quarter-second samples are for following; a CUT needs the exact frames either side of it.
edl = json.load(open(PROJECTS/job/"edit/edl.json")); stem = list(edl["sources"])[0]
FPS = 24000/1001
def nframes(f):
    o = subprocess.run(["ffprobe","-v","error","-select_streams","v:0","-show_entries","stream=nb_frames","-of","csv=p=0",str(f)],
                       capture_output=True, text=True).stdout.strip()
    return int(o) if o.isdigit() else 0
def eye_on(frame_idx):
    raw = subprocess.run(["ffmpeg","-v","error","-i",str(SRC),"-vf",f"select=eq(n\\,{frame_idx}),scale={W}:{H}",
                          "-frames:v","1","-f","rawvideo","-pix_fmt","bgr24","-"], capture_output=True).stdout
    if len(raw) < W*H*3: return None
    _, fs = det.detect(np.frombuffer(raw, np.uint8).reshape(H, W, 3))
    if fs is None or not len(fs): return None
    f = max(fs, key=lambda r: r[2]*r[3]); return round(float((f[5]+f[7])/2/H), 4)
clips, start = [], 0
for i in range(len(edl["ranges"])):
    nf = nframes(PROJECTS/job/f"edit/clips_graded/seg_{i:02d}_{stem}.mp4")
    a = [e for e in (eye_on(start + k) for k in range(3)) if e is not None]
    b = [e for e in (eye_on(start + nf - 1 - k) for k in range(3)) if e is not None]
    clips.append({"i": i, "t0": round(start/FPS, 4), "t1": round((start+nf)/FPS, 4),
                  "eye_start": float(np.median(a)) if a else None, "eye_end": float(np.median(b)) if b else None})
    start += nf
json.dump({"rate": RATE, "source": SRC.name, "samples": out, "clips": clips}, open(B/"zones.json", "w"), indent=0)
jumps = [abs(clips[i+1]["eye_start"] - clips[i]["eye_end"]) for i in range(len(clips)-1)
         if clips[i]["eye_end"] is not None and clips[i+1]["eye_start"] is not None]
if jumps: print(f"  eye jump at the {len(jumps)} cuts, raw footage: mean {np.mean(jumps)*100:.1f}% of frame height, worst {max(jumps)*100:.1f}%")
eyes = [s["eye_y"] for s in out]
print(f"{job}: {n} frames sampled at {RATE:g}/s, face found in {len(out)} ({len(out)*100//max(n,1)}%)")
if eyes: print(f"  eye line: median {np.median(eyes):.3f} of frame height, range {min(eyes):.3f}-{max(eyes):.3f}")
