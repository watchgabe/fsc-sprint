# CineYap tester terms

You're getting CineYap early, before it's finished, in exchange for honest feedback. Things will break,
and when they do, run `/report` and post the zip in the CineYap testers space in Circle with one line about
what you were doing. That post is the most useful thing you can give me. Keep the CineYap folder and
its files to yourself while it's in testing, so please don't share, resell or repost them. Your videos
stay yours and stay on your Mac. The only thing that leaves it is your audio, which goes to ElevenLabs
under your own key so CineYap can make the transcript. Nothing comes to me unless you send a report,
and a report never holds video, audio or keys. CineYap checks for a new version once a day and `/update`
installs it without touching your projects, brand or settings. Keep your raw footage backed up
somewhere else, because this is test software and I can't promise it won't lose a file. Either of us
can end the test at any time.

Keep creating,
Gabe
