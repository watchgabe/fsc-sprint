#!/usr/bin/env python3
"""Render on-screen text as transparent PNG frames, from a STYLE PACK.

Exists because neither ffmpeg's drawtext nor libass can apply NEGATIVE letter spacing, and every
one of these styles depends on tight tracking. libass has a Spacing field but clamps negative
values to zero - measured 2026-09-23. So glyphs are placed one at a time with a manual advance.

THE LOOK IS DATA, NOT CODE. Everything that makes it Gabe's - fonts, sizes, tracking, the green and
cream, where the running caption sits - lives in `cineyap/styles/gabe.json`. Copy that file, change
what you like, and point `look` in config.json at your file's name. The rendering logic below is the
same for every pack; only the numbers differ.

Spec: Operations/Video-Text-Style.md in the AI Brain.

Usage (as a library):
    from gabe_text import render_card, render_small_left, render_big_centre
    use_style("mine")   # optional; default is the pack named in config.json, else "gabe"
    use_vertical()      # switch to the 9:16 block
"""
from __future__ import annotations

import json, os
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

STYLES = Path(__file__).resolve().parent.parent / "cineyap" / "styles"

_PACK: dict = {}
_O: dict = {}          # the active orientation block
VERTICAL = False


def _resolve(p: str) -> str:
    return os.path.expanduser(p) if p else p


def use_style(name: str = None, vertical: bool = None) -> dict:
    """Load a style pack by name (no .json). Re-applies the current orientation."""
    global _PACK, VERTICAL
    if name is None:
        try:
            import sys as _s; _s.path.insert(0, str(STYLES.parent))
            from config import opt as _opt
            name = _opt("look", "gabe")
        except SystemExit:
            name = "gabe"          # no config.json yet - a bare render still works
        except Exception:
            name = "gabe"
    if name.endswith(".py"):       # tolerate an old-style module name in config
        name = name[:-3]
    if name == "gabe_text":
        name = "gabe"
    f = STYLES / f"{name}.json"
    if not f.exists():
        raise SystemExit(f"No style pack '{name}'. Looked in {STYLES}.\n"
                         f"  Available: {', '.join(sorted(p.stem for p in STYLES.glob('*.json'))) or 'none'}\n"
                         f"  Copy styles/gabe.json to styles/<yours>.json and set `look` in config.json.")
    _PACK = json.loads(f.read_text())
    if vertical is not None:
        VERTICAL = vertical
    _apply()
    return _PACK


def _apply():
    """Pull the active orientation block into module-level names."""
    global _O, W, H, SMALL_SIZE, SMALL_TRACK, BIG_SIZE, BIG_TRACK
    global SERIF_SIZE, SERIF_TRACK, MAX_TEXT_W, SMALL_LEFT_X, SMALL_Y_FRAC
    global GREEN, CREAM, WHITE, HELVETICA, HELVETICA_BOLD_INDEX, INSTRUMENT_ITALIC, CENSOR
    _O = _PACK["vertical" if VERTICAL else "horizontal"]
    W, H = _O["canvas"]
    SMALL_SIZE, SMALL_TRACK = _O["small_size"], _O["small_track"]
    BIG_SIZE,   BIG_TRACK   = _O["big_size"],   _O["big_track"]
    SERIF_SIZE, SERIF_TRACK = _O["serif_size"], _O["serif_track"]
    MAX_TEXT_W   = _O["max_text_w"]
    SMALL_LEFT_X = _O.get("small_left_x")
    SMALL_Y_FRAC = _O.get("small_y_frac", 0.5)
    c = _PACK["colors"]
    GREEN, CREAM, WHITE = tuple(c["ink"]), tuple(c["paper"]), tuple(c["white"])
    f = _PACK["fonts"]
    HELVETICA = _resolve(f["sans"]); HELVETICA_BOLD_INDEX = f.get("sans_index", 0)
    INSTRUMENT_ITALIC = _resolve(f["serif"])
    CENSOR = _PACK.get("censor", {})


def use_vertical():
    """Switch to the pack's 9:16 block.

    Vertical drops the left-aligned treatment: EVERY caption is centred, and A-roll captions sit
    below centre so they do not cover the face. Nothing ever wraps - a caption too wide for the
    frame shrinks to fit.
    """
    global VERTICAL
    VERTICAL = True
    _apply()


use_style()   # load the default pack at import, so the module is usable immediately


def censor(text: str) -> str:
    """Profanity is always spelled with an asterisk on screen."""
    out = []
    for w in text.split(" "):
        core = w.strip(".,!?").lower()
        out.append(w.lower().replace(core, CENSOR[core]) if core in CENSOR else w)
    return " ".join(out)


def _font(bold_helvetica: bool, size: int, serif: bool = False):
    if serif:
        return ImageFont.truetype(INSTRUMENT_ITALIC, size)
    return ImageFont.truetype(HELVETICA, size, index=HELVETICA_BOLD_INDEX)


def _tracked_width(draw, text, font, track_px):
    total = 0
    for ch in text:
        total += draw.textlength(ch, font=font) + track_px
    return total - track_px if text else 0


def _draw_tracked(draw, xy, text, font, fill, track_px):
    x, y = xy
    for ch in text:
        draw.text((x, y), ch, font=font, fill=fill)
        x += draw.textlength(ch, font=font) + track_px


def _canvas(bg=None):
    return Image.new("RGBA", (W, H), bg if bg else (0, 0, 0, 0))


def render_small_left(text: str, out: Path) -> Path:
    """The running A-roll caption. Left and vertically centred in 16:9; centred at chest height in 9:16."""
    img = _canvas(); d = ImageDraw.Draw(img)
    text = censor(text)
    size = SMALL_SIZE; f = _font(True, size); track = SMALL_TRACK / 1000 * size
    if VERTICAL or SMALL_LEFT_X is None:
        w = _tracked_width(d, text, f, track)
        while w > MAX_TEXT_W and size > 40:
            size = int(size * 0.94); f = _font(True, size)
            track = SMALL_TRACK / 1000 * size; w = _tracked_width(d, text, f, track)
        asc, desc = f.getmetrics()
        x = (W - w) / 2; y = H * SMALL_Y_FRAC - (asc + desc) / 2
    else:
        x = SMALL_LEFT_X; asc, desc = f.getmetrics()
        y = H * SMALL_Y_FRAC - (asc + desc) / 2
    _draw_tracked(d, (x, y), text, f, WHITE, track)
    img.save(out); return out


def render_big_centre(text: str, out: Path, serif: bool = False, colour=None,
                      bg=None, scale: float = 1.0, y_frac: float = 0.5) -> Path:
    """The large centred word. Helvetica at big_track, or the serif at serif_track."""
    colour = WHITE if colour is None else colour
    img = _canvas(bg); d = ImageDraw.Draw(img)
    size = int((SERIF_SIZE if serif else BIG_SIZE) * scale)
    track_units = SERIF_TRACK if serif else BIG_TRACK
    text = censor(text)
    f = _font(True, size, serif=serif); track = track_units / 1000 * size
    w = _tracked_width(d, text, f, track)
    while w > MAX_TEXT_W and size > 60:
        size = int(size * 0.94); f = _font(True, size, serif=serif)
        track = track_units / 1000 * size; w = _tracked_width(d, text, f, track)
    asc, desc = f.getmetrics()
    _draw_tracked(d, ((W - w) / 2, H * y_frac - (asc + desc) / 2), text, f, colour, track)
    img.save(out); return out


def render_card(text: str, out: Path, green: bool = True, serif: bool = False,
                scale: float = 1.0) -> Path:
    """A full-frame card in ink or paper, with one word."""
    bg = GREEN if green else CREAM
    fg = WHITE if green else GREEN
    return render_big_centre(text, out, serif=serif, colour=fg, bg=bg, scale=scale)


if __name__ == "__main__":
    import sys
    out = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
    out.mkdir(parents=True, exist_ok=True)
    render_small_left("not a", out / "demo_small.png")
    render_big_centre("completely", out / "demo_big.png")
    render_card("perfectionism", out / "demo_green_serif.png", green=True, serif=True)
    render_card("perfectionism", out / "demo_cream.png", green=False, serif=False)
    render_card("200", out / "demo_green_helv.png", green=True, serif=False)
    print(f"wrote demos to {out}  (style: {_PACK.get('name')})")
