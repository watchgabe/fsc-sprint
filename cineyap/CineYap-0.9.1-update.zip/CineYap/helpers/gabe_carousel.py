#!/usr/bin/env python3
"""Render Gabe's carousel slides.

Spec: Operations/Carousel-Style.md in the AI Brain. Every number there was measured
off the Ultimate Beginner's Guide set at 1440x1080.

Same reason as gabe_text.py for placing glyphs one at a time: every element uses
NEGATIVE tracking and neither drawtext nor libass can do it.

Usage:
    from gabe_carousel import render_slide
    render_slide(slide_dict, out_png, bg=path_to_frame_or_None)
"""
from __future__ import annotations

import re
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

W, H = 1440, 1080

HELVETICA = "/System/Library/Fonts/Helvetica.ttc"
HELVETICA_BOLD_INDEX = 1
INSTRUMENT_ITALIC = str(Path.home() / "Library/Fonts/InstrumentSerif-Italic.ttf")

WHITE = (255, 255, 255, 255)

# measured at 1440x1080 — size, tracking (1/1000 em)
EYEBROW = (49, -20)
HEADLINE = (95, -70)
BULLET = (42, -40)
FOOTNOTE = (30, -20)

LEFT = 81                 # 5.6% of width
BLOCK_TOP = 349           # 32.3% of height
BLOCK_BOTTOM = 897        # 83.1% of height
HEADLINE_PITCH = 90       # tighter than the type size, on purpose
BULLET_PITCH = 50
GAP_EYEBROW = 27
GAP_FOOTNOTE = 60
ARROW_W, ARROW_H = 36, 16   # measured at bullet size 42
HANG = 49                   # arrow start -> text start, measured
SAFE = 81                   # block may grow past the measured band, but not past this
MAXW = W - LEFT * 2        # text may not cross the mirrored right margin

CENSOR = {"fucking": "f*cking", "fuck": "f*ck", "fucks": "f*cks",
          "fucked": "f*cked", "fucker": "f*cker", "motherfucking": "motherf*cking"}


def censor(text: str) -> str:
    out = []
    for w in text.split(" "):
        core = w.strip('.,!?"`').lower()          # accent markers must not hide profanity
        if core in CENSOR:
            out.append(w.lower().replace(core, CENSOR[core]))
        else:
            out.append(w)
    return " ".join(out)


def _font(size: int, serif: bool = False):
    if serif:
        return ImageFont.truetype(INSTRUMENT_ITALIC, size)
    return ImageFont.truetype(HELVETICA, size, index=HELVETICA_BOLD_INDEX)


def _w(d, text, font, track):
    if not text:
        return 0
    return sum(d.textlength(c, font=font) + track for c in text) - track


def _draw(d, xy, text, font, track, fill=WHITE):
    x, y = xy
    for c in text:
        d.text((x, y), c, font=font, fill=fill)
        x += d.textlength(c, font=font) + track


def _draw_arrow(d, x, ycentre, size, fill=WHITE):
    """The bullet arrow, drawn as a vector.

    Helvetica has no U+2192 (it renders as tofu), and the reference arrow is a
    hairline anyway — measured 36 px wide, 16 px tall, 1-2 px stroke at bullet
    size 42. So it is not a glyph from the text font; it is drawn.
    """
    w = ARROW_W / BULLET[0] * size
    h = ARROW_H / BULLET[0] * size
    sw = max(2, round(2 * size / BULLET[0]))
    tip = x + w
    d.line([(x, ycentre), (tip, ycentre)], fill=fill, width=sw)
    d.line([(tip - h * 0.55, ycentre - h / 2), (tip, ycentre)], fill=fill, width=sw)
    d.line([(tip - h * 0.55, ycentre + h / 2), (tip, ycentre)], fill=fill, width=sw)


def _wrap(d, text, font, track, maxw, hang=0):
    """Greedy wrap. Continuation lines are indented by `hang` px."""
    words, lines, cur = text.split(" "), [], ""
    for wd in words:
        trial = (cur + " " + wd).strip()
        avail = maxw - (hang if lines else 0)
        if _w(d, trial, font, track) <= avail or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = wd
    if cur:
        lines.append(cur)
    return lines


# The inline serif accent: wrap a word in `backticks` in the headline.
# NOT asterisks - the profanity rule inserts one (f*cking) and the two collide.
_ACCENT = re.compile(r"`([^`]+)`")


def _headline_runs(line: str):
    """Split a headline line into (text, serif?) runs."""
    out, pos = [], 0
    for m in _ACCENT.finditer(line):
        if m.start() > pos:
            out.append((line[pos:m.start()], False))
        out.append((m.group(1), True))
        pos = m.end()
    if pos < len(line):
        out.append((line[pos:], False))
    return out or [(line, False)]


def _headline_width(d, line, hs, serif_f, helv_f):
    total = 0
    for txt, is_serif in _headline_runs(line):
        f = serif_f if is_serif else helv_f
        tr = (FOOTNOTE[1] if is_serif else HEADLINE[1]) / 1000 * hs
        total += _w(d, txt, f, tr) + tr
    return total


def _line_drawn_width(d, line, full, hs):
    """Width of a headline line as _draw_headline_line will actually lay it out."""
    accents = {m.group(1) for m in _ACCENT.finditer(full)}
    hf, hsf = _font(hs), _font(hs, serif=True)
    htr = HEADLINE[1] / 1000 * hs
    strk = FOOTNOTE[1] / 1000 * hs
    x = 0
    words = line.split(" ")
    for i, word in enumerate(words):
        is_a = word.strip('.,!?"`') in accents
        f, tr = (hsf, strk) if is_a else (hf, htr)
        x += _w(d, word, f, tr) + tr
        if i < len(words) - 1:
            x += d.textlength(" ", font=hf) + htr
    return x


def render_slide(s: dict, out: Path, bg: Path | None = None, scale: float = 1.0,
                 transparent: bool = False) -> dict:
    """s = {eyebrow, headline, bullets[], footnote, sub}. Returns a report of what it had to do.

    transparent=True writes an RGBA PNG with only the text — the overlay layer for an NLE.
    """
    if transparent:
        img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    elif bg and Path(bg).exists():
        img = Image.open(bg).convert("RGBA").resize((W, H))
    else:
        img = Image.new("RGBA", (W, H), (18, 18, 18, 255))
    d = ImageDraw.Draw(img)
    report = {"wrapped_bullets": [], "headline_lines": 0, "shrunk": None, "overflow": False}

    es, et = EYEBROW[0], EYEBROW[1] / 1000 * EYEBROW[0]
    ef = _font(es, serif=True)
    hs = HEADLINE[0]
    bs, bt = BULLET[0], BULLET[1] / 1000 * BULLET[0]
    bf = _font(bs)
    fs, ft = FOOTNOTE[0], FOOTNOTE[1] / 1000 * FOOTNOTE[0]
    ff = _font(fs, serif=True)

    arrow = "→ "
    hang = _w(d, arrow, bf, bt) + bt

    # headline wraps at full size; if it needs more than 3 lines, shrink it
    while True:
        hf, hsf = _font(hs), _font(hs, serif=True)
        htr = HEADLINE[1] / 1000 * hs
        src_accent = censor(s["headline"])
        plain = _ACCENT.sub(r"\1", src_accent)
        hlines = _wrap(d, plain, hf, htr, MAXW)
        widest = max((_line_drawn_width(d, ln, src_accent, hs) for ln in hlines), default=0)
        if (len(hlines) <= 3 and widest <= MAXW) or hs <= 55:
            break
        hs -= 3
        report["shrunk"] = hs
    hpitch = int(HEADLINE_PITCH * hs / HEADLINE[0])
    report["headline_lines"] = len(hlines)

    blines = []
    for b in s.get("bullets", []):
        wl = _wrap(d, censor(b), bf, bt, MAXW - hang, hang=0)
        if len(wl) > 1:
            report["wrapped_bullets"].append(b[:48])
        blines.append(wl)

    flines = _wrap(d, censor(s["footnote"]), ff, ft, MAXW) if s.get("footnote") else []

    # total height, then centre the block in the measured band
    th = (es + GAP_EYEBROW if s.get("eyebrow") else 0)
    th += hpitch * len(hlines)
    th += (18 + sum(BULLET_PITCH * len(w) for w in blines)) if blines else 0
    th += int(14 + bs * 1.25) if s.get("sub") else 0
    th += (GAP_FOOTNOTE + fs * len(flines)) if flines else 0
    pos = s.get("pos")
    if pos:                            # dragged in Carousel Bay — use it verbatim
        LX, y = int(pos["x"]), int(pos["y"])
        report["pos"] = (LX, y)
    else:
        LX = LEFT
        band_top, band_h = BLOCK_TOP, BLOCK_BOTTOM - BLOCK_TOP
        y = int(band_top + band_h / 2 - th / 2)
        if y < SAFE:                   # block grew past the top safe margin
            y = SAFE
    if y < SAFE or y + th > H - SAFE or LX < SAFE or LX + MAXW > W - SAFE:
        report["overflow"] = True

    if s.get("eyebrow"):
        _draw(d, (LX, y), censor(s["eyebrow"]), ef, et)
        y += es + GAP_EYEBROW

    # headline, with the inline serif accent honoured
    src = censor(s["headline"])
    for ln in hlines:
        _draw_headline_line(d, LX, y, ln, src, hs)
        y += hpitch

    if s.get("sub"):
        y += 14
        ss = int(bs * 0.95)
        sf = _font(ss)
        sub = censor(s["sub"])
        trail = sub.rstrip().endswith("\u2192")        # Helvetica has no arrow glyph
        if trail:
            sub = sub.rstrip()[:-1].rstrip()
        str_ = BULLET[1] / 1000 * ss
        _draw(d, (LX, y), sub, sf, str_)
        if trail:
            asc, _ = sf.getmetrics()
            _draw_arrow(d, LX + _w(d, sub, sf, str_) + 16, y + asc * 0.60, ss)
        y += int(bs * 1.25)

    if blines:
        y += 18
        for wl in blines:
            for i, ln in enumerate(wl):
                x = LX
                if i == 0:
                    asc, desc = bf.getmetrics()
                    _draw_arrow(d, x, y + asc * 0.60, bs)
                _draw(d, (x + hang, y), ln, bf, bt)
                y += BULLET_PITCH

    if flines:
        y += GAP_FOOTNOTE - BULLET_PITCH
        for ln in flines:
            _draw(d, (LX, y), ln, ff, ft)
            y += fs

    if transparent:
        img.save(out)
    else:
        img.convert("RGB").save(out, quality=95)
    return report


def _draw_headline_line(d, x, y, line, full, hs):
    """Draw one wrapped headline line, setting any *word* in serif italic."""
    accents = {m.group(1) for m in _ACCENT.finditer(full)}
    hf, hsf = _font(hs), _font(hs, serif=True)
    htr = HEADLINE[1] / 1000 * hs
    str_ = FOOTNOTE[1] / 1000 * hs
    for i, word in enumerate(line.split(" ")):
        bare = word.strip('.,!?"')
        is_a = bare.strip('`') in accents
        f, tr = (hsf, str_) if is_a else (hf, htr)
        _draw(d, (x, y), word, f, tr)
        x += _w(d, word, f, tr) + tr + d.textlength(" ", font=hf) + htr
