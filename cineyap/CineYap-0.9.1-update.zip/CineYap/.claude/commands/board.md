---
description: Open the Board for a video (cut lines, swap B-roll, switch effects on, send and rebuild)
---
Open the Board for the video named in "$ARGUMENTS", or the most recently built job in `projects/` if none is
named. Start the Studio if it is not running (`./vu-py cineyap/studio.py`, port 4747), then open
`http://localhost:4747/#v/<job>`. Send and rebuild on the page applies edits itself; there is nothing to paste.
