---
description: Open the CineYap Studio (every format, every effect, your Brand, and the Board for each video)
---
Open the CineYap Studio for this person. From the project root:
1. If nothing is listening on port 4747 (`lsof -i :4747`), start it in the background: `./vu-py cineyap/studio.py`
   (it opens http://localhost:4747 in their browser). If it is already running, `open http://localhost:4747`.
2. With a video named in "$ARGUMENTS", open `http://localhost:4747/#v/<job>` instead.
3. Say in one line what they can do there: the Board for each video, Formats, Effects, and their Brand.
Notes left on the Board land in `projects/<job>/edit/board_notes.md`: read that file when they mention notes.
