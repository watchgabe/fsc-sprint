---
description: Update CineYap to the newest version (keeps your videos, brand and settings)
---
Run `./vu-py cineyap/update.py` from the project root and report what it says in plain words: the version
it moved from and to, and the release notes. It backs up the code first, never touches `projects/`,
`inbox/`, `.env`, `cineyap/config.json` or `cineyap/brand.json`, and re-runs `./install.sh` if a new
dependency is needed. If it says CapCut is open, ask them to quit CapCut first. If they gave a zip path in
"$ARGUMENTS", pass it: `./vu-py cineyap/update.py <path to zip>`.
