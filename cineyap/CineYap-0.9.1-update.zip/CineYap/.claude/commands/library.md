---
description: Show every effect and format, playing as CapCut exported them
---
Start the Studio if it is not running (`./vu-py cineyap/studio.py`, port 4747) and open
`http://localhost:4747/#effects` (or `#formats` if they asked about formats). Each tile plays a real export;
"Add to video" puts an effect on a line of one of their videos and rebuilds it.
