---
description: First run. Edit one of the two sample takes end to end, so you see CineYap work before you film anything
---
Edit a sample take as a first run. `samples/sample-16x9.mp4` is a 16:9 talking take (1:49) and
`samples/sample-vertical.mp4` is a vertical one (0:31). Use the one named in "$ARGUMENTS"; with no
argument, use the 16:9 take, because every format can be built from it.

Both samples are already color graded, so build them with NO LUT: scaffold with
`./vu-py cineyap/newjob.py try-<16x9|vertical> samples/<file> ""` (the empty third argument means no grade),
then run the normal "edit my video" flow. The 16:9 take builds a CineYap; the vertical take builds a Vertical.
Open the Board when it is done (`/board try-<name>`) and tell them, in two lines, what to try next:
open it in CapCut and change a caption, then film their own take and drop it in `inbox/`.
If `samples/` is missing, the install came from an update zip; say so and point them to `inbox/`.
