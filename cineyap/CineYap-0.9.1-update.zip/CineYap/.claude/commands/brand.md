---
description: Set up or change your brand (colors, fonts, handle, LUT) for every format
---
Open the Brand tab: start the Studio if needed (`./vu-py cineyap/studio.py`) and open `http://localhost:4747/#brand`.
If they would rather talk it through, ask for: their dark and light brand colors, an accent color, their main
and accent fonts (a .ttf/.otf file, or keep the shipped Inter Bold / Instrument Serif), their @handle, and their
LUT if they shoot log. Write the answers into `cineyap/brand.json` (shape in `cineyap/brand.example.json`) and
tell them every format picks it up on the next build. $ARGUMENTS
