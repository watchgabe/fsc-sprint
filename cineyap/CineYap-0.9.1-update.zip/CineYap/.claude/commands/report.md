---
description: Something broke? Bundle the logs so it can be fixed
---
Run `./vu-py cineyap/report.py "$ARGUMENTS"` from the project root. It writes a zip to their Desktop with the
logs, versions and the last job's build notes. No video, audio or keys are included; the cut lists quote the lines they kept.
Tell them where the zip is and to post it in the CineYap testers space in Circle with one line about what they were doing.
Never send it anywhere yourself.
