#!/usr/bin/env bash
# SessionStart hook — write down what THIS machine is, every session, before anything can fail.
#
# WHY. The support loop is: a member says "it's broken", you ask what they're running, they never answer,
# and you ship a guess. The facts were on their machine the whole time and nothing wrote them down.
#
# WHAT IT DOES NOT DO. It never sends anything anywhere. _local/ is local only. It travels only if the
# member chooses to paste it. Pure bash + printf on purpose: NO jq, NO python, because a brand-new machine
# may have neither, which is exactly when an install crashes.
cd "${CLAUDE_PROJECT_DIR:-.}" 2>/dev/null || exit 0
mkdir -p _local 2>/dev/null || exit 0
{
  printf 'when       %s\n' "$(date '+%Y-%m-%d %H:%M')"
  printf 'os         %s %s\n' "$(uname -s 2>/dev/null)" "$(uname -r 2>/dev/null)"
  printf 'arch       %s\n' "$(uname -m 2>/dev/null)"
  if [ "$(uname -s 2>/dev/null)" = "Darwin" ]; then
    printf 'macos      %s\n' "$(sw_vers -productVersion 2>/dev/null)"
    printf 'chip       %s\n' "$(sysctl -n machdep.cpu.brand_string 2>/dev/null)"
    printf 'free disk  %s\n' "$(df -h / 2>/dev/null | awk 'NR==2{print $4}')"
  fi
  printf 'python3    %s\n' "$(python3 --version 2>&1 | head -1)"
  printf 'ffmpeg     %s\n' "$(ffmpeg -version 2>/dev/null | head -1 | awk '{print $3}')"
  printf 'libass     %s\n' "$(ffmpeg -hide_banner -filters 2>/dev/null | grep -q ' subtitles ' && echo yes || echo NO)"
  printf 'venv       %s\n' "$([ -x .venv/bin/python ] && .venv/bin/python --version 2>&1 | awk '{print $2}' || echo missing)"
  printf 'configured %s\n' "$([ -f cineyap/config.json ] && echo yes || echo no)"
} > _local/machine.txt 2>/dev/null
exit 0
