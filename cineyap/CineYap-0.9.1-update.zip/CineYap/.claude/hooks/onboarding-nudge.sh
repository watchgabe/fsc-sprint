#!/usr/bin/env bash
# SessionStart — tell Claude whether this install is ready, before the person types anything.
# Prints NOTHING once set up. Always exits 0: a hook must never stop a session starting.
cd "${CLAUDE_PROJECT_DIR:-.}" 2>/dev/null || exit 0
NEED=""
[ -x .venv/bin/python ]       || NEED="$NEED venv"
[ -f cineyap/config.json ]    || NEED="$NEED config"
{ [ -f .env ] && grep -q '^ELEVENLABS_API_KEY=.\+' .env 2>/dev/null; } || NEED="$NEED elevenlabs-key"
if [ -n "$NEED" ]; then
  cat <<MSG
CINEYAP — this install is not finished (missing:$NEED).

Before transcribing or editing anything, offer setup once, warmly:
  "Want me to set this up first? It takes a couple of minutes and I do all of it. Just say 'set me up'."
Then run ./install.sh and walk them through it. If they would rather do something else first, do that
and leave the offer open. Never refuse a job over this.
Do NOT reach for the Claude app's own setup skill — this package's install is ./install.sh.
MSG
fi
exit 0
