#!/usr/bin/env bash
# SessionStart hook — is a newer CineYap out? Say so once a day, silently otherwise.
#
# Pure bash + curl + grep: NO jq, NO python. Throttled to once per day via a marker in ~/.cache, and the
# network call is capped at 2s, so this adds nothing to a normal session and a slow or absent connection
# can never stall one. Always exits 0.
#
# A copy that is LEVEL WITH or AHEAD OF the feed is never told to update — that would send it backwards.
cd "${CLAUDE_PROJECT_DIR:-.}" 2>/dev/null || exit 0
[ -f product.json ] || exit 0
MARK="$HOME/.cache/cineyap-update-check"
mkdir -p "$(dirname "$MARK")" 2>/dev/null
if [ -f "$MARK" ]; then
  LAST=$(cat "$MARK" 2>/dev/null || echo 0); NOW=$(date +%s)
  [ $((NOW - LAST)) -lt 86400 ] && exit 0
fi
date +%s > "$MARK" 2>/dev/null
FEED=$(grep -o '"update_url"[[:space:]]*:[[:space:]]*"[^"]*"' product.json | sed 's/.*"\([^"]*\)"$/\1/')
[ -n "$FEED" ] || exit 0
HAVE=$(grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' product.json | sed 's/.*"\([^"]*\)"$/\1/')
THERE=$(curl -fsS --max-time 2 "$FEED" 2>/dev/null | grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/')
[ -n "$HAVE" ] && [ -n "$THERE" ] || exit 0
# compare number by number, so 2.1.10 reads as newer than 2.1.9
newer() {
  local a b; IFS=. read -r -a a <<< "$1"; IFS=. read -r -a b <<< "$2"
  for i in 0 1 2; do
    local x=${a[i]:-0} y=${b[i]:-0}
    [ "$x" -gt "$y" ] 2>/dev/null && return 0
    [ "$x" -lt "$y" ] 2>/dev/null && return 1
  done
  return 1
}
if newer "$THERE" "$HAVE"; then
  echo "CINEYAP: version $THERE is out, this install is $HAVE. Mention it once, in one line, and offer /update. Do not interrupt what they asked for."
fi
exit 0
