# CineYap

You film it. This edits it.

Drop a talking-head video in `inbox/`, open this folder in Claude Code, and say **"edit my video."**

What comes back is a **CapCut project with every word as editable text**: the cut, the grade, captions,
B-roll, cards, punch-ins and transitions. Change a word in CapCut and it is changed. No re-render, no
round trip. A Premiere timeline comes with it if you finish there instead.

---

## Getting started

1. **Put this folder somewhere that is NOT synced to iCloud or Dropbox.** `~/Projects` is perfect.
   Cloud sync quietly evicts large video files and your render stops halfway.
2. **Install CapCut and open it once.** Make one empty project, then quit it. CineYap learns CapCut's
   project format from that.
3. Open this folder in Claude Code and say **"set me up."** It installs what is missing and asks for
   your ElevenLabs key. A couple of minutes, once.
4. Say **`/try`** to edit one of the two sample takes in `samples/` end to end. It takes a few minutes
   and shows you every step before you film anything.
5. Drop your own video in `inbox/` and say **"edit my video."**

Testing? Read `TESTER-TERMS.md`. Something broke? Say **`/report`** and post the zip in the CineYap
testers space in Circle.

`./check-setup.sh` tells you what is missing at any time. It changes nothing.

---

## The formats

One take can come out in several shapes. Each one is a CapCut project you can open and edit.

| Format | Shape | What it looks like |
|---|---|---|
| CineYap | 16:9 and 4:3 | captions on the left, B-roll, green and cream cards, punch-ins, text behind you |
| Vertical | 9:16 and 3:4 | word-by-word captions above your head, a title that rides the opening zoom, cards, flashes |
| Vertical CineYap | 9:16 and 3:4 | captions low, a serif run, green cards, a split screen with a Step label, media cards |
| YapMaxxing | 9:16 | you full frame with a picture panel on top that changes with every point |
| Poster | 4:3 and 9:16 | a magazine-style headline held over the whole take, no captions |
| Carousel | 4:3 slides | B-roll slides with a headline, bullets and a serif accent word |
| Reel template | any | the cuts and text layout of a reel you like, rebuilt with your clips and your words |

Effects drop into any format: the flash and click transition, punch-ins with your eye line held,
text behind you, plain background plates, and frames (your footage inside a matte border).

---

## The Studio

Say **"open the Studio"** (or `/studio`). A page opens in your browser with:

- **Formats** and **Effects**: every one, playing as CapCut exported it.
- **Your videos**: one page per video, a tab per format, and the **Board** for each.

The Board is how you change an edit without describing it. One row per line you said: cut it, punch in,
add or swap B-roll from your own library (thumbnails, hover to play, or drop a clip from Finder), turn on
a flash, a card, a frame, text behind you, or leave a note. **Send and rebuild** updates the CapCut project
in a minute and checks every cut. **Open in CapCut** opens that exact project.

Opening a project or sending from the Board quits CapCut first (it saves on its own) and reopens it.

---

## What you need

| | |
|---|---|
| **A Mac** | Apple Silicon recommended. Intel works, slower on 4K. |
| **CapCut** | the free desktop app, opened once |
| **Claude Code** | the Claude desktop app's Code tab, or the terminal |
| **ElevenLabs API key** | transcription runs on your key, so the cost and the data are yours. elevenlabs.io → Profile → API Keys |
| **ffmpeg with libass** | `brew install ffmpeg-full`. The plain `ffmpeg` formula cannot burn captions. |

Optional, and everything still works without them: a `.cube` LUT if you shoot log, a folder of your own
B-roll for cutaways, and a light-leak clip plus a click sound for the flash transitions.

---

## Making it yours

Open the Studio's **Brand** tab: your colors, your fonts, your handle and your LUT. Every format and
every effect picks them up on the next build. (They are saved in `cineyap/brand.json`.)

The layout (sizes, positions, timing) lives in a style pack in `cineyap/styles/`. The fastest way to
change it is in CapCut: restyle one caption, quit CapCut, and say "learn this style." CineYap reads it
back, and every caption of that kind carries it from then on. (This works for CineYap captions and the
Poster today.)

---

## Where things go

```
inbox/              drop footage here (never modified)
projects/<job>/     one folder per video: the cut, the build, previews, your Board notes
cineyap/            the pipeline
cineyap/styles/     the looks
cineyap/studio/     the Studio page
helpers/            transcription, rendering
```

Name a job by what is in it, never by a date.
