#!/usr/bin/env bash
# What is missing on this machine, with the fix beside it. Changes nothing.
cd "$(dirname "$0")" 2>/dev/null
ok=0; miss=0
say(){ printf '  %s %-16s %s\n' "$1" "$2" "$3"; }
echo; echo "CineYap — setup check"; echo

echo "Tools:"
if [ -x .venv/bin/python ]; then
  V=$(.venv/bin/python --version 2>&1 | awk '{print $2}')
  if .venv/bin/python -c "import PIL,numpy,scipy,requests,pycapcut,cv2,Vision,Quartz" 2>/dev/null; then say "OK" "python env" "$V, all packages"; ok=$((ok+1))
  else say "!!" "python env" "$V but packages missing — run ./install.sh"; miss=$((miss+1)); fi
else say "!!" "python env" "no venv — run ./install.sh"; miss=$((miss+1)); fi

if command -v ffmpeg >/dev/null 2>&1; then
  if ffmpeg -hide_banner -filters 2>/dev/null | grep -q " subtitles "; then say "OK" "ffmpeg" "has libass"; ok=$((ok+1))
  else say "!!" "ffmpeg" "built WITHOUT libass — brew uninstall ffmpeg && brew install ffmpeg-full"; miss=$((miss+1)); fi
else say "!!" "ffmpeg" "missing — brew install ffmpeg-full"; miss=$((miss+1)); fi

echo; echo "Fonts (whatever your style pack names):"
LOOK=$([ -f cineyap/config.json ] && .venv/bin/python -c "import json;print(json.load(open('cineyap/config.json')).get('look','gabe'))" 2>/dev/null || echo gabe)
if [ -f "cineyap/styles/$LOOK.json" ]; then
  .venv/bin/python - "$LOOK" <<'PYS' 2>/dev/null || say "!!" "style pack" "could not read cineyap/styles/$LOOK.json"
import json,sys,os,pathlib
d=json.load(open(f"cineyap/styles/{sys.argv[1]}.json"))
for k,v in d["fonts"].items():
    if not isinstance(v,str): continue
    p=pathlib.Path(os.path.expanduser(v))
    print(f"  {'OK' if p.exists() else '!!'} {k:<16} {p if p.exists() else str(p)+'  MISSING'}")
for k in ("sans_path","serif_path"):
    v=d.get("capcut",{}).get(k)
    if not v: continue
    p=pathlib.Path(os.path.expanduser(v))
    print(f"  {'OK' if p.exists() else '--'} {'capcut '+k.split('_')[0]:<16} {p if p.exists() else str(p)+'  not installed (CapCut draft falls back to the base font)'}")
PYS
  ok=$((ok+1))
else say "!!" "style pack" "cineyap/styles/$LOOK.json not found"; miss=$((miss+1)); fi

echo; echo "This install:"
[ -f cineyap/config.json ] && { say "OK" "config" "present"; ok=$((ok+1)); } || { say "!!" "config" "missing — run ./install.sh"; miss=$((miss+1)); }
if [ -f .env ] && grep -q '^ELEVENLABS_API_KEY=.\+' .env 2>/dev/null; then say "OK" "ElevenLabs key" "set"; ok=$((ok+1))
else say "!!" "ElevenLabs key" "not set — transcription cannot run. ./install.sh takes it."; miss=$((miss+1)); fi
[ -f cineyap/shots.json ] && say "OK" "B-roll index" "built" || say "--" "B-roll index" "none (fine — you just get no cutaways)"

echo; echo "Where it lives:"
case "$PWD" in
  *"/Library/Mobile Documents/"*|*"/iCloud Drive"*|*"/Dropbox/"*|*"/Google Drive"*)
    say "!!" "location" "in cloud sync — files get evicted and renders fail halfway. Move to ~/Projects."; miss=$((miss+1));;
  *) say "OK" "location" "not in cloud sync"; ok=$((ok+1));;
esac

echo
[ "$miss" -eq 0 ] && echo "All good — $ok checks passed." || echo "$miss to fix, $ok fine. Fix the !! lines, then run this again."
echo
