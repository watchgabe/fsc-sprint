# Visual Studio tester terms

You're getting Visual Studio early, before it's finished, in exchange for honest feedback. Things will break,
and when they do, open the Visual Studio folder in the Claude app's Code tab, type "report a problem", and post
the zip it makes in the Visual Studio testers space in Circle with one line about what you were doing. That
post is the most useful thing you can give me.

**Visual Studio is mine, and it's just for you.** It isn't open source. The full terms are in `LICENSE` in this
folder; in short, while you're testing:

- **Use it for your own videos**, on your own computers.
- **Fix things if you want.** You can change your copy, or ask Claude to, to get unstuck. Those changes
  are still Visual Studio, and an update will replace them, so tell me what you fixed and I'll ship it to everyone.
- **Don't share it.** No passing the folder, the zip, the download link or any part of it to anyone,
  and no posting, reselling or reuploading it, changed or not.
- **Don't build on it.** No using Visual Studio, its prompts, styles or presets to make or train another tool
  that does the same thing.

**Your videos are yours.** They stay on your Mac. Nothing leaves it: even the transcript is made on your
Mac. Nothing comes to me unless you send a report, and a report never holds video, audio or keys.
Anything you suggest, I may build in, without owing you for it.

When there's a new version, typing "update" in the Code tab installs it without touching your projects,
brand or settings. Keep your raw footage backed up somewhere else, because this is test software and I
can't promise it won't lose a file.

Either of us can end the test at any time. If it ends, delete your copy of Visual Studio.

Keep creating,
Gabe
