#!/usr/bin/env bash
# Everything that must pass before a tester package (FIX-PLAN-2026-10-24, Phase 0):
#   1. pyflakes: no undefined names in cineyap/*.py and helpers/*.py (a lint venv in _local/lint, never the product .venv)
#   2. py_compile with the PRODUCT's python (3.11: a newer python accepts f-strings 3.11 refuses)
#   3. node --check on every page script and on the editor's inline script
#   4. the server/export tests (tests/*.py, stdlib unittest, the product python)
#   5. the editor's pure-function tests (tests/editor/*.test.js, node:test)
# 0.10.16 shipped with "name 'NEW_FORMATS' is not defined": this is the step that would have caught it.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$HERE"
export PATH="$HERE/_local/bin:$HERE/_local/node:$PATH"
PY=".venv/bin/python"; [ -x "$PY" ] || PY=".venv/Scripts/python.exe"
fail=0
step(){ printf '\n== %s\n' "$1"; }

step "pyflakes (undefined names)"
LINT="_local/lint"
if [ ! -x "$LINT/bin/pyflakes" ]; then
  python3 -m venv "$LINT" >/dev/null 2>&1 && "$LINT/bin/pip" -q install pyflakes >/dev/null 2>&1 || { echo "!! could not make the lint venv"; fail=1; }
fi
if [ -x "$LINT/bin/pyflakes" ]; then
  out="$("$LINT/bin/pyflakes" cineyap/*.py helpers/*.py 2>&1 | grep -E "undefined name|syntax error|invalid syntax" || true)"
  if [ -n "$out" ]; then echo "$out"; fail=1; else echo "ok"; fi
fi

step "py_compile with the product python ($("$PY" --version 2>&1))"
if "$PY" -m py_compile cineyap/*.py helpers/*.py; then echo "ok"; else fail=1; fi

step "node --check on the pages and the editor's inline script"
tmp="$(mktemp -d)"
node tests/editor/extract.js cineyap/studio/editor.html "$tmp/editor.inline.js" || fail=1
for f in cineyap/studio/*.js "$tmp/editor.inline.js"; do
  node --check "$f" 2>&1 | sed "s|$tmp/editor.inline.js|cineyap/studio/editor.html (inline script)|" || true
  node --check "$f" >/dev/null 2>&1 || fail=1
done
rm -rf "$tmp"; [ $fail = 0 ] && echo "ok"

step "server and export tests (unittest)"
if "$PY" -m unittest discover -s tests -p "test_*.py" -t . 2>&1 | tail -3; then :; fi
"$PY" -m unittest discover -s tests -p "test_*.py" -t . >/dev/null 2>&1 || fail=1

step "editor tests (node:test)"
if ls tests/editor/*.test.js >/dev/null 2>&1; then
  node --test "tests/editor/*.test.js" 2>&1 | tail -4
  node --test "tests/editor/*.test.js" >/dev/null 2>&1 || fail=1
else echo "none yet"; fi

printf '\n'
if [ $fail = 0 ]; then echo "preship: all green"; else echo "preship: FAILED (fix before packaging)"; fi
exit $fail
