---
description: First run. Edit the sample take in the Studio, so you see Loop work before you film anything
---
A first run on `samples/sample-16x9.mp4`, a 16:9 talking take (1:49) that is already color graded, so it gets NO LUT.
Start the Studio if it isn't running (`./start-studio.sh`), then tell them in two lines: click **Start new video**
and choose **Edit the sample video** (or drag the sample onto the page). The Studio cuts it, they review the radio
cut, lock it, and the editor opens: B-roll, captions, effects, then **Export**.
If `samples/` is missing, the install came from an update zip; say so and have them drag in one of their own takes.
