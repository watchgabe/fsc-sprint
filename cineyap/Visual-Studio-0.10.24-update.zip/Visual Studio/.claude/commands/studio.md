---
description: Open Visual Studio (your videos, the editor, your Brand)
---
Open Visual Studio for this person. From the project root:
1. If nothing is listening on port 4747 (`lsof -i :4747`), start it in the background: `./start-studio.sh`
   (it opens http://localhost:4747 in their browser). If it is already running, open http://localhost:4747.
2. With a video named in "$ARGUMENTS", open `http://localhost:4747/static/editor.html?job=<job>` instead.
3. Say in one line what they can do there: start a new video, edit it in the editor and export it, and set their Brand.
