"""Saving the Brand page keeps config.json's LUT unless the LUT buttons were used (R5, FIX-PLAN 1.6)."""
import json, pathlib, shutil, tempfile, unittest
from tests.support import studio


class BrandLutTests(unittest.TestCase):
    def setUp(self):      # never the live config.json or brand.json: both are pointed at a temp folder for the test
        self.tmp = pathlib.Path(tempfile.mkdtemp(prefix="cineyap-brand-"))
        self.cfg = self.tmp/"config.json"; self.brand = self.tmp/"brand.json"
        self._cfg, self._brand = studio.config.PATH, studio.BRAND_FILE
        studio.config.PATH = self.cfg; studio.BRAND_FILE = self.brand
        studio.atomic_write_json(self.cfg, {"lut": "/luts/mine.cube"}, indent=2)
        studio.atomic_write_json(self.brand, {"colors": {"dark": "#111111"}, "lut": ""}, indent=1)
    def tearDown(self):
        studio.config.PATH = self._cfg; studio.BRAND_FILE = self._brand; shutil.rmtree(self.tmp, ignore_errors=True)
    def lut(self): return json.loads(self.cfg.read_text()).get("lut")

    def test_colour_change_keeps_lut(self):
        studio.save_brand({"colors": {"dark": "#222222"}, "lut": ""})
        self.assertEqual(self.lut(), "/luts/mine.cube")
        self.assertEqual(json.loads(self.brand.read_text())["lut"], "/luts/mine.cube", "brand.json mirrors the real LUT")

    def test_no_lut_button_clears_it(self):
        studio.save_brand({"colors": {}, "lut": ""}, lut_set=True)
        self.assertEqual(self.lut(), "")

    def test_choose_lut_sets_it(self):
        studio.save_brand({"colors": {}, "lut": "/luts/new.cube"}, lut_set=True)
        self.assertEqual(self.lut(), "/luts/new.cube")

    def test_brand_state_shows_the_real_lut(self):
        self.assertEqual(studio.brand_state()["brand"]["lut"], "/luts/mine.cube")


if __name__ == "__main__": unittest.main()
