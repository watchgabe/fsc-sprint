// Pulls the editor's one inline <script> out of editor.html so node can check and test it.
//   node tests/editor/extract.js cineyap/studio/editor.html out.js        -> the script, unchanged (for node --check)
//   require("./extract").load()                                           -> the pure helpers, run with a stub DOM (for tests)
// The editor is one 600 KB script that touches the page as it loads, so load() gives it just enough of a document to
// get through its top level, then hands back the functions the tests need. Nothing in editor.html changes for this.
"use strict";
const fs = require("fs"), path = require("path"), vm = require("vm");
const ROOT = path.resolve(__dirname, "../..");
const HTML = path.join(ROOT, "cineyap/studio/editor.html");

function inline(html) {
  const src = fs.readFileSync(html, "utf8");
  const a = src.indexOf("<script>\n"), b = src.indexOf("</script>", a);
  if (a < 0 || b < 0) throw new Error("no inline script in " + html);
  return src.slice(a + 9, b);
}

if (require.main === module) {
  const [html, out] = process.argv.slice(2);
  fs.writeFileSync(out, inline(html || HTML));
}

// A document that answers every query with an inert element, so the top-level code runs without a browser.
function stubDom() {
  const style = () => new Proxy({ setProperty() {}, removeProperty() {}, getPropertyValue() { return ""; } }, { get: (t, k) => (k in t ? t[k] : ""), set: (t, k, v) => { t[k] = v; return true; } });
  const node = () => new Proxy({ style: style(), dataset: {}, classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    children: [], childNodes: [], hidden: false, value: "", textContent: "", innerHTML: "",
    addEventListener() {}, removeEventListener() {}, appendChild(c) { return c; }, insertBefore(c) { return c; }, removeChild() {}, remove() {},
    querySelector() { return node(); }, querySelectorAll() { return []; }, getBoundingClientRect() { return { x: 0, y: 0, width: 0, height: 0, left: 0, top: 0 }; },
    setAttribute() {}, getAttribute() { return null; }, closest() { return null; }, focus() {}, blur() {}, play() { return Promise.resolve(); }, pause() {},
    getContext() { return new Proxy({}, { get: () => () => {} }); }, observe() {}, disconnect() {} },
    { get(t, k) { if (k in t) return t[k]; if (typeof k === "symbol" || k === "then" || /^on/.test(k)) return undefined; return (t[k] = node()); } });      // any other property is another inert element
  const doc = node();
  doc.body = node(); doc.documentElement = node(); doc.head = node();
  doc.createElement = () => node(); doc.createTextNode = () => node(); doc.createDocumentFragment = () => node();
  doc.getElementById = () => node(); doc.querySelector = () => node(); doc.querySelectorAll = () => []; doc.addEventListener = () => {};
  doc.fonts = { load: () => Promise.resolve(), ready: Promise.resolve() };
  const store = {};
  const builtins = {};
  for (const k of Object.getOwnPropertyNames(globalThis)) {      // URL, URLSearchParams, TextEncoder, structuredClone… but not CommonJS: the page scripts must see a browser
    if (/Storage$/.test(k) || /^(module|require|exports|__filename|__dirname|process)$/.test(k)) continue;
    const d = Object.getOwnPropertyDescriptor(globalThis, k); if (!d || d.get) continue;      // accessors are Node's lazy modules (punycode, sys, WASI): touching them warns
    builtins[k] = d.value;
  }
  const win = Object.assign(builtins, {
    document: doc, navigator: { userAgent: "node", platform: "MacIntel", sendBeacon: () => true }, location: { search: "?job=test", href: "", hash: "", origin: "http://localhost:4747" },
    localStorage: { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
    sessionStorage: { getItem: () => null, setItem() {}, removeItem() {} },
    fetch: () => new Promise(() => {}), setTimeout: () => 0, clearTimeout() {}, setInterval: () => 0, clearInterval() {},
    requestAnimationFrame: () => 0, cancelAnimationFrame() {}, addEventListener() {}, removeEventListener() {}, getComputedStyle: () => ({ getPropertyValue: () => "" }),
    matchMedia: () => ({ matches: false, addEventListener() {} }), ResizeObserver: class { observe() {} disconnect() {} }, MutationObserver: class { observe() {} disconnect() {} },
    IntersectionObserver: class { observe() {} disconnect() {} }, performance: { now: () => 0 }, console, Promise, JSON, Math, Date, Object, Array, String, Number, RegExp, Error, Set, Map,
    parseFloat, parseInt, isNaN, isFinite, encodeURIComponent, decodeURIComponent, Image: class {}, Audio: class { constructor() { this.addEventListener = () => {}; } },
    AudioContext: undefined, URL: { createObjectURL: () => "", revokeObjectURL() {} }, Blob: class {}, FormData: class {}, KeyboardEvent: class {}, CustomEvent: class {},
    innerWidth: 1440, innerHeight: 900, devicePixelRatio: 1, history: { replaceState() {}, pushState() {} }, screen: {}, alert() {}, confirm: () => true, prompt: () => "",
  });
  win.window = win; win.self = win; win.globalThis = win;
  return win;
}

// The names the tests use. Anything else stays private to the editor.
const EXPORTS = ["at", "clearRange", "tidyBR", "shiftAfter", "removeRange", "clone", "withSt", "blockLists", "layerFix", "hasIn",
  "rippleTrim", "followCut", "snapList", "state", "adopt", "applyPatch", "mergeList", "lineCss", "shapeR", "chunks"];

function load(opts) {
  const win = stubDom();
  const src = inline(HTML);
  const tail = "\n;({" + EXPORTS.map(n => n + ":typeof " + n + "==='undefined'?undefined:" + n).join(",") + ",G:function(n){return eval(n);},S:function(n,v){eval(n+'=__v');}})";
  const ctx = vm.createContext(win);
  for (const f of ["tlmigrate.js", "winwords.js", "colorpick.js", "grade.js", "grade_view.js", "broll_search.js", "broll_import.js"]) {      // the editor's own scripts, in page order
    try { vm.runInContext(fs.readFileSync(path.join(ROOT, "cineyap/studio", f), "utf8"), ctx, { filename: f }); }
    catch (e) { if (!(opts && opts.lenient)) throw new Error(f + ": " + e.message); }
  }
  let api;
  try { api = vm.runInContext(src + tail, ctx, { filename: "editor.html(inline)" }); }
  catch (e) { if (!(opts && opts.lenient)) throw e; }
  return { win, api, get: n => vm.runInContext(n, ctx), set: (n, v) => { ctx.__v = v; vm.runInContext(n + "=__v", ctx); }, run: s => vm.runInContext(s, ctx) };
}

module.exports = { inline, load, stubDom };
