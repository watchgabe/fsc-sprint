// The editor's timeline maths, run under node (tests/editor/extract.js loads editor.html's script with a stub DOM).
//   node --test "tests/editor/*.test.js"
"use strict";
const test = require("node:test"), assert = require("node:assert/strict");
const { load } = require("./extract.js");

let E;
test.before(() => { E = load(); });

test("at() finds the block under a time, half-open on the right", () => {
  const L = [{ t0: 0, t1: 2 }, { t0: 2, t1: 5 }];
  assert.equal(E.api.at(L, 0), L[0]); assert.equal(E.api.at(L, 2), L[1]); assert.equal(E.api.at(L, 5), null);
});

test("clearRange() trims and splits what overlaps", () => {
  const L = [{ t0: 0, t1: 10, clip: "a", in: 0 }];
  E.api.clearRange(L, 3, 4);
  L.sort((a, b) => a.t0 - b.t0);
  assert.deepEqual(L.map(o => [o.t0, o.t1]), [[0, 3], [4, 10]]);
  assert.equal(L[1].in, 4, "the right part keeps its place in the clip");
});

test("shiftAfter() moves every list, text layers included", () => {
  E.set("BR", [{ t0: 5, t1: 6 }]); E.set("HK", [{ t0: 10, t1: 12, hook: true, lines: [] }]); E.set("BG", []); E.set("FX", []); E.set("MOVES", []); E.set("MUSIC", []); E.set("SFX", []);
  E.api.shiftAfter(8, 1);
  assert.equal(E.get("BR")[0].t0, 5); assert.equal(E.get("HK")[0].t0, 11);
});

// R4 (QA-2026-10-24): rippleTrim restores every list from its snapshot on each mouse move except HK, so the text track is
// shifted again and again. Two moves of +0.5 s must leave a text at 10 s starting at 10.5 s, not 11.
test("rippleTrim keeps the text track in step with the cut (R4)", () => {
  const segs = [{ src_in: 0, src_out: 5, t0: 0, t1: 5 }, { src_in: 20, src_out: 25, t0: 5, t1: 10 }, { src_in: 40, src_out: 50, t0: 10, t1: 20 }];
  E.set("SEGS", segs); E.set("SRCDUR", 100); E.set("SRCW", []); E.set("px", 100);
  E.set("BR", []); E.set("BG", []); E.set("FX", []); E.set("MOVES", []); E.set("MUSIC", []); E.set("SFX", []); E.set("MARKERS", []);
  E.set("HK", [{ t0: 10, t1: 12, hook: true, lines: [{ text: "x", st: {} }] }]);
  // follow(fn) is the drag helper: capture its callback and feed it mouse moves
  let move; E.set("follow", fn => { move = fn; });
  E.set("layout", () => { let t = 0; E.get("SEGS").forEach(s => { s.t0 = t; t += s.src_out - s.src_in; s.t1 = t; }); });
  E.set("draw", () => {}); E.set("snapList", () => null);
  E.api.rippleTrim({ clientX: 0 }, E.get("SEGS")[1], "r");
  move({ clientX: 50, metaKey: true });      // +0.5 s
  move({ clientX: 50, metaKey: true });      // the same position again: a second mousemove event
  assert.equal(E.get("HK")[0].t0, 10.5, "the text follows the cut once, not once per mouse move");
});
