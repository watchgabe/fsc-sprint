// R3: a Chat answer merges with what was edited while Claude worked (mergeList in editor.html).
"use strict";
const test = require("node:test"), assert = require("node:assert/strict");
const { load } = require("./extract.js");
let E; test.before(() => { E = load(); });

test("Claude's additions come in, your edits stay, Claude's removals go only if you left them alone", () => {
  const A = { t0: 0, t1: 2, clip: "a" }, B = { t0: 2, t1: 4, clip: "b" }, C = { t0: 4, t1: 6, clip: "c" };
  const base = [A, B, C];
  const mine = [A, { t0: 2.5, t1: 4, clip: "b" }, C];                  // you moved B
  const theirs = [{ t0: 0, t1: 1.5, clip: "a" }, B, { t0: 6, t1: 8, clip: "d" }];      // Claude trimmed A, removed C, added D
  const r = E.api.mergeList(base, mine, theirs);
  assert.deepEqual(r.list.map(o => [o.t0, o.t1, o.clip]), [[0, 1.5, "a"], [2.5, 4, "b"], [6, 8, "d"]]);
  assert.equal(r.kept.length, 0);
});

test("a block changed on both sides keeps yours and reports it", () => {
  const A = { t0: 0, t1: 2, clip: "a" };
  const r = E.api.mergeList([A], [{ t0: 0, t1: 3, clip: "a" }], [{ t0: 0, t1: 1, clip: "a" }]);
  assert.deepEqual(r.list, [{ t0: 0, t1: 3, clip: "a" }]);
  assert.equal(r.kept.length, 1);
});

test("with no snapshot the answer is taken as it is", () => {
  const r = E.api.mergeList([], [{ t0: 0, t1: 1, clip: "x" }], [{ t0: 5, t1: 6, clip: "y" }]);
  assert.equal(r.list.length, 2);      // nothing in base: yours is new, theirs is new; both stay
});
