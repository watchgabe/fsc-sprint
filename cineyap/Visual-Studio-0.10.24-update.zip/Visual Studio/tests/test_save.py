"""/api/timeline-save: one writer at a time, never a torn file (R8, FIX-PLAN 1.1)."""
import json, os, threading, unittest
from tests.support import Studio, studio


class SaveTests(unittest.TestCase):
    def test_concurrent_saves_one_wins_rest_409(self):
        with Studio() as s:
            s.project("j1")
            codes = []; lock = threading.Lock()
            def go(i):
                c, _ = s.post("/api/timeline-save", {"job": "j1", "base": 0, "state": {"SEGS": [], "n": i}})
                with lock: codes.append(c)
            th = [threading.Thread(target=go, args=(i,)) for i in range(20)]
            [t.start() for t in th]; [t.join() for t in th]
            self.assertEqual(codes.count(200), 1, codes)
            self.assertEqual(codes.count(409), 19, codes)
            d = json.loads((s.projects/"j1/edit/timeline.json").read_text())
            self.assertEqual(d["REV"], 1)

    def test_rev_advances_and_stale_base_is_refused(self):
        with Studio() as s:
            s.project("j1")
            self.assertEqual(s.post("/api/timeline-save", {"job": "j1", "base": 0, "state": {}})[1]["rev"], 1)
            self.assertEqual(s.post("/api/timeline-save", {"job": "j1", "base": 1, "state": {}})[1]["rev"], 2)
            c, b = s.post("/api/timeline-save", {"job": "j1", "base": 1, "state": {}})
            self.assertEqual((c, b["rev"]), (409, 2))

    def test_write_is_atomic(self):
        """a crash between opening the file and finishing it must leave the old file whole"""
        with Studio() as s:
            s.project("j1", {"REV": 3, "keep": "me"})
            real = os.replace
            def boom(a, b): raise OSError("disk full")
            os.replace = boom
            try: c, _ = s.post("/api/timeline-save", {"job": "j1", "base": 3, "state": {"new": 1}})
            finally: os.replace = real
            self.assertEqual(c, 500)
            self.assertEqual(json.loads((s.projects/"j1/edit/timeline.json").read_text()), {"REV": 3, "keep": "me"})
            self.assertEqual([p.name for p in (s.projects/"j1/edit").glob("*.tmp")], [], "no half-written file left behind")

    def test_atomic_write_json_helper(self):
        p = studio.PKG/"_local"/"test-atomic.json"
        try:
            studio.atomic_write_json(p, {"a": 1}); self.assertEqual(json.loads(p.read_text()), {"a": 1})
            studio.atomic_write_json(p, {"a": 2}); self.assertEqual(json.loads(p.read_text()), {"a": 2})
        finally: p.unlink(missing_ok=True)


if __name__ == "__main__": unittest.main()
