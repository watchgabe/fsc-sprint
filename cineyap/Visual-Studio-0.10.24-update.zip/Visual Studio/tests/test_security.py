"""What the page may read and which project names the server accepts (R9, R10)."""
import json, unittest
from tests.support import Studio, studio


class FileAllowList(unittest.TestCase):
    def test_outside_files_are_refused(self):
        with Studio() as s:
            for path in ("/etc/hosts", str(studio.PKG/".env"), str(studio.PKG/"cineyap/config.json"), str(studio.PKG/"cineyap/studio.py"), str(studio.PKG.parent)):
                self.assertEqual(s.get("/file?p=" + path)[0], 404, path)
                self.assertEqual(s.get("/thumb?p=" + path)[0], 404, path)
    def test_project_and_brand_files_are_served(self):
        with Studio() as s:
            s.project("j1"); f = s.projects/"j1/edit/timeline.json"
            self.assertEqual(s.get("/file?p=" + str(f))[0], 200)
            a = studio.PKG/"cineyap/brand_assets"/"zz-test.txt"; a.parent.mkdir(exist_ok=True); a.write_text("x")
            try: self.assertEqual(s.get("/file?p=" + str(a))[0], 200)
            finally: a.unlink()
    def test_allowed_is_whole_folders(self):
        self.assertFalse(studio.allowed(str(studio.PROJECTS) + "-other/x.mp4"), "a sibling folder with the same prefix is not inside")
        self.assertTrue(studio.allowed(str(studio.PROJECTS/"a/b.mp4")))
    def test_empty_overlay_option_adds_nothing(self):
        was = studio.config.opt
        studio.config.opt = lambda k, d=None: "" if k == "sfx_flash_overlay" else was(k, d)
        try: self.assertFalse(studio.allowed("/etc/hosts"))
        finally: studio.config.opt = was


if __name__ == "__main__": unittest.main()


class JobNames(unittest.TestCase):
    def test_a_name_that_leaves_projects_is_refused_everywhere(self):
        with Studio() as s:
            for job in ("../x", "../../etc", "a/b", "/abs", ".hidden"):
                self.assertEqual(s.get("/api/progress?job=" + job)[0], 400, job)
                self.assertEqual(s.post("/api/timeline-save", {"job": job, "base": 0, "state": {}})[0], 400, job)
                self.assertEqual(s.post("/api/upload?job=" + job + "&name=a.mp4", raw=b"x", headers={"Content-Type": "application/octet-stream"})[0], 400, job)
            self.assertFalse(list(s.projects.parent.glob("x")), "nothing was created outside projects/")
    def test_real_names_pass(self):
        for job in ("zz-qa", "c1709", "an-army-of-shit-editors", "blank-1023-020004", "car-1021-182750", "v1.2"):
            self.assertFalse(studio.bad_job(job), job)
