/* In-page smoke harness for the editor (FIX-PLAN-2026-10-24, 0.3). No Playwright: paste this into the editor page
   (the in-app browser's javascript tool, or the console) on a projects/zz-* copy, then:
     QA.arm()                      mute every player, swallow every export / agent / chat call, turn the debug assertions on
     await QA.playAcrossCuts(10)   play through n A-roll cuts; returns holds (> 50 ms with no frame advance) and assertion hits
     QA.esc()                      what is open right now (dialogs, menus, Edit mode), for the Esc tests
     QA.disarm()                   pause everything (the page is left armed; navigate away when done)
   Rules it enforces come from memory: never a sound from the pane, never a scripted click that really exports. */
(function () {
  var Q = window.QA = window.QA || {};
  Q.arm = function () {
    var kill = function (v) { try { v.muted = true; v.volume = 0; Object.defineProperty(v, "volume", { get: function () { return 0; }, set: function () {}, configurable: true }); } catch (e) {} };
    document.querySelectorAll("video,audio").forEach(kill);
    new MutationObserver(function () { document.querySelectorAll("video,audio").forEach(kill); }).observe(document, { subtree: true, childList: true });
    if (!window.__fetch0) { window.__fetch0 = window.fetch; Q.blocked = [];
      window.fetch = function (u, o) { var s = String(u); if (/timeline-export|timeline-chat|timeline-agent|\/api\/agent|first-pass|\/api\/review|new-video|aroll-lut|\/api\/update/.test(s)) { Q.blocked.push(s); return Promise.resolve(new Response("{}", { status: 200, headers: { "Content-Type": "application/json" } })); } return window.__fetch0.apply(this, arguments); }; }
    try { localStorage.setItem("loop.debug", "1"); } catch (e) {}
    if (window.__debugOn) window.__debugOn();
    return "armed";
  };
  Q.disarm = function () { document.querySelectorAll("video,audio").forEach(function (v) { try { v.pause(); } catch (e) {} }); if (!A.paused) toggle(); return "paused"; };
  Q.violations = function () { return (window.__violations || []).slice(); };
  Q.playAcrossCuts = function (n, maxMs) {
    n = n || 5; maxMs = maxMs || 20000; Q.arm(); if (window.__violations) window.__violations.length = 0;
    var S = [], t0 = performance.now(), seg0 = CURSEG, iv, drive;
    if (!A.paused) toggle();
    toggle();
    if (document.hidden) drive = setInterval(function () { try { follow_play(); } catch (e) {} }, 16);      // the pane can throttle rAF when hidden
    return new Promise(function (res) {
      iv = setInterval(function () {
        S.push([Math.round(performance.now() - t0), +A.currentTime.toFixed(3), CURSEG]);
        var cuts = 0; for (var i = 1; i < S.length; i++) if (S[i][2] !== S[i - 1][2]) cuts++;
        if (cuts >= n || performance.now() - t0 > maxMs || A.paused && S.length > 20 && CURSEG === seg0) { clearInterval(iv); if (drive) clearInterval(drive); if (!A.paused) toggle(); res(); }
      }, 25);
    }).then(function () {
      var holds = [], run = 0;
      for (var i = 1; i < S.length; i++) { if (S[i][1] === S[i - 1][1]) { run += S[i][0] - S[i - 1][0]; if (run > 50 && (!holds.length || holds[holds.length - 1][0] !== S[i - 1][0])) holds.push([S[i - 1][0], S[i][1], S[i][2]]); } else run = 0; }
      var cuts = []; for (var j = 1; j < S.length; j++) if (S[j][2] !== S[j - 1][2]) cuts.push([S[j][0], S[j][2]]);
      return { samples: S.length, cuts: cuts, holds: holds, violations: Q.violations() };
    });
  };
  Q.esc = function () {
    var open = [];
    ["#exportPop", "#seqPop", "#projMenu", "#varMenu", ".stylemenu", ".kdlg", ".askbg", "#chatDock"].forEach(function (s) { var e = document.querySelector(s); if (e && !e.hidden && e.offsetParent) open.push(s); });
    if (typeof PVOFF !== "undefined" && !PVOFF) open.push("edit-mode");
    if (typeof AADJ !== "undefined" && AADJ) open.push("aroll-adjust");
    return open;
  };
})();
