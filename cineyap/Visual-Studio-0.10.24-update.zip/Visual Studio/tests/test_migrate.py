"""The editor's and the export's timeline migrations are the same (X4, FIX-PLAN 3.1)."""
import copy, json, pathlib, subprocess, sys, unittest
ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/"cineyap"))
import tlmigrate

STATE = {"HK": [{"lines": [{"text": "a", "st": {"size": 72, "sc": True}}, {"text": "b", "st": {"size": 40, "smc": True}}]}],
         "SCREENS": [{"id": "aroll", "sc": 1.2, "text": {"lines": [{"text": "t", "st": {"sc": True}}]}, "titles": [{"text": "x", "st": {"sc": True, "color": "#fff"}}]},
                     {"id": "s2", "sc": 1, "st": {"sc": 1.4}}, {"id": "s3", "kind": "color", "sc": True, "hl": {"color": "#f00", "sc": True}}],
         "BR": [{"clip": "a.mp4", "st": {"sc": 1.3}}, {"clip": "b.mp4", "st": {"sc": True}}]}


class MigrateTests(unittest.TestCase):
    def test_python_moves_small_caps_and_leaves_scale(self):
        st = tlmigrate.migrate(copy.deepcopy(STATE))
        self.assertEqual(st["HK"][0]["lines"][0]["st"], {"size": 72, "smc": True})
        self.assertEqual(st["HK"][0]["lines"][1]["st"], {"size": 40, "smc": True})
        self.assertEqual(st["SCREENS"][0]["sc"], 1.2, "a screen's picture scale is not small caps")
        self.assertEqual(st["SCREENS"][0]["text"]["lines"][0]["st"], {"smc": True})
        self.assertEqual(st["SCREENS"][0]["titles"][0]["st"], {"color": "#fff", "smc": True})
        self.assertEqual(st["BR"][0]["st"], {"sc": 1.3}, "a clip's own scale stays")
        self.assertEqual(st["BR"][1]["st"], {"smc": True}, "a clip's own small caps moves")
        self.assertEqual(st["SCREENS"][2]["smc"], True); self.assertNotIn("sc", st["SCREENS"][2])
        self.assertEqual(st["SCREENS"][2]["hl"], {"color": "#f00", "smc": True})
        self.assertEqual(tlmigrate.migrate(copy.deepcopy(st)), st, "running it twice changes nothing")

    def test_javascript_agrees(self):
        js = ("const M=require(%r);const st=JSON.parse(process.argv[1]);process.stdout.write(JSON.stringify(M.migrate(st)));" % str(ROOT/"cineyap/studio/tlmigrate.js"))
        r = subprocess.run(["node", "-e", js, json.dumps(STATE)], capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(r.stdout), tlmigrate.migrate(copy.deepcopy(STATE)))


if __name__ == "__main__": unittest.main()
