"""update.py keeps the creator's files, prunes backups, and restores on a failed copy (R6, FIX-PLAN 1.7)."""
import pathlib, shutil, sys, tempfile, time, unittest, zipfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent/"cineyap"))
import update


class UpdateTests(unittest.TestCase):
    def test_user_data_is_kept(self):
        for rel in ("cineyap/text_styles.json", "cineyap/user_styles.json", "cineyap/palette.json", "cineyap/font_stars.json", "cineyap/rules.json",
                    "cineyap/library_map.json", "cineyap/style_defaults.json", "learned.json", "library/saved_fx/fx1.json", "exports/x.mp4", "_archive/deleted/j/edit/a.json",
                    "cineyap/config.json", "cineyap/brand.json", "projects/j/edit/timeline.json"):
            self.assertTrue(update.kept(rel), rel)
        for rel in ("cineyap/studio.py", "cineyap/studio/editor.html", "cineyap/styles/cineyap.json", "product.json"):
            self.assertFalse(update.kept(rel), rel)

    def test_prune_keeps_newest_three(self):
        d = pathlib.Path(tempfile.mkdtemp())
        try:
            for i in range(5):
                z = d/f"0.10.{i}-x.zip"; z.write_bytes(b"PK"); import os; os.utime(z, (i, i))
            gone = update.prune_backups(d)
            self.assertEqual(sorted(p.name for p in gone), ["0.10.0-x.zip", "0.10.1-x.zip"])
            self.assertEqual(sorted(p.name for p in d.glob("*.zip")), ["0.10.2-x.zip", "0.10.3-x.zip", "0.10.4-x.zip"])
        finally: shutil.rmtree(d)

    def test_restore_backup_puts_code_back_and_leaves_user_files(self):
        root = pathlib.Path(tempfile.mkdtemp())
        try:
            (root/"cineyap").mkdir(); (root/"cineyap/studio.py").write_text("old code"); (root/"cineyap/config.json").write_text("{\"mine\": 1}")
            bz = root/"bk.zip"
            with zipfile.ZipFile(bz, "w") as z: z.write(root/"cineyap/studio.py", "cineyap/studio.py"); z.writestr("cineyap/config.json", "{\"from\": \"backup\"}")
            (root/"cineyap/studio.py").write_text("half new"); (root/"cineyap/config.json").write_text("{\"mine\": 2}")
            update.restore_backup(bz, root)
            self.assertEqual((root/"cineyap/studio.py").read_text(), "old code")
            self.assertEqual((root/"cineyap/config.json").read_text(), "{\"mine\": 2}", "a kept file is never touched by a restore")
        finally: shutil.rmtree(root)


if __name__ == "__main__": unittest.main()
