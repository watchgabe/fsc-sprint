"""A small synthetic project for the export tests (FIX-PLAN-2026-10-24, 3.0): a 6-second test-pattern take with a tone, two A-roll
pieces, a few transcript words, one title with small caps. Lives in projects/zz-fx-test (a zz- copy, like every test project) and
is rebuilt on each run. Nothing here needs the B-roll drive."""
import json, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/"cineyap"))
import plat      # noqa: E402
JOB = "zz-fx-test"

def ffmpeg(): return str(ROOT/"_local/bin/ffmpeg") if (ROOT/"_local/bin/ffmpeg").exists() else "ffmpeg"

def make(job=JOB, fmt="169", hdr=False, screens=None, hk=None, br=None, extra=None, take_name="take.mp4"):
    J = ROOT/"projects"/job; shutil.rmtree(J, ignore_errors=True); E = J/"edit"; (E/"transcripts").mkdir(parents=True)
    take = J/take_name
    vf = "format=yuv420p"
    extra_v = []
    if hdr:      # an HLG take, like an iPhone's: 10-bit with the HLG transfer flagged
        vf = "format=yuv420p10le"; extra_v = ["-color_primaries", "bt2020", "-color_trc", "arib-std-b67", "-colorspace", "bt2020nc",
                                             "-x264-params", "colorprim=bt2020:transfer=arib-std-b67:colormatrix=bt2020nc"]      # into the stream itself, where ffprobe reads it
    subprocess.run([ffmpeg(), "-v", "error", "-y", "-f", "lavfi", "-i", "testsrc2=size=1920x1080:rate=24000/1001:duration=6",
                    "-f", "lavfi", "-i", "sine=frequency=440:duration=6", "-vf", vf, "-c:v", "libx264", "-pix_fmt", "yuv420p10le" if hdr else "yuv420p",
                    *extra_v, "-c:a", "aac", "-shortest", str(take)], check=True)
    (E/"edl.json").write_text(json.dumps({"sources": {"take": str(take)}, "ranges": [{"start": 0.0, "end": 3.0}, {"start": 3.5, "end": 6.0}]}, indent=1))
    words = [("hello", .2, .6), ("there", .7, 1.1), ("this", 1.3, 1.6), ("is", 1.7, 1.9), ("a", 2.0, 2.1), ("test", 2.2, 2.7),
             ("second", 3.7, 4.1), ("piece", 4.2, 4.6), ("of", 4.7, 4.8), ("speech", 4.9, 5.4)]
    (E/"transcripts/take.json").write_text(json.dumps({"audio_duration_secs": 6.0, "words": [{"type": "word", "text": w, "start": a, "end": b} for w, a, b in words]}))
    (E/"faces_src.json").write_text(json.dumps({"rate": 2, "s": []})); (E/"peaks_src.json").write_text(json.dumps({"rate": 100, "p": []}))
    (E/"studio.json").write_text(json.dumps({"stage": "edit", "title": "Export fixture", "kind": "video"}))
    S = screens if screens is not None else [
        {"id": "aroll", "name": "A-roll", "kind": "aroll", "font": "h", "size": 67, "v": "bottom", "h": "center", "kase": "lower", "mode": "word", "chars": 14, "color": "#FFFFFF", "shadow": False},
        {"id": "broll", "name": "B-roll", "kind": "broll", "font": "h", "size": 150, "v": "middle", "h": "center", "kase": "lower", "mode": "word", "chars": 12, "color": "#FFFFFF", "shadow": False}]
    tl = {"REV": 1, "FMT": fmt, "SEGS": [{"src_in": 0.0, "src_out": 3.0}, {"src_in": 3.5, "src_out": 6.0}], "SCREENS": S,
          "BR": br or [], "BG": [], "FX": [], "MOVES": [], "MUSIC": [], "SFX": [], "OVR": {}, "MARKERS": [],
          "HK": hk if hk is not None else [{"hook": True, "t0": 0, "t1": 2.5, "lines": [{"text": "Hello Title", "st": {"font": "h", "size": 72, "color": "#FFFFFF", "smc": True, "v": "top", "h": "center"}}]}],
          "COLOR": None, "SOFT": True, "AUDIO_XF": 2}
    if extra: tl.update(extra)
    (E/"timeline.json").write_text(json.dumps(tl, indent=1))
    return J

def remove(job=JOB):
    shutil.rmtree(ROOT/"projects"/job, ignore_errors=True)
    for p in (ROOT/"exports").glob(job + "*"): p.unlink(missing_ok=True)

def export(job, fmt="169", k4=False, out=None, xml=False):
    a = [str(plat.PY), str(ROOT/"cineyap/timeline_tools.py"), "export", job, fmt] + ([] if xml else ["--noxml"]) + (["--4k"] if k4 else []) + (["--out", str(out)] if out else [])
    r = subprocess.run(a, cwd=ROOT, capture_output=True, text=True, timeout=600)
    if r.returncode: raise RuntimeError("export failed:\n" + r.stdout[-2000:] + r.stderr[-2000:])
    return r.stdout

def frame(video, t, out):
    """one frame as PNG (the alpha kept for the graphics layer)"""
    dec = ["-c:v", "libvpx-vp9"] if str(video).endswith(".webm") else []      # the webm's alpha only comes out of libvpx
    subprocess.run([ffmpeg(), "-v", "error", "-y", *dec, "-ss", f"{t:.3f}", "-i", str(video), "-frames:v", "1", "-pix_fmt", "rgba", str(out)], check=True)
    return out

def bbox(png, test, top=1.0):
    """bounding box (x0, y0, x1, y1) of the pixels where test(r, g, b, a) is true, in the top `top` of the frame; None when none are"""
    from PIL import Image
    im = Image.open(png).convert("RGBA"); W, H = im.size; px = im.load()
    x0 = y0 = 10**9; x1 = y1 = -1
    for y in range(0, int(H * top), 2):
        for x in range(0, W, 2):
            if test(*px[x, y]):
                x0 = min(x0, x); x1 = max(x1, x); y0 = min(y0, y); y1 = max(y1, y)
    return None if x1 < 0 else (x0, y0, x1, y1)

if __name__ == "__main__":
    print(make())
