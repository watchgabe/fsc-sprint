"""Uploads: a cut-off body ends (R19), and a take with a used name gets a new one (R7)."""
import http.client, json, unittest
from tests.support import Studio, studio


class UploadTests(unittest.TestCase):
    def test_truncated_upload_returns_400_and_leaves_no_file(self):
        with Studio() as s:
            s.project("j1")
            c = http.client.HTTPConnection("127.0.0.1", s.port, timeout=5)
            c.putrequest("POST", "/api/upload?job=j1&name=take.mp4"); c.putheader("Host", f"localhost:{s.port}"); c.putheader("Content-Length", "1000000"); c.endheaders()
            c.send(b"x" * 1000)                  # a tenth of what was promised, then the connection drops
            c.sock.shutdown(1)                   # no more bytes: the server must not spin
            r = c.getresponse(); body = json.loads(r.read())
            self.assertEqual(r.status, 400); self.assertIn("stopped", body["error"])
            self.assertEqual(list((s.projects/"j1/board_media").glob("*")), [])

    def test_raw_take_with_a_used_name_gets_a_new_one(self):
        inbox = studio.PKG/"inbox"; made = []
        try:
            with Studio() as s:
                for _ in range(2):
                    code, b = s.post("/api/upload-raw?name=zz-test-C0001.MP4", raw=b"abc", headers={"Content-Type": "application/octet-stream"})
                    self.assertEqual(code, 200); made.append(b["path"])
            self.assertNotEqual(made[0], made[1]); self.assertTrue(made[1].endswith("zz-test-C0001-2.MP4"), made[1])
        finally:
            for m in made: studio.pathlib.Path(m).unlink(missing_ok=True)

    def test_unique_path_helper(self):
        d = studio.PKG/"_local"; a = studio.unique_path(d, "zz-u.txt"); self.assertEqual(a.name, "zz-u.txt")
        a.write_text("1")
        try: self.assertEqual(studio.unique_path(d, "zz-u.txt").name, "zz-u-2.txt")
        finally: a.unlink()


if __name__ == "__main__": unittest.main()
