"""Test support: a Studio server on a free port, with its own projects folder, for the server tests.

Never the running Studio on 4747 and never the real projects/: PROJECTS is pointed at a temp folder for the test, and the
background jobs the real start does (B-roll indexing, auto update, pickers) are not started.
Run with the product python:  .venv/bin/python -m unittest discover -s tests -p "test_*.py" -t .
"""
import contextlib, json, pathlib, shutil, sys, tempfile, threading, urllib.request
from http.server import ThreadingHTTPServer

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/"cineyap"))
import studio      # noqa: E402  (the module sets nothing in motion at import)


class Studio:
    """with Studio() as s: s.post("/api/timeline-save", {...})"""
    def __init__(self, projects=None):
        self.tmp = pathlib.Path(tempfile.mkdtemp(prefix="cineyap-test-"))
        self.projects = pathlib.Path(projects) if projects else self.tmp/"projects"
        self.projects.mkdir(parents=True, exist_ok=True)
    def __enter__(self):
        self._was = studio.PROJECTS; studio.PROJECTS = self.projects
        self._log = studio.log_error; studio.log_error = lambda where: None      # a test's deliberate failures stay out of _local/studio.log
        self.srv = ThreadingHTTPServer(("127.0.0.1", 0), studio.H); self.port = self.srv.server_address[1]
        self._pw = studio.PORT; studio.PORT = self.port       # the Origin check compares against PORT
        self.th = threading.Thread(target=self.srv.serve_forever, daemon=True); self.th.start()
        return self
    def __exit__(self, *a):
        self.srv.shutdown(); self.srv.server_close()
        studio.PROJECTS = self._was; studio.PORT = self._pw; studio.log_error = self._log
        shutil.rmtree(self.tmp, ignore_errors=True)
    def url(self, path): return f"http://127.0.0.1:{self.port}{path}"
    def req(self, method, path, body=None, headers=None, raw=None):
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        r = urllib.request.Request(self.url(path), data=data, method=method)
        r.add_header("Host", f"localhost:{self.port}")
        for k, v in (headers or {}).items(): r.add_header(k, v)
        if data is not None and "Content-Type" not in (headers or {}): r.add_header("Content-Type", "application/json")
        try:
            with urllib.request.urlopen(r, timeout=10) as resp: return resp.status, resp.read()
        except urllib.error.HTTPError as e: return e.code, e.read()
    def post(self, path, body=None, **kw):
        code, b = self.req("POST", path, body, **kw)
        with contextlib.suppress(Exception): return code, json.loads(b or b"{}")
        return code, b
    def get(self, path, **kw):
        code, b = self.req("GET", path, **kw)
        return code, b
    def project(self, job, timeline=None):
        """a bare project folder the editor's API needs: edit/timeline.json (+ studio.json)"""
        e = self.projects/job/"edit"; e.mkdir(parents=True, exist_ok=True)
        (e/"studio.json").write_text(json.dumps({"stage": "edit", "title": job}))
        (e/"timeline.json").write_text(json.dumps(timeline if timeline is not None else {"REV": 0, "SEGS": [], "BR": []}))
        return self.projects/job
