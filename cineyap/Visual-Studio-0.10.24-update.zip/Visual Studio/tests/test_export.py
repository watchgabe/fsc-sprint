"""The export matches the editor (FIX-PLAN-2026-10-24, Phase 3). These run a real export (HyperFrames, ffmpeg), about a minute each,
so they run only with CINEYAP_EXPORT_TESTS=1:
    CINEYAP_EXPORT_TESTS=1 .venv/bin/python -m unittest tests.test_export
"""
import json, os, pathlib, unittest
from tests import fixture

SLOW = os.environ.get("CINEYAP_EXPORT_TESTS") == "1"
ROOT = fixture.ROOT
SCRATCH = ROOT/"_local/test-export"; SCRATCH.mkdir(parents=True, exist_ok=True)


@unittest.skipUnless(SLOW, "set CINEYAP_EXPORT_TESTS=1")
class TextSize(unittest.TestCase):
    def test_4k_text_is_twice_as_tall(self):
        """R11: the graphics layer at 4K draws the title and captions at twice the 1080p size (the whole frame scales)"""
        fixture.make()
        try:
            fixture.export(fixture.JOB, "169", out=SCRATCH/"fx-1080.mp4")
            ov1 = ROOT/"projects"/fixture.JOB/"build/export/169/graphics.webm"
            f1 = fixture.frame(ov1, 1.0, SCRATCH/"ov-1080.png"); b1 = fixture.bbox(f1, lambda r, g, b, a: a > 128, top=.3)      # the title alone (captions sit low)
            fixture.export(fixture.JOB, "169", k4=True, out=SCRATCH/"fx-4k.mp4")
            ov2 = ROOT/"projects"/fixture.JOB/"build/export/169/graphics.webm"
            f2 = fixture.frame(ov2, 1.0, SCRATCH/"ov-4k.png"); b2 = fixture.bbox(f2, lambda r, g, b, a: a > 128, top=.3)
            self.assertTrue(b1 and b2, (b1, b2))
            h1, h2 = b1[3] - b1[1], b2[3] - b2[1]
            self.assertAlmostEqual(h2 / h1, 2.0, delta=0.15, msg=f"1080p text {h1}px tall, 4K {h2}px")
        finally: fixture.remove()


if __name__ == "__main__": unittest.main()


ABG = {"id": "abg", "name": "You framed", "kind": "aroll", "afit": "frame", "abox": {"x": .3, "y": .3, "w": .4, "h": .4}, "placed": True,
       "font": "h", "size": 67, "v": "bottom", "h": "center", "kase": "lower", "mode": "word", "chars": 14, "color": "#FFFFFF", "shadow": False}

@unittest.skipUnless(SLOW, "set CINEYAP_EXPORT_TESTS=1")
class ArollFrame(unittest.TestCase):
    def test_full_aroll_behind_the_frame_and_the_clips_own_framing_in_16x9(self):
        """X2: an A-roll frame on an A-roll-background screen with no colour keeps the full A-roll behind it (16:9 painted black);
        X1: the clip's own A-roll move (ast) is read in 16:9 too (only 9:16 did)"""
        from PIL import Image
        def run(ast, tag):
            screens = [{"id": "aroll", "name": "A-roll", "kind": "aroll", "font": "h", "size": 67, "v": "bottom", "h": "center", "kase": "lower", "mode": "word", "chars": 14, "color": "#FFFFFF", "shadow": False}, ABG]
            br = [{"t0": .5, "t1": 2.5, "clip": "nowhere/missing.mp4", "in": 0, "scr": "abg", **({"ast": ast} if ast else {})}]
            fixture.make(screens=screens, br=br, hk=[])
            fixture.export(fixture.JOB, "169", out=SCRATCH/f"abg-{tag}.mp4")
            return Image.open(fixture.frame(SCRATCH/f"abg-{tag}.mp4", 1.5, SCRATCH/f"abg-{tag}.png")).convert("RGB")
        try:
            a = run(None, "plain"); W, H = a.size
            corner = a.getpixel((20, 20)); self.assertGreater(max(corner), 40, f"the corner outside the frame is black: {corner}")
            inside0 = [a.getpixel((int(W * .4) + i, int(H * .5))) for i in range(0, 200, 10)]
            b = run({"px": 40, "sc": 1.8}, "moved")
            inside1 = [b.getpixel((int(W * .4) + i, int(H * .5))) for i in range(0, 200, 10)]
            self.assertNotEqual(inside0, inside1, "the clip's own framing changed nothing inside the frame")
        finally: fixture.remove()


@unittest.skipUnless(SLOW, "set CINEYAP_EXPORT_TESTS=1")
class Hlg(unittest.TestCase):
    def test_an_hlg_take_exports_as_rec709(self):
        """R12: an HLG (iPhone) take is tone-mapped in the export like on the A-roll page; the MP4 is plain Rec.709"""
        import subprocess
        fixture.make(hdr=True)
        try:
            probe = lambda p: subprocess.run([fixture.ffmpeg().replace("ffmpeg", "ffprobe"), "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer,pix_fmt",
                                              "-of", "default=noprint_wrappers=1", str(p)], capture_output=True, text=True).stdout
            self.assertIn("arib-std-b67", probe(ROOT/"projects"/fixture.JOB/"take.mp4"), "the fixture take is flagged HLG")
            fixture.export(fixture.JOB, "169", out=SCRATCH/"hlg.mp4")
            out = probe(SCRATCH/"hlg.mp4")
            self.assertNotIn("arib-std-b67", out, out); self.assertNotIn("smpte2084", out, out)
        finally: fixture.remove()


@unittest.skipUnless(SLOW, "set CINEYAP_EXPORT_TESTS=1")
class PremiereXml(unittest.TestCase):
    def test_xml_is_well_formed_with_an_ampersand_and_points_beside_the_mp4(self):
        """R13: a file called 'B&W.mp4' no longer breaks the XML; the graphics layer and the bed live beside the MP4, not in build/"""
        import xml.etree.ElementTree as ET
        fixture.make(take_name="take & more.mp4")
        try:
            mp4 = SCRATCH/"xml-test.mp4"; mp4.unlink(missing_ok=True); (SCRATCH/"xml-test.xml").unlink(missing_ok=True)
            fixture.export(fixture.JOB, "169", out=mp4, xml=True)
            x = SCRATCH/"xml-test.xml"; self.assertTrue(x.exists(), "no XML beside the MP4")
            root = ET.parse(x).getroot()      # raises on a bare &
            names = [n.text for n in root.iter("name")]
            self.assertIn("take & more.mp4", names)
            urls = [u.text for u in root.iter("pathurl")]
            self.assertTrue(any(u.endswith("xml-test-graphics.mov") for u in urls), urls)
            self.assertTrue((SCRATCH/"xml-test-graphics.mov").exists())
            self.assertTrue(all(u.startswith("file://localhost/") for u in urls), urls)
        finally: fixture.remove()
