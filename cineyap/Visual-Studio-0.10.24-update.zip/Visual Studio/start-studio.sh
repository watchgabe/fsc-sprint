#!/usr/bin/env bash
# Start Visual Studio and open it in the browser. "Open Visual Studio.app" (made by install.sh) runs this, so a double-click
# is all it takes: no Terminal. Already running? It just opens the page.
cd "$(dirname "$0")" || exit 1
export PATH="$PWD/_local/bin:$PWD/_local/node:$PATH"
URL="http://localhost:4747/"
PY=.venv/bin/python; [ -x "$PY" ] || PY=.venv/Scripts/python.exe   # Mac / Windows (Git Bash: "Open Visual Studio.bat" is the double-click there)
export PYTHONUTF8=1
if ! curl -fs -o /dev/null "$URL"; then
  if [ ! -x "$PY" ]; then
    osascript -e 'display dialog "Visual Studio isn'"'"'t set up yet.\n\nOpen this folder in the Claude app (Code tab) and type: set me up" buttons {"OK"} default button 1 with title "Visual Studio"' >/dev/null 2>&1
    exit 1
  fi
  mkdir -p _local projects inbox
  nohup "$PY" cineyap/studio.py --no-open >> _local/studio.log 2>&1 &
  for _ in $(seq 1 60); do curl -fs -o /dev/null "$URL" && break; sleep 0.5; done
fi
case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) start "" "$URL";; *) open "$URL";; esac
