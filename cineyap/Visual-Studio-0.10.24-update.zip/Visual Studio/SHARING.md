# Sharing CineYap (Loop Studio) with testers

The whole path from "it works on my Mac" to "five people are editing with it", for testers who have never used Claude Code.
Written 2026-10-25. Items marked **To build** don't exist yet.

---

## The short version

A tester needs three things:

| What | Why | Cost |
|---|---|---|
| A Mac, Apple silicon or Intel (Intel is slower) | The editing, the face tracking (Apple Vision) and the export all run on their Mac | — |
| A Claude subscription (Pro or Max) with Claude Code installed | The Studio's chat, the first cut, effects and hook finding call Claude Code on their Mac. **They never have to open it or type in it.** | Their plan |
| ~30 minutes, once | Install, then first-run setup | — |

Their videos never leave their Mac. Transcription runs on their Mac too, free.

---

## 1. Before you send it (your side)

| # | Step | Status |
|---|---|---|
| 1 | **Commit today's work** on `studio-mvp` (the package is built from the last commit, so anything uncommitted doesn't ship) | **Done** (local commits, not pushed) |
| 2 | **The editor had your Mac's path written in it** (`/Users/gabeharris/...`), so it broke on any other Mac | **Fixed 2026-10-25**: the server fills in the right folder |
| 3 | **Installer: no Homebrew, no Terminal.** Download Python (via uv), a static ffmpeg (with libass and the Mac video encoder) and Node into `_local/bin`; `vu-py` and the Studio use them. Node is required, not optional: every export renders captions and text through it (HyperFrames) | **Done 2026-10-25** |
| 4 | **Claude Code:** the Studio also finds the copy inside the Claude app (`~/Library/Application Support/Claude/claude-code/…`). Still to check on a clean Mac: whether that copy is signed in when the Studio calls it | To check |
| 5 | **A double-click launcher**: install.sh makes `Open Loop Studio.app` (runs `start-studio.sh`: starts the Studio if needed, opens the browser) | **Done 2026-10-25** |
| 6 | **First-run setup**: as a chat in "set me up" (CLAUDE.md step 1: key, colors, fonts, LUT, B-roll + index, all skippable). A window inside the Studio is still to build (nice, not blocking) | **Done as chat** |
| 7 | **Update and Report buttons** in the Studio. Today these are only `/update` and `/report` inside Claude Code, which a non-Claude-Code tester will never see | Not blocking: "report a problem" / "update" in the Code tab work (CLAUDE.md) |
| 8 | **Test on a clean Mac**: make a new macOS user account, follow section 2 exactly as written, and fix every place you get stuck | To do |
| 9 | Update `TESTER-TERMS.md` (it says "run `/report`"; point it at the Report button) | **Done** |
| 10 | Bump `product.json` → `./vu-py cineyap/package.py 0.10.0 "Loop Studio editor"`; host the update zip and `version.json` at fscreative.live/cineyap/ (`~/code/fsc-sprint/cineyap/`); the install zip goes to `~/code/watchgabe-site/downloads/Loop-Studio.zip`, and testers get one link: **watchgabe.com/loop** (download + the steps; unlisted, noindex) | **Done 2026-10-23** |

Fonts are fine to ship: Inter and Instrument Serif are open-licensed and in `fonts/`; Helvetica comes with every Mac.
Your own Helvetica Neue LT file is NOT shipped. Testers get the starter brand until they set their own.

---

## 2. What the tester does (the install guide you send them): no Terminal

Decided 2026-10-25: testers never open Terminal. Claude does the setup inside the Claude app. **No Homebrew**: its installer
asks for the Mac password inside Terminal, which Claude can't type (that's what broke the first tester install). Instead
the setup downloads its own Python, ffmpeg and Node into the CineYap folder (no password, nothing system-wide; delete the
folder and it's all gone). **To build**: `install.sh` fetching the three tools into the folder (`_local/bin`), and `vu-py` /
the Studio using them.

Send this as a one-page guide, with the video.

1. **Install the Claude app**: claude.ai/download, drag it to Applications, sign in with a Pro or Max plan.
2. **Unzip the CineYap folder** into their home folder or Documents (NOT iCloud Drive, Dropbox or the Desktop).
3. **Open the folder in the Claude app's Code tab and type "set me up."** Claude installs everything into the folder,
   then runs the first-run setup (section 3) as a chat: brand, fonts, LUT, B-roll library.
   They can skip any of it.
4. **Double-click `Open Loop Studio`** in the folder: the Studio opens in the browser. From here on that's how they start
   it; the Code tab is only for "something's wrong" or "make me a new effect".
5. **Edit the sample first** (the sample takes ship in `samples/`), then their own take with **New edit**.

`./check-setup.sh` lists anything missing and changes nothing; in the Code tab, "check my setup" runs it.

**Mac, and Windows in testing (2026-10-23).** Windows runs in Git Bash with everything downloaded into the folder, like
Startup Mom's engine. Steps, the test checklist and what differs are in `WINDOWS.md`. Not on the download page until a
Windows tester has gone through it.

`./check-setup.sh` lists anything missing and changes nothing. It's the first thing to ask a stuck tester to run.

---

## 3. First-run setup: a simple dialog, all skippable (To build)

Shown the first time the Studio opens (and any time from a **Setup** button). Four small cards, each with **Skip**:

1. **Your colors**: two or three swatches + hex (writes `cineyap/brand.json` → `colors`). Every swatch row in the editor
   offers them.
2. **Your fonts**: a main font and an accent font from the Mac's fonts, or upload a .ttf/.otf (→ `cineyap/brand_assets/`).
3. **Your look**: "Did you shoot in log?" → pick a LUT (.cube) or **No LUT** (sets `lut` in `config.json`). This one
   matters: a log LUT on normal footage blows the image out.
4. **Your B-roll library**: pick a folder (section 4), then **Index it** with a progress bar.

The Studio already has a Brand tab that writes `brand.json`; the dialog is a friendly front door to it, plus the library step.

---

## 4. The B-roll library

**What it is:** a folder of the tester's own clips, in subfolders by type: `Office/`, `Travel/`, `Lifestyle/`… Loop never
moves or changes the files; it reads them where they sit. It's optional: videos build without it, just without cutaways.

**Three starting points:**

| They have… | Do this |
|---|---|
| Clips already one shot per file, in folders | Point the setup at the folder (`broll_root` in `config.json`). Done. |
| Long exports or mixed reels (many shots per file) | Run the library sorter, `cineyap/broll_sort.py`: **split** chops every shot into its own file (scene detection, trims the frames either side of each cut), **sheets** makes contact sheets that Claude looks at to name and bucket each shot, **apply** files them into folders. *Today this runs from Claude Code: "sort my B-roll in <folder>". To build: a Sort button in setup / Media.* |
| Nothing yet | Skip. Later, drag clips into **Media** in the editor (they upload into the project) or point the setup at a folder. |

**Indexing:** `cineyap/detect_shots.py` scene-detects every clip into `cineyap/shots.json`, so one file with several shots
is never used twice for "different" shots and a pick never spans a cut. The installer runs it the first time; it must run
again after adding clips. *To build: an **Index again** button.* `detect_shots.py` scans the whole folder (fixed 2026-10-25).

**Using it in the editor:** **Media → Video** shows the whole library (sort by Name or Newest, folders, hide, buckets).
Drag a clip onto the timeline or onto the video. On an external drive, the Studio shows a bar while the drive is unplugged
and won't rebuild without it (`cineyap/drives.py`).

---

## 5. The onboarding video

One main video (~10 min) plus three short ones. Screen recordings with your face in a corner; record it on the clean
Mac from section 1, step 8, so every click is real.

**Main video: "Your first edit in Loop Studio"**

| Time | Chapter | Show |
|---|---|---|
| 0:00 | Hook | A raw take, then the finished video, side by side. "You film it, this edits it." |
| 0:30 | What you need | Mac and a Claude plan. Your videos stay on your Mac |
| 1:30 | Install | Claude sign-in, unzip, "set me up" in the Code tab |
| 4:00 | First-run setup | Colors, fonts, LUT yes/no, connect a B-roll folder and index it |
| 5:30 | First edit | New edit → pick the take → the radio cut (listen, cut lines by number) → Lock |
| 7:00 | The editor tour | Script (Version / Full Script / Split, search, drag a line in), Screens, Text (Align, Enter for a new line), Media, Inspector, Chat (⌘K) |
| 9:00 | Export | Export video, versions, where the file lands |
| 9:30 | When something breaks | The Report button, where to post it (Circle), updates |

**Short ones (60-90 s each):** "Set up your B-roll library", "Titles and text", "Find any line in your take
(Script tab)".

---

## 6. How to send it

1. **Start with 3 testers**, then 10. Mac users who already film talking-head videos and post weekly.
2. **Each tester gets:** the private install-zip link, the main video, the one-page guide (section 2), `TESTER-TERMS.md`,
   and an invite to the Circle testers space.
3. **The message:**

   > Hey [name], I built an editor that cuts my talking-head videos for me, and I'd love you to test it before anyone else.
   > It runs on your Mac (your footage never leaves it). Setup is ~30 minutes once: watch this [video], then follow this
   > [guide]. The download is here [link]. All you need is a Mac and a Claude plan.
   > When something breaks, hit Report and post the file in [Circle space] with one line about what you were doing.
   > That's the most useful thing you can give me. Thank you!

4. **Support loop:** reports land in Circle; you (or a Claude session here) read the zip, fix, bump the version, and
   `package.py` + host the update. Testers get it from the Update button.
5. **After week one:** a 15-minute call with each of the first three, watching them edit one video. That's where the
   real onboarding fixes come from.

---

## 7. Order of work

1. Commit today's work (needs your OK).
2. Installer fixes (Node required, Claude Code check) + the double-click launcher + `detect_shots.py` scanning their folder.
3. First-run setup dialog (brand, fonts, LUT, B-roll library + Index).
4. Update and Report buttons in the Studio.
5. Clean-Mac test; fix what breaks.
6. Record the onboarding video on that clean Mac.
7. Package, send to 3 testers, then 10.

---

## Next features (after the first testers)

- **Upload your own music and sound effects** (drop a file on Audio, or pick one): today the Audio tab only lists Gabe's
  music folder and SFX drive, so testers start with an empty list. Needs: an upload into the package's own music / SFX
  folders, and those folders read by the Audio tab.
- A first-run setup window inside the Studio (today it's the "set me up" chat).
- Update and Report buttons in the Studio.
