#!/usr/bin/env bash
# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
# install-video.sh — get the CineYap pipeline running on THIS machine.
#
# Detect, then skip. Nothing is asked that can be checked, so re-running it is cheap and safe.
# Every step is idempotent. Nothing here reaches the network except the pip install and, if you
# choose, the one-time font download.
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
ROOTW="$ROOT"; command -v cygpath >/dev/null 2>&1 && ROOTW="$(cygpath -m "$ROOT")"      # Windows python can't read Git Bash's /c/... paths (C:/... it can)
HERE="$ROOT/cineyap"
VENV="$ROOT/.venv"
ENVF="$ROOT/.env"
CFG="$HERE/config.json"
ok(){ printf '  \033[32mOK\033[0m   %s\n' "$1"; }
no(){ printf '  \033[31m!!\033[0m   %s\n' "$1"; }
ask(){ printf '\n%s\n' "$1"; printf '   > '; read -r REPLY; }

echo; echo "Visual Studio — setting up this machine"; echo

# ---------- 0. no Homebrew, no password (2026-10-25) ----------
# Python, ffmpeg and Node are downloaded INTO this folder (_local/), so nothing is installed system-wide and no Mac
# password is ever asked (Homebrew's installer asks for one in Terminal, which a tester, or Claude, can't get through).
# A copy already on this Mac (Homebrew, python.org) is used when it is good enough.
# Windows: this runs in Git Bash (never WSL or PowerShell), with the same no-admin rule: every tool is a download into _local/
case "$(uname -s)" in MINGW*|MSYS*|CYGWIN*) WIN=1;; *) WIN=0;; esac
if [ "$WIN" = 1 ]; then PYV="$VENV/Scripts/python.exe"; X=.exe; export PYTHONUTF8=1; else PYV="$VENV/bin/python"; X=""; fi
ARCH="$(uname -m)"; TOOLS="$ROOT/_local/bin"; mkdir -p "$TOOLS" "$ROOT/projects" "$ROOT/inbox"; export PATH="$TOOLS:$ROOT/_local/node:$PATH"
export UV_PYTHON_INSTALL_DIR="$ROOT/_local/python" UV_CACHE_DIR="$ROOT/_local/uv-cache"
[ "$WIN" = 1 ] || xattr -dr com.apple.quarantine "$ROOT" 2>/dev/null || true      # a folder from a downloaded zip: let its scripts and the launcher run
TMPD="$(mktemp -d)"; trap 'rm -rf "$TMPD"' EXIT
fetch(){ curl -fsSL --retry 3 -o "$2" "$1"; }
# unzip ships with Git for Windows; PowerShell's Expand-Archive is the fallback
unz(){ if command -v unzip >/dev/null 2>&1; then unzip -o -q "$1" -d "$2"
  else powershell -NoProfile -Command "Expand-Archive -Force -LiteralPath '$(cygpath -w "$1")' -DestinationPath '$(cygpath -w "$2")'"; fi; }
UV="$TOOLS/uv$X"
need_uv(){ [ -x "$UV" ] && return 0
  case "$ARCH" in arm64|aarch64) UA=aarch64;; *) UA=x86_64;; esac
  echo "  downloading uv (it installs Python into this folder)…"
  if [ "$WIN" = 1 ]; then
    fetch "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" "$TMPD/uv.zip" && unz "$TMPD/uv.zip" "$TMPD/uv" \
      && cp "$TMPD/uv/uv.exe" "$UV" || { no "could not download uv. Check the internet connection and run this again."; exit 1; }; return 0
  fi
  fetch "https://github.com/astral-sh/uv/releases/latest/download/uv-$UA-apple-darwin.tar.gz" "$TMPD/uv.tgz" && tar -xzf "$TMPD/uv.tgz" -C "$TMPD" \
    && cp "$TMPD"/uv-*/uv "$UV" && chmod +x "$UV" || { no "could not download uv. Check the internet connection and run this again."; exit 1; }; }

# ---------- 1. python (3.11, in this folder) ----------
if [ ! -x "$PYV" ]; then
  need_uv; echo "  making this folder's Python 3.11 (a minute)…"
  "$UV" venv -q --python 3.11 "$VENV" || { no "could not make the Python environment"; exit 1; }
fi
ok "python: $("$PYV" --version 2>&1)"

# ---------- 2. packages ----------
# Apple Vision (OCR, eyes) is Mac-only; Windows gets the rest
if [ "$WIN" = 1 ]; then MODS="PIL,numpy,scipy,requests,pycapcut,cv2"; APPLE=""; else MODS="PIL,numpy,scipy,requests,pycapcut,cv2,Vision,Quartz"; APPLE="pyobjc-framework-Vision pyobjc-framework-Quartz"; fi
if "$PYV" -c "import $MODS" 2>/dev/null; then
  ok "python packages (Pillow, numpy, scipy, requests, pycapcut, opencv${APPLE:+, Apple Vision})"
else
  need_uv; echo "  installing Pillow, numpy, scipy, requests, pycapcut, opencv${APPLE:+, Apple Vision}…"
  "$UV" pip install -q --python "$PYV" Pillow numpy scipy requests pycapcut opencv-python-headless $APPLE \
    || { no "package install failed"; exit 1; }
  ok "python packages installed"
fi

# ---------- 3. ffmpeg + ffprobe (with libass and the Mac's video encoder) ----------
# Windows has no videotoolbox: it encodes with libx264 (slower, same picture)
[ "$WIN" = 1 ] && ENC=libx264 || ENC=h264_videotoolbox
ffok(){ command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1 && ffmpeg -hide_banner -filters 2>/dev/null | grep -q " subtitles " \
  && ffmpeg -hide_banner -encoders 2>/dev/null | grep -q " $ENC "; }
if ! ffok && [ "$WIN" = 1 ]; then
  echo "  downloading ffmpeg into this folder (gyan.dev essentials build)…"
  fetch "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" "$TMPD/ff.zip" && unz "$TMPD/ff.zip" "$TMPD/ff" \
    && cp "$TMPD"/ff/*/bin/ffmpeg.exe "$TMPD"/ff/*/bin/ffprobe.exe "$TOOLS/" || { no "could not download ffmpeg"; exit 1; }
elif ! ffok; then
  case "$ARCH" in arm64) FA=arm64;; *) FA=amd64;; esac
  echo "  downloading ffmpeg into this folder (a static build, martin-riedl.de)…"
  for b in ffmpeg ffprobe; do
    fetch "https://ffmpeg.martin-riedl.de/redirect/latest/macos/$FA/release/$b.zip" "$TMPD/$b.zip" && unzip -o -q "$TMPD/$b.zip" -d "$TOOLS" && chmod +x "$TOOLS/$b" \
      || { no "could not download $b"; exit 1; }
  done
fi
ffok && ok "ffmpeg $(ffmpeg -version 2>/dev/null | head -1 | awk '{print $3}') (captions, $ENC)" || no "ffmpeg is not usable. Delete _local/bin/ffmpeg and run this again."

# ---------- 3b. Node (every export draws captions and text with it) ----------
if ! command -v npx >/dev/null 2>&1 && [ "$WIN" = 1 ]; then
  echo "  downloading Node into this folder…"
  NV="$(curl -fsSL https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt | grep -o "node-v[0-9.]*-win-x64.zip" | head -1)"
  # Node stays in its own folder (npx.cmd finds npm next to node.exe); _local/node is on PATH, here and in every script
  [ -n "$NV" ] && fetch "https://nodejs.org/dist/latest-v22.x/$NV" "$TMPD/node.zip" && unz "$TMPD/node.zip" "$TMPD/node" \
    && rm -rf "$ROOT/_local/node" && mv "$TMPD"/node/node-v* "$ROOT/_local/node" || { no "could not download Node"; exit 1; }
elif ! command -v npx >/dev/null 2>&1; then
  case "$ARCH" in arm64) NA=arm64;; *) NA=x64;; esac
  echo "  downloading Node into this folder…"
  NV="$(curl -fsSL https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt | grep -o "node-v[0-9.]*-darwin-$NA.tar.gz" | head -1)"
  [ -n "$NV" ] && fetch "https://nodejs.org/dist/latest-v22.x/$NV" "$TMPD/node.tgz" && rm -rf "$ROOT/_local/node" && mkdir -p "$ROOT/_local/node" \
    && tar -xzf "$TMPD/node.tgz" -C "$ROOT/_local/node" --strip-components 1 \
    && for b in node npm npx; do ln -sf "../node/bin/$b" "$TOOLS/$b"; done || { no "could not download Node"; exit 1; }
fi
command -v npx >/dev/null 2>&1 && ok "Node $(node --version 2>/dev/null) (captions and text in exports)" || no "Node is not usable"
if [ ! -f "$ROOT/_local/hyperframes.ok" ] && command -v npx >/dev/null 2>&1; then
  echo "  fetching the renderer exports use (first time only, a few minutes)…"
  (cd "$TMPD" && npx --yes hyperframes --version >/dev/null 2>&1) && date > "$ROOT/_local/hyperframes.ok" && ok "renderer ready" || no "the renderer will download on the first export instead"
fi

# ---------- 3c. Claude Code (the Studio's chat, first cut and effects use it) ----------
CL=""; for c in "$(command -v claude 2>/dev/null)" "$HOME/.local/bin/claude$X" "${APPDATA:-}/npm/claude.cmd" "$HOME/.claude/local/claude$X"; do [ -n "$c" ] && [ -x "$c" ] && { CL="$c"; break; }; done
[ -z "$CL" ] && [ "$WIN" = 0 ] && CL="$(ls -d "$HOME/Library/Application Support/Claude/claude-code/"*/*/claude.app/Contents/MacOS/claude 2>/dev/null | tail -1)"
[ -n "$CL" ] && ok "Claude Code: $("$CL" --version 2>/dev/null | head -1)" || no "Claude Code not found: install the Claude app (claude.ai/download), sign in, open its Code tab once"
# installed is not enough: the Studio's Claude Code needs its own sign-in (the Claude app's doesn't carry over)
if [ -n "$CL" ]; then
  if "$CL" auth status 2>/dev/null | grep -q '"loggedIn": *true'; then ok "Claude Code is signed in"
  else no "Studio isn't connected to Claude yet: click Connect Claude in Studio and Authorize in the browser (or run: $CL auth login)"; fi
fi
[ -f "$HERE/models/face_detection_yunet_2023mar.onnx" ] && ok "face finder model (eye lock)" || no "face finder model missing - re-download the package"

# ---------- 4. fonts ----------
# The package ships two free fonts (SIL Open Font License) in fonts/. CapCut reads them straight from
# the file, so nothing has to be installed; your style pack can still point at fonts you own.
[ -f "$ROOT/fonts/Inter-Bold.ttf" ] && [ -f "$ROOT/fonts/InstrumentSerif-Italic.ttf" ] && ok "fonts (Inter Bold, Instrument Serif - shipped)" || no "fonts/ folder incomplete - re-download the package"
# the style packs and CapCut look for Instrument Serif in your Fonts folder (2026-10-23: a tester's check flagged it missing).
# A free font (SIL OFL), copied only if it isn't there; nothing else outside this folder is touched
if [ "$WIN" = 0 ] && [ -f "$ROOT/fonts/InstrumentSerif-Italic.ttf" ] && [ ! -f "$HOME/Library/Fonts/InstrumentSerif-Italic.ttf" ]; then
  mkdir -p "$HOME/Library/Fonts" && cp "$ROOT/fonts/InstrumentSerif-Italic.ttf" "$HOME/Library/Fonts/" && ok "Instrument Serif added to your fonts"
fi

# ---------- 5. transcription: free, on this Mac (WhisperX) ----------
# Set up now, not on the first edit, so the first edit just runs (2026-10-25). ~1 GB of tools + ~2 GB of models, once.
# An ElevenLabs key in .env is still used if one is there; nobody is asked for it.
if [ -f "$ROOT/_local/whisperx.ok" ]; then ok "transcription: free, on this Mac"
else
  echo "  setting up free transcription on this Mac (about 5-10 minutes, once)…"
  # (an Intel Mac gets faster-whisper instead of WhisperX: transcribe.py picks)
  if "$PYV" -c "import sys;sys.path.insert(0,r'$ROOTW/helpers');import transcribe;sys.exit(0 if transcribe.prepare() else 1)"
  then date > "$ROOT/_local/whisperx.ok"; ok "transcription: free, on this Mac"
  else no "transcription will finish setting itself up on the first edit"; fi
fi

# ---------- 5b. code a newer version retired ----------
# An update copies the new files over but never removes old ones, so what a version retires is listed in cineyap/retired.txt
# (2026-10-23: the old CapCut pipeline moved to legacy/, which doesn't ship). The update already backed them up to
# _local/backups. Never in a git checkout: there the files moved, they weren't retired.
if [ -f "$HERE/retired.txt" ] && [ ! -d "$ROOT/.git" ]; then
  gone=0
  while IFS= read -r f; do f="${f%$'\r'}"; [ -n "$f" ] && [ -f "$ROOT/$f" ] && rm -f "$ROOT/$f" && gone=$((gone+1)) && rmdir -p "$(dirname "$ROOT/$f")" 2>/dev/null; done < "$HERE/retired.txt"
  [ "$gone" -gt 0 ] && ok "removed $gone files this version retired (backed up in _local/backups)"
fi

# ---------- 6. config ----------
[ -f "$CFG" ] || cp "$HERE/config.example.json" "$CFG"
# a new install starts from the neutral starter brand; the Brand Studio (or "set up my brand") makes it theirs
[ -f "$HERE/brand.json" ] || { cp "$HERE/brand.example.json" "$HERE/brand.json" && ok "brand: the neutral starter (set yours on Visual Studio's Brand page)"; }
get(){ "$PYV" -c "import json;print(json.load(open('$CFG')).get('$1','') or '')" 2>/dev/null; }
BR="$(get broll_root)"
if [ -n "$BR" ] && [ -d "$BR" ]; then ok "B-roll library: $BR"
else ok "B-roll library: link it any time from Visual Studio's home page"; fi      # no questions in setup (Gabe, 2026-10-24)

# ---------- 7. the shot index, built from THEIR footage ----------
if [ -n "$BR" ] && [ -d "$BR" ]; then
  if [ -f "$HERE/shots.json" ]; then ok "B-roll shot index exists ($HERE/shots.json)"
  else
    echo "  Indexing your B-roll (scene detection — this can take a few minutes)…"
    ("$PYV" "$HERE/detect_shots.py") && ok "shot index built" || no "indexing failed"
  fi
fi

# ---------- 8. the launcher: double-click "Open Visual Studio" (no Terminal) ----------
chmod +x "$ROOT/start-studio.sh" 2>/dev/null
if [ "$WIN" = 1 ]; then
  # Windows: "Open Visual Studio.bat" does what start-studio.sh does (no Git Bash needed to start it), and the
  # UTF-8 setting is saved for the user so a Studio started any other way reads text the same way
  cp "$ROOT/windows/Open Visual Studio.bat" "$ROOT/Open Visual Studio.bat" && ok "launcher: double-click \"Open Visual Studio\" in this folder" \
    || no "could not make the launcher (start with ./start-studio.sh)"
  setx PYTHONUTF8 1 >/dev/null 2>&1 || true
elif [ ! -d "$ROOT/Open Visual Studio.app" ]; then
  osacompile -o "$ROOT/Open Visual Studio.app" \
    -e 'set f to do shell script "dirname " & quoted form of POSIX path of (path to me)' \
    -e 'do shell script quoted form of (f & "/start-studio.sh")' >/dev/null 2>&1 \
    && ok "launcher: double-click \"Open Visual Studio\" in this folder" || no "could not make the launcher (start with ./start-studio.sh)"
else ok "launcher: Open Visual Studio"; fi

# ---------- done ----------
mkdir -p "$ROOT/_local" && date > "$ROOT/_local/cineyap-install.ok"
echo
echo "Setup finished. Re-run this any time — it only does what is still missing."
echo "Check anything: ./check-setup.sh"
echo
