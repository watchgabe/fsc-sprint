# Loop: Visual Studio

You film it. This edits it.

Start a new video in **Visual Studio** and Claude cuts your talking-head take: the best take of every line, the false
starts and dead air gone. You listen to the cut and lock it, then the editor opens: B-roll from your own library,
captions, text, color and effects, in 16:9, 4:3, 9:16 or 3:4. **Export** gives you an MP4 and a Premiere timeline.

---

## Getting started

The install page is **watchgabe.com/loop**. In short:

1. **Put this folder in Documents** (or your home folder). Not iCloud Drive, Dropbox or the Desktop: cloud sync
   quietly moves large video files away and an export stops halfway.
2. Open this folder in the Claude app's **Code** tab and type **"set me up."** It installs what is missing into this
   folder (no password, nothing system-wide). About ten minutes, once.
3. Double-click **Open Visual Studio** in this folder. That's how you start it from now on.
4. Click **Start new video** and try `samples/sample-16x9.mp4` first, then your own take.

Testing? Read `TESTER-TERMS.md`. Something broke? In the Code tab, say **"report a problem"** and send Gabe the zip.

`./check-setup.sh` tells you what is missing at any time. It changes nothing.

---

## What you need

| | |
|---|---|
| **A Mac** | Apple silicon or Intel. Intel works, slower: transcription and the text-behind cutout take about 3x as long. Windows is in testing (`WINDOWS.md`). |
| **A Claude plan** | Pro or Max, with the Claude app. Visual Studio uses it for the cut, hooks, B-roll picks and Chat. |
| **Nothing else** | transcription is free and runs on your Mac; setup downloads Python, ffmpeg and Node into this folder |

Optional, and everything still works without them: a `.cube` LUT if you shoot log, and a folder of your own B-roll.

---

## Making it yours

Open **Brand** (top right of Visual Studio): your colors, fonts, handle and LUT. New videos pick them up. They are saved
in `cineyap/brand.json`. Link your B-roll folder from the home page; Claude looks at every clip once so it can pick
shots by what's in them.

---

## Where things go

```
projects/<job>/     one folder per video: the cut, the editor's timeline, exports
cineyap/            the engine: studio.py (Visual Studio), timeline_tools.py (the export)
cineyap/studio/     Visual Studio's pages and the editor
cineyap/styles/     the looks
helpers/            transcription, rendering
```
