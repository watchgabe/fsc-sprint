#!/usr/bin/env bash
# What is missing on this machine, with the fix beside it. Changes nothing.
cd "$(dirname "$0")" 2>/dev/null
export PATH="$PWD/_local/bin:$PWD/_local/node:$PATH"      # the tools install.sh put in this folder
export PYTHONUTF8=1
PY=.venv/bin/python; [ -x "$PY" ] || PY=.venv/Scripts/python.exe   # Mac / Windows (Git Bash)
MODS="PIL,numpy,scipy,requests,pycapcut,cv2"; [ "$(uname -s)" = Darwin ] && MODS="$MODS,Vision,Quartz"
ok=0; miss=0
say(){ printf '  %s %-16s %s\n' "$1" "$2" "$3"; }
echo; echo "Visual Studio — setup check"; echo

echo "Tools:"
if [ -x "$PY" ]; then
  V=$("$PY" --version 2>&1 | awk '{print $2}')
  if "$PY" -c "import $MODS" 2>/dev/null; then say "OK" "python env" "$V, all packages"; ok=$((ok+1))
  else say "!!" "python env" "$V but packages missing — run ./install.sh"; miss=$((miss+1)); fi
else say "!!" "python env" "no venv — run ./install.sh"; miss=$((miss+1)); fi

if command -v ffmpeg >/dev/null 2>&1; then
  if ffmpeg -hide_banner -filters 2>/dev/null | grep -q " subtitles "; then say "OK" "ffmpeg" "has libass"; ok=$((ok+1))
  else say "!!" "ffmpeg" "built WITHOUT libass — run ./install.sh (it puts a full one in this folder)"; miss=$((miss+1)); fi
else say "!!" "ffmpeg" "missing — run ./install.sh"; miss=$((miss+1)); fi
if command -v npx >/dev/null 2>&1; then say "OK" "node" "$(node --version 2>/dev/null) (exports draw captions with it)"; ok=$((ok+1))
else say "!!" "node" "missing — run ./install.sh (exports need it)"; miss=$((miss+1)); fi

echo; echo "Fonts (whatever your style pack names):"
LOOK=$([ -f cineyap/config.json ] && "$PY" -c "import json;print(json.load(open('cineyap/config.json')).get('look','gabe'))" 2>/dev/null || echo gabe)
if [ -f "cineyap/styles/$LOOK.json" ]; then
  "$PY" - "$LOOK" <<'PYS' 2>/dev/null || say "!!" "style pack" "could not read cineyap/styles/$LOOK.json"
import json,sys,os,pathlib
d=json.load(open(f"cineyap/styles/{sys.argv[1]}.json"))
for k,v in d["fonts"].items():
    if not isinstance(v,str): continue
    p=pathlib.Path(os.path.expanduser(v))
    print(f"  {'OK' if p.exists() else '!!'} {k:<16} {p if p.exists() else str(p)+'  MISSING'}")
for k,ship in (("sans_path","Inter-Bold.ttf"),("serif_path","InstrumentSerif-Italic.ttf")):
    v=d.get("capcut",{}).get(k)
    p=pathlib.Path(os.path.expanduser(v)) if v else None
    if p and p.exists(): print(f"  OK {'capcut '+k.split('_')[0]:<16} {p}")
    else: print(f"  OK {'capcut '+k.split('_')[0]:<16} {ship} (comes with Loop)")
PYS
  ok=$((ok+1))
else say "!!" "style pack" "cineyap/styles/$LOOK.json not found"; miss=$((miss+1)); fi

echo; echo "This install:"
# Claude Code: the Studio runs it for the A-roll cut, hooks, B-roll picks and Chat. It needs its OWN sign-in (the Claude app's
# doesn't carry over), with an account that's yours (2026-10-23, a tester's first edit stopped halfway on this)
CL=""; for c in "$(command -v claude 2>/dev/null)" "$HOME/.local/bin/claude.exe" "$APPDATA/npm/claude.cmd" "$HOME/.local/bin/claude" "$HOME/.claude/local/claude" /opt/homebrew/bin/claude /usr/local/bin/claude; do [ -n "$c" ] && [ -x "$c" ] && { CL="$c"; break; }; done
[ -z "$CL" ] && CL="$(ls -d "$HOME/Library/Application Support/Claude/claude-code/"*/*/claude.app/Contents/MacOS/claude 2>/dev/null | tail -1)"
if [ -z "$CL" ]; then say "!!" "Claude Code" "not found — install the Claude app (claude.ai/download), sign in, open its Code tab once"; miss=$((miss+1))
elif "$CL" auth status 2>/dev/null | grep -q '"loggedIn": *true'; then say "OK" "Claude Code" "signed in ($("$CL" auth status 2>/dev/null | grep -o '"email": *"[^"]*"' | sed 's/.*"\([^"]*\)"$/\1/'))"; ok=$((ok+1))
else say "!!" "Claude Code" "not connected — click Connect Claude in Studio, then Authorize in the browser (or run: $CL auth login)"; miss=$((miss+1)); fi
[ -f cineyap/config.json ] && { say "OK" "config" "present"; ok=$((ok+1)); } || { say "!!" "config" "missing — run ./install.sh"; miss=$((miss+1)); }
# transcription is free on this Mac (WhisperX, 2026-10-25); an ElevenLabs key is only an optional extra
if [ -f _local/whisperx.ok ]; then say "OK" "transcription" "free, on this Mac"; ok=$((ok+1))
elif [ -f .env ] && grep -q '^ELEVENLABS_API_KEY=.\+' .env 2>/dev/null; then say "OK" "transcription" "ElevenLabs key set"; ok=$((ok+1))
else say "!!" "transcription" "not set up yet — run ./install.sh (or say \"set me up\")"; miss=$((miss+1)); fi
[ -f cineyap/shots.json ] && say "OK" "B-roll index" "built" || say "--" "B-roll index" "none (fine — you just get no cutaways)"

echo; echo "Where it lives:"
case "$PWD" in
  *"/Library/Mobile Documents/"*|*"/iCloud Drive"*|*"/Dropbox/"*|*"/Google Drive"*|*"/OneDrive"*)
    say "!!" "location" "in cloud sync — files get evicted and renders fail halfway. Move to ~/Projects."; miss=$((miss+1));;
  *) say "OK" "location" "not in cloud sync"; ok=$((ok+1));;
esac

echo
[ "$miss" -eq 0 ] && echo "All good — $ok checks passed." || echo "$miss to fix, $ok fine. Fix the !! lines, then run this again."
echo
