"""Transcribe a video: ElevenLabs Scribe when there's a key, else WhisperX free on this Mac (2026-10-25).

With ELEVENLABS_API_KEY set: Scribe (the best cuts: every "um" and restart, tight word times). Without one: the free
transcriber, transcribe_local.py, in its own environment (_local/whisperx-venv, built the first time, ~4 GB with
the model). Both write the same JSON, so nothing after this step knows which ran.

Extracts mono 16kHz audio via ffmpeg, uploads to Scribe with verbatim +
diarize + audio events + word-level timestamps, writes the full response
to <edit_dir>/transcripts/<video_stem>.json.

Cached: if the output file already exists, the upload is skipped.

Usage:
    python helpers/transcribe.py <video_path>
    python helpers/transcribe.py <video_path> --edit-dir /custom/edit
    python helpers/transcribe.py <video_path> --language en
    python helpers/transcribe.py <video_path> --num-speakers 2
"""

from __future__ import annotations

import argparse
import array
import json
import math
import os
import platform
import subprocess
import sys
import tempfile
import time
import wave
from pathlib import Path

import requests


SCRIBE_URL = "https://api.elevenlabs.io/v1/speech-to-text"


def load_api_key() -> str:
    for candidate in [Path(__file__).resolve().parent.parent / ".env", Path(".env")]:
        if candidate.exists():
            for line in candidate.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                if k.strip() == "ELEVENLABS_API_KEY":
                    return v.strip().strip('"').strip("'")
    return os.environ.get("ELEVENLABS_API_KEY", "")      # none: the free transcriber runs instead


PKG = Path(__file__).resolve().parent.parent
# Intel Macs get faster-whisper alone: PyTorch stopped shipping for them at 2.2 and WhisperX needs 2.8 (2026-10-23).
# The chip this Python runs on decides, so a Terminal under Rosetta gets the Intel tools all the way through.
INTEL = platform.machine() == "x86_64"
# Windows gets faster-whisper too (no PyTorch either; platform.machine() there says "AMD64", 2026-10-23)
WIN = os.name == "nt"
FAST = INTEL or WIN
WX = PKG / ("_local/fasterwhisper-venv" if FAST else "_local/whisperx-venv")
ENGINE = "faster_whisper" if FAST else "whisperx"
MODEL = "large-v3-turbo"


def ensure_whisperx(verbose: bool = True) -> Path:
    """the free transcriber's own environment, built once into this folder: WhisperX (with PyTorch), or on an Intel
    Mac faster-whisper alone"""
    py = WX / ("Scripts/python.exe" if WIN else "bin/python")
    if py.exists() and subprocess.run([str(py), "-c", f"import {ENGINE}"], capture_output=True).returncode == 0:
        return py
    if verbose:
        print("  first time with the free transcriber: setting it up on this Mac (about 5-10 minutes, once)…", flush=True)
    import shutil
    pkg = ENGINE.replace("_", "-")
    local_uv = PKG / ("_local/bin/uv.exe" if WIN else "_local/bin/uv")
    uv = shutil.which("uv") or (str(local_uv) if local_uv.exists() else None)
    env = dict(os.environ, UV_PYTHON_INSTALL_DIR=str(PKG / "_local/python"), UV_CACHE_DIR=str(PKG / "_local/uv-cache"))
    if uv:
        subprocess.run([uv, "venv", "-q", "--python", "3.11", str(WX)], check=True, env=env)
        subprocess.run([uv, "pip", "install", "-q", "--python", str(py), pkg], check=True, env=env)
    else:
        subprocess.run([sys.executable, "-m", "venv", str(WX)], check=True)
        subprocess.run([str(py), "-m", "pip", "install", "-q", "--upgrade", "pip"], check=True)
        subprocess.run([str(py), "-m", "pip", "install", "-q", pkg], check=True)
    return py


def model_env() -> dict:
    return dict(os.environ, HF_HOME=str(PKG / "_local/models"), TORCH_HOME=str(PKG / "_local/models/torch"))      # the models stay in this folder


def prepare() -> bool:
    """install.sh: the environment and the models, so the first edit just runs"""
    py = ensure_whisperx()
    load = (f"import whisperx;whisperx.load_model('{MODEL}','cpu',compute_type='int8',language='en');"
            "whisperx.load_align_model(language_code='en',device='cpu')") if ENGINE == "whisperx" else \
           f"from faster_whisper import WhisperModel;WhisperModel('{MODEL}',device='cpu',compute_type='int8')"
    return subprocess.run([str(py), "-c", load], env=model_env(), capture_output=True).returncode == 0


def call_local(audio: Path, language: str | None, verbose: bool = True) -> dict:
    py = ensure_whisperx(verbose)
    out = audio.with_suffix(".local.json")
    env = model_env()
    cmd = [str(py), str(PKG / "helpers/transcribe_local.py"), str(audio), str(out)] + (["--language", language] if language else [])
    r = subprocess.run(cmd, env=env)
    if r.returncode or not out.exists():
        raise RuntimeError("the transcriber stopped (see above)")
    return json.loads(out.read_text())


def count_audio_tracks(video_path: Path) -> int:
    """How many audio streams the container holds."""
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "a",
         "-show_entries", "stream=index", "-of", "csv=p=0", str(video_path)],
        capture_output=True, text=True,
    )
    return len([ln for ln in out.stdout.splitlines() if ln.strip()])


def peak_dbfs(wav_path: Path) -> float:
    """Peak level of a 16-bit PCM wav, in dBFS. -inf for digital silence."""
    peak = 0
    with wave.open(str(wav_path), "rb") as w:
        # A chunk at a time: batch mode runs several of these at once, and a two-hour
        # take is 230 MB of 16 kHz mono before the array copy doubles it.
        while frames := w.readframes(1 << 16):
            samples = array.array("h", frames)
            peak = max(peak, max(samples), -min(samples))
    return 20 * math.log10(peak / 32768) if peak > 0 else float("-inf")


def extract_audio(video_path: Path, dest: Path, audio_track: int = 0) -> None:
    cmd = [
        "ffmpeg", "-y", "-i", str(video_path),
        "-map", f"0:a:{audio_track}",
        "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le",
        str(dest),
    ]
    subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def call_scribe(
    audio_path: Path,
    api_key: str,
    language: str | None = None,
    num_speakers: int | None = None,
) -> dict:
    data: dict[str, str] = {
        "model_id": "scribe_v1",
        "diarize": "true",
        "tag_audio_events": "true",
        "timestamps_granularity": "word",
    }
    if language:
        data["language_code"] = language
    if num_speakers:
        data["num_speakers"] = str(num_speakers)

    with open(audio_path, "rb") as f:
        resp = requests.post(
            SCRIBE_URL,
            headers={"xi-api-key": api_key},
            files={"file": (audio_path.name, f, "audio/wav")},
            data=data,
            timeout=1800,
        )

    if resp.status_code != 200:
        raise RuntimeError(f"Scribe returned {resp.status_code}: {resp.text[:500]}")

    return resp.json()


def transcript_path(edit_dir: Path, video: Path, audio_track: int = 0) -> Path:
    """Where a video's transcript lands.

    The track belongs in the name, or a rerun with --audio-track hands back the transcript of
    the track it is meant to replace. Track 0 keeps the plain name, so transcripts made before
    the flag existed stay valid. Batch mode tests its cache with this too — one function, so
    the two cannot drift apart.
    """
    suffix = "" if audio_track == 0 else f".track{audio_track}"
    return edit_dir / "transcripts" / f"{video.stem}{suffix}.json"


def transcribe_one(
    video: Path,
    edit_dir: Path,
    api_key: str,
    language: str | None = None,
    num_speakers: int | None = None,
    verbose: bool = True,
    audio_track: int = 0,
) -> Path:
    """Transcribe a single video. Returns path to transcript JSON.

    Cached: returns existing path immediately if the transcript already exists.
    """
    transcripts_dir = edit_dir / "transcripts"
    transcripts_dir.mkdir(parents=True, exist_ok=True)
    out_path = transcript_path(edit_dir, video, audio_track)

    if out_path.exists():
        if verbose:
            print(f"cached: {out_path.name}")
        return out_path

    if verbose:
        print(f"  extracting audio from {video.name}", flush=True)

    n_tracks = count_audio_tracks(video)
    if n_tracks > 1 and verbose:
        print(f"  note: {video.name} has {n_tracks} audio tracks, using track "
              f"{audio_track + 1} (--audio-track to change)", flush=True)

    t0 = time.time()
    with tempfile.TemporaryDirectory() as tmp:
        audio = Path(tmp) / f"{video.stem}.wav"
        extract_audio(video, audio, audio_track)

        # Uploading silence costs the same as uploading speech and returns
        # nothing, so catch the wrong-track case before paying for it.
        peak = peak_dbfs(audio)
        if peak < -60.0:
            raise RuntimeError(
                f"track {audio_track + 1} of {video.name} is silent "
                f"(peak {peak:.1f} dBFS) - not uploading. "
                + (f"The file has {n_tracks} audio tracks; try --audio-track "
                   + " or ".join(str(i) for i in range(n_tracks) if i != audio_track) + "."
                   if n_tracks > 1 else "Check the source audio.")
            )

        size_mb = audio.stat().st_size / (1024 * 1024)
        if api_key:
            if verbose:
                print(f"  uploading {video.stem}.wav ({size_mb:.1f} MB) to ElevenLabs", flush=True)
            payload = call_scribe(audio, api_key, language, num_speakers)
        else:
            if verbose:
                print("  transcribing on this Mac", flush=True)
            payload = call_local(audio, language, verbose)

    out_path.write_text(json.dumps(payload, indent=2))
    dt = time.time() - t0

    if verbose:
        kb = out_path.stat().st_size / 1024
        print(f"  saved: {out_path.name} ({kb:.1f} KB) in {dt:.1f}s")
        if isinstance(payload, dict) and "words" in payload:
            print(f"    words: {len(payload['words'])}")

    return out_path


def main() -> None:
    ap = argparse.ArgumentParser(description="Transcribe a video (ElevenLabs Scribe with a key, WhisperX on this Mac without)")
    ap.add_argument("video", type=Path, help="Path to video file")
    ap.add_argument(
        "--edit-dir",
        type=Path,
        default=None,
        help="Edit output directory (default: <video_parent>/edit)",
    )
    ap.add_argument(
        "--language",
        type=str,
        default=None,
        help="Optional ISO language code (e.g., 'en'). Omit to auto-detect.",
    )
    ap.add_argument(
        "--num-speakers",
        type=int,
        default=None,
        help="Optional number of speakers when known. Improves diarization accuracy.",
    )
    ap.add_argument("--local", action="store_true", help="Use the free on-Mac transcriber even if an ElevenLabs key is set")
    ap.add_argument(
        "--audio-track",
        type=int,
        default=0,
        help="Zero-based audio track to transcribe. OBS writes the game on track 0 "
             "and the mic on track 1; without this ffmpeg applies its default audio "
             "stream selection, which picks the track with the most channels.",
    )
    args = ap.parse_args()

    video = args.video.resolve()
    if not video.exists():
        sys.exit(f"video not found: {video}")

    edit_dir = (args.edit_dir or (video.parent / "edit")).resolve()
    api_key = "" if args.local else load_api_key()

    transcribe_one(
        video=video,
        edit_dir=edit_dir,
        api_key=api_key,
        language=args.language,
        num_speakers=args.num_speakers,
        audio_track=args.audio_track,
    )


if __name__ == "__main__":
    main()
