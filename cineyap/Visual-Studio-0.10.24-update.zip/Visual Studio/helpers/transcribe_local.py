"""The free transcriber: WhisperX on this Mac, no account and no key (2026-10-25).

Runs INSIDE the environment that transcribe.py builds on first use, never the main .venv. Apple silicon:
_local/whisperx-venv (WhisperX, which pulls in PyTorch). Intel Macs: _local/fasterwhisper-venv, faster-whisper alone,
because PyTorch stopped shipping for Intel Macs at 2.2 and WhisperX needs 2.8 (2026-10-23). Writes the same JSON shape
ElevenLabs Scribe returns (word / spacing entries with start and end), so everything after transcription reads it unchanged.

    <that venv>/bin/python helpers/transcribe_local.py <audio.wav> <out.json> [--language en] [--model large-v3]

large-v3-turbo for the words, then (WhisperX only) wav2vec2 forced alignment for each word's timing. On Intel the word
times are Whisper's own, a little looser; snap_edges.py measures every cut edge against the sound either way. Whisper tends to tidy speech
(it leaves out "um"s and the first half of a restart), and the cut needs those to find where the clean take
starts, so the prompt is written the way a person talks. snap_edges.py still measures every cut against the
real sound afterwards.
"""
from __future__ import annotations

import argparse
import json
import sys

# a prompt written verbatim nudges Whisper to keep fillers and restarts instead of cleaning them up
VERBATIM = ("Um, so, uh, I- I was gonna say, like, okay so, you know, I mean- Okay, so let me start over. "
            "So, um, the thing is, uh, yeah.")


def fill_times(words: list[dict]) -> None:
    """a few words come back without times (numbers, symbols): give them the gap their neighbours leave"""
    for i, w in enumerate(words):
        if w.get("start") is not None and w.get("end") is not None:
            continue
        prev_end = next((words[j]["end"] for j in range(i - 1, -1, -1) if words[j].get("end") is not None), 0.0)
        nxt = next((j for j in range(i + 1, len(words)) if words[j].get("start") is not None), None)
        next_start = words[nxt]["start"] if nxt is not None else prev_end + 0.3
        n = (nxt if nxt is not None else len(words)) - i
        step = max(0.05, (next_start - prev_end) / max(1, n))
        w["start"] = round(prev_end, 3)
        w["end"] = round(prev_end + step, 3)


def speech_in(audio, a: float, b: float) -> float:
    """how much of a stretch is someone talking: the share of 30 ms frames above -38 dBFS"""
    import numpy as np
    x = audio[int(a * 16000):int(b * 16000)]
    if len(x) < 480:
        return 0.0
    f = x[: len(x) // 480 * 480].reshape(-1, 480)
    rms = np.sqrt((f.astype("float64") ** 2).mean(axis=1)) + 1e-9
    return float((20 * np.log10(rms) > -38).mean())


def fill_holes(words_of, audio, raw: list[dict]) -> int:
    """THE SECOND PASS (2026-10-25). Whisper collapses repeated attempts at the same sentence: on a test take it skipped
    17 s of four restarts, and those attempts are exactly what the cut chooses between. Wherever the audio has speech
    but the transcript has no words for over a second, that stretch is transcribed again on its own and its words
    go in. Returns how many words it added."""
    dur = len(audio) / 16000
    edges = [0.0] + [x for w in raw for x in (w["start"], w["end"])] + [dur]
    holes = [(edges[i], edges[i + 1]) for i in range(0, len(edges) - 1, 2) if edges[i + 1] - edges[i] > 1.0]
    added = []
    for a, b in holes:
        if speech_in(audio, a, b) < 0.3:
            continue
        a0, b0 = max(0.0, a - 0.05), min(dur, b + 0.05)
        try:
            ws = words_of(audio[int(a0 * 16000):int(b0 * 16000)], 4)
        except Exception:
            continue
        for w in ws:
            if w.get("start") is None:
                continue
            s, e = a0 + float(w["start"]), a0 + float(w.get("end") or w["start"] + 0.2)
            if s >= a - 0.05 and e <= b + 0.05:
                added.append({**w, "start": round(s, 3), "end": round(e, 3)})
    raw.extend(added)
    raw.sort(key=lambda w: w["start"])
    return len(added)


def whisperx_words(name: str, language: str | None):
    """Apple silicon: WhisperX for the words, wav2vec2 for their times. Returns (words_of(audio, batch), load_audio)"""
    import whisperx      # here, so --help works without loading torch

    device, compute = "cpu", "int8"      # Apple Silicon: no CUDA; int8 on the CPU is the fast path
    model = whisperx.load_model(name, device, compute_type=compute, language=language,
                                asr_options={"initial_prompt": VERBATIM, "suppress_numerals": False})
    aligners = {}

    def words_of(audio, batch):
        res = model.transcribe(audio, batch_size=batch, language=language)
        lang = res.get("language") or language or "en"
        if lang not in aligners:
            aligners[lang] = whisperx.load_align_model(language_code=lang, device=device)
        am, meta = aligners[lang]
        al = whisperx.align(res["segments"], am, meta, audio, device, return_char_alignments=False)
        words_of.language = lang
        return [{"text": (w.get("word") or "").strip(), "start": w.get("start"), "end": w.get("end"), "score": w.get("score")}
                for seg in al.get("segments", []) for w in seg.get("words", []) if (w.get("word") or "").strip()]
    return words_of, whisperx.load_audio


def faster_whisper_words(name: str, language: str | None):
    """Intel Macs: faster-whisper alone (no PyTorch). Same model files, word times from Whisper itself"""
    import os
    import numpy as np
    from faster_whisper import WhisperModel, decode_audio

    model = WhisperModel(name, device="cpu", compute_type="int8", cpu_threads=os.cpu_count() or 4)

    def words_of(audio, batch):
        segs, info = model.transcribe(audio.astype(np.float32), language=language, initial_prompt=VERBATIM,
                                      word_timestamps=True, suppress_tokens=[], condition_on_previous_text=False)
        out = [{"text": w.word.strip(), "start": w.start, "end": w.end, "score": w.probability}
               for seg in segs for w in (seg.words or []) if w.word.strip()]
        words_of.language = info.language or language or "en"
        return out
    return words_of, lambda p: decode_audio(p, sampling_rate=16000)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("audio")
    ap.add_argument("out")
    ap.add_argument("--language", default=None)
    ap.add_argument("--model", default="large-v3-turbo")      # tested 2026-10-25: more accurate than large-v3 here and 3x faster
    a = ap.parse_args()

    try:
        import whisperx  # noqa: F401
        engine, make = "whisperx", whisperx_words
    except ImportError:
        engine, make = "faster-whisper", faster_whisper_words
    print(f"  loading the {a.model} model (the first time it downloads, about 3 GB)…", flush=True)
    words_of, load_audio = make(a.model, a.language)
    audio = load_audio(a.audio)
    print(f"  transcribing {len(audio) / 16000 / 60:.1f} min of audio on this Mac…", flush=True)
    raw = words_of(audio, 8)
    lang = words_of.language

    fill_times(raw)
    n = fill_holes(words_of, audio, raw)
    if n:
        print(f"  second pass: {n} words Whisper skipped (repeated attempts) put back", flush=True)

    # Scribe's shape: a word, then a spacing entry up to the next word
    words = []
    for i, w in enumerate(raw):
        s, e = round(float(w["start"]), 3), round(max(float(w["end"]), float(w["start"]) + 0.02), 3)
        words.append({"text": w["text"], "start": s, "end": e, "type": "word", "speaker_id": "speaker_0",
                      "logprob": 0.0 if w.get("score") is None else round(float(w["score"]) - 1.0, 4)})
        if i + 1 < len(raw):
            nxt = round(float(raw[i + 1]["start"]), 3)
            words.append({"text": " ", "start": e, "end": max(e, nxt), "type": "spacing", "speaker_id": "speaker_0", "logprob": 0.0})

    payload = {"language_code": lang, "language_probability": 1.0, "text": " ".join(w["text"] for w in raw),
               "words": words, "engine": f"{engine}-{a.model}", "audio_duration_secs": round(len(audio) / 16000, 3)}
    with open(a.out, "w") as f:
        json.dump(payload, f, indent=2)
    print(f"  {len(raw)} words", flush=True)


if __name__ == "__main__":
    sys.exit(main())
