@echo off
rem Start Visual Studio and open it in the browser: the Windows "Open Visual Studio" (install.sh copies this next to Visual Studio's
rem files). Already running? It just opens the page. The Studio runs hidden; its log is _local\studio.log.
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
set "PATH=%~dp0_local\bin;%~dp0_local\node;%PATH%"
set "URL=http://localhost:4747/"
curl -fs -o NUL %URL% && goto open
if not exist ".venv\Scripts\python.exe" (
  powershell -NoProfile -Command "Add-Type -AssemblyName PresentationFramework; [void][System.Windows.MessageBox]::Show(\"Visual Studio isn't set up yet.`n`nOpen this folder in the Claude app, Code tab, and type: set me up\", 'Visual Studio')"
  exit /b 1
)
if not exist _local mkdir _local
if not exist projects mkdir projects
if not exist inbox mkdir inbox
rem a hidden console, so the ffmpeg and node the Studio starts never flash a window
powershell -NoProfile -Command "Start-Process -WindowStyle Hidden -FilePath '.venv\Scripts\python.exe' -ArgumentList 'cineyap\studio.py','--no-open' -RedirectStandardOutput '_local\studio.log' -RedirectStandardError '_local\studio.err.log'"
for /l %%i in (1,1,60) do (
  curl -fs -o NUL %URL% && goto open
  timeout /t 1 /nobreak >NUL
)
:open
start "" %URL%
