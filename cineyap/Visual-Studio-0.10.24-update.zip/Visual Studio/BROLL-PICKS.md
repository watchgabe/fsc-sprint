# B-roll picks: grade a folder, pick the best moment of each take, export

The rules for turning a folder of raw takes into graded B-roll picks. This becomes a skill; every rule here is from Gabe
reviewing a real run (Mexico Sept / 001 Office, 2026-10-22).

## The job
Given a folder of takes: grade each one (log → the LUT in `config.json`), watch it, pick its best 10 seconds, and export the pick to
`<folder>/_Loop picks/<Shoot> - <what's in it> (<source clip>).mp4`. Never touch the originals.

## How to watch
- Pull graded frames at 4 a second, small, and look at them laid out one frame a second (contact sheets).
- Measure each 10 s window: shake (frame-to-frame jitter), focus, exposure, fast pans. Measurement ranks; looking decides.
- Look close (one frame a second) at every window before exporting it, and at the first, middle and last frame of every export.

## What a good pick is
- **Never looking at the camera.** Start after he looks away; if he looks at the lens mid-window, move the window.
- **Just working.** At the desk, typing, writing, thinking. No slating, walking off, reaching for the camera, phone in hand,
  adjusting gear or lights.
- **Start after the setup is done.** If he moves things around at the top of a take (a lamp, the chair), start after, so the
  room matches every other shot.
- **One of each.** Two takes of the same framing doing the same thing: keep one (the cleaner one) and say which was dropped.
- **Long takes can run longer** (15 s) when there's a good stretch of real working or talking.
- Don't end on a reach toward the camera (it's him stopping the recording).

## 🔴 NEVER a black thumbnail (absolute rule)
A black first frame or thumbnail is a no-no; it happened twice before it became a rule. The cause both times: the video track
started a frame after 0 (seeking before the input, encoder delay), so anything that shows frame 0 (Finder, Quick Look, players
opening at 0:00) shows black.
- Export with `setpts=PTS-STARTPTS` on the video, `asetpts=PTS-STARTPTS` on the audio, `-bf 0`, and no `-avoid_negative_ts`.
- After export, **verify every file**: video `start_time` is exactly 0, the first frame's average brightness is above 12/255, and
  Quick Look's own thumbnail (`qlmanage -t`) is above 12/255. Any file that fails is fixed (re-export, or move the start off a dark
  frame) before anyone is told the picks are ready.

## Export settings
- LUT: `lut3d=file='<config.json lut>'` on the full-resolution frames, then `format=yuv420p10le`.
- HEVC Main 10, `hevc_videotoolbox` 50 Mbps, `-tag:v hvc1`, AAC 192k audio, `+faststart`. Full source resolution.
