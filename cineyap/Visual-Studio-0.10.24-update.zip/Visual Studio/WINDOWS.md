# Visual Studio on Windows (first test, 2026-10-23)

Built the way Startup Mom's engine runs on Windows: everything goes through **Git Bash** (never WSL or PowerShell),
every tool is a download into the Visual Studio folder (no admin, no winget needed), and Python runs in UTF-8.
Nothing here has run on a real PC yet. This page is the tester's steps plus what to check.

## What the tester needs

- Windows 10 or 11, 64-bit, ~8 GB free
- **Git for Windows** (gitforwindows.org, the defaults). Claude Code on Windows runs its commands in Git Bash, so it's
  needed anyway. Without it, the Code tab can't run `install.sh`.
- The Claude app (claude.ai/download), signed in with Pro or Max

## Steps

1. Install Git for Windows, then the Claude app, and sign in.
2. Unzip the Visual Studio folder into `Documents` (**not OneDrive**: Windows often syncs Documents to OneDrive. If the path
   has `OneDrive` in it, use `C:\Users\<you>\Visual Studio` instead).
3. In the Claude app's Code tab, open the Visual Studio folder and type **set me up**. It downloads uv/Python, ffmpeg
   (gyan.dev) and Node into `_local\`, sets up free transcription (faster-whisper, ~5-10 min), and writes
   `Open Visual Studio.bat`.
4. Double-click **Open Visual Studio** (the .bat). The browser opens on http://localhost:4747.
5. Edit `samples\sample-16x9.mp4` first.

If Claude's commands don't seem to reach the computer (it says something installed, but the folder doesn't
change): on some PCs the Claude app runs in a container whose installs land in a private copy. Startup Mom's fix is
to have Claude hand over the lines to paste into Git Bash instead. Write what you find in `_local/machine-notes.md`.

## Test checklist (tick each, and send `report a problem` for anything that fails)

| # | Check | Expect |
|---|---|---|
| 1 | `./install.sh` finishes | Every line OK except maybe the Claude sign-in |
| 2 | `./check-setup.sh` | All good |
| 3 | Double-click Open Visual Studio | Browser opens, no black console window stays up |
| 4 | Start new video → pick the sample | A normal Windows file picker; the job starts |
| 5 | Transcription | Finishes (slower than a Mac: ~1.5 min per minute of audio) |
| 6 | Radio cut, lock, editor | Plays, edits save |
| 7 | Export video | An MP4 lands; captions look right (Helvetica shows as **Arial** on Windows) |
| 8 | Export with a LUT on (Brand → LUT) | The grade applies (a path with `C:` inside an ffmpeg filter is the risky bit) |
| 9 | Show in Explorer / reveal | Explorer opens with the file selected |
| 10 | Brand → fonts | Their installed fonts list |
| 11 | B-roll: Link your folder, Index | Clips show, index builds |
| 12 | Update button | Updates and restarts Visual Studio |
| 13 | Report a problem | A zip on the Desktop |

## Known differences

- **Slower export**: no Mac video chip, so H.264 is libx264 and ProRes is prores_ks.
- No Apple Vision: Visual Studio finds faces with OpenCV, which runs the same on Windows. (The old formats that needed
  Vision are in `legacy/`.)
- Pickers are PowerShell dialogs; paths come back to Visual Studio with forward slashes.
- All platform differences live in `cineyap/plat.py`; the installer's are behind `WIN=1` in `install.sh`.
