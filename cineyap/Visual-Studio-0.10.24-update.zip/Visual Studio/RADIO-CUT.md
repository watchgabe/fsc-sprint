# The radio cut

Lock the story by ear before anything goes on screen. No B-roll, no cards, no captions, no zooms. Only the
words, in the order that works, with the best take of each line. Graphics are decoration on a cut that
already flows. If the flow is wrong, no effect saves it, and every effect added before the lock gets
redone when the lock changes.

Trigger: "radio cut", "rough cut", `/radio-cut`, or any new raw take ("edit my video"). It runs before
every format: CineYap vertical, CineYap horizontal, and the video carousel's voiceover.

## The steps

1. **Start the job and transcribe** (package steps 2 and 3). Once per take (it's cached).
2. **Rank the takes** (step 4). Read `edit/takes_ranked.md`, never the raw transcript.
3. **Ask two things, once:** what is the one point of this video, and how long should it run? If they don't
   know the length, use the take's natural length and say so.
4. **Build the first radio cut** in `build/mkedl.py` (step 5). The editor's rules, in order:
   - **The hook lands the point in the first line.** If the best opener is buried at minute two, it moves up.
   - **One idea per line, said once.** When two lines say the same thing, keep the stronger one.
   - **Pick takes for delivery, then cleanliness.** The ranker finds the cleanest run; the person decides
     which one has the energy. Note the runner-up in `reason` so a swap is one word away.
   - **Every line earns its place.** If cutting a line loses nothing, cut it.
   - **The end is the payoff, then the ask.** Nothing after the CTA.
   - Cut on word boundaries only, never inside a word. A second tuple inside a sentence only drops a false
     start or dead air.
5. **Snap the edges and render** (steps 6 and 7): `snap_edges.py`, then `render.py` to `build/base_clean.mp4`.
6. **Make the script and the audio:**
   ```bash
   ./vu-py cineyap/radio_script.py <job> --audio
   ```
   It writes `edit/radio_cut.md` (one numbered row per line: clock, length, what is said, flags for dead
   air, filler, repeats and long lines) and `edit/radio_cut.m4a`.
7. **Show it.** In the chat, in this order:
   1. The audio link, so it plays in the side panel: `▶ [radio cut](projects/<job>/edit/radio_cut.m4a)`
   2. The table from `radio_cut.md`
   3. At most three editor's notes, each tied to a line number ("line 14 repeats line 8, I'd cut 14")
8. **Take changes by line number** and apply them in `mkedl.py`, then repeat steps 5 to 7:
   - `cut 4` drops the line
   - `move 7 after 2` reorders
   - `swap 3` uses the other take of that line (from `takes_ranked.md`)
   - `start 5 at "the"` or `end 6 after "done"` trims to a word
   - Anything else is a note: do it, say what you did in one line
   After the first pass, reply with the table only. Never re-explain the rules.
9. **Lock.** When they say "lock it" (or "flow's good", "locked"), write `edit/radio_lock.json`:
   `{"locked": "<date time>", "lines": N, "runtime_s": S, "edl_sha1": "<sha1 of edl.json>"}`. Then and
   only then does the Studio editor open on it (B-roll, captions, effects and the export happen there).

## After the lock

- The editor can still cut, trim or move a line. That keeps the lock.
- A take swap or a new line after the lock goes back here: unlock (delete `radio_lock.json`), change the cut,
  lock again. Say that out loud, because the editor's B-roll and text follow the words.
- Never add B-roll, captions or effects to a job without `edit/radio_lock.json`. If one is asked for, say the
  cut isn't locked yet and show the radio cut.

One radio cut serves every shape of the same video (16:9, 4:3, 9:16, 3:4): the editor switches between them.
