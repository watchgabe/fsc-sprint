# Grading in the Studio: the build plan (2026-10-24; phases 1 and 2 built)

Goal: grade every clip inside Loop Studio well enough that Premiere is never opened for color. Grading belongs to the
footage, not the screen (decided in `EDITOR.md`, 2026-10-23).

## How it works for Gabe

- **New video shot in log:** the take is tagged Log on the way in, gets the LUT plus an automatic white balance and
  exposure, and the radio cut already looks graded.
- **Fixing it:** Media → A-roll → click the take. The grade panel has two groups:
  - **Fix the footage** (before the LUT, in log): Temp, Tint, Exposure, Highlights, Shadows, Whites, Blacks.
  - **Shape the look** (after the LUT): LUT intensity, Contrast + pivot, Curve, Saturation, Vibrance.
  - Scopes (waveform, vectorscope) beside the video, Hold to compare, Reset.
- **Raw B-roll:** tagged Log when it's dropped in or indexed, graded the same way, with a "Graded" badge on the clip. The grade lives
  with the clip in the library, so it looks the same in every video. Already-graded clips get no LUT.
- **Matching:** Copy grade / Paste grade across clips.
- **One-off:** Inspector → Color correction still adjusts one piece on the timeline, on top of the clip's grade.
- Nothing is burned into a file: a grade is a recipe (numbers). Reset or LUT off always works.

## Why before the LUT matters

Today: LUT first, then four sliders on the finished picture (`color_vf` / `cc_vf` in `timeline_tools.py`, `ccUrl` and
the SVG filter in `editor.html`). What the LUT blew out can't come back. The new order is DaVinci's:
**log fixes → LUT → look**. Exposure in log is a clean offset; highlights roll off through the LUT instead of clipping.

## How it's built

**One grade engine, one source of truth: `cineyap/studio/grade.js`.**
A grade recipe (JSON) turns into a 3D LUT: every color goes through the log fixes, the creator's .cube (sampled with
tetrahedral interpolation), then the look. Every per-pixel operation fits in that LUT.
- **Preview:** the editor runs grade.js in the browser (a 33-point LUT builds in a few ms while a slider is dragged) and draws
  the video through it with WebGL. This replaces the SVG filter, the two-player LUT-intensity trick (`lutMix`,
  `#arollRaw`) and the baked `proxy_lut_*.mp4` copies.
- **Export:** the same grade.js runs in Node (already installed for HyperFrames) and writes a 65-point `.cube` per clip,
  applied by `lut3d=interp=tetrahedral` on the 10-bit source. One piece of maths, so the preview and the export can't drift
  apart.
- **Storage (decided in phase 2):** a grade is `{space, fix, lut_on, lut, lut_amt, exposure, contrast, saturation, warmth,
  vibrance, curve}`. The take's grade is the timeline's `COLOR` (it always was the A-roll's grade; `fix`, `space`, `vibrance`
  and `curve` are new keys, so old videos need no conversion). A B-roll clip's grade is in `cineyap/grades.json` (git-ignored,
  like the palette), keyed by the clip as the timeline names it, so it is the same in every video. `cc` stays as Just this piece.
  The recipe is built the same way in `recipe()` (editor) and `grade_recipe()` (export).
- **Log detection:** the camera's metadata first (ffprobe transfer tags, Sony / Canon / Panasonic sidecars), then how flat the
  picture is (contrast and saturation). It's always one click to flip.
- **Auto-balance on drop:** deterministic and instant (gray-world white balance, exposure to a target middle gray), so it runs on
  hundreds of library clips without a Claude call. **Auto grade** (Claude reads a frame and the scopes and sets the sliders) is a
  button.
- **Premiere:** each clip's `.cube` is written next to the XML, so the grade can follow the clip into Lumetri.

## Phases

1. **Engine + export — built 2026-10-24.** `cineyap/studio/grade.js` (browser `window.Grade`, Node `write`), and
   `timeline_tools.grade_recipe / grade_cube / grade_vf`: every A-roll piece and B-roll clip exports through one
   `lut3d=…:interp=tetrahedral`, a 65-point .cube cached in `_local/grades/` (keyed by the recipe, the LUT file and grade.js
   itself; unused for 30 days → deleted). Old `COLOR` + `cc` read as look stages unchanged, so nothing to convert on disk.
   Measured against the old filter chain on c1709 frames, 8- and 10-bit: mean 0.00-0.10/255 (p99 under 1) for the LUT, the
   sliders, B-roll scope and a clip's own color; LUT intensity 50% mean 0.17-0.56/255 (the old blend mixed in subsampled YUV,
   the new one in RGB like the preview). Log fixes decode with Sony's S-Log3 curve: a plain log offset lifted the black floor
   and went milky. Tone sliders never reverse brightness (checked on gray ramps at every extreme). Loading the 65-point cube
   costs ffmpeg ~0.35 s per piece.
2. **Panel + preview — built 2026-10-24.** `cineyap/studio/grade_view.js`: each of the 8 preview players (A-roll pair,
   cut-out pair, B-roll pair, B-roll still, B-roll cut-out) gets a WebGL canvas right after it that copies its box,
   transform, clip, opacity and object-fit every frame and draws it through a 33-point LUT from grade.js; the player itself
   is hidden (`.gvhid`) but keeps playing, so nothing else in the editor changed. The thumbnails (Screens mini preview) draw
   through `GV.paint`. Gone: the SVG `#grade` filter, `ccUrl`, `lutMix` / `#arollRaw`, `lutSource` / `makeGraded` (the A-roll
   always plays the raw proxy now). **The panel** (`gradePanel`) is in the Inspector: an A-roll piece → Color grading (the
   whole take), a B-roll clip → Color grading (this clip, every video), then Just this piece (`cc`). It has Compare (hold),
   Copy / Paste (`localStorage loop.grade`, works across videos), Reset, a waveform and a vectorscope, Footage Log / Already
   graded, Fix the footage, the LUT, Shape the look and a curve (drag, click to add, double-click to remove). The Screens
   inspector's Color grading section is gone (grading left the screens). Text-behind cut-outs are now cut from the raw take
   and drawn through the take's grade; old ones cut from the LUT copy (`-g<hash>` keys) are still used while the grade is that
   LUT at 100% with nothing fixed, after which new raw ones are cut. Measured on c1709 at the same frame: preview vs export
   mean 1.9/255 (p99 8) for a grade that moves the picture 26.5/255; most of it is the browser's and ffmpeg's YUV→RGB
   decoding differing (0.5/255 raw) and being stretched by the LUT. The 33-point LUT builds in 16 ms while dragging; drawing
   every player costs ~1 ms a frame. Not covered: Undo for a B-roll clip's grade (it saves to the library at once; Reset or
   Paste puts it back), and smoothness checked only with the pane in the background.
3. **Automatic:** log detection, LUT + auto-balance on drop and on library index, the Graded badge, Auto grade.
4. **Later (DaVinci's everyday tools):** lift / gamma / gain wheels, hue curves, skin qualifier, Match to a reference,
   saved looks.
5. **Later (the hard ones):** subject / background mask (from the existing matting), vignette, noise reduction, sharpening.

Phases 1-3 are the release that replaces Premiere for color.

## Risks

- **Text behind subject cut-outs** (handled in phase 2): cut from the raw take, drawn through the same grade. A video with an
  old LUT-copy cut-out recuts it (a few minutes) the first time the take's grade moves past "just the LUT".
- **Several players at once** (seamless cuts, B-roll, the raw take) all need the WebGL pass. Done carelessly, it makes
  playback stutter.
- **Wrong log detection** blows the picture out (the CLAUDE.md warning). Keep detection conservative, show the badge, one
  click to undo.
- **Changing the default LUT** must not re-grade finished videos. A clip's grade is pinned once it's in a video.
- **Timing with the Layers merge:** the Media "Footage: A-roll / B-roll" home is part of that batch. The engine (phase 1)
  doesn't depend on it, and the panel can open from the Inspector until Media's home exists.
- **Precision:** the browser decodes 8-bit, so the preview may band slightly in smooth skies. The export is 10-bit.

## Clip grade and piece grade (2026-10-24, Gabe: "the inspector edits it on the clip, and the media panel edits it globally")

Like Premiere's master clip and its timeline instances:
- **The clip's grade** applies under every piece of that clip in every video: a B-roll clip's in `cineyap/grades.json`, graded from
  **Media → ✎ Edit** (the clip editor's color side is now the grade panel, live through grade_view.js; nothing is baked, a trim
  still saves a new clip and that copy gets the same grade). The take's grade is `COLOR`.
- **A piece's grade** (`o.grade` on an A-roll piece or a B-roll block) sits on top, from the **Inspector**: its fixes add to the
  clip's, its look comes after, and an Input LUT or Look it picks replaces the clip's (the menu's first entry, "Clip's: …", keeps
  the clip's). On A-roll, **All clips on this track** (remembered, off by default) switches the Inspector to the take's grade.
  A B-roll piece has **Grade this clip in every video…**, which opens Media's Edit.
- `Grade.fromGrades(clip, piece)` builds the recipe in the editor and in Node; the export sends `{"grades": [clip, piece]}`.
  The old Just this piece (`cc`) reads as a piece grade and turns into `o.grade` the first time it's changed.
- Panel: Basic Correction (Input LUT, Intensity, Color: Temperature / Tint / Saturation, Light: Exposure, Contrast, Highlights,
  Shadows, Whites, Blacks), Creative (Look: a second, creative .cube at its own Intensity, Faded Film, Vibrance), Curves (white,
  red, green, blue). Scopes and the "A-roll + B-roll" look are gone (no video used it).
- ⌘Z undoes every color change: a piece's or the take's through the timeline's undo, a clip's (Media) through the side undo,
  which saves the grade before it back to the library. A LUT menu lets go of the keyboard after a pick, so ⌘Z still reaches the editor.

