"""HDR → SDR for HLG and PQ takes (an iPhone records HLG by default), shared by the A-roll page's render (helpers/render.py) and the
export (timeline_tools.py; R12, 2026-10-25: the export skipped it, so iPhone footage came out oversaturated and blown out wherever a
player honoured the HDR flags). The chain goes in front of any scale/crop/grade: it ends in 8-bit Rec.709."""
import pathlib, subprocess

HDR_TRANSFERS = {"smpte2084", "arib-std-b67"}      # PQ (HDR10) and HLG

TONEMAP_CHAIN = ("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
                 "zscale=t=bt709:m=bt709:r=tv,format=yuv420p")

def is_hdr_source(video) -> bool:
    """True when the first video stream uses a PQ or HLG transfer"""
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=color_transfer",
                              "-of", "default=noprint_wrappers=1:nokey=1", str(pathlib.Path(video))], capture_output=True, text=True, check=True)
        return out.stdout.strip() in HDR_TRANSFERS
    except (subprocess.CalledProcessError, OSError):
        return False

def sdr_vf(video, vf=""):
    """the filter chain with the tone map in front when the take is HDR, unchanged otherwise"""
    if not is_hdr_source(video): return vf
    return TONEMAP_CHAIN + ("," + vf if vf else "")
