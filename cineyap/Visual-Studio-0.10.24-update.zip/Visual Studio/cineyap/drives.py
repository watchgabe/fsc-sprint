#!/usr/bin/env python3
"""drives.py — which external drives this CineYap reads from, and whether they are plugged in.

CineYap edits files where they live. Nothing is uploaded or copied off the drive, so the B-roll library,
the LUT and the sound effects in config.json, and the raw take of each video, must be reachable while a
video is built. A drive that is unplugged mid-build does not crash anything: the builders skip a missing
B-roll clip with a NOTE. That is the danger: the draft comes out without its B-roll. So the Studio
refuses to rebuild while a drive a video needs is missing, and asks once, up front, that they know.

    ./vu-py cineyap/drives.py            # what is needed and whether it is plugged in
"""
import json, pathlib
from _root import PKG, PROJECTS
import config, plat

ACK = PKG/"_local/drive_ack.json"
WHAT = {"broll_root": "B-roll", "broll_clips": "B-roll", "lut": "LUT", "sfx_flash_overlay": "sound effects",
        "sfx_click": "sound effects"}

def volume(p):
    """the drive a path lives on (/Volumes/<name> on a Mac, D: on Windows), or None for the computer's own disk"""
    return plat.volume(p)

def job_sources(job):
    f = PROJECTS/job/"edit/edl.json"
    try: return list(json.loads(f.read_text()).get("sources", {}).values())
    except Exception: return []

def status(job=None):
    """[{name, mounted, needed_for: [...]}] for every drive config.json (and the job's take) points at"""
    vols = {}
    try: cfg = config.load()
    except SystemExit: cfg = {}
    for k, what in WHAT.items():
        v = volume(cfg.get(k) or "")
        if v: vols.setdefault(v, set()).add(what)
    for s in (job_sources(job) if job else []):
        v = volume(s)
        if v: vols.setdefault(v, set()).add("the raw take")
    return [{"name": v, "mounted": plat.volume_root(v).is_dir(), "needed_for": sorted(n)}
            for v, n in sorted(vols.items())]

def missing(job=None):
    return [d for d in status(job) if not d["mounted"]]

def acked():
    try: return bool(json.loads(ACK.read_text()).get("ok"))
    except Exception: return False

def ack():
    ACK.parent.mkdir(exist_ok=True); ACK.write_text(json.dumps({"ok": True}))

if __name__ == "__main__":
    st = status()
    if not st: print("Everything CineYap reads is on this Mac. No drive to keep connected.")
    for d in st:
        print(f"{d['name']}: {'connected' if d['mounted'] else 'NOT CONNECTED'} ({', '.join(d['needed_for'])})")
