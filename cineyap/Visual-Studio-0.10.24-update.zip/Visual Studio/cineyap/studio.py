#!/usr/bin/env python3
# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
"""studio.py — the CineYap Studio: one local page with every format and effect, every test draft, and
the Board for every video in every format.

    ./vu-py cineyap/studio.py            -> http://localhost:4747   (opens the browser)
    ./vu-py cineyap/studio.py --no-open

Local only (127.0.0.1). It is a page and not a chat widget because a page on this Mac can do what a
widget cannot: open a draft in CapCut, show a file in Finder, play your real clips, and apply a Board
Send itself instead of round-tripping through a pasted message.

Reads, never copies. The old Board, the CapCut drafts and the format builders are in legacy/ (2026-10-23):
the editor and its export replaced them.
"""
import shutil
import hashlib, json, mimetypes, os, pathlib, re, subprocess, sys, tempfile, threading, time, traceback, urllib.parse, urllib.request, uuid
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import plat
from plat import PY
from _root import PKG, PROJECTS
import config, clips, drives
import broll_index      # what is IN each B-roll clip (2026-10-22): Claude picks by content, Media searches it
import broll_import    # Media's Upload that splits sequences, and the clip editor (2026-10-22)
import edit_learn       # learns from how the creator finishes Claude's first version, with their approval (2026-10-22)

PORT = int(os.environ.get("CINEYAP_STUDIO_PORT", 4747))
WEB = PKG/"cineyap/studio"
LIB = PKG/"cineyap/library"
THUMBS = PKG/"_local/thumbs"; THUMBS.mkdir(parents=True, exist_ok=True)
RUNS = {}                                  # run id -> {"log": [...], "done": bool, "ok": bool}
BUSY = threading.Lock()                    # one rebuild at a time: they all share CapCut
def log_error(where):
    """every server error goes to _local/studio.log, which "report a problem" bundles (2026-10-24: it stayed empty, so a tester's
    crash never reached the report). Kept under ~1 MB"""
    try:
        f = PKG/"_local/studio.log"; f.parent.mkdir(exist_ok=True)
        if f.exists() and f.stat().st_size > 1_000_000: f.write_text(f.read_text(errors="replace")[-300_000:])
        with open(f, "a") as fh: fh.write(time.strftime("%Y-%m-%d %H:%M:%S ") + f"ERROR {where}\n" + traceback.format_exc() + "\n")
    except Exception: pass
NEW_FORMATS = {"vcineyap": "9:16", "cineyap43": "4:3", "cineyap": "16:9"}      # shown to the creator ("Starting a new 16:9 edit"): no internal names
# the Studio's small one-shot calls run on cheaper models (Gabe, 2026-10-22): names, rules and music picks on Haiku;
# the quick timeline chat, finding hooks and the review on Sonnet. The agent, the A-roll step and the first pass keep the default.
# (Both were lost when the old pipeline moved to legacy/ on 2026-10-23, which broke New video and those calls; restored 2026-10-24.)
MODEL_FAST, MODEL_MID = "haiku", "sonnet"

FONT_DIRS = [PKG/"fonts", PKG/"cineyap/brand_assets", plat.user_fonts_dir()] + ([pathlib.Path(os.environ.get("WINDIR", "C:/Windows"))/"Fonts"] if plat.IS_WIN
             else [pathlib.Path("/Library/Fonts"), pathlib.Path("/System/Library/Fonts")])

EXPORT_DIRS = set()
EXPORTING = {}           # job -> the export run in progress
EXPORT_LOCK = threading.Lock()
EXPORT_LOG = []          # every export this session, newest last, for the editor's export queue      # folders you picked in Export's Save window, so Play works on what landed there
def allowed(p):
    """files the page may read: the projects, the inbox, the B-roll library, fonts, brand assets, the built-in library, samples,
    exports and your export folders. Not the whole package (.env, config) and never a parent of it (R9, 2026-10-24: with the shipped
    sfx_flash_overlay of "" the list held "/", so /file served any file on the Mac). Whole folders only, never a prefix of a name."""
    p = pathlib.Path(p).resolve()
    roots = [*EXPORT_DIRS, PROJECTS, PKG/"inbox", PKG/"samples", PKG/"exports", PKG/"library", PKG/"fonts", PKG/"cineyap/library",
             PKG/"cineyap/brand_assets", PKG/"cineyap/studio", PKG/"_local/thumbs", *clips.broll_roots(), *FONT_DIRS, MUSIC_DIR, SSD_SFX]
    ov = config.opt("sfx_flash_overlay")
    if ov: roots.append(pathlib.Path(ov).parent)
    try: roots.append(broll_import.loop_dir())      # an upload's shots on the shot sheet, the clip editor's previews
    except Exception: pass
    for r in roots:
        if not r: continue
        try:
            if p.is_relative_to(pathlib.Path(r).resolve()): return True
        except Exception: pass
    return False

# ONE WRITER AT A TIME, NEVER A TORN FILE (R8, FIX-PLAN-2026-10-24 1.1): every JSON the Studio keeps is written to a .tmp
# beside it and renamed into place, so a reader (an export's load(), another tab) sees the old file or the new one, never half.
# timeline.json also takes a per-job lock around read-compare-write, so two saves can't both pass the REV check.
import collections
SAVE_LOCKS = collections.defaultdict(threading.Lock)
JOB_RE = re.compile(r"[A-Za-z0-9_-][A-Za-z0-9_.-]*")
def bad_job(job):
    """a project name that could leave projects/ (R10): anything but letters, digits, _ - and inner dots. '' is left to each handler"""
    return job is not None and not JOB_RE.fullmatch(str(job))

def unique_path(d, name):
    """a free file name in d: name, else name-2, name-3… (R7: a dropped take overwrote an earlier take with the same name)"""
    d = pathlib.Path(d); out = d/name; k = 2
    while out.exists(): out = d/f"{pathlib.Path(name).stem}-{k}{pathlib.Path(name).suffix}"; k += 1
    return out

def receive_body(rfile, n, dst):
    """copy n bytes of an upload into dst. A connection cut short used to loop at 100% CPU forever (R19): an early EOF stops it,
    the partial file goes, and the caller gets False"""
    left = n
    with open(dst, "wb") as fh:
        while left > 0:
            chunk = rfile.read(min(1 << 20, left))
            if not chunk: break
            fh.write(chunk); left -= len(chunk)
    if left > 0:
        pathlib.Path(dst).unlink(missing_ok=True); return False
    return True

def atomic_write_json(path, obj, **kw):
    path = pathlib.Path(path); tmp = path.with_name(path.name + ".tmp")
    try:
        tmp.write_text(json.dumps(obj, ensure_ascii=False, **kw)); os.replace(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)

TITLING = set()
def make_title(job):
    """a short name for the video from what's said in it (Gabe, 2026-10-20: not the camera's file name)"""
    J = PROJECTS/job; f = J/"edit/studio.json"
    try:
        st = json.loads(f.read_text())
        if st.get("title"): return
        rc = json.loads((J/"edit/radio_cut.json").read_text())
        said = " ".join(r.get("text", "") for r in rc.get("rows", [])[:12])[:1500]
        cl = claude_bin()
        if not cl or not said.strip(): return
        r = subprocess.run([cl, "--model", MODEL_FAST, "-p", "Name this talking-head video in 2 to 5 words, Title Case, plain words, no quotes, no punctuation "
                            "at the end, no colon, no em dash, US spelling. Reply with the name only.\n\nWhat is said:\n" + said,
                            "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=120)
        t = r.stdout.strip().splitlines()[-1].strip().strip('"').strip("'") if r.stdout.strip() else ""
        if r.returncode == 0 and re.fullmatch(r"[A-Za-z0-9'\u2019 ]{3,60}", t) and not limit_note(t):      # never "You've hit your limit" as a title (R21)
            st = json.loads(f.read_text()); st["title"] = t; atomic_write_json(f, st, indent=1)
    except Exception: pass
    finally: TITLING.discard(job)

def thumb_source(J):
    for p in (J/"build/base_clean.mp4", J/"edit/proxy.mp4"):
        if p.exists(): return str(p)
    return ""

def jobs():
    """every video and carousel, with its stage"""
    out = []
    for J in sorted(PROJECTS.iterdir(), key=lambda p: -p.stat().st_mtime):
        if not J.is_dir() or J.name.startswith("."): continue
        st = {}
        try: st = json.loads((J/"edit/studio.json").read_text())
        except Exception: pass
        if st:
            if st and not st.get("title") and (J/"edit/radio_cut.json").exists() and J.name not in TITLING:
                TITLING.add(J.name); threading.Thread(target=make_title, args=(J.name,), daemon=True).start()
            if st.get("kind") == "carousel":
                cs = {}
                try: cs = json.loads((J/"edit/timeline.json").read_text())
                except Exception: pass
                c0 = next((x.get("clip") for x in sorted(cs.get("BR", []), key=lambda b: b.get("t0", 0)) if x.get("clip")), "")
                out.append({"job": J.name, "kind": "carousel", "title": st.get("title") or J.name, "thumb": c0,
                            "formats": [], "stage": "edit", "slides": len(cs.get("SEGS", [])), "created": st.get("created", ""),
                            "modified": int(J.stat().st_mtime)})
                continue
            out.append({"job": J.name, "kind": "video", "modified": int(J.stat().st_mtime), "title": st.get("title") or J.name, "thumb": thumb_source(J),
                        "formats": [], "stage": st.get("stage", ""), "format": st.get("format", ""),
                        "format_name": st.get("format_name", ""), "error": st.get("error", ""), "created": st.get("created", ""),
                        "busy": any(r.get("job") == J.name and not r.get("done") for r in list(RUNS.values())),
                        "brief": (J/"edit/brief.json").exists()})      # from the New video panel: its waiting and stopped views are in the editor      # a run still going: the home page keeps checking
    return out

LIBMAP = PKG/"cineyap/library_map.json"     # how the Visuals tab shows your B-roll: hidden clips, buckets, names. Never touches the files
def libmap():
    m = json.loads(LIBMAP.read_text()) if LIBMAP.exists() else {}
    for k, v in (("hidden", []), ("moved", {}), ("renamed", {}), ("buckets", []), ("order", []), ("hidden_buckets", []), ("tags", {})): m.setdefault(k, v)
    return m

def library():
    root = config.opt("broll_clips") or config.opt("broll_root"); raw = {}; mtime = {}
    if root and pathlib.Path(root).is_dir():
        for p in sorted(pathlib.Path(root).rglob("*")):
            if p.suffix.lower() in (".mp4", ".mov") and not p.name.startswith("."):
                raw.setdefault(str(p.parent.relative_to(root)), []).append(str(p.relative_to(root)))
                try: mtime[str(p.relative_to(root))] = int(p.stat().st_mtime)      # for Media's "Newest" sort
                except OSError: pass
    m = libmap(); hid = set(m["hidden"]); lib = {}
    for folder, clips in raw.items():
        for c in clips:
            b = "Hidden" if c in hid else m["moved"].get(c) or m["renamed"].get(folder, folder)
            lib.setdefault(b, []).append(c)
    for b in m["buckets"]: lib.setdefault(b, [])      # your own buckets, after the folders
    for b in list(lib):      # a sub-bucket's parent always exists (Mexico for Mexico/Contorno)
        for k in range(1, len(b.split("/"))): lib.setdefault("/".join(b.split("/")[:k]), [])
    # your order (dragged pills): top-level buckets in m["order"] first, the rest after in their usual order; Hidden always last
    tops = []
    for b in lib:
        if b.split("/")[0] not in tops: tops.append(b.split("/")[0])
    tops = [t for t in m["order"] if t in tops] + [t for t in tops if t not in m["order"]]
    lib = {k: lib[k] for t in tops for k in sorted((k for k in lib if k == t or k.startswith(t + "/")), key=lambda k: k.count("/"))}      # parent first
    if "Hidden" in lib: lib["Hidden"] = lib.pop("Hidden")      # always last
    # Stills (2026-10-22): every picture in the library, by folder (uploads land in "Stills"). They go on the B-roll track like clips
    stills = {}
    if root and pathlib.Path(root).is_dir():
        for p in sorted(pathlib.Path(root).rglob("*")):
            if p.suffix.lower() in IMG_EXT and not p.name.startswith("."):
                stills.setdefault(str(p.parent.relative_to(root)), []).append(str(p.relative_to(root)))
    if "Stills" in stills: stills = {"Stills": stills.pop("Stills"), **stills}      # your uploads first
    return {"root": root, "folders": lib, "stills": stills, "hidden_buckets": m["hidden_buckets"], "mtime": mtime, "tags": m["tags"]}
IMG_EXT = (".jpg", ".jpeg", ".png", ".webp")

LIBMAP_LOCK = threading.Lock()      # Media's drags come quickly; two read-modify-writes at once lost one (R8)
def library_edit(b):
  with LIBMAP_LOCK:
    m = libmap(); op = b.get("op"); clips = b.get("clips", [])
    if op == "hide": m["hidden"] = sorted(set(m["hidden"]) | set(clips))
    elif op == "unhide": m["hidden"] = [c for c in m["hidden"] if c not in clips]
    elif op == "move":
        for c in clips: m["moved"][c] = b["to"]
        m["hidden"] = [c for c in m["hidden"] if c not in clips]
    elif op in ("tag", "untag"):      # your own tags on clips (Theo, Girlfriend, Mexico, New house): Loop only, the files never change
        t = re.sub(r"\s+", " ", str(b.get("tag") or "")).strip()[:40]
        if not t: raise ValueError("give the tag a name")
        t = next((x for L in m["tags"].values() for x in L if x.lower() == t.lower()), t)      # one spelling per tag
        for c in clips:
            L = [x for x in m["tags"].get(c, []) if x.lower() != t.lower()] + ([t] if op == "tag" else [])
            if L: m["tags"][c] = L
            else: m["tags"].pop(c, None)
    elif op == "newbucket":
        if b["name"] not in m["buckets"]: m["buckets"].append(b["name"])
    elif op == "order":      # the top-level pills, in the order you dragged them
        m["order"] = [str(x) for x in b.get("names", []) if x and x != "Hidden"]
    elif op == "hidebucket": m["hidden_buckets"] = sorted(set(m["hidden_buckets"]) | {b["name"]})
    elif op == "showbucket": m["hidden_buckets"] = [x for x in m["hidden_buckets"] if x != b["name"]]
    elif op == "deletebucket":      # only an empty bucket you made (folders on the drive are never touched)
        n = b["name"]; lib_ = library()["folders"]
        if any(lib_.get(k) for k in lib_ if k == n or k.startswith(n + "/")): raise ValueError("that bucket has clips: hide it instead")
        m["buckets"] = [x for x in m["buckets"] if x != n and not x.startswith(n + "/")]; m["order"] = [x for x in m["order"] if x != n]
    elif op == "nest":      # put bucket "from" (and its sub-buckets) inside "to" ("" = top level): Contorno -> Mexico/Contorno
        fr, par = b["from"], (b.get("to") or "").strip("/")
        if par == fr or par.startswith(fr + "/"): raise ValueError("a bucket can't go inside itself")
        to = (par + "/" if par else "") + fr.split("/")[-1]
        sw = lambda x: to + x[len(fr):] if x == fr or x.startswith(fr + "/") else x
        root = library()["root"]; raw = {str(p.parent.relative_to(root)) for p in pathlib.Path(root).rglob("*") if p.suffix.lower() in (".mp4", ".mov")}
        for f in raw:
            cur = m["renamed"].get(f, f)
            if sw(cur) != cur: m["renamed"][f] = sw(cur)
        m["moved"] = {c: sw(v) for c, v in m["moved"].items()}
        m["buckets"] = [sw(x) for x in m["buckets"]] + ([par] if par and par not in m["buckets"] else [])
        m["hidden_buckets"] = [sw(x) for x in m["hidden_buckets"]]; m["order"] = [x for x in m["order"] if x != fr]
    elif op == "rename":
        fr, to = b["from"], b["to"].strip()
        if not to or to == "Hidden": raise ValueError("pick another name")
        root = library()["root"]; raw = {str(p.parent.relative_to(root)) for p in pathlib.Path(root).rglob("*") if p.suffix.lower() in (".mp4", ".mov")}
        for f in raw:
            if m["renamed"].get(f, f) == fr: m["renamed"][f] = to
        m["moved"] = {c: (to if v == fr else v) for c, v in m["moved"].items()}
        m["buckets"] = [to if x == fr else x for x in m["buckets"]]
    atomic_write_json(LIBMAP, m, indent=1); return library()

# ---- the Brand tab: brand.json is the one place a creator's colors, fonts, handle and LUT live (style.py)
BRAND_FILE = PKG/"cineyap/brand.json"; BRAND_ASSETS = PKG/"cineyap/brand_assets"
NATIVE = {"dark": "#091A14", "light": "#F5F0EA", "label": "#F2F2EB", "ink": "#12130D", "text": "#FFFFFF", "accent": ""}
def brand_state():
    ex = json.loads((PKG/"cineyap/brand.example.json").read_text())
    cur = json.loads(BRAND_FILE.read_text()) if BRAND_FILE.exists() else None
    if cur is not None and not cur.get("lut"): cur = {**cur, "lut": config.opt("lut") or ""}      # the LUT lives in config.json (R5)
    fonts = []
    for d in FONT_DIRS:
        if d.exists():
            for f in sorted(d.glob("*")):
                if f.suffix.lower() in (".ttf", ".otf"): fonts.append({"name": f.stem.replace("-", " "), "path": str(f), "shipped": d == PKG/"fonts"})
    import style
    pack = style.resolve_fonts(json.loads((PKG/"cineyap/styles"/f"{config.opt('look', 'gabe')}.json").read_text())).get("capcut", {})      # a font this Mac lacks: the shipped default
    pack_fonts = {"main": os.path.expanduser(pack.get("sans_path", "")), "accent": os.path.expanduser(pack.get("serif_path", ""))}
    return {"pack_fonts": pack_fonts, "brand": cur or {"_native": True, "colors": NATIVE, "fonts": {}, "handle": "", "name": "", "lut": config.opt("lut") or ""},
            "saved": cur is not None and {k: v for k, v in cur.items() if not k.startswith("_")} != {k: v for k, v in ex.items() if not k.startswith("_")},      # the starter install.sh copies isn't "your brand" yet
            "example": ex, "presets": {"Neutral starter": ex["colors"], "FSCreative": NATIVE},
            "fonts": fonts, "lut": config.opt("lut") or ""}
# UPDATES FROM THE STUDIO (2026-10-23, Gabe: "I don't want to send this to anybody and then they don't get the updates").
# The Studio reads the feed in product.json (fscreative.live/cineyap/version.json) and, when a newer version is out, shows an
# Update button. It runs cineyap/update.py (backs up the code, keeps projects/brand/settings, re-runs install.sh), then restarts
# itself and the page reloads. A git checkout (Gabe's own copy) is never offered an update: it would overwrite work in progress.
UPDATE = {"state": "idle", "log": [], "to": ""}
_FEED = {"t": 0, "v": None}
def update_check():
    have = json.loads((PKG/"product.json").read_text()).get("version", "0")
    out = {"have": have, "state": UPDATE["state"], "log": UPDATE["log"][-6:], "dev": (PKG/".git").exists()}
    if out["dev"]: return out
    if time.time() - _FEED["t"] > 300 or _FEED["v"] is None:
        try:
            url = json.loads((PKG/"product.json").read_text()).get("update_url")
            with urllib.request.urlopen(url, timeout=4) as r: _FEED["v"] = json.loads(r.read().decode())
        except Exception: _FEED["v"] = {}
        _FEED["t"] = time.time()
    f = _FEED["v"] or {}; vt = lambda v: tuple(int(x) if x.isdigit() else 0 for x in str(v or "0").split("."))
    out.update(there=f.get("version", ""), notes=f.get("notes", ""), newer=bool(f.get("version")) and vt(f["version"]) > vt(have))
    return out

def update_start():
    if (PKG/".git").exists(): return {"error": "This is the development copy. Update it with git."}
    if UPDATE["state"] == "running": return {"ok": True}
    if any(not r.get("done", True) for r in RUNS.values()): return {"error": "Something is still building or exporting. Update when it's done."}
    UPDATE.update(state="running", log=["Downloading the new version…"])
    def go():
        r = subprocess.run([sys.executable, str(PKG/"cineyap/update.py")], cwd=PKG, capture_output=True, text=True)
        UPDATE["log"] += [l for l in (r.stdout + r.stderr).splitlines() if l.strip()][-8:]
        if r.returncode != 0: UPDATE["state"] = "failed"; return
        UPDATE["state"] = "done"; _FEED["t"] = 0
        def restart():      # the new code: the same command again, in place (the page waits and reloads)
            os.execv(sys.executable, [sys.executable] + sys.argv)
        threading.Timer(1.5, restart).start()
    threading.Thread(target=go, daemon=True).start(); return {"ok": True}

# AUTOMATIC UPDATES (Gabe, 2026-10-23: "I don't want to make them update every time"). The Studio installs a newer version by
# itself: right when it starts (nobody is working yet), and otherwise when it's idle: nothing building or exporting and no click
# for 15 minutes. It checks every 10 minutes. Open pages show "Updating…" and reload. "auto_update": false in config.json turns it off.
# RUN PERMISSIONS (a tester, 2026-10-23): update.py before 0.10.12 unpacked with zipfile, which drops them, so after an update vu,
# vu-py and every script failed with "permission denied" and the next edit stopped at transcription. On every start the Studio puts
# the run bit back on each script of the package (a .sh, or a file that starts with #!). Their work and _local are never touched.
def fix_run_bits(root=None):
    root = root or PKG
    if (root/".git").exists(): return      # the development copy: git owns its file modes
    skip = ("projects", "inbox", "samples", "_local", ".venv", ".git", "node_modules")
    n = 0
    for p in root.rglob("*"):
        try:
            rel = p.relative_to(root).parts
            if not rel or rel[0] in skip or "__pycache__" in rel or not p.is_file() or p.is_symlink() or p.stat().st_mode & 0o100: continue
            if p.suffix == ".sh" or "/Contents/MacOS/" in str(p) or (p.suffix in ("", ".py", ".command") and p.open("rb").read(2) == b"#!"):      # MacOS/ = the Open Loop Studio app
                p.chmod(p.stat().st_mode | 0o111); n += 1
        except OSError: pass
    if n: print(f"  put the run permission back on {n} script(s)", flush=True)

LAST_POST = [0.0]; STARTED = time.time()
def auto_update_loop():
    time.sleep(15)
    while True:
        try:
            if config.opt("auto_update", True) is not False and not (PKG/".git").exists():
                u = update_check(); quiet = time.time() - LAST_POST[0] > 900 or (not LAST_POST[0] and time.time() - STARTED < 600)
                busy = any(not r.get("done", True) for r in RUNS.values())
                if u.get("newer") and UPDATE["state"] == "idle" and quiet and not busy: update_start()
        except Exception: pass
        time.sleep(600)      # every 10 minutes (Gabe, 2026-10-23: a change should reach testers without anyone doing anything)

# YOUR B-ROLL FOLDER (2026-10-23, the Studio's top bar): which folder is linked, how many clips, how many Claude has looked at.
# Linking one writes broll_clips in config.json and starts indexing it in the background (broll_index: a description per shot).
def broll_folder_state():
    root = config.opt("broll_clips") or config.opt("broll_root") or ""
    p = pathlib.Path(root).expanduser() if root else None; ok = bool(p and p.is_dir())
    have = set()
    if ok:
        try: have = {c for k, v in library()["folders"].items() if k != "Hidden" for c in v}
        except Exception: have = set()
    try: done = len(have & set(broll_index.by_clip()))
    except Exception: done = 0
    return {"path": root, "name": p.name if p else "", "exists": ok, "clips": len(have), "indexed": done, "status": dict(broll_index.STATUS)}

def broll_folder_set(body):
    if body.get("choose"):
        path = plat.pick_folder("Pick the folder your B-roll clips are in").rstrip("/")
        if not path: return broll_folder_state()      # cancelled
        cfg_f = PKG/"cineyap/config.json"
        cfg = json.loads(cfg_f.read_text()) if cfg_f.exists() else {}
        cfg["broll_clips"] = path; atomic_write_json(cfg_f, cfg, indent=2)
    if body.get("choose") or body.get("index"): broll_index.start_background(library)
    return broll_folder_state()

def save_brand(b, lut_set=False):
    b = {k: v for k, v in b.items() if not k.startswith("_")}
    if not lut_set: b["lut"] = config.opt("lut") or ""        # brand.json mirrors config.json's LUT; the page's copy may be stale
    atomic_write_json(BRAND_FILE, b, indent=1)
    if lut_set and b.get("lut") is not None:           # the grade new videos start with (config.json "lut"): only when the page's LUT buttons were used
        cfg_f = config.PATH                               # (R5: brand.json starts with "lut": "", and a colour change posted it back, wiping the LUT)
        if cfg_f.exists():
            cfg = json.loads(cfg_f.read_text()); cfg["lut"] = b.get("lut") or ""; atomic_write_json(cfg_f, cfg, indent=2)
    return True

def thumb(p, t):
    try: mt = int(pathlib.Path(str(p)).stat().st_mtime)      # a clip edited in place gets new pictures
    except OSError: mt = 0
    key = hashlib.md5(f"{p}|{t}|{mt}".encode()).hexdigest(); out = THUMBS/f"{key}.jpg"
    if not out.exists():
        seek = [] if pathlib.Path(str(p)).suffix.lower() in IMG_EXT else ["-ss", f"{t:.2f}"]      # a still has no time to seek to
        subprocess.run(["ffmpeg","-v","error","-y",*seek,"-i",str(p),"-frames:v","1","-vf","scale=320:-2","-q:v","5",str(out)])
    return out

def claude_bin():
    """Claude Code on this Mac: config.json's "claude", then PATH, then the usual install spots"""
    for c in (config.opt("claude") if hasattr(config, "opt") else None, shutil.which("claude"), *map(str, plat.claude_candidates())):
        if c and pathlib.Path(c).exists(): return c
    # the copy of Claude Code inside the Claude desktop app (a tester who only has the app, 2026-10-25): the newest version
    app = sorted(pathlib.Path.home().glob("Library/Application Support/Claude/claude-code/*/*/claude.app/Contents/MacOS/claude"),
                 key=lambda p: [int(x) if x.isdigit() else 0 for x in p.parts[-6].split(".")])
    return str(app[-1]) if app else None

# IS CLAUDE SIGNED IN? (a tester, 2026-10-23: the Studio's Claude Code had never been signed in, so the A-roll cut failed halfway
# with "OAuth session expired". The Claude desktop app has its own sign-in; the Claude Code program the Studio runs needs one too.)
_AUTH = {"t": 0, "v": None}
def claude_auth(fresh=False):
    if not fresh and _AUTH["v"] and time.time() - _AUTH["t"] < 30: return _AUTH["v"]
    cl = claude_bin(); out = {"found": bool(cl), "signedIn": False, "email": ""}
    if cl:
        try:
            r = subprocess.run([cl, "auth", "status"], capture_output=True, text=True, timeout=20)
            j = json.loads(r.stdout[r.stdout.index("{"): r.stdout.rindex("}") + 1])
            out.update(signedIn=bool(j.get("loggedIn")), email=j.get("email") or "")
        except Exception: pass
    _AUTH.update(t=time.time(), v=out); return out

def claude_login():
    """claude auth login opens the browser to sign in. The Studio starts it and the page waits for the sign-in to land"""
    cl = claude_bin()
    if not cl: return {"error": "Claude Code isn't on this Mac. Install the Claude app (claude.ai/download), sign in, and open its Code tab once."}
    lf = open(PKG/"_local/claude-login.log", "w") if (PKG/"_local").is_dir() else subprocess.DEVNULL
    subprocess.Popen([cl, "auth", "login"], cwd=PKG, stdin=subprocess.DEVNULL, stdout=lf, stderr=subprocess.STDOUT,
                     **({"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if plat.IS_WIN else {"start_new_session": True}))
    _AUTH["t"] = 0; return {"ok": True}

def silent_take(path):
    """a take with no sound has nothing to cut (2026-10-23: a tester picked a silent screen recording and it failed at
    transcription with "track 1 is silent"). No audio track, or the first 90 s never louder than -50 dB: say so before starting"""
    try:
        a = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "csv=p=0", str(path)],
                           capture_output=True, text=True, timeout=20).stdout.strip()
        if not a: return True
        r = subprocess.run(["ffmpeg", "-hide_banner", "-t", "90", "-i", str(path), "-vn", "-af", "volumedetect", "-f", "null", "-"],
                           capture_output=True, text=True, timeout=60)
        m = re.search(r"max_volume:\s*(-?[\d.]+|-inf) dB", r.stderr)
        return bool(m) and (m.group(1) == "-inf" or float(m.group(1)) < -50)
    except Exception: return False      # can't tell: let the edit try

NOT_SIGNED_IN = "Studio isn't connected to Claude yet, so it can't cut your video. Click Connect Claude at the top, then Authorize on the Claude page that opens in your browser, and start the edit again."

def choose_file():
    """the Mac's own file picker, so a raw take is used where it sits (no gigabyte upload through the browser)"""
    return plat.pick_file("Pick your raw video", "movie")

def choose_files():
    """the Mac's file picker with several videos allowed (Gabe, 2026-10-25: "Start new edit" takes a batch)"""
    return plat.pick_files("Pick your raw videos (several are fine)")

def probe_video(path):
    """what a take is, so nobody has to say it: its shape (from the picture, rotation included), length, the settings that decide
    whether takes can be joined without re-encoding, and whether it looks like log footage (flat, low saturation)"""
    p = pathlib.Path(path); out = {"path": str(p), "name": p.name, "ok": p.is_file()}
    if not out["ok"]: return out
    try:
        j = json.loads(subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                                       "stream=width,height,codec_name,r_frame_rate,pix_fmt:stream_side_data=rotation:stream_tags=rotate:format=duration",
                                       "-of", "json", str(p)], capture_output=True, text=True).stdout)
        s = j["streams"][0]; w, h = int(s["width"]), int(s["height"])
        rot = abs(int(float(((s.get("side_data_list") or [{}])[0]).get("rotation", 0) or (s.get("tags") or {}).get("rotate", 0) or 0)))
        if rot in (90, 270): w, h = h, w
        d = float(j["format"]["duration"]); a = w / h
        out.update(w=w, h=h, dur=round(d, 2), sig=f"{s['codec_name']},{s['width']}x{s['height']},{s['r_frame_rate']},{s.get('pix_fmt')}",
                   shape="916" if a < .9 else "43" if a < 1.5 else "169")
        out["fmt"] = {"916": "vcineyap", "43": "cineyap43", "169": "cineyap"}[out["shape"]]
        sat, spread = [], []      # log or not: saturation and contrast of three small frames (plain Python: the server may have no numpy)
        for f in (.2, .5, .8):
            r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{d * f:.2f}", "-i", str(p), "-frames:v", "1", "-vf", "scale=96:96",
                                "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True)
            b = r.stdout
            if len(b) < 96 * 96 * 3: continue
            ss, ys = 0.0, []
            for i in range(0, 96 * 96 * 3, 3):
                R_, G_, B_ = b[i] / 255, b[i + 1] / 255, b[i + 2] / 255; mx, mn = max(R_, G_, B_), min(R_, G_, B_)
                ss += (mx - mn) / max(mx, 1e-3); ys.append(.2126 * R_ + .7152 * G_ + .0722 * B_)
            ys.sort(); sat.append(ss / (96 * 96)); spread.append(ys[int(len(ys) * .98)] - ys[int(len(ys) * .02)])
        if sat:
            out["sat"], out["spread"] = round(sum(sat) / len(sat), 3), round(sum(spread) / len(spread), 3)
            out["log"] = out["sat"] < LOG_SAT and out["spread"] < LOG_SPREAD
    except Exception as e: out["error"] = str(e)
    return out
LOG_SAT, LOG_SPREAD = .16, .70      # measured on Gabe's log takes vs graded footage (see EDITOR.md, 2026-10-25)

def start_batch(groups):
    """one project per group (Gabe, 2026-10-25): each group's takes, joined in order, become one video. Shape and LUT come from
    the footage (probe_video); they can be changed in the editor. The projects are cut one after another (NEWLOCK)"""
    runs = []
    for g in groups:
        files = [f for f in g.get("files", []) if pathlib.Path(f).is_file()]
        if not files: continue
        pr = probe_video(files[0]); lut_ok = bool(config.opt("lut")) and pathlib.Path(config.opt("lut") or "/nonexistent").exists()
        fmt = g.get("fmt") if g.get("fmt") in NEW_FORMATS else pr.get("fmt", "cineyap")
        lut = g["lut"] if isinstance(g.get("lut"), bool) else bool(pr.get("log")) and lut_ok
        runs.append(start_new(files[0], fmt, lut, takes=files, name=g.get("name") or ""))
    return runs

def set_stage(job, stage, error=""):
    if job in DELETED: return                         # never recreate a deleted project's folder
    f = PROJECTS/job/"edit/studio.json"
    try: st = json.loads(f.read_text())
    except Exception: st = {}
    st["stage"] = stage
    if error: st["error"] = error
    else: st.pop("error", None)
    f.parent.mkdir(parents=True, exist_ok=True); atomic_write_json(f, st, indent=1)

PROCS, DELETED = {}, set()     # the Claude run working on each project, so Delete can stop it

def delete_job(job):
    """Delete from the Studio: stop its Claude run, then move the folder to _archive/deleted (nothing is erased)"""
    J = PROJECTS/job
    if not job or "/" in job or job.startswith(".") or not J.is_dir(): raise RuntimeError("no such project")
    DELETED.add(job); pr = PROCS.get(job)
    if pr and pr.poll() is None:
        pr.terminate()
        try: pr.wait(timeout=10)
        except Exception: pr.kill()
    dest = PKG/"_archive/deleted"/f"{job}-{time.strftime('%Y%m%d-%H%M%S')}"
    dest.parent.mkdir(parents=True, exist_ok=True); shutil.move(str(J), str(dest))
    return str(dest)

# CLAUDE'S USAGE LIMIT, IN PLAIN WORDS (Gabe, 2026-10-23: "Claude stopped early… what's up here?" The whole log was "You've hit your
# weekly limit · resets 11am"). Whatever Claude feature it is, the message says what happened and what to do.
def limit_note(text):
    m = re.search(r"hit your ([a-z ]*?)limit(?:[^\n]*?(resets [^\n]*))?", text or "", re.I)
    if not m: return ""
    when = re.sub(r"[()]", "", m.group(2) or "").strip()
    return (f"The Claude account Studio uses has hit its {m.group(1).strip() or 'usage'} limit" + (f" ({when})" if when else "") +
            ". Nothing is wrong with your video. Try again after that, or sign Studio's Claude in to another account.")

def run_claude(job, prompt, logname, log):
    """Claude Code, headless, in this folder. The full reply goes to edit/<logname>; the last lines to the run log."""
    cl = claude_bin()
    if not cl: raise RuntimeError("Claude Code was not found on this Mac")
    out = PROJECTS/job/"edit"/logname
    with open(out, "w") as lf:
        pr = subprocess.Popen([cl, "-p", prompt, "--permission-mode", "acceptEdits",
                               "--allowedTools", "Bash,Read,Write,Edit,Glob,Grep,Skill,WebFetch"], cwd=PKG, stdout=lf, stderr=subprocess.STDOUT)
        PROCS[job] = pr
        try: rc = pr.wait(timeout=4*3600)
        finally: PROCS.pop(job, None)
    if job in DELETED: raise RuntimeError("the project was deleted")
    log.extend(out.read_text().strip().splitlines()[-3:])
    if rc: raise RuntimeError(limit_note(out.read_text()) or f"Claude stopped early (the full log is {out})")

def render_aroll(job, log):
    """the A-roll as it stands: render the cut (no captions, no B-roll) and rewrite the line list + audio"""
    vpy = str(PY)
    env = plat.utf8_env(); env["PATH"] = os.pathsep.join([str(PKG/"_local/bin"), str(PKG/"_local/node"), env.get("PATH", "")])      # what ./vu does, without bash (Windows can't run it: WinError 193)
    for args, cwd in (([vpy, str(PKG/"helpers/render.py"), f"projects/{job}/edit/edl.json", "-o", f"projects/{job}/build/base_clean.mp4"], PKG),
                      ([vpy, str(PKG/"cineyap/radio_script.py"), job, "--audio"], PKG)):
        r = subprocess.run(args, cwd=cwd, capture_output=True, text=True, env=env)
        if r.returncode: log.extend((r.stdout + r.stderr).strip().splitlines()[-6:]); raise RuntimeError("the A-roll could not be rendered")

def aroll_prompt(job, fmt, note=""):
    head = (f"This comes from the CineYap Studio (no human is watching, do not ask questions). Video `{job}`, "
            f"format {NEW_FORMATS[fmt]} (`{fmt}`). Work in this CineYap folder and follow CLAUDE.md and RADIO-CUT.md. ")
    if note:
        task = (f"The A-roll cut exists. The creator asked for this change: \"{note}\". Read edit/radio_cut.md and edit/takes_ranked.md, "
                f"start from edit/edl.json as it stands (the creator may have cut or moved lines in the Studio, so update "
                f"projects/{job}/build/mkedl.py to reproduce that order first), make the change in mkedl.py, run it, then snap the edges (RADIO-CUT.md step 5). ")
    else:
        task = (f"Write the A-roll cut ONLY (RADIO-CUT.md steps 4 and 5): pick the best take of every line, cut false starts, repeats "
                f"and dead air, one clear point, the order a listener can follow. Keep lines in the order they were said unless the "
                f"hook is buried. If the take stops before the point lands, keep what makes sense and say so. "
                f"Write projects/{job}/build/mkedl.py, run it, snap the edges. ")
    if not note: task += brief_for_claude(job, "cut")
    return (head + task + "Do NOT lock the cut, do NOT build captions, B-roll, cards or any format, do NOT render: the Studio "
            "renders the A-roll and the creator reviews it. Finish with two plain sentences: what the cut says and anything missing from the take.")

NEWLOCK = threading.Lock(); NEWQ = []      # new edits waiting their turn (the home page shows them)

# THE BRIEF (Gabe, 2026-10-23: the New video panel). What the creator said when starting a video: notes for Claude, B-roll they
# shot for it, whether to use the library, music, the style and the captions. Its own file, edit/brief.json, so nothing that
# rewrites studio.json can drop it. The A-roll cut reads the notes; the first version reads all of it.
def brief(job):
    try: return json.loads((PROJECTS/job/"edit/brief.json").read_text())
    except Exception: return {}

def brief_for_claude(job, part):
    b = brief(job); out = []
    if b.get("notes"): out.append(f"THE CREATOR'S NOTES FOR THIS VIDEO (follow them): \"{b['notes']}\"")
    if part == "first":
        if b.get("broll"):
            ix = supporting_index(job)
            out.append("SUPPORTING CLIPS the creator shot for this video. Use these FIRST, where they fit what's said; their \"clip\" is the "
                       "full path, use it as is: " + json.dumps([{"clip": c, "secs": round(probe_secs(c), 1), **({"about": ix[c]["description"], "tags": ix[c]["tags"]} if ix.get(c) else {})}
                                                                for c in b["broll"]], ensure_ascii=False))
        if b.get("library") is False: out.append("Do NOT use the B-roll library: only the supporting clips above.")
        out.append("No music: leave \"music\" out.")      # music is off for now (Gabe, 2026-10-23); a shared music library may come later
    return ("\n" + "\n".join(out) + "\n") if out else ""

# SUPPORTING FOOTAGE IS INDEXED BY ITSELF (Gabe, 2026-10-23: "they won't always index B-roll"). The clips dropped in the New video
# panel get the library's description and tags (broll_index.describe) in the background while Claude cuts the A-roll, so Layer It
# picks them by what's in them. Kept with the job (edit/supporting_index.json), never in the library's index.
def supporting_index(job):
    try: return json.loads((PROJECTS/job/"edit/supporting_index.json").read_text())
    except Exception: return {}

def index_supporting(job, clips):
    F = PROJECTS/job/"edit/supporting_index.json"; have = supporting_index(job)
    todo = [{"path": c, "rel": pathlib.Path(c).name, "folder": "Supporting", "start": 0.0, "end": None, "key": c} for c in clips if c not in have]
    if not todo: return
    try: cl = broll_index.claude_bin()
    except Exception: return
    tmp = tempfile.mkdtemp(prefix="supporting_")
    try:
        for i in range(0, len(todo), broll_index.BATCH):
            batch = todo[i:i + broll_index.BATCH]
            try: res, _ = broll_index.describe(batch, ["Supporting"], cl, tmp)
            except Exception: continue
            for u, x in zip(batch, res):
                if x: have[u["path"]] = {**broll_index.clean(x), "secs": u["end"]}
            F.write_text(json.dumps(have, indent=1, ensure_ascii=False))
    finally: shutil.rmtree(tmp, ignore_errors=True)

# NEW VIDEO B-ROLL GOES IN THE LIBRARY TOO (Gabe, 2026-10-23: "if I upload B-roll it should be the newest in the library"). Once the
# video has its name (the one typed, or Claude's from what's said), the clips are copied into <library>/<that name>/, with a fresh
# date so Newest puts them on top, and indexed like any library clip. The video keeps using its own copies; the originals are never
# moved. No library folder linked: nothing to do.
def add_to_library(job, clips, name=""):
    root = config.opt("broll_clips")
    if not clips or not root or not pathlib.Path(root).is_dir(): return
    for _ in range(240):      # up to 20 min for Claude's name (it comes right after the cut)
        if name: break
        try: st = json.loads((PROJECTS/job/"edit/studio.json").read_text())
        except Exception: st = {}
        if st.get("title") or st.get("stage") == "failed" or job in DELETED: name = st.get("title") or ""; break
        time.sleep(5)
    folder = re.sub(r"\s*[/:\\]+\s*", " - ", name or job).strip(" .") or job
    dest = pathlib.Path(root)/folder; dest.mkdir(parents=True, exist_ok=True); added = []
    for c in clips:
        src = pathlib.Path(c)
        if not src.is_file(): continue
        out = dest/src.name; n = 2
        while out.exists() and out.stat().st_size != src.stat().st_size: out = dest/f"{src.stem}_{n}{src.suffix}"; n += 1
        if out.exists(): continue      # already there (the same file again)
        try: shutil.copyfile(src, out); added.append(str(out))      # copyfile, not copy2: today's date, so it sorts newest
        except OSError: pass
    if added:
        try:
            b = brief(job); b["library_copies"] = added; (PROJECTS/job/"edit/brief.json").write_text(json.dumps(b, indent=1, ensure_ascii=False))
        except Exception: pass
        broll_index.start_background(library)      # what's in them, so search and Layer It find them

def probe_secs(p):
    try: return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                                     capture_output=True, text=True, timeout=20).stdout.strip())
    except Exception: return 0.0

def lock_cut(job):
    """lock the radio cut (edit/radio_lock.json, RADIO-CUT.md): no B-roll, captions or effects before this file exists"""
    E = PROJECTS/job/"edit"
    if not (E/"edl.json").exists(): return {"ok": False, "error": "There is no radio cut to lock yet."}
    rd = json.loads((E/"radio_cut.json").read_text()) if (E/"radio_cut.json").exists() else {}
    (E/"radio_lock.json").write_text(json.dumps({"locked": time.strftime("%Y-%m-%d %H:%M"), "lines": rd.get("lines"), "runtime_s": rd.get("runtime_s"),
        "edl_sha1": hashlib.sha1((E/"edl.json").read_bytes()).hexdigest()}, indent=1))
    set_stage(job, "locked")
    return {"ok": True, "message": "The radio cut is locked."}

def lock_for_editor(job, log):
    """what "Lock this script, open the editor" does: lock the cut, get the raw take ready (face track, waveform), stage edit"""
    r = lock_cut(job)
    if not r.get("ok"): raise RuntimeError(r.get("error", "the cut could not be locked"))
    set_stage(job, "preparing"); log.append("Getting the editor ready (face track and waveform)…")
    p = subprocess.run([str(PY), str(PKG/"cineyap/timeline_tools.py"), "prep", job], cwd=PKG, capture_output=True, text=True)
    if p.returncode: raise RuntimeError("the editor prep failed: " + (p.stderr or p.stdout)[-300:])
    set_stage(job, "edit"); log.append("Ready.")

def start_new(src, fmt, lut=False, takes=None, name="", brief_in=None, autolock=False):
    rid = uuid.uuid4().hex[:8]; nm = name or pathlib.Path(src).stem
    log = [f"Starting a new {NEW_FORMATS[fmt]} edit from {len(takes)} takes…" if takes and len(takes) > 1 else f"Starting a new {NEW_FORMATS[fmt]} edit from {pathlib.Path(src).name}…",
           ("Your LUT goes on." if lut else "No LUT set up, so this stays ungraded. Add yours in Brand." if not (config.opt("lut") and pathlib.Path(config.opt("lut")).exists())
            else "No LUT on this one.") + " Change shape or color any time in the editor."]      # never a guess about the footage (a tester shoots log and was told "already graded")
    RUNS[rid] = {"log": log, "done": False, "ok": False, "job": ""}
    q = {"run": rid, "name": nm, "files": len(takes or [src]), "fmt": fmt}; NEWQ.append(q)
    def work():
        job = ""
        try:
          with NEWLOCK:      # one new edit at a time: each runs Claude on a whole take
            if q in NEWQ: NEWQ.remove(q)
            # 1. join + transcribe + rank (cheap to rerun: transcripts are cached)
            p = subprocess.Popen([str(PY), str(PKG/"cineyap/newedit.py"), src, fmt] + ([] if lut else ["--no-lut"])
                                 + (sum((["--take", t] for t in takes), []) + ["--fresh"] if takes else []) + (["--name", re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:40]] if name else []),
                                 cwd=PKG, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in p.stdout:
                line = line.rstrip()
                m = re.match(r"New edit: (\S+) ·", line)
                if m and not job:      # the project exists from here: the editor can open now (its progress view) and the brief is kept
                    job = m.group(1); RUNS[rid]["job"] = job; DELETED.discard(job)      # a fresh project, whatever was deleted under this name (R20)
                    if brief_in is not None:
                        (PROJECTS/job/"edit").mkdir(parents=True, exist_ok=True); (PROJECTS/job/"edit/brief.json").write_text(json.dumps(brief_in, indent=1, ensure_ascii=False))
                        if brief_in.get("broll"):
                            threading.Thread(target=index_supporting, args=(job, brief_in["broll"]), daemon=True).start()      # while the cut runs
                            threading.Thread(target=add_to_library, args=(job, brief_in["broll"], name), daemon=True).start()      # into the library once it has a name
                if line.startswith("JOB: "): job = line[5:].strip(); RUNS[rid]["job"] = job
                elif line: log.append(line)
            if p.wait() or not job: raise RuntimeError("the take could not be prepared (see the lines above)")
            st = json.loads((PROJECTS/job/"edit/studio.json").read_text()); st["lut"] = bool(lut)
            (PROJECTS/job/"edit/studio.json").write_text(json.dumps(st, indent=1))
            # 2. A-roll first (Gabe, 2026-10-20): Claude writes the cut, the Studio renders it, the creator locks it
            set_stage(job, "cutting")
            log.append("Claude is cutting the A-roll. You'll review it before any captions or B-roll go on.")
            run_claude(job, aroll_prompt(job, fmt), "studio_aroll.log", log)
            render_aroll(job, log)
            if autolock:      # the New video panel: straight into the editor, which builds the first version (B-roll, captions, music)
                if not name and job not in TITLING:      # named from what's said, before the editor opens (the home page used to do it)
                    TITLING.add(job); threading.Thread(target=make_title, args=(job,), daemon=True).start()
                lock_for_editor(job, log); RUNS[rid]["ok"] = True; RUNS[rid]["editor"] = f"/static/editor.html?job={job}"
            else:
                set_stage(job, "aroll"); RUNS[rid]["ok"] = True; log.append(f"The A-roll is ready to review. Open {job} from the Studio home.")
            threading.Thread(target=warm_editor, args=(job,), daemon=True).start()
            threading.Thread(target=lambda: find_hooks(job, []), daemon=True).start()      # the other scripts (hooks you recorded), ready on the A-roll page
        except Exception as e:
            why = next((l.strip() for l in reversed(log) if re.match(r"\s*(\w+(Error|Exception)|stopped):", l)), "")      # the real cause, not "see the lines above"
            log.append(f"STOPPED: {e}")
            if job: set_stage(job, "failed", str(e).replace(" (see the lines above)", "") + ": " + why if why and "see the lines above" in str(e) else str(e))
        if job:      # the whole run, kept with the video: /report bundles it (Gabe, 2026-10-23: a tester's cut stopped and only a traceback tail showed)
            try: (PROJECTS/job/"edit/start.log").write_text("\n".join(log) + "\n")
            except Exception: pass
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

def src_info(job):
    """the take's own size and frame rate, for Sequence settings (2026-10-23): 4K is only offered when the footage is 4K.
    Cached in edit/src_info.json, next to the path it measured"""
    E = PROJECTS/job/"edit"; C = E/"src_info.json"
    try: src = list(json.loads((E/"edl.json").read_text())["sources"].values())[0]
    except Exception: return {}
    try:
        c = json.loads(C.read_text())
        if c.get("path") == src: return c
    except Exception: pass
    if not pathlib.Path(src).exists(): return {}
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate:stream_side_data=rotation",
                            "-of", "json", src], capture_output=True, text=True, timeout=20)
        v = json.loads(r.stdout)["streams"][0]; w, h = int(v["width"]), int(v["height"])
        if any(abs(int(d.get("rotation", 0) or 0)) == 90 for d in v.get("side_data_list", [])): w, h = h, w
        a, b = (v.get("r_frame_rate") or "0/1").split("/"); fps = round(float(a) / float(b or 1), 3)
        c = {"path": src, "w": w, "h": h, "fps": fps}; C.write_text(json.dumps(c)); return c
    except Exception: return {}

def aroll_model(job):
    E = PROJECTS/job/"edit"
    try: st = json.loads((E/"studio.json").read_text())
    except Exception: st = {}
    rc = json.loads((E/"radio_cut.json").read_text()) if (E/"radio_cut.json").exists() else {"rows": []}
    base = PROJECTS/job/"build/base_clean.mp4"
    try: chat = json.loads((E/"aroll_chat.json").read_text())
    except Exception: chat = []
    return {"chat": chat, "job": job, "kind": st.get("kind", "video"), "title": st.get("title") or job, "stage": st.get("stage", ""), "format": st.get("format", ""), "format_name": st.get("format_name", ""),
            "lut": st.get("lut", False), "error": st.get("error", ""), "rows": rc.get("rows", []), "runtime_s": rc.get("runtime_s"),
            "video": str(base) if base.exists() else "", "v": int(base.stat().st_mtime) if base.exists() else 0}

# ---------------------------------------------------------------- HOOKS (2026-10-21): every opening you recorded (no grading: trial reels judge them)
HOOKS_PROMPT = """You find hooks for the CineYap Studio. The creator recorded one long take and tried the OPENING of the video several times
(restarts, rewordings, different angles). Find every distinct attempt at the opening hook in the transcript below. Don't judge or
rank them: the creator tests them against each other with trial reels.

Rules:
- Only lines that were actually said. Never write or combine words that are not one contiguous stretch of the transcript.
- Each hook is ONE contiguous run of words: from the first word of that attempt to the end of the hook (usually 1-3 sentences,
  ending where the promise or setup lands, before the body starts). Give word numbers from the transcript: "a" first word,
  "b" last word, inclusive. Skip false starts that stop mid-sentence unless nothing better exists.
- Two attempts with nearly the same words are separate entries only if the delivery differs; keep the cleaner one otherwise.
- "current": true for the attempt the cut uses now (it is quoted below).
Return 2 to 8 hooks, in the order they were recorded. Reply with ONE JSON object and nothing else:
{"hooks": [{"a": int, "b": int, "current": false}]}

THE CUT'S CURRENT OPENING: "%s"

TRANSCRIPT (word number, then the words; [12.3s] marks a gap of more than a second):
%s
"""

LABELING = set()
def label_hooks(job):
    """a label of about five words per hook, saying what it is about: the versions are named "Variation N: <label>" (Gabe, 2026-10-21)"""
    try:
        f = PROJECTS/job/"edit/hooks.json"; d = json.loads(f.read_text()); H = d.get("hooks", [])
        cl = claude_bin()
        if not cl or not H: return
        prompt = ("Each line below is one hook (the opening lines of a short video). For each, write a label of about five words that says "
                  "what that hook is about, so the creator can tell the versions apart at a glance. Plain words, sentence case, no quotes, "
                  "no ending punctuation, no swearing. Reply with ONE JSON object and nothing else: {\"labels\": [\"...\", ...]} in the same order.\n\n"
                  + "\n".join(f"{i + 1}. {h['text']}" for i, h in enumerate(H)))
        r = subprocess.run([cl, "--model", MODEL_FAST, "-p", prompt, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=300)
        out = r.stdout.strip(); L = json.loads(out[out.index("{"): out.rindex("}") + 1])["labels"]
        d = json.loads(f.read_text())      # re-read: the hooks may have been found again meanwhile
        for h, lab in zip(d.get("hooks", []), L):
            if isinstance(lab, str) and lab.strip(): h["label"] = lab.strip().rstrip(".")[:60]
        f.write_text(json.dumps(d, indent=1))
    except Exception as e: print("hook labels failed:", e, flush=True)
    finally: LABELING.discard(job)

def hook_words(job):
    J = PROJECTS/job; src = list(json.loads((J/"edit/edl.json").read_text())["sources"].keys())[0]
    tr = json.loads((J/"edit/transcripts"/f"{src}.json").read_text())
    return src, [w for w in tr["words"] if w.get("type") == "word"]

def find_hooks(job, log):
    cl = claude_bin()
    if not cl: raise RuntimeError("Claude Code was not found on this Mac")
    J = PROJECTS/job; E = J/"edit"; edl = json.loads((E/"edl.json").read_text()); R = edl["ranges"]
    k = 0
    while k < len(R) and (R[k].get("beat") or "").upper() == "HOOK": k += 1
    k = k or 1
    src, W = hook_words(job)
    cur = " ".join(r.get("quote", "") for r in R[:k])
    lines, row, last = [], [], None
    for i, w in enumerate(W):
        gap = last is not None and w["start"] - last > 1.0
        if gap or not row or len(row) >= 26:      # a numbered line every ~25 words and after every pause
            if row: lines.append(" ".join(row))
            row = ([f"[{w['start']:.1f}s]"] if gap else []) + [f"#{i}"]
        row.append(w["text"]); last = w["end"]
    if row: lines.append(" ".join(row))
    log.append(f"Reading all {len(W)} words of the take for every opening you tried…")
    prompt = HOOKS_PROMPT % (cur, "\n".join(lines))
    r = subprocess.run([cl, "--model", MODEL_MID, "-p", prompt, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=900)
    out = r.stdout.strip()
    try: H = json.loads(out[out.index("{"): out.rindex("}") + 1])["hooks"]
    except Exception: raise RuntimeError("Claude answered but not with hooks: " + out[:300])
    hooks = []
    for n, h in enumerate(H, 1):
        a, b = int(h["a"]), int(h["b"])
        if not (0 <= a <= b < len(W)): continue
        prev_end = W[a - 1]["end"] if a > 0 else 0.0
        next_start = W[b + 1]["start"] if b + 1 < len(W) else W[b]["end"] + .3
        s0 = max(prev_end + .02, W[a]["start"] - .08); s1 = min(next_start - .02, W[b]["end"] + .18)
        hooks.append({"id": f"h{n}", "a": a, "b": b, "src_in": round(s0, 3), "src_out": round(s1, 3), "text": " ".join(w["text"] for w in W[a:b + 1]),
                      "current": bool(h.get("current"))})
    if not any(x["current"] for x in hooks) and hooks:      # the cut's own opening, matched by time
        c0 = R[0]["start"]
        for x in hooks:
            if abs(x["src_in"] - c0) < 1.5: x["current"] = True
    data = {"hooks": hooks, "lead": k, "source": src, "made": time.strftime("%Y-%m-%d %H:%M")}
    (E/"hooks.json").write_text(json.dumps(data, indent=1)); return data

def start_hooks(job):
    rid = uuid.uuid4().hex[:8]; log = ["Finding every hook you recorded…"]; RUNS[rid] = {"log": log, "done": False, "ok": False, "job": job}
    def work():
        try: d = find_hooks(job, log); log.append(f"Found {len(d['hooks'])} hooks."); RUNS[rid]["ok"] = True
        except Exception as e: log.append(f"STOPPED: {e}")
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

def use_hook(job, hid, log):
    """make this hook the cut's opening: it replaces the lead HOOK lines in the EDL, then the A-roll re-renders"""
    E = PROJECTS/job/"edit"; d = json.loads((E/"hooks.json").read_text()); h = next(x for x in d["hooks"] if x["id"] == hid)
    f = E/"edl.json"; edl = json.loads(f.read_text()); R = edl["ranges"]; k = int(d.get("lead", 1))
    edl["ranges"] = [{"source": d["source"], "start": h["src_in"], "end": h["src_out"], "beat": "HOOK", "quote": h["text"],
                      "reason": "hook picked in the Studio"}] + R[k:]
    edl["total_duration_s"] = round(sum(r["end"] - r["start"] for r in edl["ranges"]), 3); f.write_text(json.dumps(edl, indent=2))
    for x in d["hooks"]: x["current"] = x["id"] == hid
    d["lead"] = 1; (E/"hooks.json").write_text(json.dumps(d, indent=1))
    log.append("Rendering the A-roll with that hook…"); render_aroll(job, log)

def start_use_hook(job, hid):
    rid = uuid.uuid4().hex[:8]; log = ["Putting that hook at the front…"]; RUNS[rid] = {"log": log, "done": False, "ok": False, "job": job}
    def work():
        try: use_hook(job, hid, log); log.append("Done. The A-roll opens with that hook."); RUNS[rid]["ok"] = True
        except Exception as e: log.append(f"STOPPED: {e}")
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

def apply_order(job, order):
    """keep and reorder the cut's lines by number (1-based, play order). No Claude: the EDL is edited directly."""
    f = PROJECTS/job/"edit/edl.json"; edl = json.loads(f.read_text()); R = edl["ranges"]
    if sorted(set(order)) != sorted(order) or any(not 1 <= n <= len(R) for n in order) or not order:
        raise RuntimeError("that line order does not match the cut")
    edl["ranges"] = [R[n - 1] for n in order]
    edl["total_duration_s"] = round(sum(r["end"] - r["start"] for r in edl["ranges"]), 3)
    f.write_text(json.dumps(edl, indent=2))

def aroll_chat(job, role, text):
    """the A-roll notes as a conversation: what was asked, what Claude did (edit/aroll_chat.json)"""
    f = PROJECTS/job/"edit/aroll_chat.json"
    try: c = json.loads(f.read_text())
    except Exception: c = []
    c.append({"role": role, "text": text, "at": time.strftime("%Y-%m-%d %H:%M")}); f.write_text(json.dumps(c, indent=1))

def warm_editor(job):
    """everything the editor needs, made while the creator is still on the A-roll, so Lock opens it at once"""
    vpy, tools = str(PY), str(PKG/"cineyap/timeline_tools.py")
    subprocess.run([vpy, tools, "prep", job], cwd=PKG, capture_output=True)
    try: st = json.loads((PROJECTS/job/"edit/studio.json").read_text())
    except Exception: st = {}
    lut = config.opt("lut")
    if st.get("lut") and lut and pathlib.Path(lut).exists():
        subprocess.run([vpy, tools, "gradeproxy", job, lut], cwd=PKG, capture_output=True)

def set_lut(job, on):
    """the A-roll page's LUT switch: the A-roll re-renders with or without it, the editor follows"""
    J = PROJECTS/job; E = J/"edit"; lut = config.opt("lut") or ""
    if on and not (lut and pathlib.Path(lut).exists()): raise RuntimeError("your LUT isn't on this Mac (is SSD 2026 plugged in?)")
    st = json.loads((E/"studio.json").read_text()); st["lut"] = bool(on); atomic_write_json(E/"studio.json", st, indent=1)
    if on: shutil.copy(lut, J/"lut.cube")
    grade = (("lut3d=file='" + (J/"lut.cube").as_posix().replace(":", "\\:") + "'") if plat.IS_WIN else f"lut3d={J}/lut.cube") if on else ""      # C: in a filter needs escaping
    edl = json.loads((E/"edl.json").read_text()); edl["grade"] = grade; (E/"edl.json").write_text(json.dumps(edl, indent=2))
    mk = J/"build/mkedl.py"          # so a later re-run of the cut keeps the choice
    if mk.exists():
        import re
        t = mk.read_text(); t2 = re.sub(r'("grade"\s*:\s*)(f?"[^"]*"|\'[^\']*\'|""|None)', lambda m: m.group(1) + repr(grade).replace("'", '"'), t, count=1)
        if t2 != t: mk.write_text(t2)
    tl = E/"timeline.json"
    if tl.exists():
      with SAVE_LOCKS[job]:      # the editor may be saving this file right now (R8)
        d = json.loads(tl.read_text()); c = d.get("COLOR") or {"exposure": 0, "contrast": 1, "saturation": 1, "warmth": 0, "scope": "aroll"}
        c["lut_on"] = bool(on); c["lut"] = c.get("lut") or lut; d["COLOR"] = c; d["REV"] = int(d.get("REV", 0)) + 1; atomic_write_json(tl, d)

def start_lut(job, on):
    rid = uuid.uuid4().hex[:8]; log = [("Turning your LUT on" if on else "Turning the LUT off") + " and re-rendering the A-roll…"]
    RUNS[rid] = {"log": log, "done": False, "ok": False, "job": job}
    def work():
        try:
            set_lut(job, on); render_aroll(job, log)
            if on:
                log.append("Making the editor's graded preview in the background.")
                threading.Thread(target=warm_editor, args=(job,), daemon=True).start()
            log.append("Done."); RUNS[rid]["ok"] = True
        except Exception as e: log.append(f"STOPPED: {e}")
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

def apply_script(job, hid, body_order):
    """another script picked on the A-roll page: its hook first, then the body lines in the order kept (row numbers of
    the current cut, hook rows left out)"""
    E = PROJECTS/job/"edit"; d = json.loads((E/"hooks.json").read_text()); h = next(x for x in d["hooks"] if x["id"] == hid)
    f = E/"edl.json"; edl = json.loads(f.read_text()); R = edl["ranges"]; k = int(d.get("lead", 1))
    body = [R[n - 1] for n in body_order if k < n <= len(R)]
    edl["ranges"] = [{"source": d["source"], "start": h["src_in"], "end": h["src_out"], "beat": "HOOK", "quote": h["text"], "reason": "script picked in the Studio"}] + body
    edl["total_duration_s"] = round(sum(r["end"] - r["start"] for r in edl["ranges"]), 3); f.write_text(json.dumps(edl, indent=2))
    for x in d["hooks"]: x["current"] = x["id"] == hid
    d["lead"] = 1; (E/"hooks.json").write_text(json.dumps(d, indent=1))

def start_aroll(job, order=None, note="", lock=False, hook=None):
    """the A-roll page: apply line cuts/moves, or a note for Claude, re-render; with lock, build the format on top"""
    rid = uuid.uuid4().hex[:8]; log = []; RUNS[rid] = {"log": log, "done": False, "ok": False, "job": job}
    st = json.loads((PROJECTS/job/"edit/studio.json").read_text()); fmt = st.get("format", "cineyap"); was = st.get("stage")
    def work():
        nonlocal order
        try:
            n = len(json.loads((PROJECTS/job/"edit/edl.json").read_text())["ranges"])
            if hook:
                log.append("Putting that script's hook at the front…"); apply_script(job, hook, order or list(range(1, n + 1)))
                order = None; n = len(json.loads((PROJECTS/job/"edit/edl.json").read_text())["ranges"]); hooked = True
            else: hooked = False
            changed = (bool(order) and order != list(range(1, n + 1))) or hooked
            if changed or note:
                set_stage(job, "cutting")
                if changed and order: log.append("Applying your line changes…"); apply_order(job, order)
                if note:
                    log.append("Claude is changing the cut…"); aroll_chat(job, "you", note)
                    run_claude(job, aroll_prompt(job, fmt, note), "studio_aroll.log", log)
                    aroll_chat(job, "claude", " ".join(l.strip() for l in (PROJECTS/job/"edit/studio_aroll.log").read_text().strip().splitlines()[-3:] if l.strip()))
                log.append("Rendering the A-roll…"); render_aroll(job, log)
                set_stage(job, "edit" if was == "edit" else "aroll"); log.append("Done. The A-roll is updated.")
            if lock:
                r = lock_cut(job)
                if not r.get("ok"): raise RuntimeError(r.get("error", "the cut could not be locked"))
                # A-roll first, then the timeline editor (Gabe, 2026-10-20): no Claude build here any more. The editor
                # opens on the locked cut; B-roll, screens, captions and effects happen there.
                set_stage(job, "preparing")
                log.append("A-roll locked. Getting the raw take ready for the editor (face track and waveform)…")
                p = subprocess.run([str(PY), str(PKG/"cineyap/timeline_tools.py"), "prep", job], cwd=PKG,
                                   capture_output=True, text=True)
                if p.returncode: raise RuntimeError("the editor prep failed: " + (p.stderr or p.stdout)[-300:])
                set_stage(job, "edit"); log.append("Ready. Opening the editor.")
                RUNS[rid]["editor"] = f"/static/editor.html?job={job}"
            RUNS[rid]["ok"] = True
        except Exception as e:
            log.append(f"STOPPED: {e}"); set_stage(job, "aroll" if not lock else "failed", "" if not lock else str(e))
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

TIMELINE_CHAT = """You edit a video timeline for the CineYap Studio. The creator typed a request; change the timeline to do it.
Times are seconds on the timeline. Tracks: "segs" (the talking A-roll, in play order, each with its words), "br" (B-roll clips:
clip is a path from the library, in = seconds into the clip), "bg" (screen blocks: screen is a screen id), "screens" (caption style
per screen: font h|i|s|f, size in px at 1920 wide, v top|middle|bottom, h left|center|right, kase lower|upper|none, mode word|chars,
chars 7-80 (lines 1|2), color, bg for color screens, shadow 0-100, ls letter spacing in em, frame inset|rounded|absent, behind true|false),
"hk" (TEXT on the Text track: titles, labels, any words on screen that aren't captions. Each block {"hook": true, "v": 2, "t0", "t1",
"lines": [LAYER, ...]} is one clip holding layers (later layers draw on top). A LAYER is {"text", "st": {"font": h|i|s|f, "size" px at 1080
wide, "color", "kase" lower|upper|none, "b" false for regular weight, "it" true for italic, "ls" letter spacing em, "lh" line spacing %,
"shadow" 0-100 opacity, "sha" angle, "shd" distance, "shb" blur, "olw" outline 0-30, "olc", "box" true for a background, "boxc",
"v" top|middle|bottom, "h" left|center|right, "ox", "oy" (position nudge in px at 1080 wide; a layer's centre), "wbox" width in % of the
frame (absent = one line), "ta" align}, "hide"?, "lock"?, "g"? (same g = grouped)}. Every layer has its own place: a small line under a
title is its own layer with a larger "oy" (about the two sizes' average further down). New text copies the look and place of the
existing text unless asked otherwise; colors come from the brand palette in the screens, never invented).. Rules: blocks on one track never overlap; B-roll and screen blocks stay
inside 0..duration; prefer cutting on the A-roll's word edges; only use clips that exist in the library list, and pick them by
their "about" (what is in the shot), not their file name. "labels" are the creator's own tags (who and where: a person, a pet, a place):
trust them over "about", and use a labelled clip when the line is about that person, pet or place. A clip with "only_when" is only for a video about that (unless they ask
for it by name). B-roll clips that touch (no A-roll between) come from one "shoot", best one "seq" (one moment from several
framings), stepping wide, medium, tight, never two of the same "framing" in a row.
Reply with ONE JSON object and nothing else:
{"reply": "<one or two plain sentences saying what you changed>", "br": [...]?, "bg": [...]?, "screens": [...]?, "hk": [...]?,
 "ovr": {"<caption key>": {"text": "...", "serif": true, "hide": true}}?, "remove_ranges": [[a, b], ...]?}
Include a key only if you change it; br, bg, screens and hk are the FULL new list when present. remove_ranges ripple-deletes A-roll time
(everything after slides left). Never invent footage. If the request is unclear, change nothing and ask in "reply". Write the reply in US spelling (color, never colour).
Words on screen (a title, a label, a step name) are text boxes in "hk": do those here. If the request needs anything this schema
can't express (moving, scaling or animating the shot, animated graphics, split screens, any motion design), reply {"escalate": true} and nothing else.
"""

FIRST_PASS = """You are the CineYap Studio's editor. The creator just locked the script (the A-roll: their talking, already cut).
Make the FIRST VERSION of the edit in their style, so they only fine-tune. Times are seconds on the timeline.

You get the timeline: "segs" (the A-roll pieces in play order with their words and times), "captions", "screens" (their screen
styles: "aroll", "broll", color screens with "kind": "color" and a "bg"), "library" (their B-roll clips by bucket, each {"clip": path, "about": what is in the shot, "tags", "secs": its length, "framing": wide/medium/tight, "creative"?, "angle", "seq": the moment it belongs to}),
"music_library" (song names), "pauses", "duration" and "format" (169, 43 or 916).

Build:
1. B-ROLL over the lines that describe something you can show: an action, a place, a habit, an object, a routine. Cover roughly
   35 to 50 percent of the runtime. Never in the first 2.5 seconds (the hook stays on the face) or the last 2 seconds. Each clip
   2 to 4 seconds; start and end on a word edge (a caption start/end). Pick the clip whose "about" and "tags" show what the line says
   (a line about filming gets a shot of a camera, a line about a flight gets an airport); folder and file names are often wrong,
   so go by "about", never by the name; "labels" are the creator's own tags (a person, a pet, a place) and beat "about". A clip with "only_when" is ONLY for a video that is about that; otherwise leave it. Never use the same clip twice; vary folders; keep "in" + length inside "secs". Each: {"clip": "<path exactly as in library>", "in": 0, "t0": a, "t1": b}.
   Never a clip where someone looks, talks or smiles at the camera (BROLL-PICKS.md): B-roll is people just working, never presenting.
   A clip with "in" is one shot inside a longer file: give its br item that same "in" (where the shot starts in the file) and keep
   t1 - t0 no longer than its "secs". These count like any other clip; their "shoot" and "seq" work the same way.
   Match the clip's "shape" to the video: a 169 or 43 video takes "wide" clips (a "vertical" one would leave bars or a heavy crop).
   A 916 video takes BOTH shapes equally ("wide" ones are cropped to fill), so pick by what the shot shows, never by its shape.
   Clips that play back to back (one ends where the next starts, no A-roll between) are a run, and a run comes from ONE "shoot"
   (same "shoot" value: same place, same light, same look), like a 1-2-3 of one scene. Never cut from one shoot straight to a
   different one; put the face back in between instead. A single clip on its own can come from any shoot.
   Best of all, a run comes from ONE "seq" (one moment filmed from several framings) and steps through the framings like a scene:
   "wide" then "medium" then "tight" (or wide, tight, medium), never two of the same "framing" back to back. Where the line has a
   seq that shows it, build a run of 2 or 3 from it; a run from one shoot without a shared seq is the fallback. Vary the "angle"
   too (a "top-down" or "pov" shot is a good middle or last beat). A "creative" shot of the same seq is the play shot: last in a run.
2. COLOR SCREENS (the color screens in "screens") on 3 to 6 key moments: a number, a named step ("Week one", "Next is ideas"),
   the core promise, a punchline. 1.2 to 3 seconds each, on word edges, never overlapping B-roll you placed (a screen replaces the
   picture, so put it where there's no B-roll). Alternate the color screens. Each: {"screen": "<color screen id>", "t0", "t1"}.
   Optionally one split of two colors: add "split": "<other color id>".
3. MUSIC: one song from music_library that fits the tone, from 0 to the end: {"music": "<exact song name>"}.
4. FLASHES: 2 to 4 times where a new section starts (a new step or idea), each at the start of an A-roll piece: [seconds, ...].
5. A TITLE for the hook: the 2 to 5 most important words of the hook, US spelling, no em dashes, and where it should sit
   ("top", "middle", "bottom") so it does not cover the face.
Rules: blocks on one track never overlap; everything inside 0..duration; B-roll and screens never in the same moment.
Reply with ONE JSON object and nothing else:
{"br": [...], "bg": [...], "music": "<song name>", "flashes": [..], "title": {"text": "...", "v": "top"},
 "reply": "<two plain sentences on what you placed, US spelling, no em dashes>"}
"""

# ---- carousels (2026-10-21): slides of B-roll with Gabe's carousel type, made from pasted copy, exported one file per slide
CAR_SHAPES = {"169": (1920, 1080), "43": (1440, 1080), "34": (1080, 1440)}
CAR_HEAD = re.compile(r"^(cover|closer|slide\s*\d+)\s*:?\s*$", re.I)
def parse_slides(text):
    """COVER / SLIDE 2 / ... / CLOSER blocks (as Loop copies them): the first line is the headline, the rest the body.
    No markers: every blank-line-separated block is a slide."""
    lines = [l.rstrip() for l in (text or "").replace("\r", "").split("\n")]
    marked = any(CAR_HEAD.match(l.strip()) for l in lines)
    blocks, cur = [], None
    for l in lines:
        t = l.strip(); m = CAR_HEAD.match(t)
        if m:
            k = t.lower(); cur = {"kind": "cover" if k.startswith("cover") else "closer" if k.startswith("closer") else "point", "lines": []}
            blocks.append(cur); continue
        if not marked and not t: cur = None; continue
        if cur is None:
            if not t: continue
            cur = {"kind": "point", "lines": []}; blocks.append(cur)
        cur["lines"].append(t)
    slides = []
    for b in blocks:
        L = [x for x in b["lines"] if x]
        if not L: continue
        slides.append({"kind": b["kind"], "eyebrow": "", "head": L[0], "body": "\n".join(L[1:]), "clip": "", "in": 0, "dur": 7, "still": False})
    if slides and not marked: slides[0]["kind"] = "cover"
    if len(slides) > 2 and not any(x["kind"] == "closer" for x in slides): slides[-1]["kind"] = "closer"
    return slides

def carousel_new(body):
    """a carousel is an ordinary editor project: a silent black 'A-roll' with one piece per slide (so the editor's clock, trims,
    ripple, undo and export all work as they are), B-roll over every slide, one song across the whole thing, and each piece's
    slide text (seg.slide) drawn in the carousel type. Claude picks the B-roll and the song before the editor opens."""
    slides = parse_slides(body.get("text", ""))
    if not slides: raise ValueError("I couldn't find any slides in that text. Paste it with COVER / SLIDE 2 / ... headings, or a blank line between slides.")
    fmt = body.get("fmt") if body.get("fmt") in ("169", "43", "34") else "43"
    job = "car-" + time.strftime("%m%d-%H%M%S"); J = PROJECTS/job; E = J/"edit"; (E/"transcripts").mkdir(parents=True); DELETED.discard(job)
    room = 30.0; total = room * max(25, len(slides) + 10)       # every slide has 30 s of slate to grow into
    slate = E/"slate.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "color=c=black:s=640x360:r=24000/1001", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
                    "-t", str(total), "-c:v", "libx264", "-tune", "stillimage", "-crf", "35", "-g", "24", "-c:a", "aac", "-b:a", "32k", str(slate)], check=True)
    plat.link_or_copy(slate, E/"proxy.mp4")
    (E/"transcripts/slate.json").write_text(json.dumps({"words": [], "audio_duration_secs": total}))
    (E/"faces_src.json").write_text(json.dumps({"rate": 2, "s": []})); (E/"peaks_src.json").write_text(json.dumps({"rate": 100, "p": []}))
    ranges = [{"start": i * room, "end": i * room + 7.0} for i in range(len(slides))]
    (E/"edl.json").write_text(json.dumps({"sources": {"slate": str(slate)}, "ranges": ranges}, indent=1))
    title = " ".join(slides[0]["head"].split()[:7])
    (E/"studio.json").write_text(json.dumps({"kind": "carousel", "stage": "edit", "format": "car" + fmt, "title": title, "created": time.strftime("%Y-%m-%d %H:%M")}, indent=1))
    picks = pick_clips([{"n": i + 1, "kind": x["kind"], "text": x["head"] + " " + x["body"]} for i, x in enumerate(slides)], [])
    segs, br, t = [], [], 0.0
    for i, (x, r) in enumerate(zip(slides, ranges)):
        segs.append({"src_in": r["start"], "src_out": r["end"], "slide": {k: x[k] for k in ("kind", "eyebrow", "head", "body", "still")}})
        pk = picks["clips"].get(i + 1)
        if pk: br.append({"clip": pk["clip"], "in": pk["in"], "t0": t, "t1": t + 7.0})
        t += 7.0
    mu = []
    if picks.get("music"): m = picks["music"]; mu = [{"music": True, "file": m["file"], "name": m["name"], "dur": m.get("dur") or 30, "gain_db": -18, "in": 0, "t0": 0, "t1": t}]
    sig = ",".join(f"{r['start']:.3f}-{r['end']:.3f}" for r in ranges)
    (E/"timeline.json").write_text(json.dumps({"KIND": "carousel", "FIRST": True, "EDLSIG": sig, "FMT": fmt, "SEGS": segs, "BR": br, "BG": [], "FX": [],
                                               "MOVES": [], "MUSIC": mu, "SFX": [], "OVR": {}, "MARKERS": [], "REV": 1}, indent=1, ensure_ascii=False))
    return {"job": job}

def new_video(b):
    """the New video panel (2026-10-23): A-roll takes (maybe none), supporting B-roll, notes and settings. With takes: Claude cuts
    them (using the notes), the cut locks itself and the editor builds the first version. Without: a blank project in that shape,
    the supporting clips laid end to end on it."""
    takes = [t for t in b.get("takes") or [] if pathlib.Path(t).is_file()]
    broll = [c for c in b.get("broll") or [] if pathlib.Path(c).is_file()]
    br = {"notes": (b.get("notes") or "").strip()[:4000], "broll": broll, "library": b.get("library") is not False,
          "music": "none" if b.get("music") == "none" else "auto", "style": b.get("style") or "", "captions": b.get("captions") or "",
          "takes": takes, "shape": b.get("shape") or "", "name": b.get("name") or ""}      # the rest of the request: Try again sends it again
    if isinstance(b.get("lut"), bool): br["lut"] = b["lut"]
    if not takes:
        fmt = b.get("shape") if b.get("shape") in ("916", "169", "43") else "916"
        job = blank_new({"fmt": fmt})["job"]; E = PROJECTS/job/"edit"
        (E/"brief.json").write_text(json.dumps(br, indent=1, ensure_ascii=False))
        if broll:
            threading.Thread(target=index_supporting, args=(job, broll), daemon=True).start()
            threading.Thread(target=add_to_library, args=(job, broll, b.get("name") or "Blank project"), daemon=True).start()
        if b.get("name"):
            st = json.loads((E/"studio.json").read_text()); st["title"] = b["name"][:60]; (E/"studio.json").write_text(json.dumps(st, indent=1))
        if broll:
            tl = json.loads((E/"timeline.json").read_text()); t = 0.0
            for c in broll:
                d = min(7.0, probe_secs(c) or 7.0); tl["BR"].append({"clip": c, "in": 0, "t0": round(t, 3), "t1": round(t + d, 3)}); t += d
            tl["SEGS"] = [{"src_in": 0.0, "src_out": round(max(t, 1.0), 3)}]; tl["EDLSIG"] = ""; (E/"timeline.json").write_text(json.dumps(tl, indent=1))
        return {"job": job, "editor": f"/static/editor.html?job={job}"}
    fmt = {"916": "vcineyap", "43": "cineyap43", "169": "cineyap"}.get(b.get("shape")) or probe_video(takes[0]).get("fmt", "cineyap")
    lut_ok = bool(config.opt("lut")) and pathlib.Path(config.opt("lut") or "/nonexistent").exists()
    lut = bool(b["lut"]) and lut_ok if isinstance(b.get("lut"), bool) else bool(probe_video(takes[0]).get("log")) and lut_ok
    return {"run": start_new(takes[0], fmt, lut, takes=takes, name=b.get("name") or "", brief_in=br, autolock=True)}

def retry_job(job):
    """Try again on a stopped video (a tester, 2026-10-23: rebuilding the whole panel looked like the brief was gone). Sends the
    same takes, B-roll, notes and settings again as a new video; the stopped one moves to the archive once the new one exists"""
    J = PROJECTS/job; b = brief(job)
    try: st = json.loads((J/"edit/studio.json").read_text())
    except Exception: st = {}
    takes = [t for t in b.get("takes") or [] if pathlib.Path(t).is_file()]
    if not takes and st.get("folder"):
        takes = [str(pathlib.Path(st["folder"])/t["file"]) for t in st.get("takes") or [] if (pathlib.Path(st["folder"])/t["file"]).is_file()]
    if not takes: raise RuntimeError("Your takes aren't where they were. Is the drive plugged in? Or start a new video with them.")
    body = {"takes": takes, "broll": b.get("broll") or [], "notes": b.get("notes") or "", "library": b.get("library", True),
            "shape": b.get("shape") or "", "name": b.get("name") or ""}
    if isinstance(b.get("lut"), bool): body["lut"] = b["lut"]
    elif "lut" in st: body["lut"] = bool(st["lut"])
    r = new_video(body); rid = r["run"]
    def tidy():      # the new project exists: the stopped one goes to the archive (nothing is erased)
        for _ in range(600):
            nj = RUNS.get(rid, {}).get("job")
            if nj and nj != job:
                try: delete_job(job)
                except Exception: pass
                return
            if RUNS.get(rid, {}).get("done"): return
            time.sleep(1)
    threading.Thread(target=tidy, daemon=True).start()
    return {"run": rid}

def progress(job):
    """the editor's view while Claude makes the first cut: what's done, what's happening, the raw take to watch, the notes"""
    J = PROJECTS/job; E = J/"edit"
    try: st = json.loads((E/"studio.json").read_text())
    except Exception: st = {}
    stage = st.get("stage", "")
    run = next((r for r in reversed(list(RUNS.values())) if r.get("job") == job), None)
    have = lambda p: p.exists()
    tr, rk = have(E/"transcripts") and any((E/"transcripts").glob("*.json")), have(E/"takes_ranked.md")
    cut_done = stage in ("aroll", "preparing", "edit")
    steps = [{"label": f"Got your {len(st.get('takes') or []) or 1} take{'s' if len(st.get('takes') or []) > 1 else ''} ready", "done": bool(st)},
             {"label": "Wrote down every word, on your Mac", "done": bool(tr)},
             {"label": "Found the best try of each line" + (", using your notes" if brief(job).get("notes") else ""), "done": bool(rk)},
             {"label": "Cut the A-roll", "done": cut_done},
             {"label": "Getting the editor ready", "done": stage == "edit"}]
    cur = next((i for i, x in enumerate(steps) if not x["done"]), None)
    failed = stage == "failed" or bool(run and run.get("done") and not run.get("ok"))
    tail = []
    if failed:      # what happened just before it stopped, for the Details under the error
        try: L = (run or {}).get("log") or (E/"start.log").read_text().splitlines()
        except Exception: L = []
        tail = [l.rstrip() for l in L if l.strip()][-12:]
    return {"tail": tail, "stage": stage, "error": st.get("error", ""), "title": st.get("title", ""), "source": st.get("source", ""),
            "notes": brief(job).get("notes", ""), "steps": steps, "current": cur,
            "log": [] if failed else [l.strip() for l in (run or {}).get("log", []) if l.strip() and not l.strip().startswith((">", "[", "next:", "takes ranked", "File ", "Traceback", "^", "raise ", "self.")) and "/" not in l][-4:],
            "done": stage == "edit", "failed": failed}

def blank_new(body):
    """A BLANK PROJECT (Gabe, 2026-10-23: "a 7-second B-roll clip with a text hook"). The same trick as a carousel: a silent black
    slate stands in for the take, so the clock, trims, undo and export work as they are. One 7 s piece to start; B-roll dropped on it
    makes it longer (the editor grows the piece to the last clip), and dragging the piece's end sets the length by hand."""
    fmt = body.get("fmt") if body.get("fmt") in ("916", "169", "43") else "916"
    job = "blank-" + time.strftime("%m%d-%H%M%S"); J = PROJECTS/job; E = J/"edit"; (E/"transcripts").mkdir(parents=True); DELETED.discard(job)
    total = 600.0       # ten minutes of slate to grow into
    slate = E/"slate.mp4"
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-f", "lavfi", "-i", "color=c=black:s=640x360:r=24000/1001", "-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
                    "-t", str(total), "-c:v", "libx264", "-tune", "stillimage", "-crf", "35", "-g", "24", "-c:a", "aac", "-b:a", "32k", str(slate)], check=True)
    plat.link_or_copy(slate, E/"proxy.mp4")
    (E/"transcripts/slate.json").write_text(json.dumps({"words": [], "audio_duration_secs": total}))
    (E/"faces_src.json").write_text(json.dumps({"rate": 2, "s": []})); (E/"peaks_src.json").write_text(json.dumps({"rate": 100, "p": []}))
    (E/"edl.json").write_text(json.dumps({"sources": {"slate": str(slate)}, "ranges": [{"start": 0.0, "end": 7.0}]}, indent=1))
    (E/"studio.json").write_text(json.dumps({"kind": "blank", "stage": "edit", "format": "cineyap", "title": "Blank project",
                                             "created": time.strftime("%Y-%m-%d %H:%M")}, indent=1))
    (E/"timeline.json").write_text(json.dumps({"BLANK": True, "FIRST": True, "EDLSIG": "0.000-7.000", "FMT": fmt, "SEGS": [{"src_in": 0.0, "src_out": 7.0}],
                                               "BR": [], "BG": [], "FX": [], "MOVES": [], "MUSIC": [], "SFX": [], "OVR": {}, "MARKERS": [], "REV": 1}, indent=1))
    return {"job": job}

def with_index(state):
    """the timeline state as Claude should see it: each library clip with what is in it ("about", tags, secs) instead of a bare
    path, Hidden left out. The folder and file names are often wrong; the index (broll_index.py) is what the shot shows"""
    lib = state.get("library")
    if not isinstance(lib, dict): return state
    m = libmap(); out = {}; ix = broll_index.by_clip()
    for b, L in lib.items():
        if not ai_ok(b, m): continue
        note = bucket_note(b, m); N = [x for x in broll_index.notes(L) if not broll_index.at_camera(ix.get(x["clip"]))]      # never someone at the camera (BROLL-PICKS.md, 2026-10-24)
        if note: N = [{**x, "only_when": note} for x in N]
        out[b] = N
    LN = broll_index.long_notes(set(m.get("hidden", [])))      # the shots inside long exports (2026-10-24): about 380 more to pick from
    if LN: out["Long files"] = LN
    return {**state, "library": out}

def ai_ok(b, m=None):
    """Claude may pick from this bucket: not Hidden, and not a bucket you hid in Media (or inside one) (Gabe, 2026-10-22)"""
    m = m or libmap(); hb = m["hidden_buckets"]
    return b != "Hidden" and not any(b == h or b.startswith(h + "/") for h in hb)

def bucket_note(b, m=None):
    """the "only use this when..." rule for a bucket or its parent, from library_map.json "bucket_notes" """
    n = (m or libmap()).get("bucket_notes", {}); parts = b.split("/")
    for k in range(len(parts), 0, -1):
        if n.get("/".join(parts[:k])): return n["/".join(parts[:k])]
    return ""

def pick_clips(want, used):
    """Claude matches a B-roll clip to each slide ({n, kind, text}) and one song; returns {clips: {n: {clip, in}}, music}"""
    lib = library(); root = lib["root"] or ""; clips = [c for b, L in lib["folders"].items() if ai_ok(b) and not bucket_note(b) for c in L]
    music = media_lists().get("music", []); res = {}; cl = claude_bin()
    if cl and clips and want:
        prompt = CAR_PICK + "\nSLIDES:\n" + json.dumps([{**w, "text": w["text"][:300]} for w in want], ensure_ascii=False) + "\nMUSIC:\n" + json.dumps([m["name"] for m in music]) + "\nLIBRARY:\n" + "\n".join(json.dumps(x, ensure_ascii=False) for x in broll_index.notes(clips))
        try:
            r = subprocess.run([cl, "--model", MODEL_FAST, "-p", prompt, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=300)
            out = r.stdout.strip(); res = json.loads(out[out.index("{"): out.rindex("}") + 1])
        except Exception: res = {}
    got, seen = {}, set(used)
    for pk in res.get("picks", []):
        c = pk.get("clip", ""); n = int(pk.get("n", 0) or 0)
        if c not in clips or c in seen or not n: continue
        d = clip_dur(root + "/" + c); at = max(0.0, min(0.6, float(pk.get("at", 0.2) or 0)))
        got[n] = {"clip": c, "abs": root + "/" + c, "in": round(max(0.0, min(at * d, d - 7)) if d else 0, 2)}; seen.add(c)
    m = next((m for m in music if m["name"] == res.get("music")), None)
    return {"clips": got, "music": m}

def clip_dur(p):
    try: return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p], capture_output=True, text=True, timeout=20).stdout.strip())
    except Exception: return 0.0

CAR_PICK = """You pick B-roll for an Instagram video carousel. Each slide is a 7-second clip with white text on its LEFT third, so prefer
clips that are dark or calm on the left. Match each slide to a clip whose "about" (what is in the shot) fits what the slide says (a laptop
for work, an airport for travel, a camera for filming); the file names are often wrong, so go by "about" and "tags" ("labels", the creator's own, beat both), keep the look consistent across slides, and never use the same clip twice.
Also pick one song for the whole carousel from MUSIC (exact name), or "" if none fits.
Answer with ONLY this JSON, "clip" copied exactly from LIBRARY:
{"picks": [{"n": 1, "clip": "<path>", "at": 0.2}], "music": "<name>"}
"at" is where in the clip to start, as a fraction of its length (0 to 0.6)."""
# ---- editing rules (Gabe, 2026-10-21): plain-language rules the creator adds from the chat ("New editing rule"). Every chat, agent
# and First version prompt gets them; word swaps (fuck -> f*ck) are applied to the captions themselves by the editor and the export,
# so they never depend on Claude remembering. "client": "all" for now; per-client rules come with clients.
RULES_FILE = PKG/"cineyap/rules.json"
def rules_list():
    try: return json.loads(RULES_FILE.read_text()).get("rules", [])
    except Exception: return []
def rules_save(R): atomic_write_json(RULES_FILE, {"rules": R}, indent=1)
# Gabe's own editing rules used to ship in every package (rules.json, until 0.10.14), so testers got his "fuck -> f*ck". The file
# isn't shipped any more; on a tester's Mac his rule comes out once, by its id. Their own rules stay. (Gabe, 2026-10-23)
GABES_RULES = {"r4e7183"}
def drop_shipped_rules():
    if (PKG/".git").exists(): return      # Gabe's own copy keeps his rules
    try:
        R = rules_list(); keep = [r for r in R if r.get("id") not in GABES_RULES]
        if len(keep) != len(R): rules_save(keep)
    except Exception: pass
def rules_text():
    R = rules_list()
    return (("\nTHE CREATOR'S EDITING RULES (always follow these):\n" + "\n".join("- " + r["text"] for r in R) + "\n") if R else "") + edit_learn.prefs_text()      # + what they approved under "What I've learned"
RULE_PROMPT = """The creator of a video editor typed a standing editing rule. List any word replacements it asks for in captions and
on-screen text (lowercase "from", the replacement "to", exactly as typed). Sentence punctuation that sits inside a closing quote
is not part of the word: as "color." means "color". Reply with ONE JSON object and nothing else:
{"swaps": [{"from": "...", "to": "..."}]}

RULE: """
def rules_add(text):
    same = next((r for r in rules_list() if r["text"].strip().lower() == text.strip().lower()), None)
    if same: return same      # already a rule: no duplicate
    rule = {"text": text.strip(), "swaps": []}; cl = claude_bin()      # the text is kept exactly as typed (Gabe, 2026-10-21); Claude only finds the word swaps
    if cl:
        try:
            r = subprocess.run([cl, "--model", MODEL_FAST, "-p", RULE_PROMPT + text, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=120)
            out = r.stdout.strip(); d = json.loads(out[out.index("{"): out.rindex("}") + 1])
            rule["swaps"] = [{"from": str(w["from"]).lower(), "to": str(w["to"])} for w in d.get("swaps", []) if w.get("from") and w.get("to") is not None]
        except Exception: pass
    R = rules_list(); rule.update({"id": "r" + uuid.uuid4().hex[:6], "client": "all", "made": time.strftime("%Y-%m-%d %H:%M")}); R.append(rule); rules_save(R)
    return rule

def first_pass(body):
    """the first version after the script is locked: B-roll, color screens, music, flashes and a hook title, in seconds"""
    cl = claude_bin()
    if not cl: return {"reply": "Claude Code was not found on this Mac."}
    prompt = FIRST_PASS + rules_text() + brief_for_claude(body.get("job", ""), "first") + "\nTIMELINE:\n" + json.dumps(with_index(body.get("state", {})), ensure_ascii=False)
    r = subprocess.run([cl, "-p", prompt, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=600)
    out = r.stdout.strip()
    if limit_note(out + r.stderr): return {"reply": limit_note(out + r.stderr)}
    try: R = json.loads(out[out.index("{"): out.rindex("}") + 1])
    except Exception: return {"reply": "Claude answered but not with a first version I could use: " + out[:300]}
    R.pop("music", None)      # music is off for now (Gabe, 2026-10-23)
    # a shot inside a long file (2026-10-24): only real shots, starting where the shot starts, never running past its end
    LS = {}
    for x in broll_index.long_notes(): LS.setdefault(x["clip"], []).append(x)
    ok = []
    for o in R.get("br") or []:
        if not isinstance(o, dict) or o.get("clip") not in LS: continue
        try: i0, t0, t1 = float(o.get("in") or 0), float(o["t0"]), float(o["t1"])
        except Exception: o["clip"] = None; continue
        sh = min(LS[o["clip"]], key=lambda x: abs(x["in"] - i0))      # the shot it meant
        if abs(sh["in"] - i0) > max(1.0, sh["secs"]): o["clip"] = None; continue
        i0 = min(max(i0, sh["in"]), sh["in"] + sh["secs"] - 1.0); o["in"] = round(i0, 2)
        o["t1"] = round(min(t1, t0 + (sh["in"] + sh["secs"] - i0)), 2); ok.append(o["clip"])
    R["long_ok"] = sorted(set(ok))
    return R

# CHAT HISTORY (2026-10-26, Gabe: "there's not a way to see my old chats"). Each Chat thread is one file in
# projects/<job>/edit/chats/<id>.json: {"id", "title" (the first thing you asked), "created", "updated", "version" (the version it
# started in), "messages": [{"role": "you" | "claude", "text"}]}. Nothing here deletes a thread.
def _chat_dir(job):
    if not re.fullmatch(r"[A-Za-z0-9_-][A-Za-z0-9_.-]*", job or "") or not (PROJECTS/job).is_dir(): raise ValueError("no such video")      # never "..": stays inside projects/
    return PROJECTS/job/"edit/chats"

def chat_threads(job, tid=None):
    d = _chat_dir(job)
    if tid:
        if not re.fullmatch(r"c[0-9a-z]+", tid): raise ValueError("bad thread")
        f = d/f"{tid}.json"
        return json.loads(f.read_text()) if f.exists() else {"id": tid, "messages": []}
    out = []
    for f in d.glob("c*.json") if d.is_dir() else []:
        try: t = json.loads(f.read_text())
        except Exception: continue
        out.append({k: t.get(k) for k in ("id", "title", "created", "updated", "version")} | {"n": len(t.get("messages") or [])})
    out.sort(key=lambda t: t.get("updated") or "", reverse=True)
    return {"threads": out}

def chat_save(body):
    d = _chat_dir(body.get("job")); tid = body.get("id") or ""
    if not re.fullmatch(r"c[0-9a-z]+", tid): raise ValueError("bad thread")
    msgs = [{"role": "you" if m.get("role") == "you" else "claude", "text": str(m.get("text") or "")[:20000]}
            for m in (body.get("messages") or []) if str(m.get("text") or "").strip()]
    if not msgs: return {"ok": True, "skipped": "empty"}
    d.mkdir(parents=True, exist_ok=True); f = d/f"{tid}.json"
    old = json.loads(f.read_text()) if f.exists() else {}
    now = time.strftime("%Y-%m-%d %H:%M:%S")      # to the second, so newest-first holds within a minute
    t = {"id": tid, "title": old.get("title") or next((m["text"] for m in msgs if m["role"] == "you"), msgs[0]["text"])[:80],
         "created": old.get("created") or now, "updated": now, "version": old.get("version") or body.get("version") or "", "messages": msgs}
    tmp = f.with_suffix(".json.tmp"); tmp.write_text(json.dumps(t, indent=1, ensure_ascii=False)); tmp.replace(f)
    return {"ok": True, "thread": {k: t[k] for k in ("id", "title", "created", "updated", "version")}}

# MADE FOR THIS VIDEO (2026-10-26, Gabe deleted an effect and thought it was gone): every effect Claude rendered for a job is a
# .webm in projects/<job>/fx/, kept there whether or not it's on the timeline. Named from the FX entry that used it (the current
# timeline, its history, Claude's patch), renders of one effect (-v2, -v3) grouped with the newest on top. Read only: nothing moves.
_FXDUR = {}
def job_fx(job):
    J = PROJECTS/_chat_dir(job).parent.parent.name; d = J/"fx"
    if not d.is_dir(): return {"effects": []}
    used = {}      # file -> the FX entry that used it, newest source last so it wins
    srcs = sorted((J/"edit/timeline_history").glob("*.json"), key=lambda p: p.stat().st_mtime) + [J/"edit/timeline_patch.json", J/"edit/timeline.json"]
    for f in srcs:
        try: st = json.loads(f.read_text())
        except Exception: continue
        lists = [st.get("FX"), st.get("fx")] + [((v.get("data") or {}).get("FX")) for v in (st.get("VARS") or []) if isinstance(v, dict)]
        for L in lists:
            for o in L or []:
                if isinstance(o, dict) and str(o.get("file", "")).startswith(str(d)):
                    mv = [m for m in (st.get("MOVES") or []) if o.get("link") and isinstance(m, dict) and m.get("link") == o["link"]]
                    used[o["file"]] = o | {"_moves": [{"dt0": m["t0"] - o["t0"], "dt1": m["t1"] - o["t0"], **{k: m.get(k) for k in ("x", "y", "s", "ramp")}} for m in mv]}
    groups = {}
    for p in d.glob("*.webm"):
        if p.name.startswith("."): continue
        base = re.sub(r"-v(\d+)$", "", p.stem); v = int(re.search(r"-v(\d+)$", p.stem).group(1)) if re.search(r"-v(\d+)$", p.stem) else 1
        o = used.get(str(p), {}); key = (str(p), p.stat().st_mtime)
        if key not in _FXDUR:
            r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)], capture_output=True, text=True)
            try: _FXDUR[key] = float(r.stdout.strip())
            except ValueError: _FXDUR[key] = 0.0
        dur = round(float(o["t1"]) - float(o["t0"]), 3) if o.get("t1") is not None and o.get("t0") is not None else round(_FXDUR[key], 3)
        groups.setdefault(base, []).append({"file": str(p), "v": v, "name": o.get("name") or base.replace("-", " ").strip().capitalize(),
            "id": o.get("id") or base, "fmt": o.get("fmt") or "", "hide_captions": o.get("hide_captions", True), "dur": dur,
            "entry": {k: v for k, v in o.items() if k not in ("t0", "t1", "link", "saved", "_moves")}, "moves": o.get("_moves") or [],
            "made": time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime)), "mtime": p.stat().st_mtime})
    out = []
    for base, vs in groups.items():
        vs.sort(key=lambda x: (x["v"], x["mtime"]), reverse=True)
        named = next((x["name"] for x in vs if used.get(x["file"], {}).get("name")), vs[0]["name"])
        out.append({"key": base, "name": named, "newest": max(x["mtime"] for x in vs), "versions": vs})
    out.sort(key=lambda g: g["newest"], reverse=True)
    return {"effects": out}

def timeline_chat(body):
    cl = claude_bin()
    if not cl: return {"reply": "Claude Code was not found on this Mac."}
    prompt = TIMELINE_CHAT + rules_text() + "\nREQUEST: " + body.get("message", "") + "\nTIMELINE:\n" + json.dumps(with_index(body.get("state", {})), ensure_ascii=False)
    r = subprocess.run([cl, "--model", MODEL_MID, "-p", prompt, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=300)
    out = r.stdout.strip()
    if limit_note(out + r.stderr): return {"reply": limit_note(out + r.stderr)}
    try: return json.loads(out[out.index("{"): out.rindex("}") + 1])
    except Exception: return {"reply": "Claude answered but not with an edit I could apply: " + out[:400]}

BRAIN = pathlib.Path.home()/"iCloud Drive (Archive)/Desktop/Claude Code/Gabe's Ai Brain"
def agent_prompt(job, message):
    J = PROJECTS/job
    return f"""You are the CineYap Studio's editing agent. No human is watching this run: do not ask questions, do not open previews
or wait for approval (the creator reviews your work on the timeline and can undo it). Work fast.

The creator asked: "{message}"

The current timeline is {J}/edit/timeline_state.json. Times are seconds on the timeline. Keys: duration, playhead, segs (the A-roll
in play order with its words), captions, br (B-roll), bg (screen blocks), screens (caption style per screen), moves, fx, library.

What you can change, all as blocks on the timeline:
- br, bg, screens, ovr, remove_ranges: same meaning as the state file (remove_ranges ripple-deletes A-roll time).
- hk: "hk" (TEXT on the Text track: titles, labels, any words on screen that aren't captions. Each block {{"hook": true, "v": 2, "t0", "t1",
"lines": [LAYER, ...]}} is one clip holding layers (later layers draw on top). A LAYER is {{"text", "st": {{"font": h|i|s|f, "size" px at 1080
wide, "color", "kase" lower|upper|none, "b" false for regular weight, "it" true for italic, "ls" letter spacing em, "lh" line spacing %,
"shadow" 0-100 opacity, "sha" angle, "shd" distance, "shb" blur, "olw" outline 0-30, "olc", "box" true for a background, "boxc",
"v" top|middle|bottom, "h" left|center|right, "ox", "oy" (position nudge in px at 1080 wide; a layer's centre), "wbox" width in % of the
frame (absent = one line), "ta" align}}, "hide"?, "lock"?, "g"? (same g = grouped)}}. Every layer has its own place: a small line under a
title is its own layer with a larger "oy" (about the two sizes' average further down). New text copies the look and place of the
existing text unless asked otherwise; colors come from the brand palette in the screens, never invented).
  Plain words on screen are text boxes, not fx: use fx only for animated graphics.
- moves: shot moves on the A-roll. [{{"t0","t1","x","y","s","ramp"}}]. x and y shift the shot in percent of the frame (x -25 puts
  a centered subject in the middle of the left half), s is scale (1 = as shot), ramp is seconds of eased animation in and out.
- fx: graphics over the video. Build each one with HyperFrames (read ~/.claude/skills/hyperframes/SKILL.md, hyperframes-core/SKILL.md and hyperframes-cli/SKILL.md first):
  a composition at the video's canvas size (1920x1080 unless the format says otherwise) with a TRANSPARENT background, its duration exactly the block length, in {J}/fx/<id>/. Run
  `npx hyperframes lint`, then render with `npx hyperframes render --format webm --quality looks --output {J}/fx/<id>.webm`.
  A cut-out of the creator (`hyperframes remove-background`, for anything that goes BEHIND them) must match the A-roll it sits on:
  right after making it, and before the render, run `{PKG}/vu-py {PKG}/cineyap/fix_cutout.py <cutout.webm> <the clip it was cut from>`.
  Without it the cut-out comes out about 5% darker and the creator visibly dims the moment the effect starts.
  Confirm the file exists, then CHECK YOUR WORDS: grab a frame where the text is fully on screen
  (`ffmpeg -c:v libvpx-vp9 -ss <t> -i <file> -frames:v 1 check.png`), look at it, and make sure every word, hyphen and
  apostrophe rendered. Fix and re-render if not. Skip the preview and approval steps of the skill: the Studio timeline is
  the review. While an effect is up the Studio hides the running captions (set "hide_captions": false on the block to keep
  them). Effects and shot moves must suit the video's shape: the state's "format" is 169, 43 or 916 (vertical 1080x1920),
  so build the composition at that canvas size.
  Style: follow {BRAIN}/Operations/Video-Text-Style.md (Helvetica Bold with tight negative tracking, Instrument Serif italic accents,
  green #091A14, cream #F5F0EA, text on cream is green). Animate in Gabe's restrained way: eased slides and fades, nothing bouncy.
  Any words on screen follow {BRAIN}/Operations/Writing-Standards.md and use US spelling.

The state's "selected" is the block the creator has selected on the timeline ({{"track","index","block"}}), or null. When the
request says "this", "the selected effect" or similar, it means that block. To CHANGE an existing effect: its composition is in
{J}/fx/<its id>/ (find it from the block's "file"); edit that composition, render to a NEW file ({J}/fx/<id>-v2.webm, -v3, ...) so
Cmd+Z can go back to the old one, and return the full fx list with that block's "file" pointing at the new render (same t0/t1
unless asked). If the composition folder is missing, rebuild the effect from scratch to match what was asked.
The state's "refs" are screenshots the creator pasted as references: open each one with the Read tool and match its look (layout,
type, color, motion feel) within Gabe's style rules below. Links in the request are references too: fetch them if you can.
To build a NEW SCREEN (caption style per shot type), add it to "screens" (copy an existing screen's keys, new "id" and "name",
"placed": true for A-roll/B-roll kinds) and return the full screens list; fonts are limited to h|i|s|f.

When done, write {J}/edit/timeline_patch.json:
{{"reply": "<one or two plain sentences, US spelling, no em dashes>", "br"?, "bg"?, "screens"?, "hk"?, "ovr"?, "remove_ranges"?,
  "moves"?: [...each with "fmt": "<the state's format>"], "fx"?: [{{"id","name","file": "<absolute path to the .webm>","t0","t1","in": 0,
  "hide_captions": true,"fmt": "<the state's format>"}}],
  "music"?: [...], "sfx"?: [...]}}
Include a key only if you change it; br, bg, screens, hk, moves and fx are the FULL new list when present (keep existing blocks you
didn't touch). Blocks on one track never overlap. Never invent footage; only use library clips that exist, picked by
their "about" (what is in the shot, from the B-roll index), not their file name. "labels" are the creator's own tags (who and
where: a person, a pet, a place): trust them over "about".""" + rules_text()

def start_agent(job, message, state):
    rid = uuid.uuid4().hex[:8]; log = ["Claude is building it. Effects take a minute or two."]; RUNS[rid] = {"log": log, "done": False, "ok": False, "job": job}
    E = PROJECTS/job/"edit"; (E/"timeline_state.json").write_text(json.dumps(with_index(state), ensure_ascii=False)); (E/"timeline_patch.json").unlink(missing_ok=True)
    def work():
        try:
            run_claude(job, agent_prompt(job, message), "studio_agent.log", log)
            RUNS[rid]["result"] = json.loads((E/"timeline_patch.json").read_text()); RUNS[rid]["ok"] = True
        except Exception as e:
            RUNS[rid]["result"] = {"reply": f"That didn't work: {e}. The full log is in edit/studio_agent.log."}
        RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

# ---------------------------------------------------------------- the timeline editor (2026-10-20 night)
MUSIC_DIR = BRAIN/"Video-Studio/Music"
SSD_SFX = pathlib.Path("/Volumes/SSD 2026/000 Assets/Sound FX")
def lut_list():
    """the creator's own LUTs for the Color panel: the default (Brand page) first, the rest of its folder, then the ones imported in
    the grade panel (cineyap/brand_assets/luts). The old pipeline's looks (cineyap/looks) are left out: they weren't the creator's"""
    seen, out = set(), []
    def add(p, note=""):
        p = pathlib.Path(p)
        if p.suffix.lower() == ".cube" and p.exists() and not p.name.startswith("._") and str(p) not in seen:
            seen.add(str(p)); out.append({"file": str(p), "name": p.stem + note})
    if config.opt("lut"): add(config.opt("lut"), " (your default)")
    for d in (pathlib.Path(config.opt("lut") or "/nonexistent").parent, LUT_DIR):
        if d.is_dir():
            for f in sorted(d.glob("*.cube")): add(f)
    return out
USER_STYLES = PKG/"cineyap/user_styles.json"
STYLE_DEFAULTS = PKG/"cineyap/style_defaults.json"      # the style a new video starts with, by shape: {"tall": name, "wide": name} (Gabe, 2026-10-25)
def style_defaults():
    try: return json.loads(STYLE_DEFAULTS.read_text())
    except Exception: return {}
TEXT_STYLES = PKG/"cineyap/text_styles.json"
SCREEN_TEMPLATES = PKG/"cineyap/screen_templates.json"      # screens saved as templates, for any video (2026-10-23)
AROLL_GRADES = PKG/"cineyap/aroll_grades.json"      # each take's grade, by its file: grading is on the footage, Media > A-roll (2026-10-23)
def aroll_grades():
    try: return json.loads(AROLL_GRADES.read_text())
    except Exception: return {}
def aroll_takes():
    """every take you've uploaded, one each, newest video first, with the videos made from it: Media > A-roll"""
    g, out, by = aroll_grades(), [], {}
    for j in jobs():
        if j.get("kind") != "video": continue
        try: srcs = json.loads((PROJECTS/j["job"]/"edit/edl.json").read_text()).get("sources") or {}
        except Exception: continue
        for src in srcs.values():
            src = str(src)
            if pathlib.Path(src).name == "slate.mp4" and "/projects/" in src.replace("\\", "/"): continue      # a blank project's stand-in, not a take
            if src not in by:
                by[src] = {"src": src, "name": pathlib.Path(src).name, "thumb": str(PROJECTS/j["job"]/"edit/proxy.mp4"), "videos": [],
                           "graded": src in g, "exists": pathlib.Path(src).exists()}
                out.append(by[src])
            by[src]["videos"].append({"job": j["job"], "title": j["title"]})
    return out
def graded_map(job):
    """the preview copies with a LUT already baked in, {lut path: file}, so the editor opens graded instead of re-applying the LUT
    every time (2026-10-22). Same file name as timeline_tools.grade_proxy: proxy_lut_<md5 of the LUT path>.mp4"""
    E = PROJECTS/job/"edit"; luts = set()
    try: luts.add((json.loads((E/"timeline.json").read_text()).get("COLOR") or {}).get("lut") or "")
    except Exception: pass
    try: luts.add(json.loads((PKG/"cineyap/config.json").read_text()).get("lut") or "")
    except Exception: pass
    try: luts.update(m.get("file", "") for m in media_lists().get("luts", []))
    except Exception: pass
    out = {}
    for l in luts:
        if not l: continue
        f = E/f"proxy_lut_{hashlib.md5(l.encode()).hexdigest()[:8]}.mp4"
        if f.exists() and f.stat().st_size > 1000: out[l] = str(f)
    return out      # saved text box looks (each line's style + the box), for any video
SAVED_FX = PKG/"library/saved_fx"

def media_lists():
    music = []
    try: idx = {m.get("file") or m.get("name"): m for m in json.loads((MUSIC_DIR/"_index.json").read_text())}
    except Exception: idx = {}
    for f in sorted(MUSIC_DIR.glob("*.mp3")):
        m = idx.get(f.name) or {}
        music.append({"file": str(f), "name": f.stem, "dur": m.get("seconds") or m.get("duration") or 0})
    sfx, seen = [], set()
    for d in (SSD_SFX, PKG/"cineyap/assets"):
        if d.is_dir():
            for f in sorted(d.glob("*")):
                if f.suffix.lower() in (".mp3", ".wav", ".m4a", ".flac", ".aif", ".aiff") and not f.name.startswith("._") and f.name not in seen:
                    seen.add(f.name); sfx.append({"file": str(f), "name": f.stem})
    saved = []
    SAVED_FX.mkdir(parents=True, exist_ok=True)
    for j in sorted(SAVED_FX.glob("*.json")):
        try: saved.append(json.loads(j.read_text()))
        except Exception: pass
    styles = json.loads(USER_STYLES.read_text()) if USER_STYLES.exists() else {}
    builtin = []
    fl, ck = config.opt("sfx_flash_overlay"), config.opt("sfx_click")
    # Loop's own flash and click (library/builtin, made from scratch 2026-10-21, ours to ship) when this Mac has none set
    if not (fl and pathlib.Path(fl).exists()): fl = str(PKG/"library/builtin/flash.mp4")
    if not (ck and pathlib.Path(ck).exists()): ck = str(PKG/"library/builtin/click.wav")
    if fl and pathlib.Path(fl).exists():    # Flash + Click, locked 2026-10-02 (effects/flash-click.md)
        builtin.append({"id": "flash", "name": "Flash + click", "file": fl, "dur": 0.458, "blend": "screen", "portrait": True,
                        "click": ck if ck and pathlib.Path(ck).exists() else "", "click_gain_db": -9.1, "click_lead": 2 / (24000 / 1001) + 0.064})
    return {"music": music, "sfx": sfx, "saved_fx": saved, "styles": styles, "style_defaults": style_defaults(), "luts": lut_list(), "builtin_fx": builtin, "palette": palette(),
            "panel_ph": str(PKG/"library/builtin/panel_placeholder.jpg")}      # YapMaxxing's empty panel slot

LUT_DIR = PKG/"cineyap/brand_assets/luts"      # LUTs imported in the grade panel: copied here, so they work with the drive unplugged
def import_lut(src):
    """copy a picked .cube into the LUTs folder (a new name if one is taken by a different file) and return where it landed"""
    src = pathlib.Path(src); LUT_DIR.mkdir(parents=True, exist_ok=True); out = LUT_DIR/src.name; k = 1
    while out.exists() and out.read_bytes() != src.read_bytes(): k += 1; out = LUT_DIR/f"{src.stem} {k}{src.suffix}"
    if not out.exists(): shutil.copy(src, out)
    return out
GRADES = PKG/"cineyap/grades.json"      # each B-roll clip's own grade (GRADING.md), keyed by the clip as the timeline names it; every video uses it
def grades():
    try: return json.loads(GRADES.read_text())
    except Exception: return {}
PALETTE = PKG/"cineyap/palette.json"      # colors the creator saved in the editor, and brand colors they took off the swatches
SYSFONTS = PKG/"cineyap/system_fonts.json"
FONT_STARS = PKG/"cineyap/font_stars.json"
_SF_LOCK = threading.Lock()
def scan_fonts():
    """every font installed on this machine, by family (system_profiler on a Mac, ~15 s; the Fonts folders on Windows),
    cached in system_fonts.json"""
    with _SF_LOCK:
        try: faces = plat.font_files()
        except Exception: return None
        fams = {}
        for t in faces:
            fam, ps = t["family"], t["ps"]
            if not fam or not ps or fam.startswith("."): continue
            fams.setdefault(fam, {})[ps] = {"ps": ps, "style": t["style"], "full": t["full"] or ps, "path": t["path"]}
        out = {"made": time.strftime("%Y-%m-%d %H:%M"), "families": [{"family": k, "faces": sorted(v.values(), key=lambda x: x["style"])} for k, v in sorted(fams.items(), key=lambda kv: kv[0].lower())]}
        SYSFONTS.write_text(json.dumps(out)); return out
def sys_fonts(refresh=False):
    if not refresh and SYSFONTS.exists():
        try: return json.loads(SYSFONTS.read_text())
        except Exception: pass
    if _SF_LOCK.locked(): return {"loading": True}
    threading.Thread(target=scan_fonts, daemon=True).start(); return {"loading": True}

def palette():
    import re
    try: cols = brand_state()["brand"].get("colors", {})
    except Exception: cols = NATIVE
    brand, roles = [], {}
    for k in ("dark", "light", "text", "accent"):       # ONLY the brand's colors (Gabe, 2026-10-24): no black or white unless they are in the brand
        c = str(cols.get(k) or "").upper()
        if re.fullmatch(r"#[0-9A-F]{6}", c):
            roles[k] = c
            if c not in brand: brand.append(c)
    p = json.loads(PALETTE.read_text()) if PALETTE.exists() else {}
    return {"brand": brand, "roles": roles, "saved": p.get("saved", []), "hidden": p.get("hidden", []), "from_brand_tab": BRAND_FILE.exists()}

def run_tool(rid, args, log, done_note):
    p = subprocess.Popen([str(PY), str(PKG/"cineyap/timeline_tools.py")] + args, cwd=PKG,
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    for line in p.stdout:
        line = line.rstrip()
        if line: log.append(line)
        if line.startswith("DONE "): RUNS[rid]["file"] = line[5:].rsplit(" (", 1)[0]
    RUNS[rid]["ok"] = p.wait() == 0
    if RUNS[rid]["ok"] and done_note: log.append(done_note)
    RUNS[rid]["done"] = True

def start_variants(job, args, variants, outdir=None):
    """Export every variation, one after another: each one's timeline goes to edit/variants/<slug>.json and comes out as
    exports/<job>-<fmt>-<slug>.mp4 (with its Premiere XML)"""
    import re
    rid = uuid.uuid4().hex[:8]; log = [f"Exporting {len(variants)} video{'s' if len(variants) != 1 else ''}, one after another."]; RUNS[rid] = {"log": log, "done": False, "ok": False, "files": []}
    D = PROJECTS/job/"edit/variants"; D.mkdir(parents=True, exist_ok=True)
    def work():
        ok = True
        for k, v in enumerate(variants, 1):
            slug = re.sub(r"[^a-z0-9]+", "-", (v.get("name") or f"v{k}").lower()).strip("-")[:40] or f"v{k}"
            f = D/f"{slug}.json"; f.write_text(json.dumps(v["state"], ensure_ascii=False))
            log.append(f"Video {k} of {len(variants)}: {v.get('name', slug)}")
            sub = {"log": [], "done": False, "ok": False}; RUNS[rid + str(k)] = sub
            vname = re.sub(r"[^\w .,()&-]", "_", str(v.get("name") or "")).strip() or slug      # a name stays a file name (R10)
            extra = ["--out", str(pathlib.Path(outdir)/f"{vname}.mp4")] if outdir else []
            a_ = list(args)
            if v.get("fmt"): a_[2] = v["fmt"]      # the export dialog: each item is one version in one shape
            run_tool(rid + str(k), a_ + ["--tl", str(f), "--suffix", "-" + slug] + extra, sub["log"], "")
            log.extend("  " + l for l in sub["log"][-2:])
            if sub.get("file"): RUNS[rid]["files"].append(sub["file"]); RUNS[rid]["file"] = sub["file"]
            ok = ok and sub["ok"]
        RUNS[rid]["ok"] = ok; log.append("All versions are ready." if ok else "One or more versions stopped. The log above says which."); RUNS[rid]["done"] = True
    threading.Thread(target=work, daemon=True).start(); return rid

def start_tool(args, first, done_note=""):
    rid = uuid.uuid4().hex[:8]; log = [first]; RUNS[rid] = {"log": log, "done": False, "ok": False}
    threading.Thread(target=run_tool, args=(rid, args, log, done_note), daemon=True).start(); return rid

REVIEW = """You review a talking-head video edit for the CineYap Studio like a sharp human editor. You get the timeline: the A-roll
pieces with their words, the captions, B-roll, screens, effects and the long pauses still in the cut. Leave 4 to 10 MARKERS for the
creator, the things a good editor would flag: a slow or buried hook, a pause or stumble still in, a long stretch of talking head
that wants B-roll (name a real clip from the library that fits), a line that repeats an earlier one, a spot for a green or cream
screen to land a key word, a caption that covers the face, an ending that trails off. Be specific and short, US spelling, no em dashes. Music beds loop on their own to fill their block, so never flag a song for being shorter than the video.
Each marker may carry a FIX the Studio can apply in one click, in the same patch format as the chat
({"br": [...full list], "bg": [...full list], "remove_ranges": [[a,b]], "ovr": {...}}). Only add a fix you are sure of.
Reply with ONE JSON object and nothing else: {"markers": [{"t": seconds, "kind": "hook|pause|broll|repeat|screen|caption|ending",
"note": "<one sentence>", "fix": {...}?}]}
"""
def timeline_review(state):
    cl = claude_bin()
    if not cl: return {"markers": []}
    r = subprocess.run([cl, "--model", MODEL_MID, "-p", REVIEW + "\nTIMELINE:\n" + json.dumps(state, ensure_ascii=False), "--max-turns", "1"],
                       cwd=PKG, capture_output=True, text=True, timeout=300)
    out = r.stdout.strip()
    try: return json.loads(out[out.index("{"): out.rindex("}") + 1])
    except Exception: return {"markers": [], "error": out[:300]}

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def send_json(self, obj, code=200):
        b = json.dumps(plat.web_paths(obj), ensure_ascii=False).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(b)
    def send_file(self, p, ctype=None):
        p = pathlib.Path(p); size = p.stat().st_size; ctype = ctype or mimetypes.guess_type(str(p))[0] or "application/octet-stream"
        rng = self.headers.get("Range")
        if rng and rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-"); a = int(a or 0); b = int(b) if b else size - 1; b = min(b, size - 1)
            self.send_response(206); self.send_header("Content-Range", f"bytes {a}-{b}/{size}")
        else:
            a, b = 0, size - 1; self.send_response(200)
        self.send_header("Content-Type", ctype); self.send_header("Accept-Ranges", "bytes")
        if p.suffix in (".js", ".css", ".html"): self.send_header("Cache-Control", "no-cache")      # a refresh always gets the latest Studio
        self.send_header("Content-Length", str(b - a + 1)); self.end_headers()
        with open(p, "rb") as fh:
            fh.seek(a); left = b - a + 1
            while left > 0:
                chunk = fh.read(min(1 << 20, left))
                if not chunk: break
                try: self.wfile.write(chunk)
                except (BrokenPipeError, ConnectionResetError): return
                left -= len(chunk)

    def do_GET(self):
        if not self.from_here(): return self.send_json({"error": "forbidden"}, 403)
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        if bad_job(q.get("job")): return self.send_json({"error": "no such project"}, 400)
        try:
            if u.path in ("/", "/index.html"): return self.send_file(WEB/"index.html", "text/html; charset=utf-8")
            if u.path == "/static/editor.html":      # the editor learns where projects live on THIS Mac (it had Gabe's path written in)
                b = (WEB/"editor.html").read_text().replace("__PROJECTS__", PROJECTS.as_posix()).encode()
                self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(b)))
                self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(b); return
            if u.path.startswith("/static/"):
                f = (WEB/u.path[8:]).resolve()
                if str(f).startswith(str(WEB.resolve())) and f.exists(): return self.send_file(f)
            if u.path.startswith("/library/"):
                f = (LIB/u.path[9:]).resolve()
                if str(f).startswith(str(LIB.resolve())) and f.exists(): return self.send_file(f)
            if u.path == "/api/exports":           # the export queue: every export this session, its progress and its files
                out = []
                for e in EXPORT_LOG[-30:]:
                    r = RUNS.get(e["run"], {}); log = r.get("log", []); last = log[-1] if log else ""
                    step = 0
                    for l in reversed(log):
                        m = re.match(r"\s*(\d)/5", l)
                        if m: step = int(m.group(1)); break
                    vd = sum(1 for l in log if l.startswith(("Version ", "Video ")))      # (the export dialog logs "Video k of n")
                    if e["versions"] and vd:      # versions: the step comes from the one exporting now
                        for l in reversed(RUNS.get(e["run"] + str(vd), {}).get("log", [])):
                            m = re.match(r"\s*(\d)/5", l)
                            if m: step = int(m.group(1)); last = l; break
                    out.append(dict(e, done=bool(r.get("done")), ok=bool(r.get("ok")), last=last, step=step, vdone=vd,
                                    file=r.get("file", ""), files=r.get("files", []), secs=round(time.time() - e["started"])))
                return self.send_json({"exports": out})
            if u.path == "/api/fonts":             # the fonts installed on this Mac, for the font menus, + the ones that ship with the Studio
                d = sys_fonts(q.get("refresh") == "1")
                if not d.get("loading"):
                    have = {f["family"] for f in d.get("families", [])}
                    d["bundled"] = [{"family": f.stem.split("-")[0].replace("InstrumentSerif", "Instrument Serif"), "name": f.stem.replace("-", " "), "path": str(f)}
                                    for f in sorted((PKG/"fonts").glob("*")) if f.suffix.lower() in (".ttf", ".otf")]
                    d["bundled"] = [x for x in d["bundled"] if x["family"] not in have]
                    d["stars"] = json.loads(FONT_STARS.read_text()) if FONT_STARS.exists() else []
                return self.send_json(d)
            if u.path == "/api/state":
                return self.send_json({"jobs": jobs(), "newq": NEWQ,
                                       "drives": {"list": drives.status(), "ack": drives.acked()}})
            if u.path == "/api/drives": return self.send_json({"list": drives.status(q.get("job")), "ack": drives.acked()})
            if u.path == "/api/aroll":
                d = aroll_model(q["job"]); d["graded"] = graded_map(q["job"]); d["src"] = src_info(q["job"]); d["brief"] = brief(q["job"]); return self.send_json(d)
            if u.path == "/api/rules": return self.send_json({"rules": rules_list()})
            if u.path == "/api/chats": return self.send_json(chat_threads(q["job"], q.get("id")))      # Chat history: the list, or one thread
            if u.path == "/api/job-fx": return self.send_json(job_fx(q["job"]))      # every effect Claude made for this video, on the timeline or not
            if u.path == "/api/learned": return self.send_json(edit_learn.api_state())      # "What I've learned": candidates and approved
            if u.path == "/api/text-styles": return self.send_json({"styles": json.loads(TEXT_STYLES.read_text()) if TEXT_STYLES.exists() else {}})
            if u.path == "/api/screen-templates": return self.send_json({"templates": json.loads(SCREEN_TEMPLATES.read_text()) if SCREEN_TEMPLATES.exists() else {}})
            if u.path == "/api/aroll-takes": return self.send_json({"takes": aroll_takes()})
            if u.path == "/api/aroll-grade": return self.send_json({"color": aroll_grades().get(q.get("src", ""))})
            if u.path == "/api/hooks":
                f = PROJECTS/q["job"]/"edit/hooks.json"; d = json.loads(f.read_text()) if f.exists() else {"hooks": []}
                if any(not h.get("label") for h in d.get("hooks", [])) and q["job"] not in LABELING:      # short names for the versions
                    LABELING.add(q["job"]); threading.Thread(target=label_hooks, args=(q["job"],), daemon=True).start()
                d["labeling"] = q["job"] in LABELING
                d["proxy"] = str(PROJECTS/q["job"]/"edit/proxy.mp4"); return self.send_json(d)
            if u.path == "/api/media": return self.send_json(media_lists())
            if u.path == "/api/grades": return self.send_json(grades())
            if u.path == "/api/cube":            # a LUT's text, for the editor's live grade (LUTs live wherever the creator keeps them)
                p = pathlib.Path(q["p"])
                if p.suffix.lower() == ".cube" and p.is_file(): return self.send_file(p, "text/plain")
            if u.path == "/api/cutouts":
                C = PROJECTS/q["job"]/"edit/cutouts"
                return self.send_json({"keys": sorted(f.stem for f in C.glob("*.webm")) if C.exists() else []})
            if u.path == "/api/library": return self.send_json(library())
            if u.path == "/api/broll-index":      # Media's search and hover: {clips: {path: {d: description, t: tags, f: framing, a: angle, s: sequence}}, status}
                return self.send_json({"clips": {c: {"d": e["description"], "t": e["tags"], "f": e.get("framing", ""), "a": e.get("angle", ""), "c": bool(e.get("creative")), "s": e.get("seq", ""),
                                                     "p": e.get("place", ""), "ac": e.get("action", ""), "o": e.get("objects", []), "cam": broll_index.at_camera(e)}
                                                 for c, e in broll_index.by_clip().items()},
                                       "status": broll_index.STATUS})
            if u.path == "/api/broll-cleanup": return self.send_json({"rows": broll_index.report(library(), quiet=True)})      # clips that don't fit their bucket
            if u.path == "/api/brand": return self.send_json(brand_state())
            if u.path == "/api/broll-folder": return self.send_json(broll_folder_state())
            if u.path == "/api/update": return self.send_json(update_check())
            if u.path == "/api/progress": return self.send_json(progress(q["job"]))
            if u.path == "/api/sample":         # the sample take that ships in samples/, for "Edit the sample video"
                sp = PKG/"samples/sample-16x9.mp4"; return self.send_json({"path": str(sp) if sp.exists() else ""})
            if u.path == "/api/claude": return self.send_json(claude_auth(fresh="fresh" in q))
            if u.path == "/api/broll-import":     # an upload's progress and its shot sheet; no id = the uploads waiting on their sheet
                return self.send_json(broll_import.status(q["id"]) if q.get("id") else {"pending": broll_import.pending()})
            if u.path == "/api/clip-info": return self.send_json(broll_import.clip_info(q["clip"], probe_video))      # the clip editor
            if u.path == "/api/choose": return self.send_json({"path": choose_file()})
            if u.path == "/api/choose-files": return self.send_json({"paths": choose_files()})
            if u.path == "/api/run": return self.send_json(RUNS.get(q["id"], {"log": ["unknown run"], "done": True, "ok": False}))
            if u.path == "/thumb":
                p = pathlib.Path(q["p"])
                if not p.is_absolute(): p = clips.resolve_clip(q["p"]) or p
                if p.exists() and allowed(p): return self.send_file(thumb(p, float(q.get("t", 0.5))), "image/jpeg")
            if u.path in ("/file", "/thumb"): LAST_POST[0] = time.time()      # playing or scrubbing is working too: no auto update under them (R23)
            if u.path == "/file":
                p = pathlib.Path(q["p"])
                if not p.is_absolute(): p = clips.resolve_clip(q["p"]) or p
                if p.exists() and allowed(p): return self.send_file(p)
            self.send_json({"error": "not found"}, 404)
        except Exception as e:
            log_error(self.path)
            self.send_json({"error": str(e), "trace": traceback.format_exc().splitlines()[-3:]}, 500)

    def from_here(self):
        """only this Mac's own Studio page may talk to the server. A website you visit can still send requests to
        localhost; without this it could drive the agent, which runs commands (2026-10-21 audit). The Host check stops
        DNS rebinding; the Origin check stops cross-site POSTs."""
        host = (self.headers.get("Host") or "").split(":")[0]
        if host not in ("localhost", "127.0.0.1"): return False
        org = self.headers.get("Origin")
        return org is None or org in (f"http://localhost:{PORT}", f"http://127.0.0.1:{PORT}")
    def do_POST(self):
        if not self.from_here(): return self.send_json({"error": "forbidden"}, 403)
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        if u.path not in ("/api/update", "/api/claude-login"): LAST_POST[0] = time.time()      # someone is working: no auto update now
        n = int(self.headers.get("Content-Length", 0))
        if bad_job(q.get("job")): return self.send_json({"error": "no such project"}, 400)
        try:
            if u.path == "/api/upload":            # a clip dropped from Finder: the browser gives bytes, not a path
                job = q["job"]; name = pathlib.Path(q["name"]).name
                d = PROJECTS/job/"board_media"; d.mkdir(parents=True, exist_ok=True); out = unique_path(d, name)
                if not receive_body(self.rfile, n, out): return self.send_json({"error": "the upload stopped before the file was complete"}, 400)
                found = clips.resolve_clip(name)        # the same clip already in the library: use that one
                return self.send_json({"clip": clips.rel_clip(found) if found and "board_media" not in str(found) else str(out)})
            if u.path == "/api/library-add":       # a clip dropped on Visuals: copied to "Added in Studio" on your drive, filed in the bucket
                name = pathlib.Path(q["name"]).name; img = pathlib.Path(name).suffix.lower() in IMG_EXT + (".heic", ".heif")
                root = pathlib.Path(library()["root"]); d = root/("Stills" if img else "Added in Studio"); d.mkdir(exist_ok=True)      # a picture goes to Stills
                out = d/name; k = 2
                while out.exists(): out = d/f"{pathlib.Path(name).stem}_{k}{pathlib.Path(name).suffix}"; k += 1
                if not receive_body(self.rfile, n, out): return self.send_json({"error": "the upload stopped before the file was complete"}, 400)
                if img:
                    if out.suffix.lower() in (".heic", ".heif"):      # iPhone photos: a JPG the browser and ffmpeg can read
                        jpg = out.with_suffix(".jpg")
                        if plat.IS_WIN: subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(out), "-frames:v", "1", "-q:v", "2", str(jpg)], capture_output=True)
                        else: subprocess.run(["sips", "-s", "format", "jpeg", str(out), "--out", str(jpg)], capture_output=True)
                        if jpg.exists(): out.unlink(); out = jpg
                    return self.send_json({**library(), "added": str(out.relative_to(root))})
                r = library_edit({"op": "move", "clips": [str(out.relative_to(root))], "to": q.get("bucket") or "Added in Studio"})
                broll_index.start_background(library); return self.send_json(r)      # what's in it, in the background
            if u.path == "/api/chat-attach":       # a screenshot pasted or dropped in Chat, kept with the project for Claude to look at
                d = PROJECTS/q["job"]/"edit/chat_refs"; d.mkdir(parents=True, exist_ok=True)
                out = d/f"{time.strftime('%H%M%S')}-{uuid.uuid4().hex[:4]}-{pathlib.Path(q['name']).name}"
                if not receive_body(self.rfile, n, out): return self.send_json({"error": "the upload stopped before the file was complete"}, 400)
                return self.send_json({"path": str(out)})
            if u.path == "/api/upload-raw":        # a raw take dropped on the home page
                name = pathlib.Path(q["name"]).name; d = PKG/"inbox"; d.mkdir(exist_ok=True); out = unique_path(d, name)      # C0001.MP4 from two shoots are two files (R7)
                if not receive_body(self.rfile, n, out): return self.send_json({"error": "the upload stopped before the file was complete"}, 400)
                return self.send_json({"path": str(out)})
            if u.path == "/api/brand/upload":      # a font, LUT or logo dropped on the Brand tab
                name = pathlib.Path(q["name"]).name; BRAND_ASSETS.mkdir(parents=True, exist_ok=True); out = BRAND_ASSETS/name      # a font or LUT dropped again replaces itself on purpose
                if not receive_body(self.rfile, n, out): return self.send_json({"error": "the upload stopped before the file was complete"}, 400)
                return self.send_json({"path": str(out)})
            if u.path == "/api/broll-import/upload":     # one file of a Media upload, into its staging folder (the original stays put)
                return self.send_json(broll_import.status(broll_import.receive(q["id"], q["name"], self.rfile, n)["id"]))
            body = json.loads(self.rfile.read(n) or b"{}")
            if bad_job(body.get("job") if isinstance(body, dict) else None): return self.send_json({"error": "no such project"}, 400)
            if u.path == "/api/broll-import/new": return self.send_json(broll_import.new_import())
            if u.path == "/api/broll-import/start": return self.send_json(broll_import.start(body["id"], probe_video))      # cuts, looks, look-alikes
            if u.path == "/api/broll-import/add": return self.send_json(broll_import.add(body["id"], body["outs"], library))     # the shot sheet's Add N clips
            if u.path == "/api/broll-import/cancel": return self.send_json(broll_import.cancel(body["id"]))
            if u.path == "/api/clip-lut-preview": return self.send_json({"path": broll_import.lut_preview(body["clip"])})
            if u.path == "/api/clip-save": return self.send_json(broll_import.clip_save(body["clip"], body, library))       # trim + grade: a new "(edit)" clip beside it
            if u.path == "/api/clip-delete-copy": return self.send_json(broll_import.clip_delete_copy(body["clip"], library))      # an edited copy, deleted
            if u.path == "/api/brand": save_brand(body["brand"], lut_set=bool(body.get("lut_set"))); return self.send_json({"ok": True})
            if u.path == "/api/broll-folder": return self.send_json(broll_folder_set(body))
            if u.path == "/api/update": return self.send_json(update_start())
            if u.path == "/api/claude-login": return self.send_json(claude_login())
            if u.path == "/api/ack-drive": drives.ack(); return self.send_json({"ok": True})
            if u.path == "/api/probe":            # what each picked take is: shape, length, log or not, joinable settings
                return self.send_json({"videos": [probe_video(p) for p in body.get("paths", [])[:60]]})
            if u.path in ("/api/new-batch", "/api/new") or (u.path == "/api/new-video" and body.get("takes")):
                if not claude_auth(fresh=True)["signedIn"]: return self.send_json({"error": NOT_SIGNED_IN})
                files = [g["files"][0] for g in body.get("groups", []) if g.get("files")] or body.get("takes") or [body.get("path", "")]
                quiet = [f for f in files if f and pathlib.Path(f).is_file() and silent_take(f)]
                if quiet: return self.send_json({"error": f"“{pathlib.Path(quiet[0]).name}” has no sound, so there's nothing to cut. Pick a take where you're talking. A screen recording or B-roll clip goes on the B-roll track instead (or start a Blank project)."})
            if u.path == "/api/new-batch":        # "Group your videos": one project per group, shape and LUT from the footage
                runs = start_batch(body.get("groups", []))
                return self.send_json({"runs": runs} if runs else {"error": "none of those videos could be found (is the drive plugged in?)"})
            if u.path == "/api/new":
                src, fmt = body.get("path", ""), body.get("fmt", "")
                if fmt not in NEW_FORMATS: return self.send_json({"error": "pick Vertical, 4:3 or 16:9"}, 400)
                if not src or not pathlib.Path(src).is_file(): return self.send_json({"error": "that video could not be found (is its drive plugged in?)"}, 400)
                return self.send_json({"run": start_new(src, fmt, bool(body.get("lut")))})
            if u.path == "/api/stage":                 # the editor's Back to A-roll
                if body.get("stage") not in ("aroll", "edit"): return self.send_json({"error": "no"}, 400)
                if body["stage"] == "aroll":
                    (PROJECTS/body["job"]/"edit/radio_lock.json").unlink(missing_ok=True)
                set_stage(body["job"], body["stage"]); return self.send_json({"ok": True})
            if u.path == "/api/cutouts":               # text-behind: cut you out of these stretches of the take
                return self.send_json({"run": start_tool(["cutouts", body["job"], json.dumps(body.get("ranges", []))] + ([body["src"]] if body.get("src") else []),
                                                          "Cutting you out for text-behind…", "Cut-outs ready.")})
            if u.path == "/api/grade-proxy":           # the Color panel: a preview copy with the LUT baked in
                if not pathlib.Path(body.get("lut", "")).exists(): return self.send_json({"error": "that LUT is not on this Mac"}, 400)
                return self.send_json({"run": start_tool(["gradeproxy", body["job"], body["lut"]], "Applying the LUT to the preview…")})
            if u.path == "/api/choose-lut":            # the grade panel's Import…: pick a .cube, it's copied into the LUTs folder
                p = plat.pick_file("Import a LUT (.cube)", "cube")
                if not p or not p.lower().endswith(".cube"): return self.send_json({"file": ""})
                return self.send_json({"file": str(import_lut(p)), "luts": lut_list()})
            if u.path == "/api/timeline-prep":
                return self.send_json({"run": start_tool(["prep", body["job"]], "Getting the raw take ready for editing…")})
            if u.path == "/api/choose-save":       # Export: the Mac's own Save window (a file), or a folder for every version
                if body.get("folder"):
                    p = plat.pick_folder("Export to…")
                else:
                    nm = re.sub(r'[\\/:"*?<>|]', "-", body.get("name") or "video")
                    p = plat.save_file("Export video", f"{nm}.mp4")
                if p and not body.get("folder") and not p.lower().endswith(".mp4"): p += ".mp4"
                if p: EXPORT_DIRS.add(pathlib.Path(p) if body.get("folder") else pathlib.Path(p).parent)
                return self.send_json({"path": p})        # "" when you press Cancel
            if u.path == "/api/timeline-export":
                # one export per video at a time: two at once share the same working files and wreck each other (2026-10-21)
                with EXPORT_LOCK:      # a double-click sent two exports of one job into the same folder (R22)
                    cur = EXPORTING.get(body["job"])
                    if cur and not RUNS.get(cur, {}).get("done", True):
                        return self.send_json({"run": cur, "already": True})
                    a = ["export", body["job"], body.get("fmt", "169")] + (["--4k"] if body.get("k4") else []) + (["--noxml"] if body.get("xml") is False else [])
                    if body.get("dir"): EXPORT_DIRS.add(pathlib.Path(body["dir"]))      # a folder remembered by the dialog: Play and Show in Finder can reach it
                    if body.get("variants"): rid = start_variants(body["job"], a, body["variants"], body.get("dir"))
                    else:
                        if body.get("out"): a += ["--out", body["out"]]
                        rid = start_tool(a, "Exporting. This takes a few minutes.", "Your video is ready.")
                    EXPORTING[body["job"]] = rid
                    title = ""
                    try: title = json.loads((PROJECTS/body["job"]/"edit/studio.json").read_text()).get("title", "")
                    except Exception: pass
                    EXPORT_LOG.append({"run": rid, "job": body["job"], "title": title or body["job"], "fmt": body.get("fmt", "169"), "k4": bool(body.get("k4")),
                                       "versions": len(body.get("variants") or []), "dest": body.get("out") or body.get("dir") or "", "started": time.time()})
                    threading.Thread(target=edit_learn.on_export, args=(body["job"], body, claude_bin()), daemon=True).start()      # every exported version is a finished edit
                    return self.send_json({"run": rid})
            if u.path == "/api/timeline-review":
                try: return self.send_json(timeline_review(body.get("state", {})))
                except Exception as e: return self.send_json({"markers": [], "error": str(e)})
            if u.path == "/api/library-edit":      # hide, show, move, rename, new bucket: only library_map.json changes
                r = library_edit(body)
                if body.get("op") == "unhide": broll_index.start_background(library)      # skipped while hidden: index it now
                return self.send_json(r)
            if u.path == "/api/carousel-new": return self.send_json(carousel_new(body))
            if u.path == "/api/blank-new": return self.send_json(blank_new(body))
            if u.path == "/api/new-video": return self.send_json(new_video(body))
            if u.path == "/api/carousel-parse": return self.send_json({"slides": parse_slides(body.get("text", ""))})
            if u.path == "/api/carousel-picks":    # the editor's bulk import: B-roll for the new slides
                r = pick_clips(body.get("slides", []), body.get("used", [])); return self.send_json({"clips": {str(k): v for k, v in r["clips"].items()}, "music": r["music"]})
            if u.path == "/api/grades":            # one B-roll clip's grade: set it, or null takes it off
                G = grades()
                if body.get("grade"): G[body["clip"]] = body["grade"]
                else: G.pop(body.get("clip"), None)
                tmp = GRADES.with_suffix(".part"); tmp.write_text(json.dumps(G, indent=1)); tmp.replace(GRADES); return self.send_json({"ok": True})
            if u.path == "/api/palette":           # save a color to the palette, or take one off
                atomic_write_json(PALETTE, {"saved": body.get("saved", []), "hidden": body.get("hidden", [])}, indent=1); return self.send_json(palette())
            if u.path == "/api/font-stars":        # star or unstar a font family in the font menus
                st = json.loads(FONT_STARS.read_text()) if FONT_STARS.exists() else []
                fam = body.get("family", "")
                if body.get("on") and fam not in st: st.append(fam)
                if not body.get("on") and fam in st: st.remove(fam)
                atomic_write_json(FONT_STARS, st); return self.send_json({"ok": True, "stars": st})
            if u.path == "/api/text-styles":       # save or delete a named text box look: {"name", "style": {"lines": [...], "box": {...}}} or {"name", "delete": true}
                st = json.loads(TEXT_STYLES.read_text()) if TEXT_STYLES.exists() else {}
                if body.get("delete"): st.pop(body.get("name", ""), None)
                elif body.get("name") and isinstance(body.get("style"), dict): st[body["name"]] = body["style"]
                atomic_write_json(TEXT_STYLES, st, indent=1); return self.send_json({"ok": True, "styles": st})
            if u.path == "/api/screen-templates":       # save or delete a screen template: {"name", "screen": {...}} or {"name", "delete": true}
                st = json.loads(SCREEN_TEMPLATES.read_text()) if SCREEN_TEMPLATES.exists() else {}
                if body.get("delete"): st.pop(body.get("name", ""), None)
                elif body.get("name") and isinstance(body.get("screen"), dict): st[body["name"]] = body["screen"]
                atomic_write_json(SCREEN_TEMPLATES, st, indent=1); return self.send_json({"ok": True, "templates": st})
            if u.path == "/api/aroll-grade":            # a take's grade changed in the editor: {"src", "color"}
                g = aroll_grades()
                if body.get("src") and isinstance(body.get("color"), dict): g[body["src"]] = body["color"]
                atomic_write_json(AROLL_GRADES, g, indent=1); return self.send_json({"ok": True})
            if u.path == "/api/style-default":     # star a style as the default for vertical ("tall") or horizontal ("wide") videos
                d = style_defaults(); k = body.get("shape")
                if k not in ("tall", "wide"): return self.send_json({"error": "shape is tall or wide"}, 400)
                if body.get("name"): d[k] = body["name"]
                else: d.pop(k, None)
                atomic_write_json(STYLE_DEFAULTS, d, indent=1); return self.send_json({"style_defaults": d})
            if u.path == "/api/styles":            # save a named set of screens
                st = json.loads(USER_STYLES.read_text()) if USER_STYLES.exists() else {}
                if body.get("delete"): st.pop(body["name"], None)
                else: st[body["name"]] = body["screens"]
                atomic_write_json(USER_STYLES, st, indent=1); return self.send_json({"ok": True, "styles": st})
            if u.path == "/api/save-effect":       # keep an effect Claude built, for any video
                SAVED_FX.mkdir(parents=True, exist_ok=True); src = pathlib.Path(body["file"])
                if not src.exists(): return self.send_json({"error": "that effect file is gone"}, 400)
                eid = "fx" + uuid.uuid4().hex[:6]; dst = SAVED_FX/f"{eid}.webm"; shutil.copy(src, dst)
                rec = {"id": eid, "name": body.get("name") or "Effect", "file": str(dst), "dur": body.get("dur", 3),
                       "moves": body.get("moves") or [], "fmt": body.get("fmt") or "169", "made": time.strftime("%Y-%m-%d")}
                (SAVED_FX/f"{eid}.json").write_text(json.dumps(rec, indent=1)); return self.send_json({"ok": True, "effect": rec})
            if u.path == "/api/timeline-save":          # the timeline editor saves itself after every change
                J = PROJECTS/body.get("job", "")
                if not body.get("job") or "/" in body["job"] or not J.is_dir(): return self.send_json({"error": "no such project"}, 400)
                f = J/"edit/timeline.json"; st = body.get("state", {}); cur = {}
                with SAVE_LOCKS[body["job"]]:      # read, compare and write as one step (R8)
                  try: cur = json.loads(f.read_text())
                  except Exception: pass
                  # a window that loaded an older version must not write over a newer one (2026-10-20: a stale tab erased an effect)
                  if int(cur.get("REV", 0)) > int(body.get("base", 0)):
                    return self.send_json({"error": "stale", "rev": cur.get("REV", 0)}, 409)
                  st["REV"] = int(cur.get("REV", 0)) + 1
                  if f.exists():
                    H = J/"edit/timeline_history"; H.mkdir(exist_ok=True)
                    shutil.copy(f, H/f"timeline-{time.strftime('%Y%m%d-%H%M%S')}.json")
                    # the last 60 saves, and one per 10 minutes before that for two days (2026-10-24: a deleted screen had rolled off 60 saves in minutes)
                    snaps = sorted(H.glob("timeline-2*.json")); seen = set(); cut = time.strftime('%Y%m%d', time.localtime(time.time() - 2*86400))
                    for old in snaps[:-60]:
                        k = old.stem[9:21]          # 20261024-185 = the 10-minute bucket
                        if k[:8] >= cut and k not in seen: seen.add(k); continue
                        old.unlink()
                  atomic_write_json(f, st)
                edit_learn.on_save(body["job"], cur, st, claude_bin())      # the first version's snapshot; a version set to Approved is diffed
                return self.send_json({"ok": True, "rev": st["REV"]})
            if u.path == "/api/timeline-agent":
                return self.send_json({"run": start_agent(body["job"], body.get("message", ""), body.get("state", {}))})
            if u.path == "/api/first-pass":            # the first version of the edit, right after the script is locked
                try:
                    res = first_pass(body); edit_learn.save_first_pass(body.get("job", ""), res)      # kept, to compare with the finished edit
                    return self.send_json(res)
                except Exception as e: return self.send_json({"reply": f"That didn't work: {e}"})
            if u.path == "/api/learned":               # {"op": "approve" | "edit" | "delete" | "refresh", "id"?, "text"?}
                return self.send_json(edit_learn.api_op(body, claude_bin()))
            if u.path == "/api/chat-save":             # Chat history: one thread, saved as it changes (never deleted here)
                return self.send_json(chat_save(body))
            if u.path == "/api/rules":                 # editing rules: {"op": "add", "text"} or {"op": "delete", "id"}
                if body.get("op") == "add" and str(body.get("text", "")).strip(): return self.send_json({"rule": rules_add(body["text"]), "rules": rules_list()})
                if body.get("op") == "delete": rules_save([r for r in rules_list() if r.get("id") != body.get("id")])
                return self.send_json({"rules": rules_list()})
            if u.path == "/api/timeline-chat":
                try: return self.send_json(timeline_chat(body))
                except Exception as e: return self.send_json({"reply": f"That didn't work: {e}"})
            if u.path == "/api/retry":
                try: return self.send_json(retry_job(body.get("job", "")))
                except Exception as e: return self.send_json({"error": str(e)}, 400)
            if u.path == "/api/delete":
                try: return self.send_json({"ok": True, "moved_to": delete_job(body.get("job", ""))})
                except Exception as e: return self.send_json({"error": str(e)}, 400)
            if u.path == "/api/aroll-lut":
                return self.send_json({"run": start_lut(body["job"], bool(body.get("on")))})
            if u.path == "/api/hooks":                 # find every hook in the take, graded (Claude, about a minute)
                return self.send_json({"run": start_hooks(body["job"])})
            if u.path == "/api/use-hook":              # put that hook at the front of the cut
                return self.send_json({"run": start_use_hook(body["job"], body["id"])})
            if u.path == "/api/aroll":                 # the A-roll page: {job, order?, note?, lock?}
                return self.send_json({"run": start_aroll(body["job"], body.get("order"), (body.get("note") or "").strip(), bool(body.get("lock")), body.get("hook"))})
            if u.path == "/api/reveal":
                p = pathlib.Path(body["path"])
                if not p.is_absolute(): p = clips.resolve_clip(body["path"]) or p
                if p.exists() and allowed(p): plat.reveal(p); return self.send_json({"ok": True})
                return self.send_json({"ok": False, "error": "not found"}, 404)
            self.send_json({"error": "not found"}, 404)
        except Exception as e:
            log_error(self.path)
            self.send_json({"error": str(e), "trace": traceback.format_exc().splitlines()[-3:]}, 500)

if __name__ == "__main__":
    for _try in range(20):      # after an update on Windows the old process lets go of the port a moment after this one starts
        try: srv = ThreadingHTTPServer(("127.0.0.1", PORT), H); break
        except OSError:
            if _try == 19: raise
            time.sleep(0.5)
    url = f"http://localhost:{PORT}"
    print(f"Visual Studio: {url}   (Ctrl-C to stop)")
    if "--no-open" not in sys.argv: plat.open_url(url)
    broll_index.start_background(library)      # new or changed B-roll since last time: indexed in the background
    broll_import.load_jobs()                   # uploads whose shot sheet is still waiting
    fix_run_bits(); drop_shipped_rules()
    plat.warm_pickers()      # Windows: the Choose… dialogs open at once
    threading.Thread(target=auto_update_loop, daemon=True).start()      # a newer version installs itself when nobody is working
    srv.serve_forever()
