"""timeline.json's small key changes, for the export: the same steps as cineyap/studio/tlmigrate.js (the editor's copy), kept
line for line; tests/test_migrate.py runs both on one state and expects the same result. Every step is safe to run twice."""

def text_styles(st):
    out = []
    for h in st.get("HK") or []:
        for l in h.get("lines") or []:
            if l and l.get("st") is not None: out.append(l["st"])
    for S in st.get("SCREENS") or []:
        if not S: continue
        for l in ((S.get("text") or {}).get("lines") or []):
            if l and l.get("st") is not None: out.append(l["st"])
        for T in S.get("titles") or []:
            if T and T.get("st") is not None: out.append(T["st"])
    return out

def cap_styles(st):      # every caption style: a screen, its highlight word, a clip's own settings (sc there is a picture scale: a number, never True)
    out = []
    for S in st.get("SCREENS") or []:
        if S:
            out.append(S)
            if S.get("hl"): out.append(S["hl"])
    for k in ("BR", "BG", "SEGS"):
        for o in st.get(k) or []:
            if o and o.get("st") is not None: out.append(o["st"])
    return out

def migrate(st):
    if not isinstance(st, dict): return st
    for s in text_styles(st) + cap_styles(st):
        if s.get("sc") is True: s["smc"] = True; s.pop("sc", None)      # X4: small caps was saved under a screen's scale key
    return st
