"""clips.py — finding a B-roll clip by the name the Studio gives it (moved out of the old Board's boards.py, 2026-10-23).

A clip comes back from the page as an absolute path, a path relative to a B-roll root, or a bare filename (a drag from
Finder gives only the name). These resolve it, and give back the shortest stable name for one.
"""
import pathlib
from _root import PROJECTS
import config

def broll_roots():
    return [pathlib.Path(p) for p in (config.opt("broll_clips"), config.opt("broll_root")) if p]

def resolve_clip(name, job=None):
    """an absolute path, a path relative to a B-roll root, or a bare filename"""
    p = pathlib.Path(name)
    if p.is_absolute() and p.exists(): return p
    if job and (PROJECTS/job/"board_media"/p.name).exists(): return PROJECTS/job/"board_media"/p.name
    for r in broll_roots():
        if (r/name).exists(): return r/name
    for r in broll_roots():
        hits = list(r.rglob(p.name)) if r.exists() else []
        if hits: return hits[0]
    return None

def rel_clip(p):
    """the shortest stable name for a clip: relative to broll_clips when it lives there"""
    p = pathlib.Path(p)
    for r in broll_roots():
        try: return str(p.relative_to(r))
        except ValueError: pass
    return str(p)
