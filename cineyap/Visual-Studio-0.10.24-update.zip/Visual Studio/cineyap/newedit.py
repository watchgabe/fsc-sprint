#!/usr/bin/env python3
# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
"""newedit.py <folder> <format> [--name <job>] [--lut <cube>|--no-lut] — start a New Edit from a folder of takes.

    ./vu-py cineyap/newedit.py "/Volumes/SSD 2026/Footage/ladder" vertical
        format: vcineyap (Vertical CineYap 9:16) | cineyap43 (CineYap 4:3) | cineyap (CineYap 16:9) | vertical | carousel

Every video file in the folder is a take of ONE video (Gabe, 2026-10-05). The takes are joined in name order
(camera numbering = shooting order) into one file that stays on the same drive, beside them:
`<folder>/.cineyap/<job>-takes.<ext>`. Joining is a stream copy (no re-encode, seconds, no quality loss), so
the rest of the pipeline keeps its one-source shape. A folder with one take uses that file as it is.

Then it scaffolds the job (newjob.py), transcribes (once, cached), ranks the takes, and writes
`projects/<job>/edit/studio.json`: the folder, the takes and where each starts in the joined file, the
format, and stage "radio". The radio cut itself is judgment, so it stops here: Claude writes it next,
following RADIO-CUT.md. Prints `JOB: <name>` last.
"""
import json, pathlib, re, subprocess, sys, time
HERE = pathlib.Path(__file__).resolve().parent; PKG = HERE.parent
sys.path.insert(0, str(HERE))
from plat import PY
from _root import PROJECTS

VIDEO = {".mp4", ".mov", ".m4v", ".mxf", ".mts"}
FORMATS = {"vcineyap": "9:16", "cineyap43": "4:3", "cineyap": "16:9",
           "vertical": "CineYap vertical", "carousel": "Video carousel"}   # the first three are the Studio MVP (2026-10-19)

def run(cmd, cwd=None):
    print("  > " + " ".join(str(c) for c in cmd[:3]) + (" ..." if len(cmd) > 3 else ""), flush=True)
    r = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True)
    if r.returncode: sys.stdout.write(r.stdout[-1500:]); sys.stderr.write(r.stderr[-1500:]); sys.exit(f"stopped: {cmd[1] if len(cmd) > 1 else cmd[0]} failed")
    return r.stdout

def dur(f):
    return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(f)],
                                capture_output=True, text=True).stdout.strip() or 0)

def sig(f):
    o = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name,width,height,r_frame_rate,pix_fmt",
                        "-of", "csv=p=0", str(f)], capture_output=True, text=True).stdout.strip()
    return o

def slug(s): return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:40] or "edit"

def main():
    a = sys.argv[1:]
    if len(a) < 2: sys.exit(__doc__)
    folder, fmt = pathlib.Path(a[0]).expanduser(), a[1]
    if fmt not in FORMATS: sys.exit(f"format must be one of: {', '.join(FORMATS)}")
    one = None
    # --take <file> (repeatable, Gabe 2026-10-25: the Studio's "Group your videos"): exactly these takes, in this order, as one video
    picked = [pathlib.Path(a[i + 1]).expanduser().resolve() for i, x in enumerate(a) if x == "--take" and i + 1 < len(a)]      # full paths: the join list is read from its own folder
    for p in picked:
        if not p.is_file(): sys.exit(f"that video could not be found (is its drive plugged in?): {p}")
    if picked: folder = picked[0].parent
    elif folder.is_file(): one, folder = folder, folder.parent                     # a single take picked directly
    if not folder.is_dir(): sys.exit(f"not a folder (or its drive is not connected): {folder}")
    name = a[a.index("--name") + 1] if "--name" in a and a[a.index("--name") + 1] else slug(picked[0].stem if picked else one.stem if one else folder.name)
    takes = picked or ([one] if one else sorted([p for p in folder.iterdir() if p.suffix.lower() in VIDEO and not p.name.startswith(".")], key=lambda p: p.name.lower()))
    if not takes: sys.exit(f"no video files in {folder}")
    job = name; k = 2
    if "--fresh" in a:      # a new project every time: never reuse (and rewrite) one that has the same name
        while (PROJECTS/job).exists(): job = f"{name}-{k}"; k += 1
    while (PROJECTS/job).exists() and not (PROJECTS/job/"edit/studio.json").exists(): job = f"{name}-{k}"; k += 1
    print(f"New edit: {job} · {FORMATS[fmt]} · {len(takes)} take(s) from {folder}", flush=True)

    # one source: the take itself, or the takes joined beside them on the same drive
    starts, t = [], 0.0
    for p in takes: starts.append({"file": p.name, "at": round(t, 3), "dur": round(dur(p), 3)}); t += starts[-1]["dur"]
    if len(takes) == 1:
        src = takes[0]
    else:
        sigs = {sig(p) for p in takes}
        if len(sigs) > 1: sys.exit("these takes were shot with different settings (size, frame rate or codec), so they cannot be joined "
                                   "without re-encoding: " + "; ".join(sorted(sigs)))
        out = folder/".cineyap"; out.mkdir(exist_ok=True)
        src = out/f"{job}-takes{takes[0].suffix.lower()}"
        if not src.exists() or src.stat().st_size < 1000:
            lst = out/f"{job}-takes.txt"
            lst.write_text("".join("file '" + pathlib.Path(p).as_posix().replace("'", "'\\''") + "'\n" for p in takes))      # forward slashes: ffmpeg reads a backslash as an escape
            run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-map", "0:v:0", "-map", "0:a:0?", "-c", "copy",
                 "-movflags", "+faststart", src])
        print(f"  joined {len(takes)} takes into {src} ({t / 60:.1f} min)", flush=True)

    J = PROJECTS/job
    if not (J/"build/mkedl.py").exists():
        lut = []
        if "--no-lut" in a: lut = [""]
        elif "--lut" in a: lut = [a[a.index("--lut") + 1]]
        run([PY, HERE/"newjob.py", job, src] + lut)
    st = {"folder": str(folder), "format": fmt, "format_name": FORMATS[fmt], "source": str(src), "takes": starts,
          "created": time.strftime("%Y-%m-%d %H:%M"), "stage": "radio"}
    (J/"edit").mkdir(parents=True, exist_ok=True); (J/"edit/studio.json").write_text(json.dumps(st, indent=1))

    if not list((J/"edit/transcripts").glob("*.json")) if (J/"edit/transcripts").exists() else True:
        run([PY, PKG/"helpers/transcribe.py", src, "--edit-dir", J/"edit"])      # (not ./vu: Windows can't start a bash script directly)
    run([PY, HERE/"rank_takes.py"], cwd=J/"build")
    print(f"  takes ranked: {J/'edit/takes_ranked.md'}", flush=True)
    print("next: write the radio cut (RADIO-CUT.md), then ./vu-py cineyap/radio_script.py " + job + " --audio", flush=True)
    print(f"JOB: {job}", flush=True)

if __name__ == "__main__":
    main()
