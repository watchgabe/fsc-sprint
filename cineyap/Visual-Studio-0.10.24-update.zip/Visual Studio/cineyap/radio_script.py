#!/usr/bin/env python3
"""radio_script.py <job> [--audio] — the radio cut as a script you can read while you listen.

    ./vu-py cineyap/radio_script.py <job>            -> projects/<job>/edit/radio_cut.md (and prints it)
    ./vu-py cineyap/radio_script.py <job> --audio    -> also edit/radio_cut.m4a, the cut as sound only

One row per kept line of the cut (edit/edl.json, in play order): what is said, how long it runs, where it
lands on the clock, and the things an editor's ear catches that a transcript hides: a pause inside the
line longer than PAUSE_S, filler words left in, a line that repeats an earlier one, a line too long to
hold. Judgement (is the hook strong, does the order flow, which take has the energy) stays with Claude and
the person; this only puts the facts in front of them.
"""
import json, pathlib, re, subprocess, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PROJECTS

PAUSE_S = 0.6          # a gap between two words inside a kept line longer than this is heard as dead air
LONG_S = 9.0           # a single line longer than this is hard to hold on a phone; consider a split or a trim
FILLERS = {"um", "uh", "erm", "ah", "basically", "literally", "kind of", "sort of"}   # not "like" or "you know": too often real words

def norm(s): return re.sub(r"[^a-z0-9' ]", "", s.lower()).strip()

def words_in(T, a, b):
    return [w for w in T if w.get("type") == "word" and w["start"] >= a - 0.02 and w["end"] <= b + 0.05]

def main():
    if len(sys.argv) < 2: sys.exit(__doc__)
    job = sys.argv[1]; E = PROJECTS/job/"edit"
    edl = json.load(open(E/"edl.json")); trans = {}
    for src in edl["sources"]:
        f = E/"transcripts"/f"{src}.json"
        trans[src] = json.load(open(f))["words"] if f.exists() else []
    rows, clock, seen = [], 0.0, []
    for i, r in enumerate(edl["ranges"], 1):
        a, b = r["start"], r["end"]; d = b - a; W = words_in(trans.get(r["source"], []), a, b)
        text = r.get("quote") or " ".join(w["text"] for w in W)
        pauses = [(round(W[k]["end"] - a, 1), round(W[k + 1]["start"] - W[k]["end"], 1)) for k in range(len(W) - 1)
                  if W[k + 1]["start"] - W[k]["end"] > PAUSE_S]
        lw = [norm(w["text"]) for w in W]; joined = " " + " ".join(lw) + " "
        fill = sorted({f for f in FILLERS if f" {f} " in joined})
        key = set(x for x in norm(text).split() if len(x) > 3)
        rep = next((j for j, k in seen if len(key) >= 4 and len(key & k) / max(1, len(key)) > 0.6), None)   # a short line shares words by chance
        seen.append((i, key))
        flags = []
        if pauses: flags.append("pause " + ", ".join(f"{g}s at {t}s" for t, g in pauses))
        if fill: flags.append("filler: " + ", ".join(fill))
        if rep: flags.append(f"repeats line {rep}")
        if d > LONG_S: flags.append(f"long ({d:.1f}s)")
        rows.append({"n": i, "at": clock, "dur": d, "beat": r.get("beat", ""), "text": text, "flags": flags,
                     "take": r.get("reason", "")})
        clock += d
    m = lambda s: f"{int(s // 60)}:{int(round(s % 60)):02d}" if round(s % 60) < 60 else f"{int(s // 60) + 1}:00"
    out = [f"# Radio cut · {job}", "",
           f"**{len(rows)} lines · {m(clock)}**. Listen first, read second. Reply by line number: cut 4, move 7 after 2, "
           "swap 3 for the other take, start 5 at \"the\", end 6 after \"done\". Say **lock it** when the flow is right.", "",
           "| # | at | len | beat | what is said | flags |", "|---|---|---|---|---|---|"]
    for r in rows:
        t = r["text"] if len(r["text"]) <= 90 else r["text"][:87] + "…"
        out.append(f"| {r['n']} | {m(r['at'])} | {r['dur']:.1f}s | {r['beat']} | {t} | {'; '.join(r['flags'])} |")
    md = "\n".join(out) + "\n"
    (E/"radio_cut.md").write_text(md); print(md)
    (E/"radio_cut.json").write_text(json.dumps({"lines": len(rows), "runtime_s": round(clock, 2), "made": int(__import__("time").time()),
        "rows": [{k: (round(v, 2) if isinstance(v, float) else v) for k, v in r.items()} for r in rows]}, ensure_ascii=False, indent=1))
    if "--audio" in sys.argv:
        base = PROJECTS/job/"build/base_clean.mp4"
        if not base.exists(): sys.exit(f"no {base}: render the cut first (step 7)")
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(base), "-vn", "-c:a", "aac", "-b:a", "160k", str(E/"radio_cut.m4a")], check=True)
        print(f"audio: {E/'radio_cut.m4a'}")

if __name__ == "__main__":
    main()
