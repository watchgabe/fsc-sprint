"""Where the package is, found from this file - never from a hardcoded path.

Everything resolves off PKG so the folder can live anywhere and be renamed.
"""
import pathlib, sys
PKG      = pathlib.Path(__file__).resolve().parent.parent   # the CineYap folder
CINEYAP  = PKG / "cineyap"
HELPERS  = PKG / "helpers"
PROJECTS = PKG / "projects"                                  # jobs live inside the package
# the tools install.sh downloads into the folder (ffmpeg, ffprobe, node, npx, uv: no Homebrew, 2026-10-25) come first on PATH,
# so every script and every subprocess finds them however it was started
import os
for _TOOLS in (PKG / "_local/node", PKG / "_local/bin"):      # _local/node: Node's own folder on Windows (npx.cmd lives with node.exe)
    if _TOOLS.is_dir() and str(_TOOLS) not in os.environ.get("PATH", "").split(os.pathsep):
        os.environ["PATH"] = str(_TOOLS) + os.pathsep + os.environ.get("PATH", "")
for p in (str(CINEYAP), str(HELPERS)):
    if p not in sys.path:
        sys.path.insert(0, p)
from plat import PY      # .venv/bin/python, or .venv\Scripts\python.exe on Windows
# every process this one starts reads and writes text as UTF-8 (Windows' default code page breaks on a curly quote)
os.environ["PYTHONUTF8"] = "1"; os.environ["PYTHONIOENCODING"] = "utf-8"
