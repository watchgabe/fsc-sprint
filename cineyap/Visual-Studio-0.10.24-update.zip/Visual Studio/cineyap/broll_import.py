#!/usr/bin/env python3
"""broll_import.py — grow and fix the B-roll library from Loop Studio's Media tab (2026-10-22). Standard library only: the Studio's
server Python imports this (no numpy, no PIL).

UPLOAD THAT SPLITS SEQUENCES. Media's Upload (or files dropped from Finder) lands each video in a staging folder, then:
  - every hard cut is found (ffmpeg scene detection at 0.15, the same as broll_sort.py split), shots under 2 s are dropped, 4 frames
    are shaved off each end so no clip carries a frame of its neighbour, and each shot is written starting at 0.000 s at its native
    resolution (the same encode as broll_sort.py split);
  - Claude looks at every shot (broll_index.describe, Sonnet) for its description, tags and the folder it belongs in;
  - each shot is fingerprinted and checked against the library's look-alikes (broll_index's dHash);
  - log footage is spotted (studio.probe_video, passed in) so the LUT in config.json can be baked in.
  One shot that isn't log goes straight into its suggested folder under its own file name. Anything else shows the shot sheet;
  "Add N clips" writes <Folder>/<Base name> - <what's in it>_NN.mp4 on the drive ("Contorno - Lighting a candle_05.mp4", Gabe
  2026-10-22: the shoot, then 3-6 words from the shot's description in sentence case, by Haiku), never over an existing file (_2, _3, ...), and writes each clip's
  description and fingerprint straight into broll_index.json, so it is searchable at once without being looked at twice.

CLIP EDITOR. Trim in/out (whole frames) and grade (exposure, contrast, saturation, warmth: the editor's Color correction maths through the grade
engine, timeline_tools.grade_vf; plus the LUT on or off). Save never touches the clip (Gabe, 2026-10-22: old edits keep showing the clip they
were built with): it writes a NEW clip beside it, "<name> (edit).mp4", then "(edit 2)", ..., indexed with the original's description
and a fresh fingerprint. Editing an edited copy starts again from its original, with that edit loaded, and saves another new copy.
"Delete this copy" on an edited copy deletes it. What each copy is made of: .loop_broll/edits.json {copy rel: {source, in, out, cc, lut}}.

Where the working files live: next to the library, never inside it (every scanner of the library — Media, broll_index, find_broll,
boards.resolve_clip by file name, build_review, mkreel, mkpanel — walks it with rglob and would pick up a hidden copy):
  <parent of broll_clips>/.loop_broll/import/<id>/      staging for one upload: src/ (the uploaded copy), shots/, thumbs/, job.json
  <parent of broll_clips>/.loop_broll/edits.json        each edited copy: its source clip and the edit
  <parent of broll_clips>/.loop_broll/previews/          the clip editor's LUT preview copies
Same drive as the library, so finished clips move in by rename. The original upload is never touched (the browser sends a
copy), and the staging folder is deleted once the clips are in.
"""
import concurrent.futures as cf, hashlib, json, os, pathlib, re, shutil, subprocess, sys, tempfile, threading, time, uuid

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import config, broll_index, plat
from timeline_tools import grade_recipe, grade_vf

VIDEO = (".mp4", ".mov", ".m4v")
THRESHOLD, MIN_SHOT, TRIM_FRAMES = 0.15, 2.0, 4          # broll_sort.py split's defaults
JOBS = {}                                                # import id -> its job (also saved as job.json in its staging folder)
LOCK = threading.Lock()


# ---------------------------------------------------------------------------------------------------- where things live
def clips_root():
    r = config.opt("broll_clips")
    if not r or not pathlib.Path(r).is_dir(): raise RuntimeError("The B-roll library isn't there. Is the drive plugged in?")
    return pathlib.Path(r)

def loop_dir(): return clips_root().parent/".loop_broll"

def renamed():
    try: return json.loads((pathlib.Path(__file__).parent/"library_map.json").read_text()).get("renamed", {})
    except Exception: return {}

def drive_folders():
    """the library's folders on the drive (top level and sub-folders), as [{folder, label}]: label is the name Loop shows"""
    root = clips_root(); m = renamed(); out = []
    for d in sorted(p for p in root.rglob("*") if p.is_dir()):
        rel = str(d.relative_to(root))
        if any(x.startswith((".", "_")) for x in rel.split("/")): continue
        out.append({"folder": rel, "label": m.get(rel, rel)})
    return out

def safe_name(s):
    s = re.sub(r"[/:\\]+", "-", str(s or "")).strip().lstrip(".")
    return s[:120] or "Clip"

def safe_folder(s):
    parts = [safe_name(x) for x in re.split(r"/+", str(s or "").strip("/ ")) if x.strip() and x.strip() not in (".", "..")]
    return "/".join(parts) or "Added in Studio"

def unique(dst):
    """never overwrite: name.mp4, name_2.mp4, name_3.mp4, ..."""
    dst = pathlib.Path(dst); k = 2; out = dst
    while out.exists(): out = dst.with_name(f"{dst.stem}_{k}{dst.suffix}"); k += 1
    return out


# ---------------------------------------------------------------------------------------------------- ffmpeg helpers (as broll_sort.py)
def probe(p):
    """{w, h, fps, dur, audio}"""
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height,r_frame_rate:format=duration",
                        "-of", "json", str(p)], capture_output=True, text=True, timeout=120)
    j = json.loads(r.stdout or "{}"); v = next((s for s in j.get("streams", []) if s.get("codec_type") == "video"), {})
    n, d = (v.get("r_frame_rate") or "24/1").split("/")
    return {"w": int(v.get("width") or 0), "h": int(v.get("height") or 0), "fps": float(n) / float(d or 1) or 24.0,
            "fps_s": v.get("r_frame_rate") or "24/1", "dur": float((j.get("format") or {}).get("duration") or 0),
            "audio": any(s.get("codec_type") == "audio" for s in j.get("streams", []))}

def cuts_in(p, threshold=THRESHOLD, on_progress=None, dur=0):
    """every hard cut (seconds), broll_sort.cuts_in, reading ffmpeg's progress so the sheet can show how far it got"""
    pr = subprocess.Popen(["ffmpeg", "-hide_banner", "-nostats", "-progress", "pipe:2", "-i", str(p), "-vf",
                           f"select='gt(scene,{threshold})',metadata=print", "-an", "-f", "null", "-"],
                          stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True)
    cuts = []
    for line in pr.stderr:
        m = re.search(r"pts_time:([0-9.]+)", line)
        if m: cuts.append(float(m.group(1))); continue
        m = re.match(r"out_time_us=(\d+)", line)
        if m and on_progress and dur: on_progress(min(1.0, int(m.group(1)) / 1e6 / dur))
    pr.wait()
    return sorted(set(cuts))

def kbps_for(w, h): return int(max(12000, min(60000, 60000 * (w * h) / (3840 * 2160))))      # 60 Mbps at 4K, scaled by pixels

def lut_filter(lut): return "lut3d=file='" + str(lut).replace("\\", "/").replace("'", "\\'").replace(":", "\\:") + "'"

def encode(src, a, b, dst, info, vf="", frames=None):
    """[a, b) of src -> dst, starting at 0.000 s, native resolution, h264 (broll_sort.py split's encode). frames = exact frame count"""
    chain = ",".join(x for x in ("setpts=PTS-STARTPTS", vf, "format=yuv420p") if x)
    cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{a:.4f}", "-i", str(src)]
    if frames: cmd += ["-frames:v", str(frames)]
    cmd += ["-map", "0:v:0", "-map", "0:a:0?", "-vf", chain, "-af", "asetpts=PTS-STARTPTS", "-t", f"{b - a:.4f}",
            "-c:v", plat.H264_HW or "libx264", "-b:v", f"{kbps_for(info['w'], info['h'])}k", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(dst)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode or not pathlib.Path(dst).exists():
        raise RuntimeError("ffmpeg: " + (r.stderr.strip().splitlines() or ["it stopped"])[-1])

def jpeg(src, t, dst, w=480):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{max(0, t):.3f}", "-i", str(src), "-frames:v", "1", "-vf", f"scale={w}:-2",
                    "-q:v", "5", str(dst)], capture_output=True, timeout=120)


# ---------------------------------------------------------------------------------------------------- an upload
def save_job(J):
    try: (pathlib.Path(J["dir"])/"job.json").write_text(json.dumps({k: v for k, v in J.items() if not k.startswith("_")}, indent=1))
    except OSError: pass

def new_import():
    iid = time.strftime("%Y%m%d-%H%M%S-") + uuid.uuid4().hex[:4]; d = loop_dir()/"import"/iid
    (d/"src").mkdir(parents=True, exist_ok=True)
    J = {"id": iid, "dir": str(d), "state": "uploading", "step": "", "progress": 0.0, "files": [], "shots": [], "error": "",
         "lut": config.opt("lut") or "", "folders": drive_folders(), "added": [], "started": time.time()}
    JOBS[iid] = J; save_job(J); return J

def receive(iid, name, rfile, n):
    """one uploaded file's bytes -> staging/src (the browser sends a copy; the original stays where it was)"""
    J = JOBS[iid]; dst = unique(pathlib.Path(J["dir"])/"src"/safe_name(pathlib.Path(name).name))
    with open(dst, "wb") as fh:
        left = n
        while left > 0:
            chunk = rfile.read(min(1 << 20, left))
            if not chunk: break
            fh.write(chunk); left -= len(chunk)
    J["files"].append({"name": pathlib.Path(name).name, "path": str(dst), "base": pathlib.Path(name).stem}); save_job(J)
    return J

def start(iid, probe_video):
    J = JOBS[iid]; J["state"] = "working"
    threading.Thread(target=_analyse, args=(J, probe_video), daemon=True).start(); return J

def _analyse(J, probe_video):
    try: analyse(J, probe_video)
    except Exception as e: J.update(state="error", error=str(e)[:300]); save_job(J)

def analyse(J, probe_video):
    d = pathlib.Path(J["dir"]); (d/"shots").mkdir(exist_ok=True); (d/"thumbs").mkdir(exist_ok=True)
    nf = len(J["files"]); shots = []
    for fi, F in enumerate(J["files"]):
        src = pathlib.Path(F["path"]); info = probe(src); F.update(info=info)
        J["step"] = f"Looking for cuts in {F['name']}" + (f" ({fi + 1} of {nf})" if nf > 1 else ""); save_job(J)
        F["log"] = bool(probe_video(str(src)).get("log"))
        cuts = cuts_in(src, on_progress=lambda x: J.update(progress=(fi + x * .5) / nf), dur=info["dur"])
        trim = TRIM_FRAMES / info["fps"]; bounds = [0.0] + [c for c in cuts if 0 < c < info["dur"]] + [info["dur"]]
        whole = len(bounds) == 2
        spans = [(0.0, info["dur"])] if whole else [(a + trim, b - trim) for a, b in zip(bounds, bounds[1:]) if b - a - 2 * trim >= MIN_SHOT]
        F.update(cuts=len(bounds) - 2, single=len(spans) == 1, whole=whole)
        for k, (a, b) in enumerate(spans):
            sid = len(shots) + 1; J["step"] = f"Cutting shot {k + 1} of {len(spans)} from {F['name']}"
            J["progress"] = (fi + .5 + .5 * k / len(spans)) / nf; save_job(J)
            if whole: staged = src                                   # one shot, nothing cut: the upload itself
            else: staged = d/"shots"/f"{sid:03d}.mp4"; encode(src, a, b, staged, info)
            th = d/"thumbs"/f"{sid:03d}.jpg"; jpeg(staged, (b - a) / 2, th)
            shots.append({"id": sid, "file": fi, "start": round(a, 4), "end": round(b, 4), "secs": round(b - a, 2), "staged": str(staged),
                          "thumb": str(th), "w": info["w"], "h": info["h"], "log": F["log"], "name": "", "folder": "", "alike": []})
    J.update(shots=shots, step="Checking for look-alikes in your library", progress=0.0); save_job(J)
    alike(J)
    J["step"] = f"Looking at what's in {len(shots)} shot" + ("s" if len(shots) != 1 else ""); save_job(J)
    describe_all(J)
    short_names(J)
    for s in shots:      # names: the file's own name for a lone shot, "<file> - <what's in it>_NN" for the shots of a sequence
        F = J["files"][s["file"]]; seq = [x for x in shots if x["file"] == s["file"]]
        s["name"] = F["base"] if len(seq) == 1 else f"{F['base']} - {s['short']}_{seq.index(s) + 1:02d}"
    J.update(state="ready", step="", progress=1.0); save_job(J)

def alike(J):
    """each new shot against the library: same footage when two of its three frames match a clip's (broll_index.look_alike's rule)"""
    ix = broll_index.by_clip()
    def fp(s): return broll_index.fingerprint({"path": s["staged"], "start": 0.0, "end": s["secs"]})
    with cf.ThreadPoolExecutor(6) as ex:
        for s, f in zip(J["shots"], ex.map(fp, J["shots"])): s["dh"] = f["dh"]
    for s in J["shots"]:
        A = [x for x in s["dh"] if x]
        if not A: continue
        hits = []
        for rel, e in ix.items():
            B = [x for x in (e.get("dh") or []) if x]
            if not B: continue
            best = [min(broll_index.ham(a, b) for b in B) for a in A]
            if sum(1 for x in best if x <= 12) >= min(2, len(A), len(B)): hits.append((sum(sorted(best)[:2]), rel, e.get("description", "")))
        s["alike"] = [{"clip": r, "description": dsc} for _, r, dsc in sorted(hits)[:3]]

def describe_all(J):
    """Claude's look at every shot (Sonnet, ~$0.005 a shot): description, tags and the folder it belongs in"""
    folders = [f["folder"] for f in J["folders"]]; low = {f.lower(): f for f in folders}
    units = [{"path": s["staged"], "start": 0.0, "end": s["secs"], "rel": pathlib.Path(J["files"][s["file"]]["name"]).name,
              "folder": "new upload", "key": f"import|{J['id']}|{s['id']}"} for s in J["shots"]]
    batches = [list(range(i, min(i + broll_index.BATCH, len(units)))) for i in range(0, len(units), broll_index.BATCH)]
    try: cl = broll_index.claude_bin()
    except Exception as e: J["error"] = str(e); return
    tmp = tempfile.mkdtemp(prefix="broll_import_"); done = [0]
    def work(ids):
        for attempt in range(3):
            try: return ids, broll_index.describe([units[i] for i in ids], folders, cl, tmp)[0]
            except Exception: time.sleep(3 * (attempt + 1))
        return ids, [None] * len(ids)
    try:
        with cf.ThreadPoolExecutor(4) as ex:
            for ids, res in ex.map(work, batches):
                for i, x in zip(ids, res):
                    if not x: continue
                    s = J["shots"][i]; c = broll_index.clean(x); s["about"] = c
                    sug = c.get("suggested_folder", "").strip("/"); s["folder"] = low.get(sug.lower(), sug)
                done[0] += len(ids); J["progress"] = done[0] / max(1, len(units)); save_job(J)
    finally: shutil.rmtree(tmp, ignore_errors=True)
    for s in J["shots"]:
        if not s["folder"]: s["folder"] = "Added in Studio"

def load_jobs():
    """uploads still in staging after a restart: a finished sheet can be picked up again; one cut off mid-way says so"""
    try:
        for f in (loop_dir()/"previews").glob("*.mp4"):      # the clip editor's LUT previews: a week is plenty
            if time.time() - f.stat().st_mtime > 7 * 86400: f.unlink()
    except Exception: pass
    try: dirs = sorted((loop_dir()/"import").iterdir())
    except Exception: return
    for d in dirs:
        try: J = json.loads((d/"job.json").read_text())
        except Exception: continue
        if J.get("state") in ("uploading", "working", "adding"): J.update(state="error", error="The Studio restarted while this upload was being worked on. Upload it again.")
        JOBS.setdefault(J["id"], J)

def pending():
    """uploads waiting on their shot sheet"""
    return [{"id": J["id"], "files": [F["name"] for F in J["files"]], "shots": len(J["shots"])} for J in JOBS.values() if J.get("state") == "ready"]

SHORT = """Each line below describes one B-roll shot. For each, write a short file-name phrase of 3 to 6 words saying what is in the
shot, in sentence case, no full stop, no "a man" / "a woman" (say what happens or what is seen): "Lighting a candle", "Reading on
the sofa", "Loft office wide", "Barbell deadlift in the gym". Reply with ONLY a JSON array of strings, one per line, in order.

{lines}"""

def fallback_short(d):
    w = re.sub(r"^(a|an|the)\s+(man|woman|couple|group|person|pair)\s+", "", (d or "").strip().rstrip("."), flags=re.I).split()
    return (" ".join(w[:5]) or "Shot").capitalize()

def short_names(J):
    """3-6 words per shot for its file name, from its description (one cheap text-only Haiku question for the whole upload)"""
    S = [s for s in J["shots"] if len([x for x in J["shots"] if x["file"] == s["file"]]) > 1]
    if not S: return
    got = []
    try:
        out = broll_index.ask(SHORT.format(lines="\n".join(f"{n}. {(s.get('about') or {}).get('description', '')}" for n, s in enumerate(S, 1))),
                              model="haiku", timeout=180)
        got = json.loads(out[out.index("["): out.rindex("]") + 1])
    except Exception: pass
    for n, s in enumerate(S):
        g = got[n] if n < len(got) and isinstance(got[n], str) else ""
        g = re.sub(r"[/:\\_]+", " ", g).strip().rstrip(".")
        s["short"] = (g[:1].upper() + g[1:]) if 1 <= len(g.split()) <= 8 else fallback_short((s.get("about") or {}).get("description"))

def status(iid):
    J = JOBS.get(iid)
    if not J: return {"state": "gone", "error": "That upload isn't here any more."}
    return {k: v for k, v in J.items() if not k.startswith("_")}

def cancel(iid):
    J = JOBS.pop(iid, None)
    if J: shutil.rmtree(J["dir"], ignore_errors=True)
    return {"ok": True}


# ---------------------------------------------------------------------------------------------------- Add N clips
def add(iid, outs, lib_fn=None):
    """outs = [{shots: [shot ids, in order, joined], name, folder, lut: bool}], from the shot sheet. Runs in the background"""
    J = JOBS[iid]
    if J["state"] != "ready": raise RuntimeError("That upload isn't ready yet.")
    J.update(state="adding", step="Adding your clips", progress=0.0, added=[]); save_job(J)
    threading.Thread(target=_add, args=(J, outs, lib_fn), daemon=True).start(); return status(iid)

def _add(J, outs, lib_fn):
    try:
        root = clips_root(); d = pathlib.Path(J["dir"]); by = {s["id"]: s for s in J["shots"]}; lut = J.get("lut") or ""
        entries = []
        for k, o in enumerate(outs):
            S = [by[i] for i in o["shots"] if i in by]
            if not S: continue
            F = J["files"][S[0]["file"]]; info = F["info"]; src = pathlib.Path(F["path"])
            bake = bool(o.get("lut")) and lut and pathlib.Path(lut).exists()
            J["step"] = f"Writing {safe_name(o.get('name'))} ({k + 1} of {len(outs)})"; J["progress"] = k / len(outs); save_job(J)
            folder = root/safe_folder(o.get("folder")); folder.mkdir(parents=True, exist_ok=True)
            one = len(S) == 1 and not bake
            ext = pathlib.Path(S[0]["staged"]).suffix.lower() if one else ".mp4"
            dst = unique(folder/(safe_name(o.get("name")) + (ext if ext in VIDEO else ".mp4")))
            if one: shutil.move(S[0]["staged"], dst)                  # already cut (or a lone shot): it just moves in
            else:                                                     # joined shots, or the LUT baked in: cut again from the upload
                tmp = d/f"out_{k:03d}.mp4"; a, b = S[0]["start"], S[-1]["end"]
                encode(src, a, b, tmp, info, lut_filter(lut) if bake else ""); shutil.move(tmp, dst)
            rel = str(dst.relative_to(root)); about = dict(S[0].get("about") or {})
            if len(S) > 1: about.pop("description", None)             # joined: looked at again by the index
            entries.append({"rel": rel, "path": str(dst), "secs": round(S[-1]["end"] - S[0]["start"], 2), "about": about, "folder": safe_folder(o.get("folder"))})
            J["added"].append(rel)
        J.update(step="Adding them to the search index", progress=1.0); save_job(J)
        index_add(entries)
        if lib_fn: broll_index.start_background(lib_fn)      # anything not looked at yet, and the shoot's sequences (2026-10-23)
        J.update(state="done", step=""); save_job(J)
        shutil.rmtree(d, ignore_errors=True)                          # the staging copy; the original upload is untouched
    except Exception as e:
        J.update(state="error", error=str(e)[:300]); save_job(J)

def index_add(entries, wait=90):
    """write the new clips straight into broll_index.json (their description from the sheet, a fresh fingerprint). Waits for an index
    run in progress (it saves its own copy of the index and would undo ours); False if it couldn't get in"""
    broll_index.LOCKF.parent.mkdir(exist_ok=True); lf = open(broll_index.LOCKF, "w"); t0 = time.time()
    while True:
        if plat.lock(lf, wait=False): break
        if time.time() - t0 > wait: lf.close(); return False
        time.sleep(2)
    try:
        ix = broll_index.load_index(); S = ix.setdefault("shots", {})
        for e in entries:
            if not e["about"].get("description"): continue
            p = pathlib.Path(e["path"]); mt = int(p.stat().st_mtime)
            u = {"path": str(p), "root": "clips", "rel": e["rel"], "start": 0.0, "end": e["secs"], "mtime": mt, "folder": str(pathlib.Path(e["rel"]).parent)}
            ent = {**u, **{k: e["about"].get(k) for k in broll_index.FIELDS}}; ent["suggested_folder"] = ent["folder"]
            ent.update(broll_index.fingerprint(ent), dh_mtime=mt)
            S[broll_index.key({**u, "end": None})] = ent
        broll_index.save_index(ix); return True
    finally:
        plat.unlock(lf); lf.close()


# ---------------------------------------------------------------------------------------------------- the clip editor
def clip_path(rel):
    root = clips_root(); p = (root/rel).resolve()
    if not str(p).startswith(str(root.resolve()) + "/") or not p.is_file(): raise RuntimeError("That clip isn't in your library.")
    return p

def edits_file(): return loop_dir()/"edits.json"
def edits():
    try: return json.loads(edits_file().read_text())
    except Exception: return {}
def save_edits(E):
    f = edits_file(); f.parent.mkdir(parents=True, exist_ok=True); t = f.with_suffix(".tmp"); t.write_text(json.dumps(E, indent=1)); os.replace(t, f)

def source_of(rel):
    """an edited copy's original (when it is still there), else the clip itself; and the copy's edit"""
    e = edits().get(rel)
    if e:
        try: return clip_path(e["source"]), e["source"], e
        except Exception: pass
    return clip_path(rel), rel, {}

def clip_info(rel, probe_video):
    p = clip_path(rel); src, srel, edit = source_of(rel); info = probe(src)
    lut = config.opt("lut") or ""
    copies = sorted(k for k, v in edits().items() if v.get("source") == srel and (clips_root()/k).exists())
    return {"clip": rel, "path": str(p), "source": str(src), "source_rel": srel, "edited": bool(edit), "edit": edit, "copies": copies, **info,
            "frames": int(round(info["dur"] * info["fps"])), "log": bool(probe_video(str(src)).get("log")),
            "lut": lut if lut and pathlib.Path(lut).exists() else ""}

def lut_preview(rel):
    """a small copy of the clip (its original, for an edited copy) with the LUT baked in, for the editor's preview"""
    src = source_of(rel)[0]; lut = config.opt("lut") or ""
    if not lut or not pathlib.Path(lut).exists(): raise RuntimeError("No LUT is set (Brand tab).")
    key = hashlib.md5(f"{src}|{src.stat().st_mtime}|{lut}".encode()).hexdigest()[:16]; out = loop_dir()/"previews"/f"{key}.mp4"
    if not out.exists():
        out.parent.mkdir(parents=True, exist_ok=True); tmp = out.with_name(".tmp_" + out.name)
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-map", "0:v:0", "-vf", lut_filter(lut) + ",scale='min(1280,iw)':-2,format=yuv420p",
                            "-c:v", plat.H264_HW or "libx264", "-b:v", "8000k", "-an", "-movflags", "+faststart", str(tmp)], capture_output=True, text=True)
        if r.returncode: raise RuntimeError("ffmpeg: " + (r.stderr.strip().splitlines() or ["it stopped"])[-1])
        os.replace(tmp, out)
    return str(out)

def copy_name(src):
    """<name> (edit).mp4, then (edit 2), (edit 3)... beside the original; never over a file"""
    k = 1
    while True:
        out = src.with_name(f"{src.stem} (edit{'' if k == 1 else f' {k}'}).mp4")
        if not out.exists(): return out
        k += 1

def clip_save(rel, b, lib_fn=None):
    """{in, out (frames, out exclusive), cc: {exposure, contrast, saturation, warmth}, lut: bool} -> a NEW clip beside the original,
    "<name> (edit).mp4". The clip itself (and every edit that uses it) is never touched."""
    with LOCK:
        src, srel, _ = source_of(rel); info = probe(src)
        fps = info["fps"]; total = int(round(info["dur"] * fps))
        fi = max(0, min(total - 1, int(b.get("in", 0)))); fo = max(fi + 1, min(total, int(b.get("out", total))))
        cc = {k: float((b.get("cc") or {}).get(k, dv)) for k, dv in (("exposure", 0), ("contrast", 1), ("saturation", 1), ("warmth", 0))}
        lut = config.opt("lut") or ""; use_lut = bool(b.get("lut")) and lut and pathlib.Path(lut).exists()
        vf = grade_vf(grade_recipe(dict(cc, lut_on=bool(use_lut), lut=lut, lut_amt=1)))
        out = copy_name(src); tmp = out.with_name(f".loopedit_{uuid.uuid4().hex[:6]}.mp4")
        try: encode(src, fi / fps, fo / fps, tmp, info, vf, frames=fo - fi)
        except Exception: tmp.unlink(missing_ok=True); raise
        os.replace(tmp, out); new = str(out.relative_to(clips_root()))
        E = edits(); E[new] = {"source": srel, "in": fi, "out": fo, "frames": total, "fps": info["fps_s"], "cc": cc, "lut": bool(use_lut),
                               "saved": time.strftime("%Y-%m-%d %H:%M")}; save_edits(E)
    about = {k: v for k, v in (broll_index.by_clip().get(srel) or {}).items() if k in broll_index.FIELDS}
    def index():      # searchable at once with the original's description; a fresh fingerprint (the picture changed)
        if not index_add([{"rel": new, "path": str(out), "secs": round((fo - fi) / fps, 2), "about": about}]) or not about.get("description"):
            if lib_fn: broll_index.start_background(lib_fn)
    threading.Thread(target=index, daemon=True).start()
    return {"ok": True, "clip": new, "source": srel, "secs": round((fo - fi) / fps, 2)}

def clip_delete_copy(rel, lib_fn=None):
    """an edited copy made here: deleted from the drive (only ever a copy in edits.json; an original is never deleted)"""
    with LOCK:
        E = edits()
        if rel not in E: raise RuntimeError("Only an edited copy made here can be deleted; this clip is an original.")
        p = clip_path(rel); p.unlink(); p.with_name("._" + p.name).unlink(missing_ok=True)
        src = E.pop(rel)["source"]; save_edits(E)
    if lib_fn: broll_index.start_background(lib_fn)      # drops its index entry
    return {"ok": True, "source": src}
