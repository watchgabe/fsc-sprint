#!/usr/bin/env python3
"""Scene-detect every B-roll clip so each real shot becomes an addressable unit.

Solves two problems at once:
  - two picks from the same clip that are actually the same shot (looked like reuse)
  - a pick that spans an internal cut (looked like a glitch)
"""
import json, subprocess, pathlib, re
import sys as _s; _s.path.insert(0, str(__import__("pathlib").Path(__file__).parent))
from config import need as cfg_need
B = cfg_need("broll_root")
# every video in YOUR library, in its subfolders (2026-10-25: this was a fixed list of Gabe's own files)
FILES = sorted(str(p.relative_to(B)) for p in pathlib.Path(B).rglob("*")
               if p.suffix.lower() in (".mp4", ".mov", ".m4v") and not p.name.startswith(".") and "/_" not in "/" + str(p.relative_to(B)))
MIN = 1.6          # a shot shorter than this is not usable on its own
out = []
for rel in FILES:
    p = B / rel
    dur = float(subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
                                "-of","csv=p=0",str(p)],capture_output=True,text=True).stdout)
    r = subprocess.run(["ffmpeg","-hide_banner","-i",str(p),"-vf",
                        "select='gt(scene,0.30)',metadata=print","-an","-f","null","-"],
                       capture_output=True,text=True).stderr
    cuts = [float(m) for m in re.findall(r"pts_time:([0-9.]+)", r)]
    bounds = [0.0] + cuts + [dur]
    shots = []
    for i in range(len(bounds)-1):
        a,b = bounds[i], bounds[i+1]
        if b-a >= MIN:
            shots.append({"clip": rel, "path": str(p),
                          "start": round(a+0.25,2), "end": round(b-0.25,2),
                          "dur": round(b-a-0.5,2)})
    print(f"  {rel.split('/')[-1]:32} {dur:6.1f}s -> {len(cuts):3d} cuts, {len(shots):3d} usable shots")
    out += shots
json.dump(out, open(pathlib.Path(__file__).resolve().parent/"shots.json","w"), indent=1)      # cineyap/shots.json, wherever it is run from (2026-10-23: it landed in the root)
print(f"\n  {len(out)} usable shots total")
