#!/usr/bin/env python3
# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
"""broll_index.py — what is IN every B-roll shot, so Loop picks B-roll by content, not by folder or file name (2026-10-22).

Folder and file names lie: "Content/Content Creation_01" is a couple under a palm tree on a beach. This looks at three frames of
every shot and writes one plain description per shot, with tags and the folder the shot really belongs in.

  ./vu-py cineyap/broll_index.py              # index what is new or changed (resumable: Ctrl+C and run it again)
  ./vu-py cineyap/broll_index.py --redo       # describe everything again
  ./vu-py cineyap/broll_index.py --report     # the cleanup list: clips whose content doesn't fit their bucket
  ./vu-py cineyap/broll_index.py --sequences  # group every shoot into sequences again (text only, no frames)
  ./vu-py cineyap/broll_index.py --seq-report # every sequence with its shots' framing

You never have to run it: the Studio indexes new clips by itself, in the background (Gabe, 2026-10-22): a quick mtime scan when it
starts, a clip uploaded or dropped into Media, a clip un-hidden. Hidden clips (library_map.json) are skipped until un-hidden, and
entries for files that are gone from a plugged-in drive are dropped.

What gets indexed: every clip in `broll_clips` (the one-shot-per-file library the editor shows, one entry per file) and every
shot in shots.json (detect_shots.py's shots of the long files under `broll_root`; a file there with no shots is one entry).
Each entry: {path, root, rel, start, end, mtime, folder, description, place, action, objects, people, mood, tags, suggested_folder,
framing, angle, creative, seq, seq_name}.
Claude looks through Claude Code on this Mac (Sonnet: Haiku cost the same a batch and mixed up wide and medium; about $0.005 a
shot), with no tools, MCP or project files loaded. Standard library only: the Studio's server Python imports this.

SHOT SIZE AND SEQUENCES (Gabe, 2026-10-23): "a triplet of clips, ideally from the same shot: a wide, medium, tight version". Every
shot gets its framing (wide / medium / tight), whether it is also a creative shot, and its angle. The words are Gabe's, from his
Cinematic Storyteller's Guide (Chapter 06, Shot Variation Library): "wide, medium, tight, creative". Creative is a yes/no next to
the size (a tight shot through a doorway is both). Then a
text-only pass per shoot (sequences()) groups its shots into SEQUENCES: one moment filmed from several framings (the man at the
desk: wide of the room, medium at the laptop, tight on the hands). The first version builds a B-roll run from one sequence,
wide to tight, so it cuts like a scene. Shots already described only get the two new fields (FRAMING, same three frames).

Never moves, renames or writes anything on the drive. The cleanup suggestions only ever change Loop's own buckets
(library_map.json), and only when Gabe clicks one in the editor.
"""
import base64, concurrent.futures as cf, hashlib, json, os, pathlib, re, shutil, subprocess, sys, tempfile, threading, time

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import config, plat

PKG = pathlib.Path(__file__).resolve().parent.parent
INDEX = PKG/"cineyap/broll_index.json"
SHOTS = PKG/"cineyap/shots.json"
LIBMAP = PKG/"cineyap/library_map.json"
LOCKF = PKG/"_local/broll_index.lock"
VID = (".mp4", ".mov", ".m4v")
BATCH, WORKERS = 6, 8
MODEL = "sonnet"      # 2026-10-23: same cost as Haiku a batch (measured $0.089 vs $0.092 for 18 shots), and it tells wide from medium
FIELDS = ("description", "place", "action", "objects", "people", "mood", "tags", "suggested_folder", "framing", "angle", "creative", "camera")
FRAMINGS = ("wide", "medium", "tight")
ANGLES = ("eye level", "low", "high", "high level", "top-down", "ground level", "pov", "reverse pov", "over the shoulder", "aerial", "mounted")
STATUS = {"running": False, "todo": 0, "done": 0, "error": ""}      # the Studio's "Indexing N new clips…"

PROMPT = """You index a video creator's B-roll library so an editor can find shots by what is IN them. The creator is Gabe, a
content creator who films his own life: travel, remote work, filming content, fitness, retreats he runs. Each shot below is shown
as three frames (start, middle, end), labelled SHOT 1, SHOT 2, ... with its current folder and file name. The names are often
wrong or vague: describe only what you SEE.

For every shot give:
- description: ONE plain sentence of what happens, concrete and visual ("A man takes a camera out of a backpack on a sunny beach").
  Say "a man" / "a woman" / "a couple" / "a group"; no guesses about who they are.
- place: where it is, a few words ("beach", "airport gate", "home office", "rooftop at night", "gym", "car interior")
- action: the main action, a few words ("unpacking a camera", "typing on a laptop", "walking through a crowd")
- objects: up to 6 notable things in frame
- people: "none", "one man", "one woman", "couple", "small group", "crowd", or "hands only"
- mood: one or two words ("calm", "energetic", "cozy", "moody", "bright", "focused")
- tags: 6 to 12 short lowercase search words someone might type to find this shot (topics and things: "travel", "camera",
  "photography", "laptop", "coffee", "ocean", "sunset", "work", "workout", "drone", "city", "night", "talking head", ...)
{shot_rules}
- camera: true if anyone in the shot looks, talks or smiles into the camera at any point (presenting, a selfie, a talking head);
  false if they are just doing something and ignore the camera. B-roll never uses a camera = true shot.
- suggested_folder: the folder from FOLDERS this shot really belongs in. Keep its current folder when it fits. If none fits at
  all, a new short folder name in the same style ("Travel/Beach").

FOLDERS: {folders}

Reply with ONLY a JSON array, one object per shot in order, nothing else:
[{{"n": 1, "description": "...", "place": "...", "action": "...", "objects": [...], "people": "...", "mood": "...", "tags": [...],
"suggested_folder": "...", "framing": "...", "creative": false, "angle": "...", "camera": false}}]"""

SHOT_RULES = """- framing: how big the main subject is in the frame, exactly one of "wide", "medium", "tight". Judge the middle frame:
  wide = the PLACE is the picture: a person is small, head to toe with lots of room around them (shorter than about half the frame's
  height), or no person at all (a landscape, a street, a room, a building). medium = the person AND the place: cut off somewhere
  between the knees and the chest, or filling most of the frame's height; a desk or table with what is on it. tight = a DETAIL is the
  picture: a face, hands, one object filling the frame. A person seen from behind or over his shoulder is still medium when he fills a
  big part of the frame.
- creative: true when the shot is ALSO an unexpected perspective: shot through something (a doorway, a window, leaves, a glass), a
  reflection or mirror, a strong foreground obstruction, a camera mounted somewhere strange, or a frame within a frame. Most shots
  are false.
- angle: where the camera is, exactly one of "eye level", "low" (below, looking up), "high" (well above, looking down at the subject),
  "high level" (a little above eye level, angled slightly down), "top-down" (straight down: a desk from above, food on a table),
  "ground level" (on the floor: feet, wheels, the ground in the foreground), "pov" (through his own eyes: his hands in front of him),
  "reverse pov" (from where the thing he looks at or reaches for would be, back at him), "over the shoulder" (behind a person, his
  head or shoulder in the foreground), "aerial" (a drone), "mounted" (fixed to a car, bike, bag or object and moving with it)."""

FRAMING = """You label B-roll shots by camera framing so an editor can cut a wide, medium and tight of one scene together. Each shot
below is shown as three frames (start, middle, end), labelled SHOT 1, SHOT 2, ...

For every shot give:
{shot_rules}

Reply with ONLY a JSON array, one object per shot in order, nothing else:
[{{"n": 1, "framing": "...", "creative": false, "angle": "..."}}]"""


# ---------------------------------------------------------------------------------------------------- what there is to index
def claude_bin():
    for c in (config.opt("claude"), shutil.which("claude"), *map(str, plat.claude_candidates())):
        if c and pathlib.Path(c).exists(): return c
    raise RuntimeError("Claude Code was not found on this Mac (it does the looking).")

def probe_dur(p):
    try: return float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)],
                                     capture_output=True, text=True, timeout=60).stdout.strip())
    except Exception: return 0.0

def videos(root):
    root = pathlib.Path(root)
    return sorted(p for p in root.rglob("*") if p.suffix.lower() in VID and not p.name.startswith(".")
                  and "/_" not in "/" + str(p.relative_to(root)))

def hidden():
    try: return set(json.loads(LIBMAP.read_text()).get("hidden", []))
    except Exception: return set()

def key(u):
    """a whole file is path|full (its length is only measured when it is looked at); a shot is path|start|end"""
    return f'{u["path"]}|full' if u.get("end") is None else f'{u["path"]}|{float(u["start"]):.2f}|{float(u["end"]):.2f}'

def units(skip_hidden=True):
    """every shot to index, as {key, path, root, rel, start, end (None = the whole file), mtime, folder}. Cheap: no ffprobe"""
    out = []; clips = config.opt("broll_clips"); broll = config.opt("broll_root"); hid = hidden() if skip_hidden else set()
    if clips and pathlib.Path(clips).is_dir():
        for p in videos(clips):
            rel = str(p.relative_to(clips))
            if rel in hid: continue
            out.append({"path": str(p), "root": "clips", "rel": rel, "start": 0.0, "end": None, "folder": str(pathlib.Path(rel).parent)})
    if broll and pathlib.Path(broll).is_dir() and broll != clips:
        have = {}
        for s in (json.loads(SHOTS.read_text()) if SHOTS.exists() else []): have.setdefault(s["path"], []).append(s)
        for p in videos(broll):
            rel = str(p.relative_to(broll)); fold = str(pathlib.Path(rel).parent)
            for s in have.get(str(p)) or [{"start": 0.0, "end": None}]:
                out.append({"path": str(p), "root": "broll", "rel": rel, "start": float(s["start"]), "end": s["end"], "folder": fold})
    for u in out:
        try: u["mtime"] = int(pathlib.Path(u["path"]).stat().st_mtime)
        except OSError: u["mtime"] = 0
        u["key"] = key(u)
    return out

def load_index():
    try: ix = json.loads(INDEX.read_text())
    except Exception: ix = {"version": 2, "shots": {}}
    if ix.get("version", 1) < 2:      # v1 keyed whole files by their measured length
        ix["shots"] = {(f'{e["path"]}|full' if e.get("root") == "clips" else k): e for k, e in ix["shots"].items()}; ix["version"] = 2
    return ix

def save_index(ix):
    tmp = INDEX.with_suffix(".json.tmp"); tmp.write_text(json.dumps(ix, indent=1, ensure_ascii=False)); os.replace(tmp, INDEX)


# ---------------------------------------------------------------------------------------------------- looking
def frames(u, tmp):
    """three JPEGs (15%, 50%, 85% into the shot), 512 wide, base64"""
    if u["end"] is None: u["end"] = round(probe_dur(u["path"]), 2)
    a, b = float(u["start"]), float(u["end"] or 0); d = max(0.1, b - a); out = []
    for i, f in enumerate((0.15, 0.5, 0.85)):
        t = a + d * f; jp = pathlib.Path(tmp)/f"{abs(hash(u['key']))}_{i}.jpg"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", u["path"], "-frames:v", "1",
                        "-vf", "scale=512:-2", "-q:v", "6", str(jp)], capture_output=True, timeout=120)
        if jp.exists() and jp.stat().st_size > 500: out.append(base64.b64encode(jp.read_bytes()).decode()); jp.unlink()
    return out

def describe(batch, folders, cl, tmp, only_framing=False):
    """Claude looks at each shot: the whole entry (PROMPT), or only its framing and angle (FRAMING, for shots described before 2026-10-23)"""
    content = [{"type": "text", "text": FRAMING.format(shot_rules=SHOT_RULES) if only_framing
                else PROMPT.format(folders=", ".join(folders), shot_rules=SHOT_RULES)}]
    for n, u in enumerate(batch, 1):
        fr = frames(u, tmp)
        content.append({"type": "text", "text": f"SHOT {n}: folder \"{u['folder']}\", file \"{pathlib.Path(u['rel']).name}\", "
                                                f"{float(u['end'] or 0) - float(u['start']):.1f}s" + ("" if fr else " (no frames could be read)")})
        content += [{"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": b}} for b in fr]
    msg = {"type": "user", "message": {"role": "user", "content": content}}
    r = subprocess.run([cl, "-p", "--model", MODEL, "--input-format", "stream-json", "--output-format", "stream-json", "--verbose",
                        "--max-turns", "2", "--system-prompt", "You describe video shots for a searchable B-roll index. Answer with JSON only.",
                        "--tools", "", "--strict-mcp-config", "--setting-sources", "", "--disable-slash-commands"],
                       cwd=tmp, input=json.dumps(msg) + "\n", capture_output=True, text=True, timeout=600)
    res = next((json.loads(l) for l in r.stdout.splitlines() if l.startswith("{") and '"type":"result"' in l.replace(" ", "")), None)
    if not res or res.get("is_error"): raise RuntimeError((res or {}).get("result") or r.stderr[-300:] or "no answer")
    out = res["result"]; arr = json.loads(out[out.index("["): out.rindex("]") + 1])
    got = {int(x.get("n", 0)): x for x in arr if isinstance(x, dict)}
    return [got.get(n) for n in range(1, len(batch) + 1)], float(res.get("total_cost_usd") or 0)

# ---------------------------------------------------------------------------------------------------- look alike (2026-10-22)
# Gabe: "some are basically the same, I want to remove some that are too close". Each clip gets a difference hash (dHash, 256 bits)
# of the same three frames the description uses, plus its size; look_alike() groups clips whose frames match. Plain Python and
# ffmpeg (the server's Python has no PIL or numpy).
def dhash(path, t):
    """256-bit difference hash of the frame at t: 17x16 grey, each pixel brighter than its right neighbour. None for a flat frame.
    (64 bits was too coarse: a man on a road and a man in a cornfield matched.)"""
    try:
        px = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", path, "-frames:v", "1", "-vf", "scale=17:16:flags=area,format=gray",
                             "-f", "rawvideo", "-"], capture_output=True, timeout=120).stdout
    except Exception: return None
    if len(px) < 272: return None
    m = sum(px[:272]) / 272
    if (sum((v - m) ** 2 for v in px[:272]) / 272) ** .5 < 4: return None      # black, white or a flat wall: matches everything
    return "%064x" % sum(1 << (y * 16 + x) for y in range(16) for x in range(16) if px[y * 17 + x] > px[y * 17 + x + 1])

def fingerprint(e):
    """{dh: [3 hashes], w, h} for an entry"""
    a, b = float(e["start"]), float(e["end"] or 0) or probe_dur(e["path"])
    try:
        w, h = (int(v) for v in subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                                                "-of", "csv=p=0", e["path"]], capture_output=True, text=True, timeout=60).stdout.strip().split(",")[:2])
    except Exception: w = h = 0
    return {"dh": [dhash(e["path"], a + (b - a) * f) for f in (0.15, 0.5, 0.85)], "w": w, "h": h}

def fill_hashes(S, log=print):
    """fingerprint every editor clip that has none yet (or whose file changed); called inside run(), under its lock"""
    todo = [e for e in S.values() if e.get("root") == "clips" and (e.get("dh") is None or e.get("dh_mtime") != e.get("mtime"))
            and pathlib.Path(e["path"]).exists()]
    if not todo: return
    log(f"  Fingerprinting {len(todo)} clips for Look alike…")
    with cf.ThreadPoolExecutor(WORKERS) as ex:
        for e, fp in zip(todo, ex.map(fingerprint, todo)): e.update(fp, dh_mtime=e.get("mtime"))

def ham(a, b): return bin(int(a, 16) ^ int(b, 16)).count("1")

def look_alike(lib=None):
    """groups of editor clips that are the same shot or nearly: [{"why", "keep", "clips": [{clip, bucket, secs, w, h, description}]}].
    Same footage: two of the three frames each match a frame of the other (dHash within 12 of 256 bits; any frame, so a trimmed or
    re-exported copy still matches; measured: a copy is 2-4, other shots 19+). Same scene: one frame within 40, the same place and
    at least 60% of the tags shared (the man and the dog at the wind turbine, three takes).
    Hidden clips are left out. The keeper is the biggest picture, then the longest."""
    bk = buckets(lib)
    E = [e for e in by_clip().values() if e.get("dh") and any(e["dh"]) and bk.get(e["rel"], e["folder"]) != "Hidden" and (not bk or e["rel"] in bk)]
    par = list(range(len(E))); why = {}
    def find(i):
        while par[i] != i: par[i] = par[par[i]]; i = par[i]
        return i
    for i in range(len(E)):
        for j in range(i + 1, len(E)):
            A, B = [x for x in E[i]["dh"] if x], [x for x in E[j]["dh"] if x]
            best = [min(ham(a, b) for b in B) for a in A]; near = sorted(best)
            same = sum(1 for d in best if d <= 12) >= min(2, len(A), len(B))
            ti, tj = set(E[i]["tags"]), set(E[j]["tags"])
            scene = near and near[0] <= 40 and E[i]["place"].lower() == E[j]["place"].lower() and len(ti & tj) >= .6 * min(len(ti), len(tj) or 1)
            if same or scene:
                ri, rj = find(i), find(j)
                if ri != rj: par[rj] = ri
                why[(i, j)] = "same footage" if same else "same scene"
    G = {}
    for i in range(len(E)): G.setdefault(find(i), []).append(i)
    out = []
    for r, ids in G.items():
        if len(ids) < 2: continue
        rows = [{"clip": E[i]["rel"], "bucket": bk.get(E[i]["rel"], E[i]["folder"]), "secs": round(float(E[i]["end"] or 0) - float(E[i]["start"]), 1),
                 "w": E[i].get("w", 0), "h": E[i].get("h", 0), "description": E[i]["description"]} for i in ids]
        rows.sort(key=lambda x: (-(x["w"] * x["h"]), -x["secs"], x["clip"]))
        kinds = {v for (i, j), v in why.items() if i in ids and j in ids}
        out.append({"why": "same footage" if kinds == {"same footage"} else "same scene" if kinds == {"same scene"} else "same footage or scene",
                    "keep": rows[0]["clip"], "clips": rows})
    out.sort(key=lambda g: (g["why"] != "same footage", -len(g["clips"]), g["keep"]))
    return out

# ---------------------------------------------------------------------------------------------------- wrong folder, checked
# The per-shot suggestion alone flagged 237 of 391 clips: Claude saw the drive's folder names next to Loop's renamed buckets, and
# moved clips out of folders that group by shape (Vertical) or by story (My Journey). So every flagged clip gets a second, text-only
# look (Sonnet) that sees each bucket's size, its share of vertical clips and sample descriptions, and only confirms clips that are
# clearly in the wrong bucket, naming an existing one. The verdict is kept on the entry ("tidy") until the clip's bucket changes.
VERIFY = """You help a video creator tidy his B-roll library. Below are his folders (BUCKETS: name, clip count, how many are vertical
video, and sample clip descriptions), then CLIPS a first pass flagged as maybe in the wrong folder.

Folders can group by topic (Travel, Office), by place or shoot (Travel/Kansas, Contorno), by shape (a folder of vertical clips),
or by story (a series about his journey). A vertical clip in the vertical folder, or a clip in the story or shoot folder it was
filmed for, is NOT misfiled. Otherwise, mark a clip wrong when another EXISTING folder fits what is in it clearly better than its
own does: a couple relaxing on a beach in a folder about filming content, a beach sunset in an office folder, a talking head in a
B-roll travel folder. Judge by what the clip shows next to what the folder's other clips show. When the two fit about equally,
it is not wrong.

Reply with ONLY a JSON array, one object per clip: [{{"n": 1, "wrong": false, "to": ""}}] ("to" = the existing folder name, exactly,
when wrong).

BUCKETS:
{buckets}

CLIPS:
{clips}"""

def ask(text, model="sonnet", timeout=600):
    """one text-only question through Claude Code (no tools, MCP or project files), the answer's text"""
    r = subprocess.run([claude_bin(), "-p", "--model", model, "--output-format", "json", "--max-turns", "2", "--system-prompt",
                        "You answer with JSON only.", "--tools", "", "--strict-mcp-config", "--setting-sources", "", "--disable-slash-commands"],
                       cwd=tempfile.gettempdir(), input=text, capture_output=True, text=True, timeout=timeout)
    d = json.loads(r.stdout)
    if d.get("is_error"): raise RuntimeError(d.get("result", "no answer"))
    return d["result"]

def candidates(S, lib):
    """editor clips whose first-pass suggestion is another bucket: [(entry, current bucket, suggestion)]"""
    bk = buckets(lib); m = {}
    try: m = json.loads(LIBMAP.read_text()).get("renamed", {})
    except Exception: pass
    out = []
    for e in S.values():
        if e.get("root") != "clips" or not e.get("suggested_folder") or e["rel"] not in bk: continue
        cur = bk[e["rel"]]; sug = e["suggested_folder"].strip("/"); sug = m.get(sug, sug)      # a drive folder Loop renamed
        if cur == "Hidden" or sug == cur or cur.startswith(sug + "/"): continue
        out.append((e, cur, sug))
    return out

def verify_folders(S, lib=None, log=print):
    """the second look for every flagged clip without a verdict for its current bucket; called inside run(), under its lock"""
    if lib is None:
        try:
            import studio; lib = studio.library()
        except Exception: return
    bk = buckets(lib); todo = [(e, cur, sug) for e, cur, sug in candidates(S, lib) if (e.get("tidy") or {}).get("bucket") != cur]
    if not todo: return
    log(f"  Checking {len(todo)} clips that may be in the wrong folder…")
    by = {}
    for c, b in bk.items():
        if b != "Hidden": by.setdefault(b, []).append(c)
    ix = by_clip_from(S)
    lines = []
    for b in sorted(set(by) | {x for x in lib["folders"] if x != "Hidden"}):
        L = by.get(b, []); vert = sum(1 for c in L if ix.get(c, {}).get("h", 0) > ix.get(c, {}).get("w", 0))
        ex = [ix[c]["description"] for c in L if c in ix][:6]
        lines.append(f"- {b}: {len(L)} clips, {vert} vertical. " + " | ".join(ex))
    for i in range(0, len(todo), 60):
        part = todo[i:i + 60]
        cl = "\n".join(f"{n}. in \"{cur}\" ({'vertical' if e.get('h', 0) > e.get('w', 0) else 'horizontal'}): {e['description']} "
                       f"(first pass suggested \"{sug}\")" for n, (e, cur, sug) in enumerate(part, 1))
        try:
            out = ask(VERIFY.format(buckets="\n".join(lines), clips=cl)); arr = json.loads(out[out.index("["): out.rindex("]") + 1])
        except Exception as ex_: log(f"  ! folder check skipped ({ex_})"); continue
        got = {int(x.get("n", 0)): x for x in arr if isinstance(x, dict)}
        for n, (e, cur, sug) in enumerate(part, 1):
            v = got.get(n) or {}; to = str(v.get("to") or "").strip("/")
            e["tidy"] = {"bucket": cur, "wrong": bool(v.get("wrong")) and to in by and to != cur, "to": to}
        log(f"  checked {min(i + 60, len(todo))}/{len(todo)}")

# ---------------------------------------------------------------------------------------------------- sequences (2026-10-23)
SEQ = """You group a video creator's B-roll into SEQUENCES so an editor can cut a wide, a medium and a tight shot of ONE moment
together, like a scene. Below are the shots of one shoot ("{group}"), in the order they were filmed (the number in the file name, or
the time in the source file), each with what is in it, its framing (wide / medium / tight, sometimes also creative) and its camera angle.

A sequence is one moment of one scene filmed from several setups: the same place, the same light and time of day, the same people
doing the same thing or one continuous activity (setting up a camera, then filming, then checking the shot). Its shots cut together
without the viewer feeling a jump in place or time. Usually 2 to 6 shots, and the best ones mix framings (a wide, a medium, a tight, maybe a creative one). Two shots of the same
place at different times of day, or doing unrelated things, are different sequences. A shot that goes with nothing stays alone.

Give each sequence a short name of 3 to 6 words saying what happens ("Typing at the Mexico desk", "Dog at the wind turbine").

Reply with ONLY a JSON array, every shot number exactly once, nothing else:
[{{"name": "...", "shots": [1, 2, 5]}}, {{"name": "...", "shots": [3]}}]

SHOTS:
{shots}"""

def seq_group(e):
    """the shoot a shot's sequence lives inside: a library clip's shoot (by file name), or the long source file a shot was cut from"""
    return shoot(e["rel"]) if e.get("root") == "clips" else e["rel"]

def sequences(S, log=print, redo=False):
    """group every shoot's shots into sequences (seq: "<shoot>: <name>", seq_name), text only (Sonnet). A shoot is asked again only
    when its shots change; a shot alone in its sequence gets seq "". Called inside run(), under its lock"""
    G = {}
    for k, e in S.items():
        if e.get("description") and e.get("root") in ("clips", "broll"): G.setdefault((e["root"], seq_group(e)), []).append(k)
    todo = []
    for (root, g), ks in G.items():
        ks.sort(key=lambda k: (S[k]["rel"], float(S[k]["start"])))
        sig = hashlib.sha1(repr([(k, S[k].get("mtime"), S[k].get("framing")) for k in ks]).encode()).hexdigest()[:12]
        if not redo and all(S[k].get("seq_sig") == sig for k in ks): continue
        if len(ks) < 2:
            for k in ks: S[k].update(seq="", seq_name="", seq_sig=sig)
            continue
        todo.append((g, ks, sig))
    if not todo: return
    log(f"  Grouping {sum(len(t[1]) for t in todo)} shots of {len(todo)} shoots into sequences…")

    def one(t):
        g, ks, sig = t
        lines = "\n".join(f'{n}. {pathlib.Path(S[k]["rel"]).name}' + (f' at {float(S[k]["start"]):.0f}s' if S[k]["root"] == "broll" else "")
                          + f' [{S[k].get("framing") or "?"}{", creative" if S[k].get("creative") else ""}, {S[k].get("angle") or "?"}] {S[k]["description"]} (place: {S[k]["place"]}; '
                          f'people: {S[k]["people"]})' for n, k in enumerate(ks, 1))
        try:
            out = ask(SEQ.format(group=g, shots=lines)); arr = json.loads(out[out.index("["): out.rindex("]") + 1])
        except Exception as ex_: return g, ks, sig, None, str(ex_)
        return g, ks, sig, arr, ""

    with cf.ThreadPoolExecutor(4) as ex:
        for g, ks, sig, arr, err in ex.map(one, todo):
            if arr is None: log(f"  ! sequences for {g} skipped ({err[:120]}); run again to retry"); continue
            got, names = {}, set()
            for q in arr:
                if not isinstance(q, dict): continue
                nm = base = str(q.get("name") or "").strip().rstrip(".") or "Sequence"
                c = 2
                while nm in names: nm = f"{base} {c}"; c += 1      # two sequences given one name stay two
                names.add(nm)
                ids = [int(i) for i in (q.get("shots") or []) if str(i).isdigit() and 1 <= int(i) <= len(ks) and int(i) not in got]
                for i in ids: got[i] = nm if len(ids) > 1 else ""
            for n, k in enumerate(ks, 1):
                nm = got.get(n, "")
                S[k].update(seq=f"{g}: {nm}" if nm else "", seq_name=nm, seq_sig=sig)

def by_clip_from(S): return {e["rel"]: e for e in S.values() if e.get("root") == "clips" and e.get("description")}

def pick_one(v, allowed):
    """a framing or angle from Claude, held to the list ("close-up" -> tight, "eye-level" -> eye level); "" when it fits none"""
    v = str(v or "").strip().lower().replace("-", " ").replace("_", " ")
    alias = {"close up": "tight", "closeup": "tight", "extreme close up": "tight", "detail": "tight", "insert": "tight", "ecu": "tight",
             "cu": "tight", "mcu": "medium", "medium close up": "medium", "mid": "medium", "establishing": "wide", "extreme wide": "wide",
             "full": "wide", "overhead": "top-down", "top down": "top-down", "birds eye": "top-down", "drone": "aerial", "ots": "over the shoulder",
             "point of view": "pov", "reverse point of view": "reverse pov", "ground": "ground level", "eye": "eye level",
             "slightly high": "high level", "high level angle": "high level", "car mount": "mounted", "high angle": "high", "low angle": "low"}
    v = alias.get(v, v)
    return v if v in allowed else ""

def clean_framing(x):
    x = x or {}; c = x.get("creative")
    return {"framing": pick_one(x.get("framing"), FRAMINGS), "angle": pick_one(x.get("angle"), ANGLES),
            "creative": c is True or str(c).strip().lower() in ("true", "yes")}

def clean(x):
    o = {k: x.get(k) for k in FIELDS}
    o.update(clean_framing(x))
    o["description"] = str(o["description"] or "").strip()
    o["objects"] = [str(s).strip().lower() for s in (o["objects"] or []) if str(s).strip()][:8]
    o["tags"] = sorted({str(s).strip().lower() for s in (o["tags"] or []) if str(s).strip()})[:14]
    for k in ("place", "action", "people", "mood", "suggested_folder"): o[k] = str(o[k] or "").strip()
    if o.get("camera") is None: o.pop("camera", None)
    else: o["camera"] = bool(o["camera"])
    return o


# ---------------------------------------------------------------------------------------------------- run (CLI or the Studio's thread)
def run(redo=False, limit=None, lib=None, log=print):
    """index what is new or changed. lib = the editor's library() (for its buckets); one run at a time across processes"""
    LOCKF.parent.mkdir(exist_ok=True); lf = open(LOCKF, "w")
    if not plat.lock(lf, wait=False): log("  Another index run is going; it will pick these up."); return 0
    try:
        U = units()
        if not U: log("  No B-roll found. Is the drive plugged in? (./vu-py cineyap/drives.py)"); return 0
        ix = load_index(); S = ix.setdefault("shots", {})
        todo = [u for u in U if redo or S.get(u["key"], {}).get("mtime") != u["mtime"] or not S.get(u["key"], {}).get("description")]
        new = {u["key"] for u in todo}
        todo += [u for u in U if u["key"] not in new and S.get(u["key"], {}).get("framing") is None]      # described before 2026-10-23: framing only
        for k in list(S):      # a file gone from a plugged-in drive: forget it (hidden clips keep their entry for when they come back)
            p = pathlib.Path(k.split("|")[0])
            if p.parent.parent.exists() and not p.exists(): S.pop(k)
        nf = len(todo) - len(new)
        log(f"  {len(U)} shots in the library, {len(U) - len(todo)} already indexed, {len(todo)} to look at"
            + (f" ({nf} only for their framing)." if nf else "."))
        if limit: todo = todo[:limit]
        save_index(ix)
        if not todo: fill_hashes(S, log); verify_folders(S, lib, log); sequences(S, log); save_index(ix); return 0
        bk = buckets(lib)
        fold = sorted({b for b in bk.values() if b != "Hidden"} | {u["folder"] for u in U if u["folder"] != "."})
        cl = claude_bin(); tmp = tempfile.mkdtemp(prefix="broll_index_")
        full, fo = [u for u in todo if u["key"] in new], [u for u in todo if u["key"] not in new]
        batches = [(b, False) for b in (full[i:i + BATCH] for i in range(0, len(full), BATCH))] + \
                  [(b, True) for b in (fo[i:i + BATCH] for i in range(0, len(fo), BATCH))]
        done, cost, t0 = 0, 0.0, time.time(); STATUS.update(running=True, todo=len(todo), done=0, error="")

        def work(job):
            batch, only = job; err = None
            for attempt in range(3):
                try: return batch, *describe(batch, fold, cl, tmp, only), only
                except Exception as e: err = e; time.sleep(3 * (attempt + 1))
            return batch, None, 0.0, err, only

        try:
            with cf.ThreadPoolExecutor(WORKERS) as ex:
                for got in ex.map(work, batches):
                    batch, res, c = got[0], got[1], got[2]; cost += c
                    if res is None:
                        STATUS["error"] = str(got[3])[:200]; log(f"  ! {len(batch)} shots skipped ({got[3]}); run again to retry"); continue
                    for u, x in zip(batch, res):
                        if x and got[-1]: S[u["key"]].update(clean_framing(x))
                        elif x: S[u["key"]] = {**{k: u[k] for k in ("path", "root", "rel", "start", "end", "mtime", "folder")}, **clean(x)}
                    done += len(batch); STATUS["done"] = done; save_index(ix)
                    el = time.time() - t0; left = el / done * (len(todo) - done)
                    log(f"  {done}/{len(todo)}  ${cost:.2f}  ~{left / 60:.0f} min left   {batch[0]['rel']}: {((res[0] or {}).get('description') or ' '.join(str(v) for v in clean_framing(res[0]).values()))[:90]}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        fill_hashes(S, log); verify_folders(S, lib, log); sequences(S, log); save_index(ix)
        log(f"  Done: {sum(1 for e in S.values() if e.get('description'))} shots indexed in {INDEX.name}, ${cost:.2f} this run.")
        return done
    finally:
        STATUS["running"] = False; plat.unlock(lf); lf.close()

def start_background(lib_fn=None):
    """the Studio: index new or changed clips in a thread, never blocking. Safe to call often (one run at a time)"""
    if STATUS["running"]: return False
    STATUS.update(running=True, todo=0, done=0)
    def go():
        try: run(lib=lib_fn() if lib_fn else None, log=lambda s: None)
        except Exception as e: STATUS["error"] = str(e)[:200]
        finally: STATUS["running"] = False
    threading.Thread(target=go, daemon=True).start(); return True


# ---------------------------------------------------------------------------------------------------- what the Studio reads
_CACHE = {"mtime": 0, "clips": {}}
# NEVER SOMEONE AT THE CAMERA (BROLL-PICKS.md, 2026-10-24): the indexer's yes/no "camera" field when the shot has one, else the
# description ("talks to the camera", "smiling at the camera"), for shots indexed before the field existed
AT_CAMERA = re.compile(r"\b(to|at|into|toward|towards)\s+(the\s+)?camera\b", re.I)
def at_camera(e):
    if not e: return False
    if "camera" in e: return bool(e["camera"])
    return bool(AT_CAMERA.search(str(e.get("description") or "")) or AT_CAMERA.search(str(e.get("action") or ""))
                or "talking head" in (e.get("tags") or []))

def long_notes(hidden=()):
    """THE SHOTS INSIDE LONG FILES (2026-10-24): 428 of Gabe's 852 shots sit inside long exports in broll_root; they were indexed but
    never offered. For Layer It: each with the file, where the shot starts in it ("in") and how long it runs ("secs")"""
    out = []
    for e in load_index().get("shots", {}).values():
        if e.get("root") != "broll" or not e.get("description") or at_camera(e) or e.get("path") in hidden: continue
        x = {"clip": e["path"], "in": round(float(e.get("start") or 0), 2), "secs": round(float(e.get("end") or 0) - float(e.get("start") or 0), 2),
             "about": e["description"], "tags": e.get("tags", [])}
        if e.get("place"): x["place"] = e["place"]
        if e.get("action"): x["action"] = e["action"]
        for k in ("framing", "angle", "seq"):
            if e.get(k): x[k] = e[k]
        if e.get("creative"): x["creative"] = True
        x["shoot"] = e.get("folder") or ""
        if x["secs"] >= 1.5: out.append(x)
    return out

def by_clip():
    """{clip path as the editor names it (relative to broll_clips): entry}, re-read when the index changes"""
    try: mt = INDEX.stat().st_mtime
    except OSError: return {}
    if mt != _CACHE["mtime"]:
        _CACHE.update(mtime=mt, clips={e["rel"]: e for e in load_index()["shots"].values() if e.get("root") == "clips" and e.get("description")})
    return _CACHE["clips"]

def shoot(rel):
    """which shoot a clip came from, by its file name: "Office/Mexico Office_03.mp4" -> "Mexico Office",
    "Lifestyle/Contorno - Lighting a candle_05.mp4" -> "Contorno". Clips that touch on the timeline come from one shoot (Gabe, 2026-10-22)"""
    n = re.sub(r"_\d{1,3}$", "", pathlib.Path(rel).stem).strip()
    return n.split(" - ")[0].strip() or n

def notes(clips):
    """the library as Claude should see it: each clip with what is in it, for the first version, chat and agent prompts"""
    ix = by_clip(); out = []
    try: lab = json.loads(LIBMAP.read_text()).get("tags", {})
    except Exception: lab = {}
    for c in clips:
        e = ix.get(c)
        if not e: out.append({"clip": c}); continue
        x = {"clip": c, "about": e["description"], "tags": e["tags"], "secs": e.get("end")}
        if e.get("w"): x["shape"] = "vertical" if e["h"] > e["w"] else "wide"      # a vertical clip doesn't fill a 16:9 frame
        x["shoot"] = shoot(c)
        if e.get("framing"): x["framing"] = e["framing"]
        if e.get("angle"): x["angle"] = e["angle"]
        if e.get("creative"): x["creative"] = True
        if e.get("seq"): x["seq"] = e["seq"]      # one moment shot from several framings: a run of B-roll comes from one
        if lab.get(c): x["labels"] = lab[c]      # the creator's own tags from Media (library_map.json): who and where
        out.append(x)
    return out

def buckets(lib=None):
    """the editor's buckets for every clip of broll_clips (library_map.json applied), {rel: bucket}"""
    if lib is None:
        try:
            import studio; lib = studio.library()
        except Exception: return {}
    return {c: b for b, L in lib["folders"].items() for c in L}

def report(lib=None, quiet=False):
    """clips whose content doesn't fit their bucket: [{clip, bucket, suggested, kind, description}]. kind "move" = another top
    folder, "sub" = a better bucket inside the same one"""
    ix = load_index(); out = []
    for e, cur, sug in candidates(ix["shots"], lib):
        t = e.get("tidy") or {}
        if t.get("bucket") != cur or not t.get("wrong"): continue      # only what the second look confirmed
        kind = "move" if t["to"].split("/")[0] != cur.split("/")[0] else "sub"
        out.append({"clip": e["rel"], "bucket": cur, "suggested": t["to"], "kind": kind, "description": e["description"]})
    out.sort(key=lambda r: (r["kind"] != "move", r["bucket"], r["clip"]))
    if not quiet:
        for g in look_alike(lib):
            print(f"  LOOK ALIKE ({g['why']}): keep {g['keep']}"); [print(f"      {c['clip']:52} {c['secs']:5}s {c['w']}x{c['h']}  {c['description']}") for c in g["clips"]]
        for r in out: print(f"  {r['kind']:4} {r['clip']:52} {r['bucket']:24} -> {r['suggested']:24} {r['description']}")
        print(f"\n  {len(out)} clips look misfiled.")
    return out + [{"kind": "alike", **g} for g in look_alike(lib)]      # Tidy up's "Look alike" section: one row per group

def seq_report():
    S = load_index()["shots"]; G = {}
    for e in S.values():
        if e.get("seq"): G.setdefault(e["seq"], []).append(e)
    for q in sorted(G):
        print(f"  {q}"); [print(f'      {(e.get("framing") or "?") + ("+c" if e.get("creative") else ""):8} {e.get("angle", "?"):17} {e["rel"]:52} {e["description"][:70]}') for e in G[q]]
    fr = {}
    for e in S.values(): fr[e.get("framing") or "?"] = fr.get(e.get("framing") or "?", 0) + 1
    print(f"\n  {len(G)} sequences, {sum(len(v) for v in G.values())} of {len(S)} shots in one. Framing: {fr}")

if __name__ == "__main__":
    if "--report" in sys.argv: report()
    elif "--seq-report" in sys.argv: seq_report()
    elif "--sequences" in sys.argv:
        ix = load_index(); sequences(ix["shots"], log=lambda s: print(s, flush=True), redo=True); save_index(ix)
    else:
        try: run(redo="--redo" in sys.argv, limit=int(sys.argv[sys.argv.index("--limit") + 1]) if "--limit" in sys.argv else None,
                 log=lambda s: print(s, flush=True))
        except KeyboardInterrupt: print("\n  Stopped. What's done is saved; run it again to carry on.")
