#!/usr/bin/env python3
# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
"""update.py — move this CineYap to a newer version without touching anyone's work.

    ./vu-py cineyap/update.py                  # check the feed in product.json, install a newer version
    ./vu-py cineyap/update.py <CineYap.zip>    # install from a zip someone sent
    ./vu-py cineyap/update.py --check          # just say whether a newer version exists

What it never touches: projects/, inbox/, .env, .venv/, _local/, cineyap/config.json, cineyap/brand.json,
cineyap/shots.json and the CapCut format cache this machine captured. Their videos, keys, brand and
settings stay exactly as they are.

What it does: backs up the current code to _local/backups/<version>-<time>.zip, copies the new code over,
MERGES new settings into every style pack that already exists (a value they changed or "learned" from
CapCut is kept; a setting the new version adds is filled in), adds new packs, then re-runs ./install.sh
quietly in case the new version needs a new library. The log is _local/update.log.
"""
import io, json, pathlib, shutil, subprocess, sys, tempfile, time, urllib.request, zipfile
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import plat
ROOT = pathlib.Path(__file__).resolve().parent.parent

# THEIR WORK AND THEIR SETTINGS (R6, 2026-10-24): never overwritten by a package and never zipped into a backup. Everything the Studio
# writes for the creator lives here; a new file the server starts writing goes on this list the same day.
KEEP = {"projects", "inbox", "samples", "exports", "_archive", "library/saved_fx", ".env", ".venv", "_local", ".git",
        "cineyap/config.json", "cineyap/brand.json", "cineyap/brand_assets", "cineyap/shots.json", "cineyap/broll_index.json",
        "cineyap/screen_templates.json", "cineyap/aroll_grades.json", "cineyap/grades.json", "cineyap/text_styles.json", "cineyap/user_styles.json",
        "cineyap/style_defaults.json", "cineyap/palette.json", "cineyap/font_stars.json", "cineyap/rules.json", "cineyap/library_map.json",
        "cineyap/system_fonts.json", "learned.json", "cineyap/_capcut_template",
        "cineyap/_capcut_ref_material.json", "cineyap/_capcut_ref_segment.json", "cineyap/_capcut_mix_screen.json"}
BACKUPS_KEPT = 3      # the newest backups; older ones go (R6: every update zipped exports/ and deleted projects, and nothing was ever removed)
LOG = ROOT/"_local/update.log"

def say(msg):
    print(msg); LOG.parent.mkdir(exist_ok=True)
    with open(LOG, "a") as f: f.write(time.strftime("%Y-%m-%d %H:%M ") + msg + "\n")

def version_tuple(v): return tuple(int(x) if x.isdigit() else 0 for x in (v or "0").split("."))
def product(): return json.loads((ROOT/"product.json").read_text()) if (ROOT/"product.json").exists() else {"version": "0"}

def kept(rel):
    rel = rel.replace("\\", "/")
    return any(rel == k or rel.startswith(k + "/") for k in KEEP)

def prune_backups(bk, keep=BACKUPS_KEPT):
    """the newest `keep` backup zips stay; returns what was removed"""
    zips = sorted(bk.glob("*.zip"), key=lambda p: p.stat().st_mtime)
    gone = zips[:-keep] if keep else zips
    for z in gone: z.unlink(missing_ok=True)
    return gone

def restore_backup(bz, root=ROOT):
    """put the code back from a backup zip (a failed update must not leave half of each version)"""
    with zipfile.ZipFile(bz) as z:
        for zi in z.infolist():
            if zi.is_dir() or kept(zi.filename): continue
            dst = root/zi.filename; dst.parent.mkdir(parents=True, exist_ok=True)
            with z.open(zi) as src, open(dst, "wb") as out: shutil.copyfileobj(src, out)
            mode = (zi.external_attr >> 16) & 0o777
            if mode:
                try: dst.chmod(mode)
                except OSError: pass

def merge(old, new):
    """new keys from `new` filled into `old`; every value already in `old` wins"""
    if isinstance(old, dict) and isinstance(new, dict):
        out = dict(old)
        for k, v in new.items(): out[k] = merge(old[k], v) if k in old else v
        return out
    return old

def fetch_feed():
    url = product().get("update_url")
    if not url: sys.exit("This install has no update address (product.json). Ask Gabe for the newest zip.")
    try:
        with urllib.request.urlopen(url, timeout=15) as r: return json.loads(r.read().decode())
    except Exception as e: sys.exit(f"Could not reach the update feed ({e}). Check the internet connection and try again.")

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    have = product().get("version", "0")
    if args:
        src = pathlib.Path(args[0]).expanduser()
        if not src.exists(): sys.exit(f"No file at {src}")
        data = src.read_bytes(); notes = ""
    else:
        feed = fetch_feed(); there = feed.get("version", "0")
        if version_tuple(there) <= version_tuple(have):
            print(f"Visual Studio {have} is the newest version."); return
        if "--check" in sys.argv:
            print(f"Visual Studio {there} is out (this install is {have}). {feed.get('notes', '')}"); return
        say(f"downloading {there} from {feed['download']}")
        with urllib.request.urlopen(feed["download"], timeout=300) as r: data = r.read()
        notes = feed.get("notes", "")

    with tempfile.TemporaryDirectory() as tmp:
        zf = zipfile.ZipFile(io.BytesIO(data)); zf.extractall(tmp)
        for zi in zf.infolist():      # extractall drops Unix permissions: put each file's back, or every script loses its run bit (a tester, 2026-10-23)
            mode = (zi.external_attr >> 16) & 0o777
            if mode and not zi.is_dir():
                try: (pathlib.Path(tmp)/zi.filename).chmod(mode)
                except OSError: pass
        roots = [p for p in pathlib.Path(tmp).iterdir() if p.is_dir() and (p/"product.json").exists()]
        new = roots[0] if roots else pathlib.Path(tmp)
        if not (new/"product.json").exists() or not (new/"cineyap").is_dir(): sys.exit("That zip is not a Visual Studio package.")
        there = json.loads((new/"product.json").read_text()).get("version", "?")
        if version_tuple(there) < version_tuple(have) and "--force" not in sys.argv:
            sys.exit(f"That zip is {there}, older than this install ({have}). Nothing changed.")

        # 1. back up the code (everything that is not their work) so an update can always be undone
        bk = ROOT/"_local/backups"; bk.mkdir(parents=True, exist_ok=True)
        bz = bk/f"{have}-{time.strftime('%Y%m%d-%H%M%S')}.zip"
        with zipfile.ZipFile(bz, "w", zipfile.ZIP_DEFLATED) as z:
            for p in ROOT.rglob("*"):
                rel = str(p.relative_to(ROOT))
                if p.is_file() and not kept(rel) and "__pycache__" not in rel: z.write(p, rel)
        say(f"backed up {have} to {bz}")
        for z in prune_backups(bk): say(f"removed old backup {z.name}")

        # 2. copy the new code over; style packs are merged, never overwritten. If anything fails halfway, the backup goes back
        n_new = n_merged = 0
        try:
            for p in new.rglob("*"):
                if not p.is_file(): continue
                rel = str(p.relative_to(new)).replace("\\", "/")
                if kept(rel) or "__pycache__" in rel: continue
                dst = ROOT/rel
                if rel.startswith("cineyap/styles/") and rel.endswith(".json") and dst.exists():
                    try:
                        old = json.loads(dst.read_text()); dst.write_text(json.dumps(merge(old, json.loads(p.read_text())), indent=1, ensure_ascii=False))
                        n_merged += 1; continue
                    except Exception: pass
                dst.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(p, dst); n_new += 1
                if rel.endswith(".sh") or "/Contents/MacOS/" in rel or p.read_bytes()[:2] == b"#!": dst.chmod(dst.stat().st_mode | 0o111)      # scripts stay runnable whatever the zip said
        except Exception as e:
            say(f"update failed partway ({e}): putting {have} back from {bz.name}")
            restore_backup(bz); sys.exit(f"The update didn't finish ({e}). Visual Studio {have} was put back; nothing of yours changed. Try again later.")
        say(f"installed {there}: {n_new} files, {n_merged} style pack(s) merged (their own settings kept)")

    # 3. a new version may need a new library: install.sh only adds what is missing
    r = subprocess.run([plat.bash(), str(ROOT/"install.sh")], stdin=subprocess.DEVNULL, capture_output=True, text=True)
    bad = [l for l in r.stdout.splitlines() if "!!" in l and "skipped" not in l]
    if bad: say("install check: " + " | ".join(l.strip() for l in bad))
    print(f"\nVisual Studio {have} -> {there}." + (f"\n{notes}" if notes else ""))
    print("If the Studio is open, restart it (/studio) to load the new version.")

if __name__ == "__main__":
    main()
