/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* home.js: the B-roll button in the Studio's top bar (2026-10-23). Shows the linked folder and how much of it Claude has looked
   at; the panel links a folder (Finder's picker) and indexes it. /api/broll-folder (GET state, POST {choose} or {index}). */
(function(){
var B=document.getElementById("brollBtn"),P=document.getElementById("brollPop"),L=document.getElementById("brollLab");if(!B)return;
var S=null,T=null;
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e;}
function post(b){return fetch("/api/broll-folder",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)}).then(function(r){return r.json();});}
function busy(s){return !!(s&&s.status&&s.status.running);}
function label(s){var d=B.querySelector(".dot");d.className="dot";
  if(!s||!s.path){L.textContent="Link your B-roll folder";d.classList.add("bad");return;}
  if(!s.exists){L.textContent="B-roll folder not found";d.classList.add("bad");return;}
  if(busy(s)){var st=s.status;L.textContent="Indexing B-roll"+(st.todo?" "+st.done+"/"+st.todo:"…");d.classList.add("busy");return;}
  L.textContent="B-roll linked";B.title=s.path+" · "+s.clips+" clips";d.classList.add(s.indexed>=s.clips?"ok":"busy");}
function draw(){P.innerHTML="";var s=S||{};
  if(!s.path){P.appendChild(el("b",null,"Link your B-roll folder"));
    P.appendChild(el("small",null,"Pick the folder your B-roll clips live in (subfolders are fine, one shot per file is best). Claude looks at every clip once and writes what's in it, so it can pick B-roll by what's in the shot. It runs in the background and uses your Claude plan."));}
  else{P.appendChild(el("b",null,s.exists?s.name:"Not found: "+s.name));P.appendChild(el("span","path",s.path));
    if(!s.exists)P.appendChild(el("small",null,"If it's on an external drive, plug it in. Or link a different folder."));
    else{var pct=s.clips?Math.min(100,Math.round(s.indexed/s.clips*100)):0,bar=el("div","bar"),i=el("i");i.style.width=pct+"%";bar.appendChild(i);P.appendChild(bar);
      P.appendChild(el("small",null,busy(s)?"Claude is looking at your clips: "+(s.status.todo?s.status.done+" of "+s.status.todo+" new ones done.":"getting started…")+" You can keep working.":
        s.indexed+" of "+s.clips+" clips indexed."+(s.indexed<s.clips?" Index the rest so Claude can pick them.":" Claude can pick from all of them.")));
      if(s.status&&s.status.error)P.appendChild(el("small",null,"Last run: "+s.status.error));}}
  var row=el("div","row"),ch=el("button","hbtn",s.path?"Change folder…":"Choose folder…");ch.type="button";
  ch.onclick=function(){ch.disabled=true;ch.textContent="Pick it in Finder…";post({choose:true}).then(set).catch(function(){ch.disabled=false;});};row.appendChild(ch);
  if(s.exists&&!busy(s)&&s.indexed<s.clips){var ix=el("button","hbtn","Index new clips");ix.type="button";ix.onclick=function(){ix.disabled=true;post({index:true}).then(set);};row.appendChild(ix);}
  P.appendChild(row);}
function set(s){S=s;label(s);if(!P.hidden)draw();clearTimeout(T);T=setTimeout(load,busy(s)?3000:30000);}
function load(){fetch("/api/broll-folder").then(function(r){return r.json();}).then(set).catch(function(){});}
B.onclick=function(e){e.stopPropagation();P.hidden=!P.hidden;if(!P.hidden)draw();};
document.addEventListener("click",function(e){if(!P.hidden&&!P.contains(e.target)&&e.target!==B)P.hidden=true;});
document.addEventListener("keydown",function(e){if(e.key==="Escape")P.hidden=true;});
load();
})();
