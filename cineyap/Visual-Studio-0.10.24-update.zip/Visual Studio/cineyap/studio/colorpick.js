/* colorpick.js: the one color picker (Gabe, 2026-10-24: "anywhere we're asking for color, make sure it matches this style"): the
   rainbow button opens a square, a hue bar and the hex box, focused, so typing a hex is the default. The editor and the Brand page
   both use it. set(hex, how): how is true while dragging, "done" on letting go, undefined for a typed hex */
(function(){var $=function(s){return document.querySelector(s);},el=function(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e;};
window.hsv2hex=function hsv2hex(h,s,v){var f=function(n){var k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1));};return "#"+[f(5),f(3),f(1)].map(function(x){return ("0"+Math.round(x*255).toString(16)).slice(-2);}).join("").toUpperCase();}
window.hex2hsv=function hex2hsv(c){var r=parseInt(c.slice(1,3),16)/255,g=parseInt(c.slice(3,5),16)/255,b=parseInt(c.slice(5,7),16)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn,h=0;
  if(d){h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360;}return [h,mx?d/mx:0,mx];}
window.cpOpen=function cpOpen(anchor,start,set){var old=$("#cpop");if(old)old.remove();var P=el("div");P.id="cpop";var hsv=hex2hsv(start),cur=start;
  var sq=el("div","cpsq"),dot=el("i","cpdot");sq.appendChild(dot);var hu=el("div","cphue"),hk=el("i","cphk");hu.appendChild(hk);
  var row=el("div","cprow"),sw=el("span","cpsw"),hx=el("input","cphex");hx.spellcheck=false;hx.maxLength=7;
  if(window.EyeDropper){var ed=el("button","ib");ed.type="button";ed.title="Pick a color from the screen";ed.innerHTML='<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.5 2.5l3 3-1.5 1.5-3-3zM9 4l3 3-6 6H3v-3z"/></svg>';
    ed.onclick=function(){new EyeDropper().open().then(function(r){put(hex2hsv(r.sRGBHex.toUpperCase()),"done");}).catch(function(){});};row.appendChild(ed);}
  row.appendChild(sw);row.appendChild(hx);P.appendChild(sq);P.appendChild(hu);P.appendChild(row);document.body.appendChild(P);
  function paint(){sq.style.background="linear-gradient(to top,#000,transparent),linear-gradient(to right,#fff,"+hsv2hex(hsv[0],1,1)+")";dot.style.left=hsv[1]*100+"%";dot.style.top=(1-hsv[2])*100+"%";
    hk.style.left=hsv[0]/360*100+"%";sw.style.background=cur;if(document.activeElement!==hx)hx.value=cur;}
  function put(v,how){hsv=v;cur=hsv2hex(v[0],v[1],v[2]);paint();set(cur,how);}
  function drag(elm,fn){elm.onpointerdown=function(e){e.preventDefault();elm.setPointerCapture(e.pointerId);var mv=function(ev){var r=elm.getBoundingClientRect();fn(Math.max(0,Math.min(1,(ev.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(ev.clientY-r.top)/r.height)),true);};
    mv(e);elm.onpointermove=mv;elm.onpointerup=function(ev){elm.onpointermove=null;elm.onpointerup=null;set(cur,"done");};};}
  drag(sq,function(x,y,live){put([hsv[0],x,1-y],true);});drag(hu,function(x){put([x*360,hsv[1],hsv[2]],true);});
  hx.onkeydown=function(e){e.stopPropagation();if(e.key==="Escape"){P.remove();return;}if(e.key!=="Enter")return;var v=hx.value.trim().toUpperCase();if(v[0]!=="#")v="#"+v;if(/^#[0-9A-F]{3}$/.test(v))v="#"+v[1]+v[1]+v[2]+v[2]+v[3]+v[3];
    if(/^#[0-9A-F]{6}$/.test(v)){hsv=hex2hsv(v);cur=v;paint();set(v);P.remove();}else hx.classList.add("bad");};hx.oninput=function(){hx.classList.remove("bad");};
  var r=anchor.getBoundingClientRect(),W=232,H=246,L=Math.min(window.innerWidth-W-8,Math.max(8,r.left-W/2)),T=r.bottom+8+H>window.innerHeight?r.top-H-8:r.bottom+8;P.style.left=L+"px";P.style.top=Math.max(8,T)+"px";
  paint();setTimeout(function(){hx.focus();hx.select();},0);
  var away=function(e){if(!P.isConnected){document.removeEventListener("mousedown",away,true);return;}if(!P.contains(e.target)){P.remove();document.removeEventListener("mousedown",away,true);}};document.addEventListener("mousedown",away,true);}
})();
