/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* tlmigrate.js — one place for timeline.json's small key changes, run by the editor when a project opens (adopt) and by the export
   when it loads the same file (cineyap/tlmigrate.py mirrors it line for line; tests/test_migrate.py checks the two agree).
   Add a step here the day a key changes name, so no saved project is read two ways (X4, 2026-10-24: text layers saved between
   17:10 and 19:41 carry small caps as sc:true, the key a screen uses for its picture scale; the editor and the export read smc).
   Every step is safe to run twice. */
(function (root, make) {
  var M = make();
  if (typeof module === "object" && module.exports) module.exports = M; else root.TLMigrate = M;
})(this, function () {
  function textStyles(st) {      // every text layer style in a state: hook/text blocks, screen titles, the Text window's layers
    var out = [];
    (st.HK || []).forEach(function (h) { (h.lines || []).forEach(function (l) { if (l && l.st) out.push(l.st); }); });
    (st.SCREENS || []).forEach(function (S) {
      if (S && S.text && S.text.lines) S.text.lines.forEach(function (l) { if (l && l.st) out.push(l.st); });
      (S && S.titles || []).forEach(function (T) { if (T && T.st) out.push(T.st); });
    });
    return out;
  }
  function capStyles(st) {      // every caption style: a screen, its highlight word, a clip's own settings (sc there is a picture scale: a number, never true)
    var out = [];
    (st.SCREENS || []).forEach(function (S) { if (S) { out.push(S); if (S.hl) out.push(S.hl); } });
    ["BR", "BG", "SEGS"].forEach(function (k) { (st[k] || []).forEach(function (o) { if (o && o.st) out.push(o.st); }); });
    return out;
  }
  function migrate(st) {
    if (!st || typeof st !== "object") return st;
    textStyles(st).concat(capStyles(st)).forEach(function (s) { if (s.sc === true) { s.smc = true; delete s.sc; } });      // X4: small caps was saved under a screen's scale key
    return st;
  }
  return { migrate: migrate, textStyles: textStyles, capStyles: capStyles };
});
