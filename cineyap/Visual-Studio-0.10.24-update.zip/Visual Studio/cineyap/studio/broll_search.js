/* The B-roll index in Media (2026-10-22): search by what is IN a clip, its description on hover, a quiet "Indexing N new clips…"
   while the Studio describes new ones, and Tidy up (wrong folder, look alike). The index is cineyap/broll_index.json
   (broll_index.py); Tidy up only changes Loop's folders and hidden list (library_map.json), never the drive. */
var BIX={},BIXS={};
(function(){var s=document.createElement("style");s.textContent=
  ".bixst{font-size:11px;color:var(--dim);white-space:nowrap}.bixst[hidden]{display:none}"+
  ".tidybox{width:min(760px,calc(100vw - 32px));max-height:80vh;overflow:auto}.tidyrow{display:grid;grid-template-columns:96px 1fr auto;gap:10px;align-items:center;padding:8px 0;border-top:1px solid var(--line)}"+
  ".tidyrow img{width:96px;aspect-ratio:16/9;object-fit:cover;border-radius:6px;background:var(--field)}.tidyrow .tx{font-size:12px;line-height:1.4}.tidyrow .tx small{display:block;color:var(--dim)}"+
  ".tidyrow .tx em{font-style:normal;color:var(--ink)}.tidyrow.done{opacity:.4}"+
  ".tidytabs{display:flex;gap:6px}.tidytabs .btn.on{background:var(--sel);color:#111}.tidygrp{margin:10px 0 4px;padding:6px 10px;border:1px solid var(--line);border-radius:10px}"+
  ".seqhd{grid-column:1/-1;display:flex;gap:8px;align-items:baseline;font-size:12px;font-weight:600;color:var(--ink-2);padding:10px 2px 2px;border-top:1px solid var(--line)}.seqhd small{font-weight:500;color:var(--dim)}"+
  ".tidyhd{display:flex;justify-content:space-between;align-items:center;font-size:12px;color:var(--dim);padding:2px 0 6px}.tidyrow.keep .tx small{color:var(--ink)}";document.head.appendChild(s);})();
function bixLoad(){return fetch("/api/broll-index").then(function(r){return r.json();}).then(function(d){var was=Object.keys(BIX).length;BIX=d.clips||{};BIXS=d.status||{};bixStatus();
  if(Object.keys(BIX).length!==was&&typeof drawLib==="function"&&typeof LIB!=="undefined")drawLib();
  if(BIXS.running)setTimeout(bixLoad,8000);}).catch(function(){});}
function bixStatus(){var h=document.getElementById("mhead");if(!h)return;var s=document.getElementById("bixst");if(!s){s=el("span","bixst");s.id="bixst";h.appendChild(s);}
  var left=(BIXS.todo||0)-(BIXS.done||0);s.hidden=!BIXS.running;s.textContent=BIXS.todo?"Indexing "+left+" new clip"+(left===1?"":"s")+"…":"Checking for new clips…";
  s.title="Looking at what's in your new B-roll so search and the first version can find it";}
/* a clip's description for its hover title */
function shotLine(e){if(!e||!e.f)return "";var a=[e.f.charAt(0).toUpperCase()+e.f.slice(1)];if(e.c)a.push("creative");if(e.a&&e.a!=="eye level")a.push(shotWord(e.a).toLowerCase().replace("pov","POV"));return a.join(", ")+(e.s?" · Sequence: "+e.s:"")+"\n";}
function libAbout(c){var e=BIX[c],T=typeof ctags==="function"?ctags(c):[];return (T.length?"Tags: "+T.join(", ")+"\n":"")+(e?e.d+"\n"+shotLine(e)+e.t.join(", ")+"\n\n":T.length?"\n":"");}
/* SHOT WORDS in a search (2026-10-23) are read as the shot's tags, not as words to find in its description: "tight desk" is a tight
   shot of a desk, "medium tight" is either, "overhead" is top-down. Sizes and angles are Gabe's guide's (broll_index.py). */
var SHOTQ=[[/\bmedium[\s-]+(tight|close([\s-]?up)?)\b|\bmcu\b/g,["medium","tight"]],[/\b(extreme\s+)?wide([\s-]?shot)?\b|\bestablishing\b/g,["wide"]],
  [/\b(medium|mid)([\s-]?shot)?\b/g,["medium"]],[/\b(extreme\s+)?(tight|close[\s-]?ups?|closeups?|details?|inserts?|macro)\b/g,["tight"]],[/\bcreative\b/g,["creative"]],
  [/\breverse[\s-]+pov\b/g,["reverse pov"]],[/\bpov\b|\bpoint of view\b/g,["pov"]],[/\b(top[\s-]?down|overhead|flat[\s-]?lay|birds?[\s-]?eye)\b/g,["top-down"]],
  [/\bover[\s-]the[\s-]shoulder\b|\bots\b/g,["over the shoulder"]],[/\b(aerial|drone)\b/g,["aerial"]],[/\bmounted\b/g,["mounted"]],[/\bground[\s-]level\b/g,["ground level"]],
  [/\bhigh[\s-]level\b/g,["high level"]],[/\beye[\s-]level\b/g,["eye level"]],[/\blow[\s-]angle\b/g,["low"]],[/\bhigh[\s-]angle\b/g,["high"]]];
function shotQuery(q){var rest=" "+q+" ",hits=[];
  SHOTQ.forEach(function(r){rest=rest.replace(r[0],function(m){hits.push({at:arguments[arguments.length-2],any:r[1]});return " ".repeat(m.length);});});
  hits.sort(function(a,b){return a.at-b.at;});
  var fr=hits.filter(function(h){return h.any.length===1&&SHOT_SIZES.indexOf(h.any[0])>=0;}).map(function(h){return h.any[0];});
  return {rest:rest.replace(/[,>→]|\bthen\b/g," ").trim(),any:hits.map(function(h){return h.any;}),order:fr.length>1?fr:null};}
/* never someone looking or talking at the camera in B-roll (BROLL-PICKS.md): such a shot is picked last */
function atCamera(c){var x=BIX[c]||{};if(x.cam!=null)return !!x.cam;return /\b(to|at|into|toward|towards)\s+(the\s+)?camera\b/i.test((x.d||"")+" "+(x.ac||""))||(x.t||[]).indexOf("talking head")>=0;}      /* the server's camera check (the indexer's field, else the words) */
function shotHas(e,k){return !!e&&(k==="creative"?!!e.c:e.f===k||e.a===k);}
/* every other word typed must be in the name, the description or the tags ("camera beach" finds the clip of a camera on a beach) */
function libMatch(c,q,sq){var e=BIX[c],hay=(c+" "+(e?e.d+" "+e.t.join(" ")+" "+(e.s||""):"")+" "+(typeof ctags==="function"?ctags(c).join(" "):"")).toLowerCase();
  sq=sq||shotQuery(q);if(!sq.order&&!sq.any.every(function(a){return a.some(function(k){return shotHas(e,k);});}))return false;
  return sq.rest.split(/\s+/).filter(Boolean).every(function(w){return hay.indexOf(w)>=0;});}
/* the search box over a list. An ORDERED list of sizes ("wide, medium, tight", "wide tight medium") means one sequence cut in that
   order: every sequence that has a clip of each size (and matches the other words) comes back, in that order, grouped */
var SEQORDER=null;
function libSearch(list,q){var sq=shotQuery(q);SEQORDER=sq.order;var L=list.filter(function(c){return libMatch(c,q,sq);});if(!sq.order)return L;
  var G={};L.forEach(function(c){var e=BIX[c];if(e&&e.s)(G[e.s]=G[e.s]||[]).push(c);});var out=[];
  Object.keys(G).forEach(function(s){var used={},pick=sq.order.map(function(f){var c=G[s].filter(function(x){return !used[x]&&BIX[x].f===f;}).sort(function(a,b){return atCamera(a)-atCamera(b);})[0];if(c)used[c]=1;return c;});
    if(pick.every(Boolean))out=out.concat(pick);});return out;}
/* SHOT SIZE AND SEQUENCES (Gabe, 2026-10-23): "bunch it by shot style, then by sequence". The Shot row filters what's showing to
   one framing (Wide, Medium, Tight) or one angle (Top-down, POV, ...); By sequence groups it into its sequences (one moment filmed
   from several framings, broll_index.sequences), each ordered wide to tight, so a 1-2-3 of one scene is easy to pick out. */
var SHOTF="",SEQV=false;try{SEQV=localStorage.getItem("loop.seqview")==="1";}catch(e){}
var SHOT_SIZES=["wide","medium","tight"];      /* not FRAMES: the editor's picture frames have that name */
function shotWord(k){return {pov:"POV","reverse pov":"Reverse POV"}[k]||k.charAt(0).toUpperCase()+k.slice(1);}
function shotOf(c,k){return shotHas(BIX[c],k);}
function shotFilter(list){return SHOTF?list.filter(function(c){return shotOf(c,SHOTF);}):list;}
/* Media's Shot ▾ (line 2): sizes, then angles, then By sequence; counts from what the folder or search is showing (SHOTBASE) */
var SHOTBASE=[];
function shotMenu(anchor){var n={};SHOTBASE.forEach(function(c){var e=BIX[c];if(!e)return;if(e.f)n[e.f]=(n[e.f]||0)+1;if(e.c)n.creative=(n.creative||0)+1;if(e.a&&e.a!=="eye level")n[e.a]=(n[e.a]||0)+1;});
  if(SHOTF&&!n[SHOTF])SHOTF="";
  function pick(k){return [shotWord(k),n[k],SHOTF===k,function(){SHOTF=SHOTF===k?"":k;drawLib();}];}
  var it=[["Every shot",null,!SHOTF,function(){SHOTF="";drawLib();}],["Size"]];
  SHOT_SIZES.concat(["creative"]).forEach(function(k){if(n[k])it.push(pick(k));});
  var ang=Object.keys(n).filter(function(k){return SHOT_SIZES.indexOf(k)<0&&k!=="creative";}).sort(function(a,b){return n[b]-n[a];});
  if(ang.length){it.push(["Angle"]);ang.forEach(function(k){it.push(pick(k));});}
  it.push("-");it.push([(SEQV?"✓ ":"")+"Group by sequence",null,SEQV,function(){SEQV=!SEQV;try{localStorage.setItem("loop.seqview",SEQV?"1":"0");}catch(e){}drawLib();}]);
  if(!Object.keys(n).length)it.splice(1,0,["Not indexed yet: shot sizes appear once the index has looked at these clips",null,false,function(){}]);
  ddMenu(anchor,it);}
/* the list with a header before each sequence: [{hd, n, f}, clip, clip, ..., {hd: "On their own"}, ...] */
function seqRows(list){if(SEQORDER){var o=[];for(var i=0;i<list.length;i+=SEQORDER.length){var s=(BIX[list[i]]||{}).s;o.push({hd:s,n:SEQORDER.length,f:SEQORDER.join(", ")});o=o.concat(list.slice(i,i+SEQORDER.length));}return o;}
  if(!SEQV)return list;var G={},order=[],solo=[];
  list.forEach(function(c){var s=(BIX[c]||{}).s;if(!s){solo.push(c);return;}if(!G[s]){G[s]=[];order.push(s);}G[s].push(c);});
  function fi(c){var e=BIX[c]||{},i=SHOT_SIZES.indexOf(e.f);return (i<0?9:i)+(e.c?.5:0);}
  var out=[];order.forEach(function(s){var L=G[s].sort(function(a,b){return fi(a)-fi(b);});
    if(L.length<2){solo=solo.concat(L);return;}
    var fs=[];L.forEach(function(c){var f=(BIX[c]||{}).f;if(f&&fs.indexOf(f)<0)fs.push(f);});out.push({hd:s,n:L.length,f:fs.join(", ")});out=out.concat(L);});
  if(solo.length){out.push({hd:"On their own",n:solo.length,f:""});out=out.concat(solo);}return out;}
function seqHead(o){var d=el("div","seqhd");d.appendChild(el("span",null,o.hd));d.appendChild(el("small",null,o.n+" shots"+(o.f?" · "+o.f:"")));return d;}
/* Tidy up, two sections. WRONG FOLDER: clips whose content doesn't fit their folder, with where they look like they belong; Move
   does it in Loop only. LOOK ALIKE (Gabe, 2026-10-22): groups of clips that are the same shot or nearly (same footage under
   another name, trimmed or re-exported, or the same scene from the same angle), the suggested keeper first (biggest picture, then
   longest). The only action is Hide in Loop (library_map.json); nothing on the drive is deleted or moved. */
function tidyThumb(c){var im=el("img");im.loading="lazy";im.src="/thumb?p="+encodeURIComponent(c)+"&t=1";return im;}
function libTidy(){fetch("/api/broll-cleanup").then(function(r){return r.json();}).then(function(d){var all=d.rows||[];
  var mis=all.filter(function(r){return r.kind!=="alike";}),alk=all.filter(function(r){return r.kind==="alike";});
  var bg=el("div","askbg"),bx=el("div","askbox tidybox"),tabs=el("div","ibg tidytabs"),body=el("div");
  bx.appendChild(el("b",null,"Tidy up your B-roll"));bx.appendChild(el("p",null,"From what's in each shot. Only Loop's folders change; the files on your drive stay where they are."));
  [["mis","Wrong folder ("+mis.length+")"],["alk","Look alike ("+alk.length+")"]].forEach(function(k){var t=el("button","btn",k[1]);t.type="button";t.dataset.k=k[0];t.onclick=function(){show(k[0]);};tabs.appendChild(t);});
  bx.appendChild(tabs);bx.appendChild(body);
  function show(k){[].forEach.call(tabs.children,function(t){t.classList.toggle("on",t.dataset.k===k);});body.innerHTML="";if(k==="mis")drawMis();else drawAlk();}
  function drawMis(){if(!mis.length)body.appendChild(el("p","empty","Every indexed clip fits its folder."));
    mis.forEach(function(r){var row=el("div","tidyrow");row.appendChild(tidyThumb(r.clip));
      var tx=el("div","tx");tx.appendChild(el("em",null,r.description));tx.appendChild(el("small",null,r.clip.split("/").pop()+" · in "+r.bucket+" → "+r.suggested+(r.kind==="sub"?" (same folder, better spot)":"")));row.appendChild(tx);
      var mv=el("button","btn","Move to "+r.suggested);mv.type="button";mv.onclick=function(){mv.disabled=true;libEdit({op:"move",clips:[r.clip],to:r.suggested});row.classList.add("done");mv.textContent="Moved";};
      row.appendChild(mv);body.appendChild(row);});}
  function drawAlk(){if(!alk.length)body.appendChild(el("p","empty","No look-alikes among the clips you haven't hidden."));
    alk.forEach(function(g){var grp=el("div","tidygrp"),hd=el("div","tidyhd");hd.appendChild(el("span",null,g.clips.length+" clips · "+g.why));
      var rest=g.clips.map(function(c){return c.clip;}).filter(function(c){return c!==g.keep;});
      var ha=el("button","btn","Hide all but the keeper");ha.type="button";ha.title="Hides the other "+rest.length+" in Loop (find them under Hidden)";
      ha.onclick=function(){ha.disabled=true;libEdit({op:"hide",clips:rest});[].forEach.call(grp.querySelectorAll(".tidyrow"),function(r){if(r.dataset.c!==g.keep){r.classList.add("done");var b=r.querySelector("button");b.disabled=true;b.textContent="Hidden";}});};
      hd.appendChild(ha);grp.appendChild(hd);
      g.clips.forEach(function(c){var row=el("div","tidyrow"+(c.clip===g.keep?" keep":""));row.dataset.c=c.clip;row.appendChild(tidyThumb(c.clip));
        var tx=el("div","tx");tx.appendChild(el("em",null,c.description));
        tx.appendChild(el("small",null,(c.clip===g.keep?"Suggested keeper · ":"")+c.clip.split("/").pop()+" · "+c.secs+" s"+(c.w?" · "+c.w+"×"+c.h:"")+" · "+c.bucket));row.appendChild(tx);
        var hb=el("button","btn","Hide");hb.type="button";hb.title="Hide in Loop only (find it under Hidden)";hb.onclick=function(){hb.disabled=true;libEdit({op:"hide",clips:[c.clip]});row.classList.add("done");hb.textContent="Hidden";};
        row.appendChild(hb);grp.appendChild(row);});
      body.appendChild(grp);});}
  show(mis.length||!alk.length?"mis":"alk");
  var rr=el("div","askrow"),c=el("button","btn go","Done");c.type="button";rr.appendChild(c);bx.appendChild(rr);bg.appendChild(bx);document.body.appendChild(bg);
  function close(){bg.remove();}c.onclick=close;bg.onmousedown=function(e){if(e.target===bg)close();};});}
document.addEventListener("DOMContentLoaded",function(){bixLoad();setTimeout(bixLoad,4000);
  if(typeof libEdit==="function"){var le=libEdit;libEdit=function(b,g){le(b,g);if(b&&b.op==="unhide")setTimeout(bixLoad,1500);};}});      /* un-hidden clips get indexed */
