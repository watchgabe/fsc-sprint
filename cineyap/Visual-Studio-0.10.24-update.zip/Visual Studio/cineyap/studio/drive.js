/* drive.js: CineYap edits files where they live, so the drives it reads must be plugged in.
   Asks once that they know (POST /api/ack-drive), then shows a bar whenever a drive is missing.
   The server also refuses a rebuild while a drive that video needs is missing (studio.py /api/apply). */
(function(){
var bar=document.createElement("div");bar.id="driveBar";
var main=document.querySelector(".main");main.insertBefore(bar,main.firstChild);
function names(l){return and(l.map(function(d){return d.name;}));}
function and(a){return a.length<2?a.join(""):a.slice(0,-1).join(", ")+" and "+a[a.length-1];}
function needList(l){var s={};l.forEach(function(d){d.needed_for.forEach(function(n){s[n]=1;});});return Object.keys(s);}
function needs(l){return and(needList(l));}
function check(){
  var hs=decodeURIComponent(location.hash.replace(/^#/,"")),job=hs.indexOf("v/")===0?hs.split("/")[1]:"";
  fetch("/api/drives"+(job?"?job="+encodeURIComponent(job):"")).then(function(r){return r.json();}).then(draw).catch(function(){});}
function draw(D){
  bar.innerHTML="";var l=D.list||[];if(!l.length)return;
  var gone=l.filter(function(d){return !d.mounted;});
  if(!D.ack){
    var c=document.createElement("div");c.className="drv drv-ack";
    c.innerHTML='<div><b>Your files stay on your drive</b><p>Visual Studio edits your footage where it lives, with nothing to upload. Your '+needs(l)+' '+(needList(l).length>1?'are':'is')+' on <b>'+names(l)+'</b>, so keep it plugged in while you edit. If it is unplugged, the Studio will not rebuild a video, because the clips on it would drop out.</p></div>';
    var b=document.createElement("button");b.type="button";b.className="sbtn pri";b.textContent="Got it, I'll keep it connected";
    b.onclick=function(){fetch("/api/ack-drive",{method:"POST"}).then(check);};
    c.appendChild(b);bar.appendChild(c);}
  if(gone.length){
    var w=document.createElement("div");w.className="drv drv-off";
    w.innerHTML='<div><b>'+names(gone)+(gone.length>1?' are':' is')+' not connected</b><p>Plug it in to use your '+needs(gone)+'. Videos already built still open in CapCut, but clips on that drive show as missing, and rebuilding waits until it is back.</p></div>';
    var k=document.createElement("button");k.type="button";k.className="sbtn";k.textContent="Check again";k.onclick=check;
    w.appendChild(k);bar.appendChild(w);}
}
window.addEventListener("hashchange",check);window.addEventListener("focus",check);
check();setInterval(check,15000);
})();
