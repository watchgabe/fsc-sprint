/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* CineYap Studio: the page. Formats, Effects, and a Board for every video in every format.
   Talks to studio.py on this Mac: /api/state, /api/aroll, /api/new, /api/run, /api/reveal. */
(function(){
"use strict";
var $=function(s,r){return (r||document).querySelector(s);}, $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
var page=$("#page"), APP={state:null,D:null,S:null,lib:null};
function h(tag,attrs,kids){var e=document.createElement(tag);attrs=attrs||{};
  Object.keys(attrs).forEach(function(k){var v=attrs[k];if(v==null||v===false)return;
    if(k==="class")e.className=v;else if(k==="text")e.textContent=v;else if(k==="html")e.innerHTML=v;
    else if(k.slice(0,2)==="on")e.addEventListener(k.slice(2),v);else e.setAttribute(k,v===true?"":v);});
  (kids||[]).forEach(function(c){if(c==null)return;e.appendChild(typeof c==="string"?document.createTextNode(c):c);});return e;}
var I={ /* 16px line icons */
 note:'<path d="M3 3.5h10v7H7l-3 2.5v-2.5H3z"/>', broll:'<rect x="2" y="3.5" width="12" height="9" rx="1.5"/><path d="m6.5 6.2 3.5 1.8-3.5 1.8z"/>',
 zin:'<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3 3M5 7h4M7 5v4"/>', zout:'<circle cx="7" cy="7" r="4.5"/><path d="m10.5 10.5 3 3M5 7h4"/>',
 user:'<circle cx="8" cy="5.5" r="2.5"/><path d="M3.5 13.5c.6-2.6 2.4-4 4.5-4s3.9 1.4 4.5 4"/>', sq:'<rect x="3" y="3" width="10" height="10" rx="2"/>',
 bolt:'<path d="M9 1.5 3.5 9H8l-1 5.5L12.5 7H8z"/>', card:'<rect x="2" y="4" width="12" height="8" rx="1.5"/><path d="M5 8h6"/>',
 play:'<path d="M5 3.5l7 4.5-7 4.5z"/>', up:'<path d="M8 13V3M4 7l4-4 4 4"/>', down:'<path d="M8 3v10M4 9l4 4 4-4"/>',
 look:'<path d="M2.5 12.5h11M4 9.5h8M5.5 6.5h5M7 3.5h2"/>', trash:'<path d="M3 4.5h10M6.5 4.5V3h3v1.5M4.5 4.5l.7 9h5.6l.7-9"/>',
 swap:'<path d="M3 5.5h9l-2.5-2.5M13 10.5H4l2.5 2.5"/>', open:'<path d="M9.5 2.5h4v4M13.5 2.5 7.5 8.5M12 9.5v4H2.5V4H6.5"/>',
 finder:'<rect x="2" y="3" width="12" height="10" rx="2"/><path d="M8 3v10M5.5 6v1M10.5 6v1"/>', pen:'<path d="m3 13 1-3.5 6.5-6.5 2.5 2.5L6.5 12z"/>',
 pal:'<circle cx="8" cy="8" r="5.5"/><circle cx="6" cy="6.5" r=".8"/><circle cx="9.5" cy="5.8" r=".8"/><circle cx="10.6" cy="9" r=".8"/>',
 board:'<rect x="2" y="2.5" width="12" height="11" rx="2"/><path d="M2 6h12M6 6v7.5"/>'};
function ic(n){return '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round">'+(I[n]||"")+'</svg>';}
function api(path,body){return fetch(path,body?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)}:{}).then(function(r){return r.json();});}
function fmt(s){var m=Math.floor(s/60),x=Math.round(s%60);if(x===60){m++;x=0;}return m+":"+(x<10?"0":"")+x;}
function esc(s){return String(s||"").replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}


function delBtn(job){return h("button",{type:"button",class:"sbtn danger",html:ic("trash")+"Delete project",onclick:function(){
  if(!confirm("Delete "+job+"? It stops any edit in progress and moves the project to the archive. Your raw video is not touched."))return;
  api("/api/delete",{job:job}).then(function(r){if(r.error){alert(r.error);return;}location.hash="#home";load().then(route);});}});}
function titleOf(job){var j=(APP.state.jobs||[]).filter(function(x){return x.job===job;})[0];return (j&&j.title)||job;}
function vhead(job){return h("div",{class:"vhead"},[h("div",{class:"t"},[h("a",{class:"note back",href:"#home",text:"← All projects"}),h("h1",{text:titleOf(job)})]),delBtn(job)]);}
/* ---------------------------------------------------------------- a video */
function renderVideo(job,f,again){
  var J=APP.state.jobs.filter(function(j){return j.job===job;})[0];
  page.className="wrap wide";page.innerHTML="";
  /* made since this page loaded (a Try again, a new video from Claude): ask again before saying it isn't there (a tester, 2026-10-23) */
  if(!J&&!again){load().then(function(){renderVideo(job,f,true);});return;}
  if(!J){page.appendChild(h("p",{class:"as-p",text:"No video called "+job+"."}));return;}
  if(J.stage==="edit"){location.href="/static/editor.html?job="+encodeURIComponent(job);return;}   /* step 2 is the timeline editor */
  if(J.brief&&!J.formats.length){location.replace("/static/editor.html?job="+encodeURIComponent(job));return;}      /* from the New video panel: the editor shows it cutting, or why it stopped and Try again */
  if(["cutting","aroll","preparing"].indexOf(J.stage)>=0)return renderAroll(job);
  page.appendChild(vhead(job));      /* what is left of the old project page (2026-10-23): a take still being cut, or why it stopped */
  page.appendChild(h("div",{class:"as-empty",html:J.stage==="failed"?"<b>This edit stopped</b>"+esc(J.error||"See edit/studio_new.log in the project."):"<b>Adding captions and B-roll</b>The A-roll is locked. Claude is building "+esc(J.format_name||"it")+" on it. It shows up here when it's ready."}));}

/* ---------------------------------------------------------------- run log */
function showRun(first){var rl=$("#runlog");rl.hidden=false;$(".runlog-head b",rl).textContent="Working… wait for this to finish";$("pre",rl).innerHTML="";logLine(first);}
function logLine(t,cls){var pre=$("#runlog pre");var s=h("span",{class:cls||"",text:t+"\n"});pre.appendChild(s);pre.scrollTop=pre.scrollHeight;}
function poll(id,done){var seen=0;(function tick(){api("/api/run?id="+id).then(function(r){
  for(;seen<r.log.length;seen++){var l=r.log[seen];logLine(l,/^STOPPED|failed|FAIL|Error/.test(l)?"bad":(/^Done|opened|CLEAN|clean/.test(l)?"ok":""));}
  if(r.done){var rl=$("#runlog");$(".runlog-head b",rl).textContent=r.ok?"Done":"Stopped";if(r.ok){logLine("Done.","ok");setTimeout(function(){rl.hidden=true;},1800);}if(done)done(r.ok);}else setTimeout(tick,900);});})();}
$("#runlog .runlog-head button").addEventListener("click",function(){$("#runlog").hidden=true;});


/* ---------------------------------------------------------------- home (Studio MVP) */
var NEWF=[["vcineyap","Vertical","9:16 · Reels, TikTok, Shorts"],["cineyap43","4:3","Feed posts"],["cineyap","16:9","YouTube"]];
var STAGE_LABEL={cutting:"Cutting A-roll…",aroll:"Review A-roll",locked:"Locked",preparing:"Opening the editor…",edit:"Editing",building:"Adding captions…",failed:"Stopped"};
/* ---------------------------------------------------------------- the A-roll (Gabe, 2026-10-20: A-roll first, then captions and graphics) */
var AROLL_TAB="lines";
function renderAroll(job){
  page.className="wrap wide";page.innerHTML="";
  page.appendChild(vhead(job));
  api("/api/aroll?job="+encodeURIComponent(job)).then(function(A){
    if(A.stage==="cutting"||!A.rows.length){
      page.appendChild(h("div",{class:"as-empty",html:"<b>Working on the A-roll</b>Claude is picking the best take of every line and cutting the false starts. You'll review it here before any captions or B-roll go on."}));
      setTimeout(function(){if(location.hash==="#v/"+encodeURIComponent(job))load().then(route);},10000);return;}
    var editing=A.stage==="edit";
    page.appendChild(h("div",{class:"steps"},[h("span",{class:"on",text:"1 · A-roll"}),editing?h("a",{href:"/static/editor.html?job="+encodeURIComponent(job),class:"steplink",text:"2 · Edit"}):h("span",{text:"2 · Edit"})]));
    if(editing)page.appendChild(h("p",{class:"note",style:"margin:-8px 0 14px",text:"You're editing this video. Changes to the lines here go into the editor's timeline; your B-roll, screens and music stay where they are."}));
    var order=A.rows.map(function(r){return r.n;}),cut={},R={};A.rows.forEach(function(r){R[r.n]=r;});
    var split=h("div",{class:"avsplit"+(A.format==="vcineyap"?" tall":"")}),left=h("div",{class:"aleft"}),right=h("div",{class:"aright"});
    split.appendChild(left);split.appendChild(right);page.appendChild(split);
    /* left: the video, big */
    var vid=h("video",{src:"/file?p="+encodeURIComponent(A.video)+"&v="+A.v,controls:true,playsinline:true,preload:"metadata"}),stopAt=null;
    vid.addEventListener("timeupdate",function(){if(stopAt!==null&&vid.currentTime>=stopAt){vid.pause();stopAt=null;}});
    left.appendChild(h("div",{class:"apv"},[vid]));
    left.appendChild(h("div",{class:"stats"},[h("div",{},[h("b",{text:clock(A.runtime_s||0)}),h("span",{text:"length"})]),h("div",{},[h("b",{text:String(A.rows.length)}),h("span",{text:"lines"})]),
      h("div",{},[h("button",{type:"button",class:"lutsw"+(A.lut?" on":""),title:"Shot in log? Turn on your LUT. The A-roll re-renders with it, and the editor opens already graded.",
        text:A.lut?"LUT on":"LUT off",onclick:function(){var on=!A.lut;showRun(on?"Turning your LUT on…":"Turning the LUT off…");
          api("/api/aroll-lut",{job:job,on:on}).then(function(r){poll(r.run,function(){load().then(route);});});}}),h("span",{text:"color"})])]));
    /* right: SCRIPT (2026-10-21). One dropdown of scripts: the cut as it is, plus one per other hook you recorded (found
       automatically). Pick one and the lines below are that whole script: its hook, then the rest of the cut. */
    var HK={hooks:[]},SEL="";
    var picker=h("div",{class:"spick2"}),panel=h("div",{class:"apanel"});right.appendChild(picker);right.appendChild(panel);
    var hv=h("video",{class:"hookpv",playsinline:true,preload:"metadata"}),hstop=null;hv.style.display="none";left.querySelector(".apv").appendChild(hv);
    hv.addEventListener("timeupdate",function(){if(hstop!==null&&hv.currentTime>=hstop){hv.pause();hstop=null;}});
    /* PLAY-THROUGH: ▶ plays the script from that line to the end: the hook (from the raw take when it's another script),
       then every kept line in order, skipping the ones you've cut. Pause the video to stop. */
    var SEQ=null;
    function scriptSegs(){var P=picked(),k=lead(),out=[];if(P)out.push({hv:true,s:P.src_in,e:P.src_out,n:"hook"});
      order.forEach(function(n){if(cut[n]||(P&&n<=k))return;out.push({hv:false,s:R[n].at,e:R[n].at+R[n].dur,n:n});});return out;}
    function scriptLen(P){var k=lead(),d=P?P.src_out-P.src_in:0;order.forEach(function(n){if(cut[n]||(P&&n<=k))return;d+=R[n].dur;});return d;}
    function vOf(g){return g.hv?hv:vid;}
    function stepSeq(){if(!SEQ)return;var g=SEQ.segs[SEQ.i];if(!g){SEQ=null;return;}var v=vOf(g),o=g.hv?vid:hv;SEQ.busy=true;
      o.pause();o.style.display="none";v.style.display="";if(g.hv&&!hv.getAttribute("src")&&HK.proxy)hv.src="/file?p="+encodeURIComponent(HK.proxy);
      if(Math.abs(v.currentTime-g.s)>.06)v.currentTime=g.s;var pr=v.play();(pr&&pr.then?pr:Promise.resolve()).then(function(){if(SEQ)SEQ.busy=false;},function(){if(SEQ)SEQ.busy=false;});}
    var SEQT=null;
    function playFrom(key){var segs=scriptSegs(),i=Math.max(0,segs.findIndex(function(g){return g.n===key;}));stopAt=null;hstop=null;clearInterval(SEQT);SEQ={segs:segs,i:i,busy:false};stepSeq();
      SEQT=setInterval(function(){if(!SEQ){clearInterval(SEQT);return;}var g=SEQ.segs[SEQ.i],v=vOf(g);
        if(!SEQ.busy&&v.paused&&v.currentTime<g.e-.05){SEQ=null;return;}      /* you paused it */
        if(v.currentTime>=g.e-.02){SEQ.i++;var nx=SEQ.segs[SEQ.i];if(!nx){v.pause();SEQ=null;return;}
          if(!(nx.hv===g.hv&&Math.abs(nx.s-g.e)<.05))stepSeq();}},25);}      /* next line follows on: keep playing, else jump */
    function playSrc(){playFrom("hook");}
    function playCut(at){var n=order.filter(function(m){return R[m].at===at;})[0];playFrom(n);}
    var note=h("textarea",{class:"aroll-note",rows:3,placeholder:"Note to Claude: \"Use the other take of line 3.\" \"Trim the pause after line 9.\" \"End on the payoff.\""});
    var ct=h("span",{class:"ct"}),apply=h("button",{type:"button",class:"sbtn",text:"Apply changes",onclick:function(){go(false);}}),
        lockb=h("button",{type:"button",class:"sbtn go",text:A.stage==="edit"?"Save and back to the editor":"Lock this script, open the editor",onclick:function(){go(true);}});
    var bar=h("div",{class:"sendbar"},[ct,apply,lockb]);
    function curHook(){return (HK.hooks||[]).filter(function(x){return x.current;})[0]||null;}
    function lead(){return curHook()?(HK.lead||1):0;}
    function picked(){return SEL&&curHook()&&SEL!==curHook().id?(HK.hooks.filter(function(x){return x.id===SEL;})[0]||null):null;}
    function short(t){t=String(t||"").trim();return t.length>50?t.slice(0,50).replace(/\s+\S*$/,"")+"…":t;}
    function scripts(){var c=curHook(),L=[{id:c?c.id:"",text:c?c.text:order.slice(0,1).map(function(n){return R[n].text;}).join(" "),cur:true}];
      (HK.hooks||[]).forEach(function(x){if(!x.current)L.push({id:x.id,text:x.text,hook:x});});return L;}
    function kept(){return order.filter(function(n){return !cut[n];});}
    function moved(){var k=kept();return k.length!==A.rows.length||k.some(function(n,i){return n!==i+1;});}
    function counts(){var k=kept(),P=picked(),d=k.reduce(function(a,n,i){return a+(P&&n<=lead()?0:R[n].dur);},0)+(P?P.src_out-P.src_in:0),dirty=moved()||!!note.value.trim()||!!P;
      ct.innerHTML="<b>"+(k.length-(P?lead()-1:0))+"</b> lines · <b>"+clock(d)+"</b>"+(dirty?" · unsaved":"");apply.disabled=!dirty;
      apply.textContent=note.value.trim()?"Send to Claude":"Apply changes";}
    function drawPicker(){picker.innerHTML="";var L=scripts(),i=Math.max(0,L.findIndex(function(x){return x.id===(SEL||L[0].id);})),cur=L[i];
      var menu=h("div",{class:"smenu2",hidden:true});
      var btn=h("button",{type:"button",class:"sbtn2",onclick:function(e){e.stopPropagation();menu.hidden=!menu.hidden;}},[h("span",{class:"sl",text:"Script "+(i+1)}),h("span",{class:"st",text:short(cur.text)}),h("span",{class:"slen",text:clock(scriptLen(cur.hook||null))}),h("span",{class:"sc",text:L.length>1?"▾ "+L.length+" scripts":"▾"})]);
      L.forEach(function(x,j){menu.appendChild(h("div",{class:"smi2"+(j===i?" on":""),onclick:function(){menu.hidden=true;SEL=x.id;draw();}},[
        h("span",{class:"sl",text:"Script "+(j+1)}),h("span",{class:"st",text:short(x.text)}),h("span",{class:"slen",text:clock(scriptLen(x.hook||null))}),
        h("button",{type:"button",class:"ibtn",title:"Play this whole script",html:ic("play"),onclick:function(e){e.stopPropagation();menu.hidden=true;SEL=x.id;draw();playFrom(x.hook?"hook":order[0]);}})]));});
      if(!(HK.hooks||[]).length)menu.appendChild(h("div",{class:"smi2 find",text:HK.finding?"Finding the other hooks you recorded…":"Find the other hooks you recorded",onclick:function(e){e.stopPropagation();if(HK.finding)return;HK.finding=true;menu.hidden=true;drawPicker();
        api("/api/hooks",{job:job}).then(function(r){poll(r.run,function(){loadHooks();});});}}));
      document.addEventListener("click",function(){menu.hidden=true;},{once:true});
      picker.appendChild(btn);picker.appendChild(menu);}
    function lineRow(n,i,isHook){var r=R[n];var flags=(r.flags||[]).length?h("div",{class:"note",text:"⚑ "+r.flags.join(" · ")}):null;
      return h("div",{class:"ln"+(cut[n]?" cut":"")+(isHook?" hookln":"")},[
        h("button",{type:"button",class:"ibtn",title:"Play line "+(i+1),"aria-label":"Play line "+(i+1),html:ic("play"),onclick:function(){playCut(r.at,r.dur);}}),
        h("div",{class:"mid"},[h("div",{class:"txt"},[h("span",{class:"num",text:String(i+1)}),r.text||"",r.beat?h("span",{class:"beat",text:r.beat}):null]),flags]),
        h("div",{class:"right"},[h("span",{class:"dur",text:r.dur.toFixed(1)+"s"}),
          h("button",{type:"button",class:"ibtn",title:"Move up","aria-label":"Move line up",disabled:i===0,html:ic("up"),onclick:function(){var k=order.indexOf(n);order.splice(k,1);order.splice(k-1,0,n);draw();}}),
          h("button",{type:"button",class:"ibtn",title:"Move down","aria-label":"Move line down",disabled:order.indexOf(n)===order.length-1,html:ic("down"),onclick:function(){var k=order.indexOf(n);order.splice(k,1);order.splice(k+1,0,n);draw();}}),
          h("button",{type:"button",class:"ibtn"+(cut[n]?" on":""),title:cut[n]?"Restore":"Cut","aria-label":(cut[n]?"Restore":"Cut")+" line",html:ic("trash"),onclick:function(){cut[n]=!cut[n];draw();}})])]);}
    function drawLines(){var list=h("div",{class:"board"}),P=picked(),k=lead(),i=0;
      if(P){list.appendChild(h("div",{class:"ln hookln"},[h("button",{type:"button",class:"ibtn",title:"Play the hook",html:ic("play"),onclick:function(){playSrc(P.src_in,P.src_out);}}),
          h("div",{class:"mid"},[h("div",{class:"txt"},[h("span",{class:"num",text:"1"}),P.text,h("span",{class:"beat",text:"HOOK"})])]),h("div",{class:"right"},[h("span",{class:"dur",text:(P.src_out-P.src_in).toFixed(1)+"s"})])]));i=1;}
      order.forEach(function(n){if(P&&n<=k)return;list.appendChild(lineRow(n,i,!P&&n<=k));i++;});return list;}
    function drawNote(){var box=h("div",{class:"notes2"});box.appendChild(note);
      var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
      if(SR){var rec=null,mic=h("button",{type:"button",class:"sbtn mic",html:ic("note")+"<span>Voice note</span>"});
        mic.addEventListener("click",function(){if(rec){rec.stop();return;}rec=new SR();rec.continuous=true;rec.interimResults=false;rec.lang="en-US";
          var base=note.value;rec.onresult=function(e){var t="";for(var i=0;i<e.results.length;i++)t+=e.results[i][0].transcript;note.value=(base?base.trim()+" ":"")+t.trim();counts();};
          rec.onend=function(){rec=null;mic.classList.remove("rec");mic.querySelector("span").textContent="Voice note";};
          rec.start();mic.classList.add("rec");mic.querySelector("span").textContent="Stop recording";});
        box.appendChild(mic);}
      return box;}
    function draw(){drawPicker();panel.innerHTML="";panel.appendChild(drawLines());panel.appendChild(drawNote());panel.appendChild(bar);counts();}
    note.addEventListener("input",function(){counts();});
    function go(lock){var k=kept(),P=picked();if(!k.length)return;
      showRun(lock?"Locking the A-roll…":(P?"Putting that script's hook at the front…":(note.value.trim()?"Sending your note to Claude…":"Updating the A-roll…")));
      split.style.opacity=".45";split.style.pointerEvents="none";
      api("/api/aroll",{job:job,order:k,note:note.value.trim(),lock:lock,hook:P?P.id:undefined}).then(function(r){poll(r.run,function(){if(lock){location.href="/static/editor.html?job="+encodeURIComponent(job);return;}load().then(route);});});}
    function loadHooks(){api("/api/hooks?job="+encodeURIComponent(job)).then(function(H){HK=H||{hooks:[]};draw();});}
    draw();loadHooks();});}
function clock(s){s=Math.round(s||0);return Math.floor(s/60)+":"+("0"+s%60).slice(-2);}
function renderHome(){
  page.className="wrap wide";page.innerHTML="";
  if(window.welcomeCard)page.appendChild(welcomeCard());      /* first open: the setup checklist (newvideo.js), until it's done or skipped */
  page.appendChild(h("h1",{class:"pg-title",text:"Projects"}));
  var dz=h("div",{class:"dropzone"},[h("b",{text:"Drop your raw video here, or start a new video"}),
    h("span",{text:"Add your takes and any B-roll, tell Claude what you want, and the editor opens right away. No take? You get a blank project to build from B-roll and text."}),
    h("div",{class:"newrow"},[h("button",{type:"button",class:"bigbtn",text:"Start new video",onclick:function(){openNewVideo();}})])]);      /* New carousel is hidden until carousels ship (Gabe, 2026-10-24) */
  dz.addEventListener("dragover",function(e){e.preventDefault();dz.classList.add("drag");});
  dz.addEventListener("dragleave",function(){dz.classList.remove("drag");});
  dz.addEventListener("drop",function(e){e.preventDefault();dz.classList.remove("drag");var F=[].slice.call((e.dataTransfer&&e.dataTransfer.files)||[]).filter(function(f){return /\.(mp4|mov|m4v|mxf|mts)$/i.test(f.name);});if(!F.length)return;
    var paths=[];(function next(i){if(i>=F.length){$("#runlog").hidden=true;openNewVideo(paths);return;}showRun("Copying "+F[i].name+" into Visual Studio ("+(i+1)+" of "+F.length+")…");
      fetch("/api/upload-raw?name="+encodeURIComponent(F[i].name),{method:"POST",body:F[i]}).then(function(r){return r.json();}).then(function(r){if(r.path)paths.push(r.path);next(i+1);});})(0);});
  page.appendChild(dz);
  var all=APP.state.jobs,show=HOMEKIND,sort=HOMESORT;
  var jobs=all.filter(function(j){return show==="all"||(show==="carousel")===(j.kind==="carousel");});
  jobs=jobs.slice().sort(function(a,b){if(sort==="name")return (a.title||a.job).localeCompare(b.title||b.job);var x=a.modified||0,y=b.modified||0;return sort==="old"?x-y:y-x;});
  var bar=h("div",{class:"pbar"},[h("span",{class:"pg-sub",text:all.length?(jobs.length===all.length?all.length+" project"+(all.length===1?"":"s"):jobs.length+" of "+all.length+" projects"):"Your projects show up here."})]);
  var seg=h("div",{class:"pseg"});[["all","All"],["video","Videos"],["carousel","Carousels"]].forEach(function(k){seg.appendChild(h("button",{type:"button",class:k[0]===show?"on":"",text:k[1],onclick:function(){HOMEKIND=k[0];try{localStorage.setItem("loop.homekind",k[0]);}catch(e){}renderHome();}}));});
  var so=h("select",{class:"psort",onchange:function(e){HOMESORT=e.target.value;try{localStorage.setItem("loop.homesort",HOMESORT);}catch(x){}renderHome();}});
  [["new","Newest first"],["old","Oldest first"],["name","By name"]].forEach(function(k){var o=h("option",{value:k[0],text:k[1]});if(k[0]===sort)o.selected=true;so.appendChild(o);});
  bar.appendChild(seg);bar.appendChild(so);page.appendChild(bar);
  var g=h("div",{class:"projects"});
  jobs.forEach(function(j){
    if(j.kind==="carousel"){var ct=h("div",{class:"pthumb"});if(j.thumb)ct.appendChild(h("img",{src:"/thumb?p="+encodeURIComponent(j.thumb)+"&t=1",alt:"",loading:"lazy"}));else ct.appendChild(h("span",{text:"No B-roll yet"}));
      ct.appendChild(h("span",{class:"ptag",text:"Carousel · "+j.slides+" slide"+(j.slides===1?"":"s")}));
      g.appendChild(h("a",{class:"pcard",href:"/static/editor.html?job="+encodeURIComponent(j.job)},[ct,h("div",{class:"pmeta"},[h("b",{text:j.title||j.job})])]));return;}
    var busy={cutting:"Cutting the A-roll…",preparing:"Opening the editor…",building:"Building…",failed:"Stopped"}[j.stage]||"";
    var th=h("div",{class:"pthumb"});
    if(j.thumb)th.appendChild(h("img",{src:"/thumb?p="+encodeURIComponent(j.thumb)+"&t=4",alt:"",loading:"lazy"}));
    else th.appendChild(h("span",{text:busy||"No picture yet"}));
    if(busy&&j.thumb)th.appendChild(h("span",{class:"pbusy"+(j.stage==="failed"?" warn":""),text:busy}));
    var card=h("a",{class:"pcard",href:j.stage==="edit"?"/static/editor.html?job="+encodeURIComponent(j.job):"#v/"+encodeURIComponent(j.job)},[th,h("div",{class:"pmeta"},[h("b",{text:j.title||j.job})])]);
    var v=th.querySelector("video");if(v){card.addEventListener("mouseenter",function(){v.play();});card.addEventListener("mouseleave",function(){v.pause();});}
    g.appendChild(card);});
  /* new edits still waiting their turn (one is cut at a time) */
  (APP.state.newq||[]).forEach(function(q){var th=h("div",{class:"pthumb"},[h("span",{text:"Waiting to start"})]);
    g.insertBefore(h("div",{class:"pcard wait"},[th,h("div",{class:"pmeta"},[h("b",{text:q.name}),h("span",{class:"pg-sub",text:q.files+" take"+(q.files===1?"":"s")+" · next in line"})])]),g.firstChild);});
  page.appendChild(g);
  /* keep checking while anything is still going, every step of it (2026-10-23: the card sat on "transcribing" until a refresh) */
  if((APP.state.newq||[]).length||jobs.some(function(j){return j.busy||["cutting","building","preparing"].indexOf(j.stage)>=0;}))setTimeout(function(){if((location.hash||"#home")==="#home")load().then(route);},5000);}
var HOMEKIND=(function(){try{return localStorage.getItem("loop.homekind")||"all";}catch(e){return "all";}})(),HOMESORT=(function(){try{return localStorage.getItem("loop.homesort")||"new";}catch(e){return "new";}})();
/* a carousel starts from its copy: paste the slides (COVER / SLIDE 2 / ...), pick a shape, and the editor opens with them built */
/* BLANK PROJECT (Gabe, 2026-10-23): pick a shape, the editor opens on an empty timeline; drop B-roll, add a hook on the Text track */
function newBlank(){var box=h("div",{class:"modal"}),fmt="916";
  var row=h("div",{class:"fpick"});[["916","9:16","Reels, TikTok, Shorts"],["169","16:9","YouTube"],["43","4:3","Feed"]].forEach(function(k){row.appendChild(h("button",{type:"button",class:"fopt"+(k[0]===fmt?" on":""),html:"<b>"+k[1]+"</b><span>"+k[2]+"</span>",onclick:function(e){fmt=k[0];[].forEach.call(row.children,function(b){b.classList.toggle("on",b===e.currentTarget);});}}));});
  var go=h("button",{type:"button",class:"bigbtn",text:"Open the editor",onclick:function(){go.disabled=true;go.textContent="Opening…";api("/api/blank-new",{fmt:fmt}).then(function(r){if(r.error){alert(r.error);go.disabled=false;go.textContent="Open the editor";return;}location.href="/static/editor.html?job="+encodeURIComponent(r.job);});}});
  var card=h("div",{class:"mcard wide"},[h("h3",{text:"Blank project"}),h("p",{class:"note",text:"No take to cut. You start with an empty timeline: drop B-roll on it, add your hook with Text, add music, export."}),row,
    h("div",{class:"newrow"},[go,h("button",{type:"button",class:"sbtn",text:"Cancel",onclick:function(){box.remove();}})])]);
  box.appendChild(card);box.addEventListener("click",function(e){if(e.target===box)box.remove();});document.body.appendChild(box);}
function newCarousel(){var box=h("div",{class:"modal"}),ta=h("textarea",{class:"carta",placeholder:"COVER\nYour headline\nThe line under it\n\nSLIDE 2\nNext headline\nIts body…"}),fmt="43";
  var row=h("div",{class:"fpick"});[["169","16:9","Horizontal"],["43","4:3","Horizontal"],["34","3:4","Vertical"]].forEach(function(k){row.appendChild(h("button",{type:"button",class:"fopt"+(k[0]===fmt?" on":""),html:"<b>"+k[1]+"</b><span>"+k[2]+"</span>",onclick:function(e){fmt=k[0];[].forEach.call(row.children,function(x){x.classList.remove("on");});e.currentTarget.classList.add("on");}}));});
  var go=h("button",{type:"button",class:"bigbtn",text:"Build the slides",onclick:function(){go.disabled=true;go.textContent="Building…";api("/api/carousel-new",{text:ta.value,fmt:fmt}).then(function(r){if(r.error){alert(r.error);go.disabled=false;go.textContent="Build the slides";return;}location.href="/static/editor.html?job="+encodeURIComponent(r.job);});}});
  var card=h("div",{class:"mcard wide"},[h("h3",{text:"New carousel"}),h("p",{class:"note",text:"Paste the slides copied from Loop. Each slide gets 7 seconds of B-roll Claude picks from your library, in your carousel style."}),ta,row,
    h("div",{class:"newrow"},[go,h("button",{type:"button",class:"sbtn",text:"Cancel",onclick:function(){box.remove();}})])]);
  box.appendChild(card);box.addEventListener("click",function(e){if(e.target===box)box.remove();});document.body.appendChild(box);ta.focus();}
/* NEW EDIT (Gabe, 2026-10-25): pick one take or many. One take starts straight away. Several open "Group your videos": every take
   starts in its own folder (one folder = one video); drag takes into a folder to make them one video, joined in the order shown.
   No shape or LUT question: the server reads both off the footage (probe_video), and both can be changed in the editor */
function startNew(paths){if(!paths||!paths.length)return;if(paths.length===1){goBatch([{name:"",files:paths}]);return;}groupVideos(paths);}
function goBatch(groups){showRun(groups.length>1?"Starting "+groups.length+" edits. They're cut one after another; each shows up on the home page.":"Starting the edit…");
  api("/api/new-batch",{groups:groups}).then(function(r){if(r.error||!r.runs){logLine(r.error||"Couldn't start","bad");return;}poll(r.runs[0],function(){load().then(route);});setTimeout(function(){load().then(route);},4000);});}
function groupVideos(paths){
  var box=h("div",{class:"modal"}),card=h("div",{class:"mcard gv"}),INFO={},G=paths.map(function(p){return {name:"",files:[p]};}),DRAG=null;
  var grid=h("div",{class:"gvgrid"}),start=h("button",{type:"button",class:"bigbtn"}),warn=h("p",{class:"gvwarn"});
  function fname(p){return p.split("/").pop();}
  function stem(p){return fname(p).replace(/\.[^.]+$/,"");}
  function dur(s){s=Math.round(s||0);return Math.floor(s/60)+":"+("0"+s%60).slice(-2);}
  function shapeName(s){return {"916":"Vertical","43":"4:3","169":"16:9"}[s]||"";}
  function move(p,gi,before){G.forEach(function(g){g.files=g.files.filter(function(x){return x!==p;});});var f=G[gi].files,k=before?f.indexOf(before):-1;if(k<0)f.push(p);else f.splice(k,0,p);draw();}
  function draw(){grid.innerHTML="";var bad=false;
    G.forEach(function(g,gi){var col=h("div",{class:"gvf"+(g.files.length?"":" empty")});
      var nm=h("input",{class:"gvname",value:g.name,placeholder:g.files.length?stem(g.files[0]):"New video",oninput:function(e){g.name=e.target.value;}});
      var sub=h("span",{class:"gvsub",text:g.files.length?(g.files.length+" take"+(g.files.length>1?"s · joined in this order":"")):"Drop takes here"});
      col.appendChild(h("div",{class:"gvhead"},[h("span",{class:"gvic",html:'<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"><path d="M2 4.5h4l1.2 1.5H14v6.5H2z"/></svg>'}),nm]));col.appendChild(sub);
      var sigs={};g.files.forEach(function(p){var I=INFO[p]||{};if(I.sig)sigs[I.sig]=1;
        var ch=h("div",{class:"gvc",draggable:"true"},[h("img",{src:"/thumb?p="+encodeURIComponent(p)+"&t=1",alt:"",loading:"lazy"}),
          h("div",{class:"gvct"},[h("b",{text:fname(p)}),h("span",{text:I.dur?dur(I.dur)+" · "+shapeName(I.shape)+(I.log?" · log":""):(I.ok===false?"Not found":"Reading…")})]),
          h("button",{type:"button",class:"gvx",title:"Leave this take out",text:"×",onclick:function(){G.forEach(function(x){x.files=x.files.filter(function(y){return y!==p;});});draw();}})]);
        ch.addEventListener("dragstart",function(e){DRAG=p;e.dataTransfer.effectAllowed="move";e.dataTransfer.setData("text/plain",p);ch.classList.add("dragging");});
        ch.addEventListener("dragend",function(){DRAG=null;ch.classList.remove("dragging");});
        ch.addEventListener("dragover",function(e){if(!DRAG||DRAG===p)return;e.preventDefault();e.stopPropagation();ch.classList.add("before");});
        ch.addEventListener("dragleave",function(){ch.classList.remove("before");});
        ch.addEventListener("drop",function(e){if(!DRAG)return;e.preventDefault();e.stopPropagation();ch.classList.remove("before");move(DRAG,gi,p);});
        col.appendChild(ch);});
      if(Object.keys(sigs).length>1){bad=true;col.appendChild(h("p",{class:"gvwarn",text:"These were shot with different settings (size, frame rate or codec), so they can't be joined into one video. Give them their own folders."}));}
      col.addEventListener("dragover",function(e){if(!DRAG)return;e.preventDefault();col.classList.add("over");});
      col.addEventListener("dragleave",function(e){if(!col.contains(e.relatedTarget))col.classList.remove("over");});
      col.addEventListener("drop",function(e){if(!DRAG)return;e.preventDefault();col.classList.remove("over");move(DRAG,gi,null);});
      grid.appendChild(col);});
    var n=G.filter(function(g){return g.files.length;}).length;start.textContent=n===1?"Start 1 edit":"Start "+n+" edits";start.disabled=bad||!n;
    warn.textContent=bad?"Fix the folder marked above to start.":"";}
  var tools=h("div",{class:"gvtools"},[
    h("button",{type:"button",class:"sbtn",text:"All in one video",onclick:function(){var all=[];G.forEach(function(g){all=all.concat(g.files);});G=[{name:G[0]&&G[0].name||"",files:all}];draw();}}),
    h("button",{type:"button",class:"sbtn",text:"One video each",onclick:function(){var all=[];G.forEach(function(g){all=all.concat(g.files);});G=all.map(function(p){return {name:"",files:[p]};});draw();}}),
    h("button",{type:"button",class:"sbtn",text:"+ New folder",onclick:function(){G.push({name:"",files:[]});draw();}})]);
  start.onclick=function(){var groups=G.filter(function(g){return g.files.length;}).map(function(g){return {name:g.name.trim(),files:g.files};});box.remove();goBatch(groups);};
  card.appendChild(h("h3",{text:"Group your videos"}));
  card.appendChild(h("p",{class:"note",text:"Each folder becomes one video. To make several takes one video, drag them into the same folder (they're joined in the order shown). Shape and color are read from the footage, and you can change them in the editor."}));
  card.appendChild(tools);card.appendChild(grid);card.appendChild(warn);
  card.appendChild(h("div",{class:"newrow"},[start,h("button",{type:"button",class:"sbtn",text:"Cancel",onclick:function(){box.remove();}})]));
  box.appendChild(card);box.addEventListener("click",function(e){if(e.target===box)box.remove();});document.body.appendChild(box);draw();
  api("/api/probe",{paths:paths}).then(function(r){(r.videos||[]).forEach(function(v){INFO[v.path]=v;});draw();});}
function askFormat(path){
  var box=h("div",{class:"modal"}),card=h("div",{class:"mcard"},[h("h3",{text:"What shape is this edit?"}),h("p",{class:"note",text:path.split("/").pop()})]);
  var row=h("div",{class:"fpick"}),lut=h("input",{type:"checkbox"});
  NEWF.forEach(function(f){row.appendChild(h("button",{type:"button",class:"fopt",onclick:function(){box.remove();
    showRun("Starting the edit…");
    api("/api/new",{path:path,fmt:f[0],lut:lut.checked}).then(function(r){if(r.error){logLine(r.error,"bad");return;}poll(r.run,function(){load().then(route);});setTimeout(function(){load().then(route);},4000);});}},
    [h("span",{class:"shape "+f[0]}),h("b",{text:f[1]}),h("span",{text:f[2]})]));});
  card.appendChild(row);card.appendChild(h("label",{class:"lutopt"},[lut,h("span",{html:"<b>Apply my LUT</b> Only if you shot in log. Leave it off for a normal color profile."})]));
  card.appendChild(h("button",{type:"button",class:"sbtn",text:"Cancel",onclick:function(){box.remove();}}));
  box.appendChild(card);box.addEventListener("click",function(e){if(e.target===box)box.remove();});document.body.appendChild(box);}

/* ---------------------------------------------------------------- nav + routing */
function navJobs(){var nav=$("#jobNav");if(!nav)return;nav.innerHTML="";APP.state.jobs.forEach(function(j){
  var href=j.kind==="carousel"?"/static/editor.html?job="+encodeURIComponent(j.job):j.stage==="edit"?"/static/editor.html?job="+encodeURIComponent(j.job):"#v/"+encodeURIComponent(j.job);
  nav.appendChild(h("a",{href:href,"data-nav":"v/"+j.job,html:ic(j.kind==="carousel"?"card":"board")+"<span>"+esc(j.title||j.job)+"</span>"}));});}
function route(){var hs=decodeURIComponent(location.hash.replace(/^#/,""))||"home";
  $$(".rail nav a,.hbar a[data-nav]").forEach(function(a){var n=a.getAttribute("data-nav");a.classList.toggle("on",n===hs||(n&&hs.indexOf(n+"/")===0)||(n&&n.indexOf("v/")===0&&hs.split("/").slice(0,2).join("/")===n));});
  if(hs==="brand"&&typeof window.renderBrand==="function")return window.renderBrand(page,APP,h,api);      /* the Brand page is back in the sidebar (2026-10-23) */
  /* a carousel, or a video already in the editor, always opens in its editor: the old project page is only for a take still being cut */
  if(hs.indexOf("a/")===0||hs.indexOf("v/")===0){var jb=hs.split("/")[1],jj=(APP.state.jobs||[]).filter(function(x){return x.job===jb;})[0];
    if(jj&&jj.kind==="carousel"){location.replace("/static/editor.html?job="+encodeURIComponent(jb));return;}
    if(jj&&jj.stage==="edit"&&hs.indexOf("v/")===0){location.replace("/static/editor.html?job="+encodeURIComponent(jb));return;}
    /* still cutting: check again, and the editor opens by itself the moment it's ready (2026-10-23: it sat there until a refresh) */
    if(jj&&hs.indexOf("v/")===0&&(jj.busy||["cutting","preparing"].indexOf(jj.stage)>=0)){var at=location.hash;setTimeout(function(){if(location.hash===at)load().then(route);},5000);}}
  if(hs.indexOf("a/")===0)return renderAroll(hs.split("/")[1]);
  if(hs.indexOf("v/")===0){var p=hs.split("/");return renderVideo(p[1],p[2]);}
  if(hs==="newcarousel"){renderHome();history.replaceState(null,"","/#home");newCarousel();return;}
  renderHome();}
function load(){return api("/api/state").then(function(st){APP.state=st;navJobs();});}
$$("[data-go]").forEach(function(b){b.addEventListener("click",function(){location.hash=b.getAttribute("data-go");});});
window.addEventListener("hashchange",route);
window.CineYapStudio={APP:APP,h:h,api:api,poll:function(id,done){poll(id,done);},showRun:function(t){showRun(t);},reload:function(){return load().then(route);}};
load().then(route).catch(function(e){page.innerHTML="";page.appendChild(h("div",{class:"dw-flags",text:"Visual Studio is not answering. Double-click “Open Visual Studio” in its folder to start it."}));});
})();
