/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* grade.js — the grade engine (GRADING.md, 2026-10-24). One piece of maths for the editor's preview and the export.

A grade is a recipe (numbers, never pixels). It becomes one 3D LUT: every color goes through
  1. fix   — the footage itself, before the LUT: decoded to light (S-Log3 for log, gamma 2.4 for finished video), where highlights still exist
  2. lut   — the creator's .cube, at lut_amt (the graded picture laid over the ungraded one, as the Color tab always did)
  3. look  — a list of stages on the finished picture, in order (the clip's grade, then the piece's own), each: contrast and
             saturation, its creative Look LUT at its intensity, Faded Film, Vibrance, then its curve
The browser loads this file as window.Grade; Node runs it to write the export's .cube:
  node grade.js write <recipe.json> <out.cube> [size]          (LUTs are paths, read from disk; a missing one is left out)

Recipe: {space: "log"|"video", fix: {temp, tint, exposure, highlights, shadows, whites, blacks},
         lut: <path or "">, lut_amt: 0-1, look: [{exposure, contrast, pivot, warmth, saturation, lut, lut_amt, fade, vibrance, curve, curve_r, curve_g, curve_b}, ...]}
or {grades: [clip grade, piece grade]}: the editor's own grades, put together by fromGrades (the export sends these).
A grade (what the panel edits): {fix, lut_on, lut, lut_amt, look_on, look, look_amt, contrast, saturation, fade, vibrance, curve,
and the old exposure / warmth; off: true is the panel's switch). A piece's grade sits on its clip's: its fixes add on, its look comes after, and an Input LUT or
Look it picks itself replaces the clip's.
Every value's neutral is 0, except contrast and saturation (1) and pivot (0.5). Sliders are -1..1 unless noted; exposure is in stops.
The look stage's exposure, contrast, warmth and saturation are exactly the old Color tab maths (color_vf), so old videos
export the same. */
(function (root, make) {
  var G = make();
  if (typeof module === "object" && module.exports) { module.exports = G; if (require.main === module) G._cli(process.argv.slice(2)); }
  else root.Grade = G;
})(this, function () {
  "use strict";

  function clamp(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
  function smooth(a, b, x) { var t = (x - a) / (b - a); t = t < 0 ? 0 : t > 1 ? 1 : t; return t * t * (3 - 2 * t); }
  function num(o, k, d) { var v = o && o[k]; return v == null || v === "" || isNaN(v) ? d : +v; }

  /* ---------------------------------------------------------------- .cube files */
  function parseCube(text) {
    var size = 0, min = [0, 0, 0], max = [1, 1, 1], vals = [], lines = String(text).split(/\r?\n/);
    for (var i = 0; i < lines.length; i++) {
      var s = lines[i].trim(); if (!s || s[0] === "#") continue;
      var p = s.split(/\s+/), k = p[0].toUpperCase();
      if (k === "LUT_3D_SIZE") size = +p[1];
      else if (k === "LUT_1D_SIZE") throw new Error("a 1D LUT is not supported; export it as a 3D .cube");
      else if (k === "DOMAIN_MIN") min = [+p[1], +p[2], +p[3]];
      else if (k === "DOMAIN_MAX") max = [+p[1], +p[2], +p[3]];
      else if (/^[-+.\d]/.test(k)) vals.push(+p[0], +p[1], +p[2]);
    }
    if (!size || vals.length !== size * size * size * 3) throw new Error("not a 3D .cube (" + vals.length / 3 + " entries for size " + size + ")");
    return {size: size, min: min, max: max, data: new Float32Array(vals)};
  }

  /* tetrahedral interpolation, the same as ffmpeg's lut3d default; red changes fastest in a .cube */
  function sampleCube(c, r, g, b, out) {
    var N = c.size, d = c.data, x = [r, g, b], i = [0, 0, 0], f = [0, 0, 0];
    for (var a = 0; a < 3; a++) {
      var v = (x[a] - c.min[a]) / (c.max[a] - c.min[a]) * (N - 1); v = v < 0 ? 0 : v > N - 1 ? N - 1 : v;
      var q = Math.min(Math.floor(v), N - 2); i[a] = q; f[a] = v - q;
    }
    function at(dr, dg, db, ch) { return d[((i[0] + dr) + (i[1] + dg) * N + (i[2] + db) * N * N) * 3 + ch]; }
    var fr = f[0], fg = f[1], fb = f[2];
    for (var ch = 0; ch < 3; ch++) {
      var c000 = at(0, 0, 0, ch), c111 = at(1, 1, 1, ch), v;
      if (fr > fg) {
        if (fg > fb) v = (1 - fr) * c000 + (fr - fg) * at(1, 0, 0, ch) + (fg - fb) * at(1, 1, 0, ch) + fb * c111;
        else if (fr > fb) v = (1 - fr) * c000 + (fr - fb) * at(1, 0, 0, ch) + (fb - fg) * at(1, 0, 1, ch) + fg * c111;
        else v = (1 - fb) * c000 + (fb - fr) * at(0, 0, 1, ch) + (fr - fg) * at(1, 0, 1, ch) + fg * c111;
      } else {
        if (fb > fg) v = (1 - fb) * c000 + (fb - fg) * at(0, 0, 1, ch) + (fg - fr) * at(0, 1, 1, ch) + fr * c111;
        else if (fb > fr) v = (1 - fg) * c000 + (fg - fb) * at(0, 1, 0, ch) + (fb - fr) * at(0, 1, 1, ch) + fr * c111;
        else v = (1 - fg) * c000 + (fg - fr) * at(0, 1, 0, ch) + (fr - fb) * at(1, 1, 0, ch) + fb * c111;
      }
      out[ch] = v;
    }
    return out;
  }

  function toCube(lut, size, title) {
    var s = ["TITLE \"" + (title || "Loop grade") + "\"", "LUT_3D_SIZE " + size];
    for (var i = 0; i < lut.length; i += 3) s.push(lut[i].toFixed(6) + " " + lut[i + 1].toFixed(6) + " " + lut[i + 2].toFixed(6));
    return s.join("\n") + "\n";
  }

  /* ---------------------------------------------------------------- the curve (a monotone spline through the points, Fritsch-Carlson) */
  function makeCurve(pts) {
    if (!pts || pts.length < 2) return null;
    var P = pts.map(function (p) { return [clamp(+p[0]), clamp(+p[1])]; }).sort(function (a, b) { return a[0] - b[0]; });
    if (P[0][0] > 0) P.unshift([0, P[0][1]]); if (P[P.length - 1][0] < 1) P.push([1, P[P.length - 1][1]]);
    var n = P.length, dx = [], m = [], t = [];
    for (var i = 0; i < n - 1; i++) { dx[i] = Math.max(1e-6, P[i + 1][0] - P[i][0]); m[i] = (P[i + 1][1] - P[i][1]) / dx[i]; }
    t[0] = m[0]; t[n - 1] = m[n - 2];
    for (i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
    for (i = 0; i < n - 1; i++) {
      if (m[i] === 0) { t[i] = t[i + 1] = 0; continue; }
      var a = t[i] / m[i], b = t[i + 1] / m[i], h = a * a + b * b;
      if (h > 9) { var k = 3 / Math.sqrt(h); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
    }
    var ident = P.every(function (p) { return Math.abs(p[0] - p[1]) < 1e-4; });
    if (ident) return null;
    return function (x) {
      var j = 0; while (j < n - 2 && x > P[j + 1][0]) j++;
      var h = dx[j], s = (x - P[j][0]) / h, s2 = s * s, s3 = s2 * s;
      return clamp((2 * s3 - 3 * s2 + 1) * P[j][1] + (s3 - 2 * s2 + s) * h * t[j] + (-2 * s3 + 3 * s2) * P[j + 1][1] + (s3 - s2) * h * t[j + 1]);
    };
  }

  /* ---------------------------------------------------------------- 1. fix the footage */
  function fixOn(F) {
    return !!F && ["temp", "tint", "exposure", "highlights", "shadows", "whites", "blacks"].some(function (k) { return Math.abs(num(F, k, 0)) > 1e-4; });
  }
  /* how many stops each tone slider moves its range, by how far the pixel is from middle gray (z, in stops).
     Each slider's ramp is wide enough that a full pull never turns a brighter pixel darker than a dimmer one */
  function toneStops(F, z) {
    return 1.5 * (num(F, "highlights", 0) * smooth(-1, 3, z) + num(F, "shadows", 0) * (1 - smooth(-3, 1, z)))
         + 1.0 * (num(F, "whites", 0) * smooth(2, 5.5, z) + num(F, "blacks", 0) * (1 - smooth(-6.5, -3, z)));
  }
  /* log footage is decoded with Sony's S-Log3 curve (the creator's camera; V-Log and LogC sit close to it). A plain offset in log
     looked right in the highlights but lifted the black floor and turned the whole picture milky (measured 2026-10-24 on c1709) */
  function slog3Lin(v) { var x = v * 1023; return x >= 171.2102946929 ? Math.pow(10, (x - 420) / 261.5) * .19 - .01 : (x - 95) * .01125 / (171.2102946929 - 95); }
  function linSlog3(l) { return (l >= .01125 ? 420 + Math.log10((l + .01) / .19) * 261.5 : l * (171.2102946929 - 95) / .01125 + 95) / 1023; }
  function applyFix(F, log, c) {
    var e = num(F, "exposure", 0), t = num(F, "temp", 0), m = num(F, "tint", 0);
    var ch = [e + .35 * t + .15 * m, e - .3 * m, e - .35 * t + .15 * m];      // per-channel stops: warm/cool on red-blue, tint on green-magenta
    var L = log ? [slog3Lin(c[0]), slog3Lin(c[1]), slog3Lin(c[2])] : [Math.pow(c[0], 2.4), Math.pow(c[1], 2.4), Math.pow(c[2], 2.4)];
    var Y = .2126 * L[0] + .7152 * L[1] + .0722 * L[2], o = toneStops(F, Math.log2(Math.max(Y, 1e-6) / .18));
    for (var i = 0; i < 3; i++) {       // into light, a gain per channel (exposure, white balance, the tone sliders' region), back
      var g = L[i] * Math.pow(2, ch[i] + o);
      c[i] = clamp(log ? linSlog3(g) : Math.pow(Math.max(g, 0), 1 / 2.4));
    }
    return c;
  }

  /* ---------------------------------------------------------------- 3. the look */
  function lookOn(S, cubes) {
    return !!S && (Math.abs(num(S, "exposure", 0)) > 1e-3 || Math.abs(num(S, "contrast", 1) - 1) > 1e-3 || Math.abs(num(S, "warmth", 0)) > 1e-3
      || Math.abs(num(S, "saturation", 1) - 1) > 1e-3 || Math.abs(num(S, "vibrance", 0)) > 1e-3 || Math.abs(num(S, "fade", 0)) > 1e-3 || !!makeCurve(S.curve) || !!makeCurve(S.curve_r) || !!makeCurve(S.curve_g) || !!makeCurve(S.curve_b)
      || !!(S.lut && (!cubes || cubes[S.lut]) && num(S, "lut_amt", 1) > 1e-3));
  }
  function applyLook(S, c, curve, cube) {
    var E = Math.pow(2, num(S, "exposure", 0)), C = num(S, "contrast", 1), p = num(S, "pivot", .5), w = num(S, "warmth", 0), Sa = num(S, "saturation", 1), V = num(S, "vibrance", 0);
    if (Math.abs(E - 1) > 1e-3 || Math.abs(C - 1) > 1e-3 || Math.abs(w) > 1e-3) {      // color_vf's per-channel line: exposure x warmth, contrast around the pivot
      var g = [C * E * (1 + .12 * w), C * E, C * E * (1 - .12 * w)], b = p - p * C;
      for (var i = 0; i < 3; i++) c[i] = clamp(c[i] * g[i] + b);
    }
    if (Math.abs(Sa - 1) > 1e-3) {      // the SVG / colorchannelmixer "saturate" matrix
      var r = c[0], gg = c[1], bb = c[2];
      c[0] = clamp((.213 + .787 * Sa) * r + (.715 - .715 * Sa) * gg + (.072 - .072 * Sa) * bb);
      c[1] = clamp((.213 - .213 * Sa) * r + (.715 + .285 * Sa) * gg + (.072 - .072 * Sa) * bb);
      c[2] = clamp((.213 - .213 * Sa) * r + (.715 - .715 * Sa) * gg + (.072 + .928 * Sa) * bb);
    }
    var la = num(S, "lut_amt", 1);
    if (cube && la > 1e-3) {           // the creative Look (Premiere's Creative > Look): a second .cube, at its intensity
      var t = sampleCube(cube, c[0], c[1], c[2], [0, 0, 0]);
      for (var u = 0; u < 3; u++) c[u] = clamp(la * t[u] + (1 - la) * c[u]);
    }
    var F = num(S, "fade", 0);
    if (F > 1e-3) {                    // Faded Film: the blacks lift (the shadows most) and the color softens a little
      var Yf = .2126 * c[0] + .7152 * c[1] + .0722 * c[2];
      for (var w2 = 0; w2 < 3; w2++) { var x = c[w2] + .14 * F * (1 - c[w2]) * (1 - c[w2]); c[w2] = clamp(x + (Yf - x) * .15 * F); }
    }
    if (Math.abs(V) > 1e-3) {           // vibrance: more saturation where there is little, so skin and already-bright colors hold
      var Y = .2126 * c[0] + .7152 * c[1] + .0722 * c[2], sat = Math.max(c[0], c[1], c[2]) - Math.min(c[0], c[1], c[2]), k = 1 + V * (1 - sat);
      for (var q = 0; q < 3; q++) c[q] = clamp(Y + (c[q] - Y) * k);
    }
    if (curve) for (var j = 0; j < 3; j++) { if (curve.m) c[j] = curve.m(c[j]); if (curve[j]) c[j] = curve[j](c[j]); }      // the white curve, then red, green, blue
    return c;
  }

  /* ---------------------------------------------------------------- the whole grade */
  /* cubes: {path: parsed .cube} for every LUT the recipe names (one parsed cube on its own is R.lut's, as before) */
  function cubeMap(R, cubes) { if (cubes && cubes.size) { var m = {}; m[R.lut] = cubes; return m; } return cubes || {}; }
  function neutral(R, cubes) {
    if (!R) return true; var M = cubeMap(R, cubes);
    return !fixOn(R.fix) && !(R.lut && M[R.lut] && num(R, "lut_amt", 1) > 1e-3) && !(R.look || []).some(function (S) { return lookOn(S, M); });
  }
  /* every LUT path a recipe needs */
  function lutsOf(R) { var L = []; if (R && R.lut) L.push(R.lut); (R && R.look || []).forEach(function (S) { if (S && S.lut) L.push(S.lut); }); return L; }
  /* a piece's grade on its clip's grade, as one recipe (see the top) */
  var FIXK = ["temp", "tint", "exposure", "highlights", "shadows", "whites", "blacks"], STAGEK = ["exposure", "contrast", "pivot", "warmth", "curve", "curve_r", "curve_g", "curve_b", "saturation", "vibrance", "fade"];
  function fromGrades(G, P) {
    G = G || {}; P = P || {};
    if (P.off) return {space: "video", fix: {}, lut: "", lut_amt: 1, look: []};      // the piece's switch off: no color at all on it
    if (G.off) G = {};                                                                 // the clip's switch off: only the piece's own grade
    var IN = "lut_on" in P ? P : G, LK = "look_on" in P ? P : G, fix = {};
    FIXK.forEach(function (k) { var v = num(G.fix, k, 0) + num(P.fix, k, 0); if (v) fix[k] = v; });
    function stage(g, own) { var s = {}; STAGEK.forEach(function (k) { if (g[k] != null) s[k] = g[k]; });
      if (own && g.look_on && g.look) { s.lut = g.look; s.lut_amt = num(P, "look_amt", num(g, "look_amt", 1)); } return s; }
    /* the intensities: a piece's own wins, even on the clip's LUT (its Intensity slider sets just that piece) */
    return {space: IN.lut_on ? "log" : "video", fix: fix, lut: IN.lut_on && IN.lut ? IN.lut : "", lut_amt: num(P, "lut_amt", num(IN, "lut_amt", 1)),
            look: [stage(G, LK === G), stage(P, LK === P)]};
  }
  /* a function from one color to its graded color */
  function compile(R, cubes) {
    R = R || {}; var M = cubeMap(R, cubes), cube = R.lut ? M[R.lut] : null;
    var log = R.space === "log", fx = fixOn(R.fix) ? R.fix : null, k = cube ? Math.max(0, Math.min(1, num(R, "lut_amt", 1))) : 0;
    var looks = (R.look || []).filter(function (S) { return lookOn(S, M); }).map(function (S) { var cv = {m: makeCurve(S.curve), 0: makeCurve(S.curve_r), 1: makeCurve(S.curve_g), 2: makeCurve(S.curve_b)};
      return {S: S, curve: cv.m || cv[0] || cv[1] || cv[2] ? cv : null, cube: S.lut ? M[S.lut] : null}; }), tmp = [0, 0, 0];
    return function (c) {
      c[0] = clamp(c[0]); c[1] = clamp(c[1]); c[2] = clamp(c[2]);
      if (fx) applyFix(fx, log, c);
      if (k > 1e-3) {
        sampleCube(cube, c[0], c[1], c[2], tmp);
        for (var i = 0; i < 3; i++) c[i] = clamp(k * tmp[i] + (1 - k) * c[i]);
      }
      for (var j = 0; j < looks.length; j++) applyLook(looks[j].S, c, looks[j].curve, looks[j].cube);
      return c;
    };
  }
  function buildLut(R, cubes, size) {
    size = size || 65; var f = compile(R, cubes), out = new Float32Array(size * size * size * 3), c = [0, 0, 0], n = 0;
    for (var b = 0; b < size; b++) for (var g = 0; g < size; g++) for (var r = 0; r < size; r++) {
      c[0] = r / (size - 1); c[1] = g / (size - 1); c[2] = b / (size - 1); f(c);
      out[n++] = c[0]; out[n++] = c[1]; out[n++] = c[2];
    }
    return out;
  }

  function _cli(a) {
    var fs = require("fs");
    if (a[0] !== "write" || a.length < 3) { console.error("node grade.js write <recipe.json> <out.cube> [size]"); process.exit(2); }
    var R = JSON.parse(fs.readFileSync(a[1], "utf8")), size = +(a[3] || 65), cubes = {};
    if (R.grades) R = fromGrades(R.grades[0], R.grades[1]);
    lutsOf(R).forEach(function (p) { if (!cubes[p] && fs.existsSync(p)) cubes[p] = parseCube(fs.readFileSync(p, "utf8")); });
    fs.writeFileSync(a[2] + ".part", toCube(buildLut(R, cubes, size), size)); fs.renameSync(a[2] + ".part", a[2]);
    console.log("DONE " + a[2]);
  }

  return {parseCube: parseCube, sampleCube: sampleCube, toCube: toCube, makeCurve: makeCurve, compile: compile, buildLut: buildLut,
          neutral: neutral, fixOn: fixOn, lookOn: lookOn, fromGrades: fromGrades, lutsOf: lutsOf, FIXK: FIXK, STAGEK: STAGEK, slog3Lin: slog3Lin, linSlog3: linSlog3, _cli: _cli};
});
