/* Media's Upload that splits sequences, and the clip editor (2026-10-22). The server side is cineyap/broll_import.py.
   UPLOAD: every video picked or dropped goes to a staging folder next to the library (the original stays where it was). The Studio
   finds every cut, looks at each shot, checks for look-alikes and log footage, in the background, with a progress card bottom left.
   One shot that isn't log goes straight into its suggested folder. Anything else opens the SHOT SHEET: a tile per shot (hover plays
   it), its length, name and folder, Use, Join with next (a false cut), a look-alike warning; "Add N clips" writes
   <Folder>/<Base name> - <what's in it>_NN.mp4 on the drive ("Contorno - Lighting a candle_05") and they're searchable at once.
   CLIP EDITOR: "✎" on any clip in Media. Trim in/out on a filmstrip (whole frames), color (the same four sliders as a clip's Color
   correction) and the LUT on or off. Save writes a NEW clip beside it, "<name> (edit).mp4" (Gabe, 2026-10-22: edits already using the
   clip keep it); swap it in with Media's ⇄. "Hide the original" hides it in Loop only. An edited copy can be deleted. */
(function(){var s=document.createElement("style");s.textContent=
  ".bimp{position:fixed;left:16px;bottom:16px;width:340px;display:flex;flex-direction:column;gap:8px;z-index:61}.bimp[hidden]{display:none}"+
  ".bicard{background:var(--card);border:1px solid var(--line);border-radius:14px;box-shadow:var(--shadow-pop,0 10px 40px rgba(0,0,0,.4));padding:11px 13px;font-size:12px;line-height:1.4}"+
  ".bicard b{display:block;font-size:12.5px;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bicard small{color:var(--dim);display:block}"+
  ".bibar{height:4px;border-radius:2px;background:var(--field);margin:7px 0 2px;overflow:hidden}.bibar i{display:block;height:100%;background:var(--ink);transition:width .4s}"+
  ".bicard .acts{display:flex;gap:6px;margin-top:8px}.bicard.err small{color:#e5484d}"+
  ".shsheet{width:min(1180px,calc(100vw - 32px));max-width:none;max-height:90vh;overflow:auto}"+
  ".shtop{display:flex;flex-wrap:wrap;gap:10px 16px;align-items:end}.shtop label{display:flex;flex-direction:column;gap:4px;font-size:11px;color:var(--dim)}"+
  ".shtop input,.shtop select{min-width:220px}.shfile{margin-top:6px;padding-top:8px;border-top:1px solid var(--line)}.shfile>h4{margin:4px 0 8px;font-size:12.5px}"+
  ".shgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}"+
  ".shot{border:1px solid var(--line);border-radius:10px;padding:6px;display:flex;flex-direction:column;gap:5px;position:relative;background:var(--bg)}"+
  ".shot.off{opacity:.38}.shot.joined{border-color:var(--ink)}.shot .pic{position:relative;aspect-ratio:16/9;border-radius:7px;overflow:hidden;background:#000}"+
  ".shot .pic img,.shot .pic video{width:100%;height:100%;object-fit:contain;display:block}.shot .len{position:absolute;right:5px;bottom:5px;background:rgba(0,0,0,.65);color:#fff;font-size:10.5px;padding:1px 5px;border-radius:5px}"+
  ".shot .num{position:absolute;left:5px;top:5px;background:rgba(0,0,0,.65);color:#fff;font-size:10.5px;padding:1px 6px;border-radius:5px}"+
  ".shot input[type=text]{width:100%;box-sizing:border-box;background:var(--field);border:1px solid var(--line);border-radius:7px;padding:5px 7px;color:var(--ink);font:inherit;font-size:12px}"+
  ".shot select{font-size:11.5px;padding:4px 6px}.shot .row{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--dim)}.shot .row label{display:flex;align-items:center;gap:4px;cursor:pointer}"+
  ".shot .about{font-size:11px;color:var(--dim);line-height:1.35;max-height:3.9em;overflow:hidden}.shot .warn{font-size:11px;color:#f5a524;line-height:1.35}"+
  ".shot .jn{position:absolute;right:-11px;top:38%;z-index:2;width:22px;height:22px;border-radius:var(--r-ctl,7px);border:1px solid var(--line);background:var(--card);color:var(--dim);cursor:pointer;font-size:12px;line-height:20px;padding:0}"+
  ".shot .jn.on{background:var(--ink);color:var(--bg);border-color:var(--ink)}"+
  ".shfoot{position:sticky;bottom:-18px;background:var(--card);padding:10px 0 2px;display:flex;align-items:center;gap:10px;border-top:1px solid var(--line);margin-top:8px}.shfoot .sp{flex:1}"+
  ".cedit{width:min(900px,calc(100vw - 32px));max-width:none;max-height:92vh;overflow:auto}.cegrid{display:grid;grid-template-columns:minmax(0,1fr) 300px;gap:18px;align-items:start}"+
  ".cedit .grng{background:transparent;border:0;border-radius:0;padding:0}.cetrans{display:flex;align-items:center;gap:2px;margin-top:8px}.cetrans .ct{font-variant-numeric:tabular-nums;font-size:12px;font-weight:700;margin-right:8px;white-space:nowrap}.cetrans .ct small{color:var(--dim);font-weight:500;margin-left:6px}.cetrans .sp{flex:1}.cetrans button.tb{width:30px;height:28px;border-radius:6px;background:none;color:var(--ink-2);display:grid;place-items:center;padding:0;border:0;cursor:pointer}.cetrans button.tb:hover{background:var(--field);color:var(--ink)}"+
  "@media(max-width:760px){.cegrid{grid-template-columns:1fr}}.cevid{position:relative;background:#000;border-radius:10px;overflow:hidden;aspect-ratio:16/9}.cevid video{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block}"+
  ".cestrip{position:relative;height:58px;margin-top:10px;border-radius:7px;overflow:hidden;background:var(--field);display:flex;cursor:pointer;user-select:none}"+
  ".cestrip img{flex:1;min-width:0;height:100%;object-fit:cover;pointer-events:none}.cestrip .dim{position:absolute;top:0;bottom:0;background:rgba(0,0,0,.62);pointer-events:none}"+
  ".cestrip .hd{position:absolute;top:0;bottom:0;width:10px;margin-left:-5px;background:var(--ink);border-radius:3px;cursor:ew-resize}.cestrip .hd::after{content:'';position:absolute;left:4px;top:18px;bottom:18px;width:2px;background:var(--bg)}"+
  ".cestrip .ph{position:absolute;top:-2px;bottom:-2px;width:2px;margin-left:-1px;background:#e5484d;pointer-events:none}"+
  ".cetime{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center;margin-top:8px;font-size:11.5px;color:var(--dim)}.cetime b{color:var(--ink);font-variant-numeric:tabular-nums}"+
  ".cetime .btn{padding:4px 10px;font-size:11.5px}.ceside{display:flex;flex-direction:column;gap:10px}.ceside .colsl input{width:100%}"+
  ".ceside .colsh{display:flex;justify-content:space-between;font-size:11.5px;color:var(--dim)}.ceside .colsh b{color:var(--ink);font-weight:600}"+
  ".cefoot{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin-top:12px;border-top:1px solid var(--line);padding-top:10px}.cefoot .sp{flex:1}.cefoot small{color:var(--dim);font-size:11px;line-height:1.35;max-width:430px}"+
  ".qb.qed{font-size:12px}";document.head.appendChild(s);})();

var BIMP={};      /* import id -> its latest status */
function bimpBox(){var b=document.getElementById("bimp");if(!b){b=el("div","bimp");b.id="bimp";document.body.appendChild(b);}return b;}
function bimpDraw(){var B=bimpBox();B.innerHTML="";var ids=Object.keys(BIMP);B.hidden=!ids.length;
  ids.forEach(function(id){var J=BIMP[id],c=el("div","bicard"+(J.state==="error"?" err":"")),nm=(J.files||[]).map(function(x){return x.name;}).join(", ")||J._names||"Upload";
    c.appendChild(el("b",null,nm));
    var msg=J.state==="uploading"?"Uploading"+(J._pct!=null?" "+Math.round(J._pct*100)+"%":"…"):J.state==="working"?(J.step||"Starting")+"…":
      J.state==="ready"?(J.shots.length+" shot"+(J.shots.length===1?"":"s")+" ready to add"):J.state==="adding"?(J.step||"Adding")+"…":J.state==="done"?"Added.":J.error||"That didn't work.";
    c.appendChild(el("small",null,msg));
    if(J.state==="uploading"||J.state==="working"||J.state==="adding"){var bar=el("div","bibar"),i=el("i");i.style.width=Math.round(100*(J.state==="uploading"?(J._pct||0):(J.progress||0)))+"%";bar.appendChild(i);c.appendChild(bar);}
    var a=el("div","acts");
    if(J.state==="ready"){var r=el("button","btn go","Review shots");r.type="button";r.onclick=function(){shotSheet(id);};a.appendChild(r);}
    if(J.state!=="adding"){var x=el("button","btn",J.state==="error"||J.state==="done"?"Close":"Discard");x.type="button";x.title=J.state==="done"?"":"Throws away this upload's copy (the file on your Mac stays where it is)";
      x.onclick=function(){if(J.state!=="done")post("/api/broll-import/cancel",{id:id});delete BIMP[id];bimpDraw();};a.appendChild(x);}
    c.appendChild(a);B.appendChild(c);});}
/* upload the picked/dropped videos as one import, then let the server find the shots */
function brollUpload(files){var tmp="up"+Date.now();BIMP[tmp]={state:"uploading",_names:files.map(function(f){return f.name;}).join(", "),_pct:0};bimpDraw();
  var total=files.reduce(function(s,f){return s+f.size;},0)||1,sent=0;
  post("/api/broll-import/new",{}).then(function(J){if(!J||!J.id){BIMP[tmp]={state:"error",error:(J&&J.error)||"The library isn't there. Is the drive plugged in?"};bimpDraw();return;}
    var id=J.id,nm=BIMP[tmp]._names;delete BIMP[tmp];BIMP[id]=Object.assign(J,{_names:nm,_pct:0});bimpDraw();var k=0;
    (function next(){if(k>=files.length){post("/api/broll-import/start",{id:id}).then(function(s){BIMP[id]=s;bimpDraw();bimpPoll(id);});return;}
      var f=files[k++],x=new XMLHttpRequest();x.open("POST","/api/broll-import/upload?id="+encodeURIComponent(id)+"&name="+encodeURIComponent(f.name));
      x.upload.onprogress=function(e){BIMP[id]._pct=(sent+e.loaded)/total;bimpDraw();};
      x.onload=function(){sent+=f.size;try{var s=JSON.parse(x.responseText);BIMP[id]=Object.assign(s,{_pct:sent/total});}catch(e){}bimpDraw();next();};
      x.onerror=function(){BIMP[id].state="error";BIMP[id].error="The upload stopped.";bimpDraw();};x.send(f);})();});}
function bimpPoll(id){fetch("/api/broll-import?id="+encodeURIComponent(id)).then(function(r){return r.json();}).then(function(J){if(!BIMP[id])return;BIMP[id]=J;bimpDraw();
  if(J.state==="working"||J.state==="adding"){setTimeout(function(){bimpPoll(id);},1200);return;}
  if(J.state==="ready"){if(straightIn(J))return addShots(id,J.shots.map(function(s){return {shots:[s.id],name:s.name,folder:s.folder,lut:false};}));shotSheet(id);}
  if(J.state==="done")bimpDone(J);});}
/* one shot per file and nothing to decide (no log footage, nothing that looks like a clip you have): straight in */
function straightIn(J){return J.files.every(function(F){return F.single;})&&!J.shots.some(function(s){return s.log||s.alike.length;});}
function addShots(id,outs){post("/api/broll-import/add",{id:id,outs:outs}).then(function(s){if(s&&s.error){toast(s.error);return;}BIMP[id]=s;bimpDraw();bimpPoll(id);});}
function folderLabel(J,f){var x=(J.folders||[]).filter(function(o){return o.folder===f;})[0];return x&&x.label!==x.folder?x.label:f;}
function bimpDone(J){var where={};(J.added||[]).forEach(function(r){var f=r.split("/").slice(0,-1).join("/");where[folderLabel(J,f)]=1;});
  fetch("/api/library").then(function(r){return r.json();}).then(function(d){LIB=d.folders;STILLS=d.stills||STILLS;LIBMT=d.mtime||LIBMT;LIBTAGS=d.tags||LIBTAGS;LIBHB=d.hidden_buckets||LIBHB;drawLib();});
  setTimeout(bixLoad,800);var n=(J.added||[]).length;toast("Added "+n+" clip"+(n===1?"":"s")+" to "+Object.keys(where).join(", ")+". "+(n===1?"It's":"They're")+" in search now.");
  setTimeout(function(){delete BIMP[J.id];bimpDraw();},6000);}
/* uploads still waiting on their sheet from before a reload */
document.addEventListener("DOMContentLoaded",function(){fetch("/api/broll-import").then(function(r){return r.json();}).then(function(d){(d.pending||[]).forEach(function(p){
  fetch("/api/broll-import?id="+encodeURIComponent(p.id)).then(function(r){return r.json();}).then(function(J){BIMP[p.id]=J;bimpDraw();});});}).catch(function(){});});

/* ---- THE SHOT SHEET */
function shotSheet(id){var J=BIMP[id];if(!J||J.state!=="ready")return;var old=document.getElementById("shbg");if(old)old.remove();
  var bg=el("div","askbg"),bx=el("div","askbox shsheet");bg.id="shbg";
  var S=J.shots.map(function(s){return {s:s,use:true,join:false,name:s.name,named:false,folder:s.folder};});
  var base={},lut={};J.files.forEach(function(F,i){base[i]=F.base;lut[i]=!!(F.log&&J.lut);});
  var seqs=J.files.filter(function(F){return !F.single;}).length;
  bx.appendChild(el("b",null,J.shots.length===1?"1 clip to add":J.shots.length+" shots"+(seqs?" from "+J.files.map(function(F){return F.name;}).join(", "):"")));
  bx.appendChild(el("p",null,"Hover a shot to play it. Untick one to leave it out; ⊕ between two joins them (a cut that isn't one). Names and folders are suggestions from what's in each shot. Your uploaded file stays where it is."));
  var top=el("div","shtop"),lab=el("label",null,"Put every shot in");var all=folderSelect(J,"",function(v){if(!v)return;S.forEach(function(x){x.folder=v;});draw();all.value="";}),ch=el("option",null,"Choose a folder…");ch.value="";all.insertBefore(ch,all.firstChild);all.value="";lab.appendChild(all);top.appendChild(lab);bx.appendChild(top);
  var body=el("div");bx.appendChild(body);
  var foot=el("div","shfoot"),info=el("small"),go=el("button","btn go"),cx=el("button","btn","Not now");go.type=cx.type="button";
  cx.title="Keeps the shots waiting (Review shots, bottom left)";foot.appendChild(info);foot.appendChild(el("span","sp"));foot.appendChild(cx);foot.appendChild(go);bx.appendChild(foot);
  bg.appendChild(bx);document.body.appendChild(bg);cx.onclick=function(){bg.remove();};
  /* the clips that will be written: shots in order, joins merged, unticked ones left out; numbered per file */
  function outs(){var O=[];J.files.forEach(function(F,fi){var L=S.filter(function(x){return x.s.file===fi;}),cur=null;
      L.forEach(function(x,i){if(!x.use){cur=null;return;}if(cur)cur.shots.push(x.s.id);else{cur={shots:[x.s.id],x:x,fi:fi};O.push(cur);}if(!x.join||i===L.length-1||!L[i+1].use)cur=null;});});
    var per={};O.forEach(function(o){per[o.fi]=(per[o.fi]||0)+1;o.k=per[o.fi];});
    return O.map(function(o){var single=J.files[o.fi].single&&per[o.fi]===1,nm=o.x.named?o.x.name:(single?base[o.fi]:base[o.fi]+" - "+(o.x.s.short||"Shot")+"_"+(o.k<10?"0":"")+o.k);
      o.x.auto=nm;return {shots:o.shots,name:nm,folder:o.x.folder,lut:!!lut[o.fi]};});}
  function draw(){body.innerHTML="";var O=outs(),first={};O.forEach(function(o){first[o.shots[0]]=o;});
    J.files.forEach(function(F,fi){var w=el("div","shfile"),L=S.filter(function(x){return x.s.file===fi;});
      var h=el("h4",null,F.name+" · "+(F.single?"one shot":L.length+" shots"+(F.cuts>=L.length?" ("+(F.cuts+1-L.length)+" under 2 s left out)":"")));w.appendChild(h);
      var t=el("div","shtop");if(!F.single){var bl=el("label",null,"Base name"),bi=el("input");bi.className="isel";bi.value=base[fi];bi.oninput=function(){base[fi]=bi.value.trim()||F.base;drawNames();};bl.appendChild(bi);t.appendChild(bl);}
      if(F.log){var ll=el("label");ll.style.flexDirection="row";ll.style.alignItems="center";ll.style.gap="6px";var lc=el("input");lc.type="checkbox";lc.checked=!!lut[fi];lc.disabled=!J.lut;
        lc.onchange=function(){lut[fi]=lc.checked;};ll.appendChild(lc);ll.appendChild(el("span",null,J.lut?"Looks like log footage: bake your LUT in ("+J.lut.split("/").pop()+")":"Looks like log footage (no LUT set: add one in Brand)"));t.appendChild(ll);}
      if(t.children.length)w.appendChild(t);
      var g=el("div","shgrid");L.forEach(function(x,i){g.appendChild(tile(x,i,L,first[x.s.id]));});w.appendChild(g);body.appendChild(w);});
    var n=O.length;go.textContent="Add "+n+" clip"+(n===1?"":"s");go.disabled=!n;
    var fs={};O.forEach(function(o){fs[folderLabel(J,o.folder)]=1;});info.textContent=n?"Into "+Object.keys(fs).join(", "):"Nothing ticked.";}
  function drawNames(){var O=outs();O.forEach(function(o){var x=S.filter(function(y){return y.s.id===o.shots[0];})[0];if(x&&x._in&&!x.named)x._in.value=o.name;});}
  function tile(x,i,L,o){var s=x.s,d=el("div","shot"+(x.use?"":" off")+(x.join&&x.use?" joined":"")),p=el("div","pic"),im=el("img");im.src="/file?p="+encodeURIComponent(s.thumb);p.appendChild(im);
    p.appendChild(el("span","num",String(i+1)));p.appendChild(el("span","len",s.secs.toFixed(1)+" s"));d.appendChild(p);
    var hv=null,ht=null;p.onmouseenter=function(){ht=setTimeout(function(){hv=el("video");hv.muted=true;hv.loop=true;hv.playsInline=true;hv.src="/file?p="+encodeURIComponent(s.staged);
      hv.addEventListener("loadeddata",function(){if(hv&&im.parentNode){p.replaceChild(hv,im);hv.play();}},{once:true});},180);};
    p.onmouseleave=function(){clearTimeout(ht);if(hv){if(hv.parentNode)p.replaceChild(im,hv);hv.pause();hv.removeAttribute("src");hv=null;}};
    var head=!o&&x.use;      /* joined onto the shot before: its name and folder are that one's */
    var nm=el("input");nm.type="text";nm.value=o?o.name:"";nm.placeholder=head?"(joined with the one before)":"";nm.disabled=!o;x._in=nm;nm.title="The clip's file name";
    nm.oninput=function(){x.named=true;x.name=nm.value.trim();};nm.onkeydown=function(e){e.stopPropagation();};d.appendChild(nm);
    var fsel=folderSelect(J,x.folder,function(v){x.folder=v;draw();});fsel.disabled=!o;d.appendChild(fsel);
    var r=el("div","row"),ul=el("label"),uc=el("input");uc.type="checkbox";uc.checked=x.use;uc.onchange=function(){x.use=uc.checked;draw();};ul.appendChild(uc);ul.appendChild(el("span",null,"Use"));r.appendChild(ul);
    if(s.log)r.appendChild(el("span",null,"· log"));if(s.w)r.appendChild(el("span",null,"· "+s.w+"×"+s.h));d.appendChild(r);
    if(s.about&&s.about.description){var ab=el("div","about",s.about.description);ab.title=s.about.description+"\n"+(s.about.tags||[]).join(", ");d.appendChild(ab);}
    if(s.alike&&s.alike.length){var wn=el("div","warn","Looks like "+s.alike.map(function(a){return a.clip.split("/").pop();}).join(", ")+", already in your library");
      wn.title=s.alike.map(function(a){return a.clip+": "+a.description;}).join("\n");d.appendChild(wn);}
    if(i<L.length-1){var j=el("button","jn"+(x.join?" on":""),"⊕");j.type="button";j.title=x.join?"Joined with the next shot: click to keep them apart":"Join with the next shot (the cut between them isn't a real cut)";
      j.onclick=function(){x.join=!x.join;draw();};d.appendChild(j);}
    return d;}
  go.onclick=function(){var O=outs();if(!O.length)return;go.disabled=true;bg.remove();addShots(id,O);};
  draw();}
function folderSelect(J,cur,on){var s=el("select","isel");(J.folders||[]).forEach(function(o){var op=el("option",null,o.label===o.folder?o.folder:o.label+" ("+o.folder+")");op.value=o.folder;s.appendChild(op);});
  if(cur&&!(J.folders||[]).some(function(o){return o.folder===cur;})){var op=el("option",null,cur+" (new folder)");op.value=cur;s.appendChild(op);}
  var nw=el("option",null,"New folder…");nw.value="__new";s.appendChild(nw);s.value=cur||"";
  s.onchange=function(){if(s.value!=="__new")return on(s.value);var was=cur;s.value=was||"";askName("New folder","A folder in your B-roll library on the drive. Use / for one inside another (Travel/Beach).","","Create",function(n){n=n.trim().replace(/^\/+|\/+$/g,"");if(!n){s.value=was||"";return;}
    if(!(J.folders||[]).some(function(o){return o.folder===n;}))J.folders.push({folder:n,label:n});on(n);});};return s;}

/* ---- THE CLIP EDITOR */
function clipEditBtn(c){var b=el("button","qb qed","✎");b.type="button";b.title="Edit this clip: grade it for every video, or trim it (a trim is saved as a new clip beside it)";
  b.onclick=function(e){e.stopPropagation();clipEdit(c);};return b;}
function clipEdit(c){fetch("/api/clip-info?clip="+encodeURIComponent(c)).then(function(r){return r.json();}).then(function(I){if(I.error){toast(I.error);return;}
  var fps=I.fps,N=I.frames||Math.round(I.dur*fps),E=I.edit||{};
  var st={in:E.in!=null?E.in:0,out:E.out!=null?E.out:N};
  var bg=el("div","askbg"),bx=el("div","askbox cedit");bx.appendChild(el("b",null,"Edit "+c.split("/").pop()));
  bx.appendChild(el("p",null,(I.edited?"An edited copy of "+I.source_rel.split("/").pop()+": you're working from that original, with this copy's edit loaded. ":"")+I.w+"×"+I.h+" · "+fps.toFixed(3).replace(/\.?0+$/,"")+" fps · "+N+" frames"+(I.log?" · looks like log footage":"")));
  var g=el("div","cegrid"),L=el("div"),R=el("div","ceside");g.appendChild(L);g.appendChild(R);bx.appendChild(g);
  var vw=el("div","cevid"),v=el("video");v.muted=true;v.playsInline=true;v.preload="auto";vw.appendChild(v);L.appendChild(vw);
  var strip=el("div","cestrip");for(var k=0;k<12;k++){var im=el("img");im.src="/thumb?p="+encodeURIComponent(I.source)+"&t="+((k+.5)/12*I.dur).toFixed(2);strip.appendChild(im);}
  var dl=el("div","dim"),dr=el("div","dim"),hi=el("div","hd"),ho=el("div","hd"),ph=el("div","ph");[dl,dr,ph,hi,ho].forEach(function(x){strip.appendChild(x);});L.appendChild(strip);
  hi.title="Drag: where the clip starts (I sets it at the playhead)";ho.title="Drag: where the clip ends (O sets it at the playhead)";
  var tr=el("div","cetrans"),ct=el("span","ct");tr.appendChild(ct);
  function fr(){return Math.min(N-1,Math.max(0,Math.floor(v.currentTime*fps+1e-3)));}
  function seek(f){v.currentTime=(Math.max(0,Math.min(N-1,f))+.5)/fps;}
  function tc(f){var s=f/fps,m=Math.floor(s/60),ss=s-m*60;return m+":"+(ss<10?"0":"")+ss.toFixed(2);}
  function btn(t,ti,fn){var b=el("button","btn",t);b.type="button";b.title=ti;b.onclick=fn;return b;}
  function drawTrim(){var a=st.in/N*100,b=st.out/N*100;dl.style.left="0";dl.style.width=a+"%";dr.style.left=b+"%";dr.style.right="0";hi.style.left=a+"%";ho.style.left=b+"%";drawPh();dirty();}
  /* the time like the editor's: where you are / the clip's length, and the trim when there is one */
  function drawPh(){ph.style.left=(v.currentTime/I.dur*100)+"%";ct.innerHTML="";ct.appendChild(document.createTextNode(tc(fr())+" / "+tc(N)));
    if(st.in>0||st.out<N)ct.appendChild(el("small",null,"trim "+((st.out-st.in)/fps).toFixed(2)+" s"));ct.title="Frame "+fr()+". In "+tc(st.in)+", out "+tc(st.out);}
  /* THE TRANSPORT, the editor's icons (Gabe, 2026-10-24): to the in point, a frame back, play, a frame on, to the out point; then set
     in [, set out ], and the whole clip back */
  var IC=function(id){var x=document.getElementById(id);return x?x.innerHTML:"";};
  function tb(html,ti,fn){var b=el("button","tb");b.type="button";b.innerHTML=html;b.title=ti;b.onclick=fn;tr.appendChild(b);return b;}
  var TXT=function(t){return '<span style="font:700 12px/1 var(--font);padding:0 3px">'+t+'</span>';};
  tb(IC("tPrev"),"To the in point",function(){v.pause();seek(st.in);});
  tb(IC("tBack"),"One frame back (←, Shift for 10)",function(){v.pause();seek(fr()-1);});
  var pl=tb(typeof ICON_PLAY!=="undefined"?ICON_PLAY:"▶","Play the trimmed clip (Space)",function(){toggle();});pl.classList.add("tplay");
  tb(IC("tFwd"),"One frame on (→, Shift for 10)",function(){v.pause();seek(fr()+1);});
  tb(IC("tNext"),"To the out point",function(){v.pause();seek(st.out-1);});
  tr.appendChild(el("span","sp"));
  tb(TXT("["),"Start the clip here (I)",function(){st.in=Math.min(fr(),st.out-1);drawTrim();});
  tb(TXT("]"),"End the clip here (O)",function(){st.out=Math.max(fr()+1,st.in+1);drawTrim();});
  tb(TXT("⟷"),"The whole clip (no trim)",function(){st.in=0;st.out=N;drawTrim();});
  L.appendChild(tr);
  function toggle(){if(v.paused){if(fr()>=st.out-1||fr()<st.in)seek(st.in);v.play();}else v.pause();}
  v.onplay=function(){if(typeof ICON_PAUSE!=="undefined")pl.innerHTML=ICON_PAUSE;};v.onpause=function(){if(typeof ICON_PLAY!=="undefined")pl.innerHTML=ICON_PLAY;};
  v.ontimeupdate=function(){if(!v.paused&&v.currentTime>=st.out/fps){v.pause();seek(st.out-1);}drawPh();};
  function frameAt(e){var r=strip.getBoundingClientRect();return Math.round(Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*N);}
  function drag(which){return function(e){e.preventDefault();e.stopPropagation();v.pause();function mv(ev){var f=frameAt(ev);if(which==="in")st.in=Math.max(0,Math.min(f,st.out-1));else st.out=Math.min(N,Math.max(f,st.in+1));seek(which==="in"?st.in:st.out-1);drawTrim();}
    function up(){document.removeEventListener("pointermove",mv);document.removeEventListener("pointerup",up);}document.addEventListener("pointermove",mv);document.addEventListener("pointerup",up);};}
  hi.onpointerdown=drag("in");ho.onpointerdown=drag("out");strip.onpointerdown=function(e){v.pause();seek(Math.min(N-1,frameAt(e)));};
  /* COLOR: the clip's own grade, for every piece of it in every video (BGRADES, cineyap/grades.json; GRADING.md). The same
     panel as the Inspector's, previewed live through the same engine (grade_view.js); nothing is written into the file */
  v.src="/file?p="+encodeURIComponent(I.source);v.addEventListener("loadedmetadata",function(){seek(st.in);},{once:true});
  function grade(){var g=BGRADES[c]||{};GV.set(v,Grade.fromGrades(g,null));
    gradePanel(R,g,{before:function(){bGradeBefore(c,grade);},save:function(){saveBGrade(c);},
      changed:function(){if(gradeIdle(g))delete BGRADES[c];else BGRADES[c]=g;GV.set(v,Grade.fromGrades(g,null));applyColor();}});}
  grade();
  /* save: a new clip beside the original; delete: an edited copy only */
  var nm=I.source_rel.split("/").pop().replace(/\.[^.]+$/,""),foot=el("div","cefoot"),
    hint=el("small",null,"The color is this clip's in every video, as you change it. A trim saves a new clip beside it, \u201c"+nm+" (edit)\u201d; "+(I.edited?"this copy":"this clip")+" stays as it is.");
  var hw=el("label","colsh"),hc=el("input");hc.type="checkbox";hc.checked=false;hw.style.cursor="pointer";hw.style.gap="6px";hw.style.justifyContent="flex-start";hw.appendChild(hc);
  hw.appendChild(el("span",null,"Hide the original in Media"));hw.title="Only in Loop (find it under Hidden); the file stays on your drive and videos using it keep it";
  var rv=btn("Delete this copy","Deletes this edited copy from your drive (the original stays)",function(){if(!confirm("Delete "+c.split("/").pop()+" from your drive? The original, "+I.source_rel.split("/").pop()+", stays. A video that uses this copy loses it."))return;
    rv.disabled=true;post("/api/clip-delete-copy",{clip:c}).then(function(r){if(r.error){toast(r.error);rv.disabled=false;return;}close();
      if((LIB.Hidden||[]).indexOf(r.source)>=0&&!(I.copies||[]).some(function(x){return x!==c;}))libEdit({op:"unhide",clips:[r.source]});      /* the last copy gone: the original shows again */clipChanged(c);toast("Deleted "+c.split("/").pop()+".");});});
  rv.hidden=!I.edited;var cx=btn("Done","Close (the color is already saved)",function(){close();}),sv=el("button","btn go","Save trim as new clip");sv.type="button";sv.title=hint.textContent;
  foot.appendChild(hint);foot.appendChild(el("span","sp"));foot.appendChild(hw);foot.appendChild(rv);foot.appendChild(cx);foot.appendChild(sv);bx.appendChild(foot);
  var base=JSON.stringify(st);function dirty(){sv.disabled=JSON.stringify(st)===base;}dirty();
  sv.onclick=function(){sv.disabled=true;sv.textContent="Saving…";post("/api/clip-save",{clip:c,in:st.in,out:st.out,cc:{},lut:false}).then(function(r){
    if(!r||r.error){sv.disabled=false;sv.textContent="Save trim as new clip";toast((r&&r.error)||"Saving didn't work.");return;}close();
    if(BGRADES[c]){BGRADES[r.clip]=clone(BGRADES[c]);saveBGrade(r.clip);}      /* the new clip keeps this clip's grade */
    if(hc.checked&&(LIB.Hidden||[]).indexOf(r.source)<0)libEdit({op:"hide",clips:[r.source]});
    clipChanged(c,r.clip);toast("Saved "+r.clip.split("/").pop()+" ("+r.secs+" s), next to the original. Swap it in with ⇄.");});};
  function key(e){if(!document.body.contains(bg))return document.removeEventListener("keydown",key,true);if(/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)&&e.target.type!=="range"&&e.target.type!=="checkbox")return;
    var k=e.key,h=true;if(k===" ")toggle();else if(k==="ArrowLeft"){v.pause();seek(fr()-(e.shiftKey?10:1));}else if(k==="ArrowRight"){v.pause();seek(fr()+(e.shiftKey?10:1));}
    else if(k==="i"||k==="I"){st.in=Math.min(fr(),st.out-1);drawTrim();}else if(k==="o"||k==="O"){st.out=Math.max(fr()+1,st.in+1);drawTrim();}else if(k==="Escape")close();else h=false;
    if(h){e.preventDefault();e.stopPropagation();}}
  document.addEventListener("keydown",key,true);
  function close(){v.pause();GV.drop(v);v.removeAttribute("src");bg.remove();document.removeEventListener("keydown",key,true);}
  bg.appendChild(bx);document.body.appendChild(bg);bg.onmousedown=function(e){if(e.target===bg)close();};
  drawTrim();v.addEventListener("loadedmetadata",function(){drawPh();},{once:true});});}
/* the clip changed on the drive: new thumbnails and players everywhere it shows */
function clipChanged(c,sel){var v="&v="+Date.now(),e=encodeURIComponent(c);
  [].forEach.call(document.querySelectorAll("img"),function(im){var s=im.getAttribute("src")||"";if(s.indexOf(e)>=0||s.indexOf(encodeURIComponent(CLIPROOT+"/"+c))>=0)im.src=s.replace(/&v=\d+/,"")+v;});
  fetch("/api/library").then(function(r){return r.json();}).then(function(d){LIB=d.folders;LIBMT=d.mtime||LIBMT;LIBTAGS=d.tags||LIBTAGS;if(sel){LSEL=[sel];LANCH=sel;}drawLib();});setTimeout(bixLoad,1500);setTimeout(bixLoad,6000);}
/* THE LIBRARY KEEPS ITSELF CURRENT (Gabe, 2026-10-23: "when I add B-roll to the library I have to refresh to see it"). Clips added
   any other way (Finder, Chat, another tab) show up when you come back to the window, and every 20 s while Media is open. Redraws
   only when something changed, so a scroll or a selection is never thrown away for nothing. */
var LIBSIG="";
function libSig(d){return JSON.stringify([d.folders,d.stills,d.hidden_buckets,d.tags]);}
function libRefresh(){if(typeof LIB==="undefined"||!LOADED||CAR)return;fetch("/api/library",{cache:"no-store"}).then(function(r){return r.json();}).then(function(d){
  var s=libSig(d);if(!LIBSIG){LIBSIG=s;return;}if(s===LIBSIG)return;LIBSIG=s;
  LIB=d.folders||LIB;STILLS=d.stills||STILLS;LIBMT=d.mtime||LIBMT;LIBTAGS=d.tags||LIBTAGS;LIBHB=d.hidden_buckets||LIBHB;drawLib();setTimeout(bixLoad,800);}).catch(function(){});}
window.addEventListener("focus",libRefresh);
document.addEventListener("visibilitychange",function(){if(!document.hidden)libRefresh();});
setInterval(function(){if(!document.hidden&&(LEFTT==="broll"||PANE2==="broll"))libRefresh();},20000);
