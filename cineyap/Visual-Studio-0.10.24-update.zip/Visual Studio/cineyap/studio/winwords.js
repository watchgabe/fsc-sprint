/* winwords.js: on Windows the pages say File Explorer, PC and Ctrl where they say Finder, Mac and Cmd (Gabe, 2026-10-24: "do we
   need Windows language?"). One pass over every text and tooltip as it appears, so no string needs two versions */
(function(){if(!/Windows/i.test(navigator.userAgent))return;
  var R=[[/Show in Finder/g,"Show in File Explorer"],[/\bFinder's\b/g,"File Explorer's"],[/\bFinder\b/g,"File Explorer"],[/\bthis Mac\b/g,"this PC"],[/\byour Mac\b/g,"your PC"],
    [/\bon a Mac\b/g,"on a PC"],[/\bthe Mac's\b/g,"Windows'"],[/\bMac's\b/g,"PC's"],[/\bCmd\+/g,"Ctrl+"],[/\bCmd-/g,"Ctrl-"],[/⌘/g,"Ctrl+"],[/\bOption\+/g,"Alt+"],[/⌥/g,"Alt+"]];
  function fix(s){for(var i=0;i<R.length;i++)s=s.replace(R[i][0],R[i][1]);return s;}
  function walk(n){if(n.nodeType===3){var v=n.nodeValue,f=fix(v);if(f!==v)n.nodeValue=f;return;}if(n.nodeType!==1||n.tagName==="SCRIPT"||n.tagName==="STYLE")return;
    ["title","placeholder","aria-label"].forEach(function(a){var v=n.getAttribute&&n.getAttribute(a);if(v){var f=fix(v);if(f!==v)n.setAttribute(a,f);}});
    for(var c=n.firstChild;c;c=c.nextSibling)walk(c);}
  function go(){walk(document.body);new MutationObserver(function(M){M.forEach(function(m){if(m.type==="characterData")walk(m.target);else if(m.type==="attributes")walk(m.target);else m.addedNodes.forEach(walk);});})
    .observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:["title","placeholder","aria-label"]});document.title=fix(document.title);}
  if(document.body)go();else document.addEventListener("DOMContentLoaded",go);
  var a0=window.alert;window.alert=function(s){return a0.call(window,fix(String(s)));};})();
