/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* grade_view.js — the editor's live grade (GRADING.md, phase 2, 2026-10-24).

Every player in the preview (the A-roll pair, the text-behind cut-outs, the B-roll pair and its still and cut-out) gets a
WebGL canvas laid exactly over it, drawing its picture through the clip's grade: grade.js builds a 33-point LUT from the
recipe and the shader looks every pixel up in it. The export writes the same recipe as a 65-point .cube (timeline_tools),
so the preview and the export are one piece of maths. The video keeps playing underneath, hidden; the canvas copies its box,
transform, clip, opacity and object-fit every frame, so nothing else in the editor has to know the canvas is there.

  GV.set(el, recipe)        the element's grade (null or a neutral recipe: the plain video shows)
  GV.tick()                 draw every graded player (called from the editor's tick and on every animation frame)
  GV.paint(src, recipe)     a graded copy of one frame (an offscreen canvas) for the 2D thumbnails
  GV.scopes(src, recipe, wave, vec)   waveform and vectorscope of what that player shows
  GV.off                    true while "Hold to compare" is down: everything shows ungraded */
var GV = (function () {
  "use strict";
  var VS = "#version 300 es\nin vec2 p;out vec2 uv;void main(){uv=p*.5+.5;gl_Position=vec4(p,0.,1.);}";
  var FS = "#version 300 es\nprecision highp float;precision highp sampler3D;uniform sampler2D v;uniform sampler3D l;uniform float n;uniform int on;in vec2 uv;out vec4 o;" +
    "void main(){vec4 c=texture(v,uv);vec3 q=c.rgb;if(on==1)q=texture(l,q*((n-1.)/n)+.5/n).rgb;o=vec4(q*c.a,c.a);}";
  var SIZE = 33, CUBES = {}, LUTS = {}, LUTN = [], ITEMS = [], OFF = null, API = {off: false};

  /* ---------------------------------------------------------------- recipes → LUT data */
  function cube(path) {
    if (!path) return Promise.resolve(null);
    if (!CUBES[path]) CUBES[path] = fetch("/api/cube?p=" + encodeURIComponent(path)).then(function (r) { if (!r.ok) throw new Error("no LUT"); return r.text(); })
      .then(function (t) { var c = Grade.parseCube(t); CUBES[path].done = c; return c; }).catch(function () { CUBES[path].done = null; return null; });
    return CUBES[path];
  }
  function keyOf(R) { return R ? JSON.stringify(R) : ""; }
  /* the LUT for a recipe, or undefined while its .cube is still loading (the player then shows plain until it arrives) */
  function lutFor(R) {
    var k = keyOf(R); if (LUTS[k]) return LUTS[k];
    var ps = Grade.lutsOf(R), cs = ps.map(cube), wait = cs.filter(function (p) { return !("done" in p); });      // the Input LUT and any Look
    if (wait.length) { Promise.all(wait).then(function () { API.dirty = true; }); return undefined; }
    var M = {}; ps.forEach(function (p, i) { if (cs[i].done) M[p] = cs[i].done; });
    var L = {k: k, neutral: Grade.neutral(R, M), data: null};
    if (!L.neutral) L.data = Grade.buildLut(R, M, SIZE);
    LUTS[k] = L; LUTN.push(k); if (LUTN.length > 40) delete LUTS[LUTN.shift()];
    return L;
  }

  /* ---------------------------------------------------------------- one WebGL canvas */
  function makeGL(cv) {
    var gl = cv.getContext("webgl2", {premultipliedAlpha: true, alpha: true, antialias: false});
    if (!gl) return null;
    function sh(t, s) { var x = gl.createShader(t); gl.shaderSource(x, s); gl.compileShader(x); return x; }
    var pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr); gl.useProgram(pr);
    var b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var lp = gl.getAttribLocation(pr, "p"); gl.enableVertexAttribArray(lp); gl.vertexAttribPointer(lp, 2, gl.FLOAT, false, 0, 0);
    var tv = gl.createTexture(); gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tv);
    [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T].forEach(function (w) { gl.texParameteri(gl.TEXTURE_2D, w, gl.CLAMP_TO_EDGE); });
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    var tl = gl.createTexture(); gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_3D, tl);
    [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T, gl.TEXTURE_WRAP_R].forEach(function (w) { gl.texParameteri(gl.TEXTURE_3D, w, gl.CLAMP_TO_EDGE); });
    gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.uniform1i(gl.getUniformLocation(pr, "v"), 0); gl.uniform1i(gl.getUniformLocation(pr, "l"), 1); gl.uniform1f(gl.getUniformLocation(pr, "n"), SIZE);
    return {gl: gl, on: gl.getUniformLocation(pr, "on"), lut: ""};
  }
  /* draw src through lut L into the rect (x, y, w, h) of the canvas, in canvas pixels (the rect may run past the edges: cover) */
  function draw(G, src, L, x, y, w, h) {
    var gl = G.gl, cv = gl.canvas;
    gl.activeTexture(gl.TEXTURE0); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, false);
    try { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src); } catch (e) { return false; }
    if (L && L.data && G.lut !== L.k) {
      gl.activeTexture(gl.TEXTURE1); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texImage3D(gl.TEXTURE_3D, 0, gl.RGB16F, SIZE, SIZE, SIZE, 0, gl.RGB, gl.FLOAT, L.data); G.lut = L.k;
    }
    gl.uniform1i(G.on, L && L.data && !API.off ? 1 : 0);
    gl.viewport(0, 0, cv.width, cv.height); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    gl.viewport(Math.round(x), Math.round(cv.height - y - h), Math.round(w), Math.round(h));      // GL counts y from the bottom
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    return true;
  }

  /* ---------------------------------------------------------------- the players */
  function ready(el) { return el.tagName === "IMG" ? el.complete && el.naturalWidth > 0 : el.readyState >= 2 && el.videoWidth > 0; }
  function natural(el) { return el.tagName === "IMG" ? [el.naturalWidth, el.naturalHeight] : [el.videoWidth, el.videoHeight]; }
  function pos(s, free) {       // one object-position value: "30%", "12px", "left" … as the fraction of the free space
    if (/%$/.test(s)) return parseFloat(s) / 100;
    if (/px$/.test(s)) return free ? parseFloat(s) / free : .5;
    return {left: 0, top: 0, right: 1, bottom: 1}[s] != null ? {left: 0, top: 0, right: 1, bottom: 1}[s] : .5;
  }
  /* where the picture lands inside the element's box, the way the browser lays out object-fit and object-position */
  function fitRect(cs, bw, bh, nw, nh) {
    var fit = cs.objectFit, k = fit === "contain" ? Math.min(bw / nw, bh / nh) : fit === "fill" ? 0 : Math.max(bw / nw, bh / nh);
    var dw = fit === "fill" ? bw : nw * k, dh = fit === "fill" ? bh : nh * k, op = (cs.objectPosition || "50% 50%").split(/\s+/);
    return [(bw - dw) * pos(op[0], bw - dw), (bh - dh) * pos(op[1] || "50%", bh - dh), dw, dh];
  }
  var COPY = ["transform", "transformOrigin", "clipPath", "borderRadius", "opacity", "zIndex"];
  function item(el) {
    for (var i = 0; i < ITEMS.length; i++) if (ITEMS[i].el === el) return ITEMS[i];
    var cv = document.createElement("canvas"); cv.className = "gvc"; cv.style.cssText = "position:absolute;pointer-events:none;display:none";
    el.parentNode.insertBefore(cv, el.nextSibling);      // right after its player: what sits above the player sits above the canvas too
    var it = {el: el, cv: cv, G: null, R: null, sig: ""}; ITEMS.push(it); return it;
  }
  function show(it, on) {
    if (on) { it.el.classList.add("gvhid"); } else { it.el.classList.remove("gvhid"); it.cv.style.display = "none"; it.sig = ""; }
  }
  API.set = function (el, R) { if (!el) return; var it = item(el); if (keyOf(R) !== keyOf(it.R)) { it.R = R ? JSON.parse(JSON.stringify(R)) : null; it.sig = ""; } };
  API.recipe = function (el) { var it = item(el); return it.R; };
  /* a player that's going away (the Media clip editor's): its canvas goes with it */
  API.drop = function (el) { for (var i = 0; i < ITEMS.length; i++) if (ITEMS[i].el === el) { ITEMS[i].cv.remove(); el.classList.remove("gvhid"); ITEMS.splice(i, 1); return; } };
  API.tick = function () {
    ITEMS.forEach(function (it) {
      var el = it.el, L = it.R && !API.off ? lutFor(it.R) : null, cv = it.cv, st = cv.style, up = st.display === "block";
      if (L === null || L && L.neutral || el.hidden) { show(it, false); return; }
      var cs = getComputedStyle(el); if (cs.display === "none") { show(it, false); return; }
      /* THE STANDBY PLAYER IS NOT DRAWN (Gabe, 2026-10-24: "the playhead is stopping at all the A-roll cuts"): the hidden second A-roll
         player seeks to the next piece before each cut, and copying a frame from a seeking video into WebGL blocks the page until it
         decodes, up to a second. A player you can't see (opacity 0) or one that is seeking is skipped; its canvas keeps the last frame */
      if (cs.opacity === "0" || el.seeking) { if (up) st.opacity = cs.opacity; return; }
      /* scrubbing: the player is fetching the new frame (or the new grade's .cube is loading). The last graded frame stays up
         until it's there; dropping the canvas showed the raw log picture underneath, a gray flash on every move (Gabe, 2026-10-24) */
      if (!L || !ready(el)) { if (up) COPY.forEach(function (k) { if (st[k] !== cs[k]) st[k] = cs[k]; }); else show(it, false); return; }
      COPY.forEach(function (k) { if (st[k] !== cs[k]) st[k] = cs[k]; });
      var dpr = Math.min(2, window.devicePixelRatio || 1), bw = el.offsetWidth, bh = el.offsetHeight, W = Math.max(1, Math.round(bw * dpr)), H = Math.max(1, Math.round(bh * dpr));
      st.left = el.offsetLeft + "px"; st.top = el.offsetTop + "px"; st.width = bw + "px"; st.height = bh + "px";
      var nat = natural(el), sig = [L.k.length, L.k, W, H, el.currentTime, cs.objectFit, cs.objectPosition, el.src].join("|");
      if (sig === it.sig && el.paused !== false) { show(it, true); return; }      // a still picture that hasn't changed: nothing to redraw
      if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
      if (!it.G) { it.G = makeGL(cv); if (!it.G) { show(it, false); return; } }
      var r = fitRect(cs, bw, bh, nat[0], nat[1]);
      if (draw(it.G, el, L, r[0] * dpr, r[1] * dpr, r[2] * dpr, r[3] * dpr)) { it.sig = sig; st.display = "block"; show(it, true); }
    });
    if (API.dirty) { API.dirty = false; ITEMS.forEach(function (it) { it.sig = ""; }); }
  };
  (function loop() { API.tick(); requestAnimationFrame(loop); })();

  /* ---------------------------------------------------------------- one graded frame, for the 2D canvases */
  API.paint = function (src, R, w, h) {
    if (!src || !ready(src)) return src;
    var L = R && !API.off ? lutFor(R) : null; if (!L || L.neutral) return src;
    var nat = natural(src); w = w || nat[0]; h = h || nat[1];
    if (!OFF) { var c = document.createElement("canvas"); OFF = makeGL(c); if (!OFF) return src; }
    var cv = OFF.gl.canvas; if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    if (!draw(OFF, src, L, 0, 0, w, h)) return src;
    var out = document.createElement("canvas"); out.width = w; out.height = h; out.getContext("2d").drawImage(cv, 0, 0);      // copied now: the GL canvas is reused
    return out;
  };

  /* ---------------------------------------------------------------- scopes: a waveform (brightness down the frame, left to right) and a vectorscope (hue and saturation) */
  API.scopes = function (src, R, wave, vec) {
    if (!src || !ready(src)) return;
    var nat = natural(src), w = 160, h = Math.max(1, Math.round(160 * nat[1] / nat[0]));
    var fr = API.paint(src, R, w, h), g0 = document.createElement("canvas"); g0.width = w; g0.height = h;
    var x0 = g0.getContext("2d", {willReadFrequently: true}); x0.drawImage(fr, 0, 0, w, h); var d = x0.getImageData(0, 0, w, h).data;
    if (wave) {
      var W = wave.width, H = wave.height, g = wave.getContext("2d"), acc = new Float32Array(W * H), mx = 0;
      for (var i = 0; i < w * h; i++) {
        var px = (i % w) / w * W | 0, Y = .2126 * d[i * 4] + .7152 * d[i * 4 + 1] + .0722 * d[i * 4 + 2], py = H - 1 - Math.round(Y / 255 * (H - 1));
        var a = acc[py * W + px] += 1; if (a > mx) mx = a;
      }
      var im = g.createImageData(W, H);
      for (var j = 0; j < W * H; j++) { var v = Math.min(255, Math.pow(acc[j] / Math.max(1, mx * .35), .6) * 255); im.data[j * 4] = v * .55; im.data[j * 4 + 1] = v; im.data[j * 4 + 2] = v * .7; im.data[j * 4 + 3] = 255; }
      g.putImageData(im, 0, 0); g.strokeStyle = "rgba(255,255,255,.18)"; g.lineWidth = 1;
      [0, .25, .5, .75, 1].forEach(function (q) { var yy = Math.round((1 - q) * (H - 1)) + .5; g.beginPath(); g.moveTo(0, yy); g.lineTo(W, yy); g.stroke(); });
    }
    if (vec) {
      var S = vec.width, gv = vec.getContext("2d"), ac = new Float32Array(S * S), m2 = 0;
      for (var k = 0; k < w * h; k++) {
        var r = d[k * 4] / 255, gg = d[k * 4 + 1] / 255, b = d[k * 4 + 2] / 255, Cb = -.1146 * r - .3854 * gg + .5 * b, Cr = .5 * r - .4542 * gg - .0458 * b;
        var vx = Math.round(S / 2 + Cb * S * .9), vy = Math.round(S / 2 - Cr * S * .9);
        if (vx >= 0 && vy >= 0 && vx < S && vy < S) { var q2 = ac[vy * S + vx] += 1; if (q2 > m2) m2 = q2; }
      }
      var iv = gv.createImageData(S, S);
      for (var n = 0; n < S * S; n++) { var vv = Math.min(255, Math.pow(ac[n] / Math.max(1, m2 * .3), .5) * 255); iv.data[n * 4] = vv * .8; iv.data[n * 4 + 1] = vv; iv.data[n * 4 + 2] = vv * .8; iv.data[n * 4 + 3] = 255; }
      gv.putImageData(iv, 0, 0); gv.strokeStyle = "rgba(255,255,255,.2)"; gv.beginPath(); gv.arc(S / 2, S / 2, S * .45, 0, 7); gv.stroke();
      gv.beginPath(); gv.moveTo(S / 2, S / 2); gv.strokeStyle = "rgba(255,190,120,.45)";      // the skin-tone line, 123° round from +Cb: healthy skin sits on it
      gv.lineTo(S / 2 + Math.cos(-2.15) * S * .45, S / 2 + Math.sin(-2.15) * S * .45); gv.stroke();
    }
  };
  return API;
})();
