/* update.js: "Update to 0.x" in the top bar of the Visual Studio home and the editor when a newer version is out (2026-10-23).
   One click runs cineyap/update.py on this Mac (projects, brand and settings are kept), the Studio restarts, the page reloads. */
(function(){
var bar=document.querySelector(".hbar")||document.querySelector("body > header");if(!bar)return;
var sp=bar.querySelector(".sp");
function get(){return fetch("/api/update").then(function(r){return r.json();});}
function btn(u){var b=document.createElement("button");b.type="button";b.className=bar.classList.contains("hbar")?"hbtn upd":"btn upd";
  b.textContent="Update to "+u.there;b.title=(u.notes?u.notes+". ":"")+"Your projects, brand and settings stay as they are.";
  b.style.cssText="background:#2f7d55;border-color:#2f7d55;color:#fff";
  b.onclick=function(){b.disabled=true;b.textContent="Updating…";
    fetch("/api/update",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(function(r){return r.json();}).then(function(r){
      if(r.error){b.disabled=false;b.textContent="Update to "+u.there;alert(r.error);return;}wait(b);});};
  if(sp&&sp.nextSibling)bar.insertBefore(b,sp.nextSibling);else bar.appendChild(b);return b;}
function wait(b){var t0=Date.now();(function poll(){
  get().then(function(u){if(u.state==="failed"){b.disabled=false;b.textContent="Update didn't finish";b.title=(u.log||[]).join("\n");return;}
    if(u.state==="done"||(u.have&&u.newer===false&&Date.now()-t0>3000)){b.textContent="Restarting…";back();return;}setTimeout(poll,1500);})
  .catch(function(){b.textContent="Restarting…";back();});})();}
function back(){(function ping(){setTimeout(function(){fetch("/api/update").then(function(r){if(r.ok)location.reload();else ping();}).catch(ping);},1500);})();}
var HAVE=null,UPB=null;
get().then(function(u){HAVE=u&&u.have;if(u&&u.newer&&u.state!=="running")UPB=btn(u);}).catch(function(){});
/* updates install themselves now (studio.py auto_update_loop): every minute, see whether one is running; show it and reload after */
setInterval(function(){get().then(function(u){if(!u)return;
  if(u.state==="running"&&!(UPB&&UPB.disabled)){if(!UPB)UPB=btn(u);UPB.disabled=true;UPB.textContent="Updating…";wait(UPB);}
  else if(HAVE&&u.have&&u.have!==HAVE)location.reload();}).catch(function(){});},60000);
/* SIGN IN TO CLAUDE (2026-10-23): the Claude Code program the Studio runs needs its own sign-in (the Claude app's doesn't carry
   over). Not signed in: a red button starts the sign-in in the browser and waits for it */
function auth(fresh){return fetch("/api/claude"+(fresh?"?fresh=1":"")).then(function(r){return r.json();});}
auth().then(function(a){if(!a||a.signedIn)return;
  var b=document.createElement("button");b.type="button";b.className=bar.classList.contains("hbar")?"hbtn":"btn";b.style.cssText="background:var(--accent);border-color:var(--accent);color:#fff";
  if(!a.found){b.textContent="Install Claude";b.title="Visual Studio needs Claude Code: install the Claude app, sign in, open its Code tab once";b.onclick=function(){window.open("https://claude.ai/download","_blank");};}
  else{b.textContent="Connect Claude";b.title="You're signed in to Claude already. Visual Studio needs your OK to use it: a Claude page opens in your browser, click Authorize";
    b.onclick=function(){b.disabled=true;b.textContent="Click Authorize in your browser…";
      fetch("/api/claude-login",{method:"POST",headers:{"Content-Type":"application/json"},body:"{}"}).then(function(r){return r.json();}).then(function(r){
        if(r.error){b.disabled=false;b.textContent="Connect Claude";alert(r.error);return;}var t0=Date.now();
        (function poll(){auth(true).then(function(x){if(x.signedIn){b.textContent="Connected"+(x.email?" as "+x.email:"");b.style.background="#2f7d55";b.style.borderColor="#2f7d55";setTimeout(function(){b.remove();},4000);return;}
          if(Date.now()-t0>300000){b.disabled=false;b.textContent="Connect Claude";b.title="Nothing came back from the browser. Click again and press Authorize on the Claude page that opens";return;}setTimeout(poll,3000);});})();});};}
  if(sp&&sp.nextSibling)bar.insertBefore(b,sp.nextSibling);else bar.appendChild(b);}).catch(function(){});
})();
