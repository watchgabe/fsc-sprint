/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* newvideo.js: the New video panel (Gabe, 2026-10-23, from the Studio Start Flow mockup). One place to start any video:
   A-roll takes (none = a blank project), supporting B-roll shot for it, notes for Claude (typed or spoken), and the settings.
   Start editing opens the editor right away; Claude's progress shows there while it cuts. POST /api/new-video. */
(function(){
var SHAPES=[["916","9:16"],["169","16:9"],["43","4:3"]];
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e;}
function api(p,b){return fetch(p,b?{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(b)}:{}).then(function(r){return r.json();});}
function clock(s){s=Math.round(s||0);return Math.floor(s/60)+":"+("0"+s%60).slice(-2);}
function seg(opts,cur,on){var g=el("div","nv-seg");opts.forEach(function(o){var b=el("button",o[0]===cur?"on":"",o[1]);b.type="button";
  b.onclick=function(){[].forEach.call(g.children,function(x){x.classList.toggle("on",x===b);});on(o[0]);};g.appendChild(b);});return g;}
/* a Finder file from a drop: the browser gives bytes, the Studio keeps a copy in inbox/ and hands back its path */
function upload(f){return fetch("/api/upload-raw?name="+encodeURIComponent(f.name),{method:"POST",body:f}).then(function(r){return r.json();}).then(function(r){return r.path;});}
var VID=/\.(mp4|mov|m4v|mxf|mts)$/i;

/* WELCOME TO STUDIO (the mockup's first screen): a card on the home page until Claude is connected, or it's skipped. Three steps,
   each with its own button, plus the sample. Nothing here is required except Claude. */
window.welcomeCard=function(){var c=el("section","wc");c.setAttribute("aria-label","Welcome to Visual Studio");
  try{if(localStorage.getItem("studio.welcome")==="skip")return c;}catch(e){}
  Promise.all([api("/api/claude"),api("/api/broll-folder"),api("/api/brand"),api("/api/sample")]).then(function(x){var cl=x[0]||{},bf=x[1]||{},br=x[2]||{},sm=x[3]||{};
    var done=[!!cl.signedIn,!!(bf.path&&bf.exists),!!br.saved];if(done[0]&&done[1]&&done[2])return;      /* all set: no card */
    var n=done.filter(Boolean).length,hd=el("div","wc-hd");hd.appendChild(el("span","wc-k","Set up · "+n+" of 3 done"));
    hd.appendChild(el("h2",null,"Welcome to Visual Studio"));hd.appendChild(el("p",null,"Three things and you're editing. Each takes under a minute, and you can change any of them later from the top bar."));
    var bar=el("div","wc-bar"),i=el("i");i.style.width=Math.round(n/3*100)+"%";bar.appendChild(i);hd.appendChild(bar);c.appendChild(hd);
    function step(k,ok,need,title,text,btn,fn){var r=el("div","wc-step"+(ok?" ok":need?" need":"")),dot=el("span","wc-dot",ok?"✓":String(k));r.appendChild(dot);
      var tx=el("div","wc-tx");tx.appendChild(el("b",null,title));tx.appendChild(el("span",null,ok?({1:"Connected"+(cl.email?" as "+cl.email:"")+".",2:"Linked: "+(bf.name||"your folder")+".",3:"Saved. Change it any time with Brand at the top."})[k]:text));r.appendChild(tx);
      if(!ok){var b=el("button","wc-btn"+(need?" go":""),btn);b.type="button";b.onclick=fn;r.appendChild(b);}c.appendChild(r);}
    step(1,done[0],true,"Connect Visual Studio to Claude",cl.found?"You're already signed in to Claude. Visual Studio just needs your OK to use it. Click Connect, a Claude page opens in your browser, and you click Authorize.":"Install the Claude app (claude.ai/download), sign in, and open its Code tab once. Then come back here.",
      cl.found?"Connect":"Get the Claude app",function(e){if(!cl.found){window.open("https://claude.ai/download","_blank");return;}var b=e.currentTarget;b.disabled=true;b.textContent="Click Authorize in your browser…";
        api("/api/claude-login",{}).then(function(){var t0=Date.now();(function poll(){api("/api/claude?fresh=1").then(function(a){if(a.signedIn){location.reload();return;}if(Date.now()-t0<300000)setTimeout(poll,3000);else{b.disabled=false;b.textContent="Connect";}});})();});});
    step(2,done[1],false,"Link your B-roll folder","Optional. Pick the folder your clips live in. Claude looks at each clip once, in the background, so it can pick B-roll by what's in the shot.","Choose folder…",
      function(e){var b=e.currentTarget;b.disabled=true;b.textContent="Pick it in Finder…";api("/api/broll-folder",{choose:true}).then(function(){location.reload();});});
    step(3,done[2],false,"Your brand","Your colors, main font and LUT. Every video uses them.","Set your brand",function(){location.hash="#brand";});
    if(sm.path){var s=el("div","wc-sample"),st=el("div","wc-tx");st.appendChild(el("b",null,"New here? Try the sample first"));
      st.appendChild(el("span",null,"Visual Studio comes with a 2-minute talking video. One click starts a real edit of it, so you see what Claude does before you use your own footage."));s.appendChild(st);
      var sb=el("button","wc-btn","Edit the sample video");sb.type="button";sb.onclick=function(){openNewVideo([sm.path]);};s.appendChild(sb);c.appendChild(s);}
    var sk=el("button","wc-skip","Skip setup for now");sk.type="button";sk.onclick=function(){try{localStorage.setItem("studio.welcome","skip");}catch(e){}c.remove();};c.appendChild(sk);
  }).catch(function(){});return c;};

window.openNewVideo=function(prefill){
  var S={takes:[],broll:[],info:{},notes:"",shape:"",shapeAuto:true,lut:null,library:true,name:""};
  var box=el("div","modal nv-wrap"),card=el("section","nv");card.setAttribute("aria-label","New video");box.appendChild(card);
  var hd=el("div","nv-hd");hd.appendChild(el("h2",null,"New video"));hd.appendChild(el("span","nv-sub","Drop your take and your B-roll. Claude cuts the A-roll first; you check the script before anything goes on top."));
  var x=el("button","nv-x","×");x.type="button";x.setAttribute("aria-label","Close");x.onclick=close;hd.appendChild(el("span","sp"));hd.appendChild(x);card.appendChild(hd);
  var body=el("div","nv-body"),L=el("div","nv-col"),Rr=el("div","nv-col");body.appendChild(L);body.appendChild(Rr);card.appendChild(body);

  /* ---- the name first, and big (Gabe, 2026-10-23): blank = Claude names it from what's said */
  var nl=el("label","nv-h");nl.htmlFor="nvName";nl.appendChild(el("b",null,"Name"));L.appendChild(nl);
  var nm=el("input","nv-in nv-name");nm.id="nvName";nm.placeholder="If blank, Claude will generate a name";nm.oninput=function(){S.name=nm.value;};L.appendChild(nm);
  /* ---- A-roll */
  var aH=el("div","nv-h");aH.appendChild(el("b",null,"A-roll"));aH.appendChild(el("span",null,"your talking take, or several joined in order"));L.appendChild(aH);
  var aList=el("div","nv-list");L.appendChild(aList);
  var aAdd=el("button","nv-add","+ Add a take");aAdd.type="button";aAdd.onclick=function(){pick(function(ps){add("takes",ps);});};L.appendChild(aAdd);
  var aHint=el("p","nv-hint","No take? Leave this empty and you get a blank project to build from B-roll and text.");L.appendChild(aHint);
  /* ---- supporting B-roll */
  var bH=el("div","nv-h");bH.appendChild(el("b",null,"B-roll"));bH.appendChild(el("span",null,"optional: what you shot for this video"));L.appendChild(bH);
  var bList=el("div","nv-list");L.appendChild(bList);
  var bDrop=el("button","nv-drop");bDrop.type="button";bDrop.innerHTML="<b>Drop B-roll here</b><span>or click to pick. Claude looks through every clip while it cuts, then uses them first when you Layer It.</span>";
  bDrop.onclick=function(){pick(function(ps){add("broll",ps);});};L.appendChild(bDrop);
  dropTo(bDrop,"broll");
  var libL=el("label","nv-check"),lib=el("input");lib.type="checkbox";lib.checked=true;lib.onchange=function(){S.library=lib.checked;};libL.appendChild(lib);
  var libT=el("span",null,"Also pick from my B-roll library");libL.appendChild(libT);L.appendChild(libL);
  api("/api/broll-folder").then(function(f){if(!f.path||!f.exists){lib.checked=false;lib.disabled=true;S.library=false;libT.textContent="Pick from my B-roll library (link a folder first, top right)";}
    else libT.textContent="Also pick from my B-roll library ("+f.clips+" clips)";}).catch(function(){});

  /* ---- notes for Claude, typed or spoken */
  var nH=el("label","nv-h");nH.htmlFor="nvNotes";nH.appendChild(el("b",null,"Notes for Claude"));nH.appendChild(el("span",null,"what it's about, which takes to use"));Rr.appendChild(nH);
  var nw=el("div","nv-notes"),ta=el("textarea");ta.id="nvNotes";ta.rows=5;ta.placeholder="This is about… Use the second try of the intro. Keep it under a minute. End on the comment ask.";
  ta.oninput=function(){S.notes=ta.value;};nw.appendChild(ta);
  var mic=el("button","nv-mic");mic.type="button";mic.title="Talk instead of typing (click again to stop)";mic.setAttribute("aria-label","Talk instead of typing");
  mic.innerHTML='<svg viewBox="0 0 16 16" width="15" height="15" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><rect x="5.5" y="1.75" width="5" height="8" rx="2.5"/><path d="M3 7.5a5 5 0 0 0 10 0M8 12.5v2"/></svg>';
  var rec=null;mic.onclick=function(){if(rec){try{rec.stop();}catch(e){}return;}var SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){alert("Voice typing needs Chrome or Safari.");return;}rec=new SR();rec.lang=navigator.language||"en-US";rec.continuous=true;rec.interimResults=true;var base=ta.value.replace(/\s+$/,""),fin="";
    rec.onresult=function(e){var live="";for(var i=e.resultIndex;i<e.results.length;i++){var r=e.results[i];if(r.isFinal)fin+=r[0].transcript;else live+=r[0].transcript;}
      ta.value=(base?base+" ":"")+(fin+live).replace(/^\s+/,"").replace(/\s+/g," ");S.notes=ta.value;};
    rec.onend=function(){rec=null;mic.classList.remove("on");};try{rec.start();mic.classList.add("on");}catch(e){rec=null;}};
  nw.appendChild(mic);Rr.appendChild(nw);
  var chips=el("div","nv-chips");["Under 60 seconds","Last try of every line","Cut the outro","Fast pace"].forEach(function(c){var b=el("button","nv-chip","+ "+c);b.type="button";
    b.onclick=function(){ta.value=(ta.value.replace(/\s+$/,"")+(ta.value.trim()?". ":"")+c+".").replace(/\.\.$/,".");S.notes=ta.value;ta.focus();};chips.appendChild(b);});Rr.appendChild(chips);

  /* ---- settings */
  Rr.appendChild(el("div","nv-h")).appendChild(el("b",null,"Settings"));
  var G=el("div","nv-grid");Rr.appendChild(G);
  function row(lab,ctl,note){var l=el("span","nv-lab",lab);G.appendChild(l);var w=el("div","nv-row");w.appendChild(ctl);if(note)w.appendChild(note);G.appendChild(w);return w;}
  var shapeNote=el("span","nv-note","");var shapeSeg=seg(SHAPES,"916",function(v){S.shape=v;S.shapeAuto=false;shapeNote.textContent="";});row("Shape",shapeSeg,shapeNote);
  /* Style, Captions and Music came out (Gabe, 2026-10-23): the first edit uses the default style, no music yet; it all changes in the editor */
  var lutL=el("label","nv-check"),lutC=el("input");lutC.type="checkbox";lutC.onchange=function(){S.lut=lutC.checked;};lutL.appendChild(lutC);var lutT=el("span",null,"Your LUT");lutL.appendChild(lutT);row("Color",lutL);
  api("/api/brand").then(function(b){var p=(b.brand||{}).lut||b.lut||"";if(!p){lutC.disabled=true;lutT.textContent="No LUT set (add one on the Brand page)";}else lutT.textContent="Your LUT ("+p.split("/").pop().replace(/\.cube$/i,"")+")";}).catch(function(){});

  /* ---- footer */
  var ft=el("div","nv-ft"),msg=el("span","nv-msg","The editor opens now. Your cut is ready in a few minutes; check the script, then Layer It.");ft.appendChild(msg);ft.appendChild(el("span","sp"));
  var cancel=el("button","nv-btn","Cancel");cancel.type="button";cancel.onclick=close;ft.appendChild(cancel);
  var go=el("button","nv-btn go","Start editing");go.type="button";go.onclick=start;ft.appendChild(go);card.appendChild(ft);

  dropTo(card,null);
  function close(){box.remove();document.removeEventListener("keydown",esc,true);}
  function esc(e){if(e.key==="Escape"&&!(document.activeElement&&/TEXTAREA|INPUT/.test(document.activeElement.tagName))){close();}}
  document.addEventListener("keydown",esc,true);
  box.addEventListener("mousedown",function(e){if(e.target===box)close();});
  document.body.appendChild(box);
  if(prefill&&prefill.length)add("takes",prefill);draw();

  function pick(cb){api("/api/choose-files").then(function(r){if(r.paths&&r.paths.length)cb(r.paths);});}
  function dropTo(node,kind){node.addEventListener("dragover",function(e){if([].indexOf.call(e.dataTransfer.types,"Files")>=0){e.preventDefault();node.classList.add("drag");}});
    node.addEventListener("dragleave",function(e){if(e.target===node)node.classList.remove("drag");});
    node.addEventListener("drop",function(e){var F=[].slice.call(e.dataTransfer.files||[]).filter(function(f){return VID.test(f.name);});if(!F.length)return;e.preventDefault();e.stopPropagation();node.classList.remove("drag");
      var k=kind||(e.target.closest&&e.target.closest(".nv-drop,.nv-list.broll")?"broll":"takes");msg.textContent="Copying "+F.length+" file"+(F.length>1?"s":"")+" into Visual Studio…";
      Promise.all(F.map(upload)).then(function(ps){add(k,ps.filter(Boolean));msg.textContent="The editor opens now. Your cut is ready in a few minutes; check the script, then Layer It.";});});}
  function add(kind,paths){paths.forEach(function(p){if(S[kind].indexOf(p)<0)S[kind].push(p);});draw();
    var need=paths.filter(function(p){return !S.info[p];});if(!need.length)return;
    api("/api/probe",{paths:need}).then(function(r){(r.videos||[]).forEach(function(v){S.info[v.path]=v;});
      var first=S.info[S.takes[0]]||S.info[S.broll[0]];
      if(S.shapeAuto&&first&&first.shape){S.shape=first.shape;[].forEach.call(shapeSeg.children,function(b,i){b.classList.toggle("on",SHAPES[i][0]===first.shape);});shapeNote.textContent="from your footage";}
      var t0=S.info[S.takes[0]];if(S.lut===null&&t0&&!lutC.disabled){lutC.checked=!!t0.log;S.lut=!!t0.log;}
      draw();});}
  function item(kind,p,i){var v=S.info[p]||{},r=el("div","nv-item"),th=el("img","nv-th");th.alt="";th.src="/thumb?p="+encodeURIComponent(p)+"&t=1";r.appendChild(th);
    var tx=el("div","nv-tx");tx.appendChild(el("b",null,p.split("/").pop()));
    var meta=[v.dur?clock(v.dur):"",v.shape?{"916":"vertical","169":"wide","43":"4:3"}[v.shape]:"",v.w?(v.w>=3000?"4K":v.h+"p"):""].filter(Boolean).join(" · ");tx.appendChild(el("span",null,meta||"…"));
    if(kind==="takes"&&v.log)tx.appendChild(el("em",null,"Log footage: your LUT goes on"));
    if(kind==="takes"&&i>0)tx.appendChild(el("small",null,"joined after take "+i));r.appendChild(tx);
    if(kind==="takes"&&S.takes.length>1){var up=el("button","nv-ib","↑");up.type="button";up.disabled=i===0;up.setAttribute("aria-label","Move up");up.onclick=function(){S.takes.splice(i,1);S.takes.splice(i-1,0,p);draw();};r.appendChild(up);}
    var rm=el("button","nv-ib","×");rm.type="button";rm.setAttribute("aria-label","Remove "+p.split("/").pop());rm.onclick=function(){S[kind].splice(S[kind].indexOf(p),1);draw();};r.appendChild(rm);return r;}
  function draw(){aList.innerHTML="";S.takes.forEach(function(p,i){aList.appendChild(item("takes",p,i));});bList.innerHTML="";bList.className="nv-list broll";S.broll.forEach(function(p,i){bList.appendChild(item("broll",p,i));});
    aAdd.textContent=S.takes.length?"+ Add another take":"+ Add a take";aHint.hidden=!!S.takes.length;
    go.textContent=S.takes.length?"Start editing":"Open a blank project";go.disabled=false;}
  function start(){go.disabled=true;go.textContent="Opening…";
    var body={takes:S.takes,broll:S.broll,notes:S.notes,shape:S.shape||undefined,library:S.library,name:S.name.trim()};if(S.lut!==null)body.lut=S.lut;
    api("/api/new-video",body).then(function(r){if(r.error){alert(r.error);draw();return;}
      if(r.editor){location.href=r.editor;return;}
      if(r.run){msg.textContent="Getting your takes ready…";(function wait(){api("/api/run?id="+r.run).then(function(st){
        if(st.job){location.href="/static/editor.html?job="+encodeURIComponent(st.job);return;}
        if(st.done){alert((st.log||[]).slice(-1)[0]||"That didn't start.");draw();return;}setTimeout(wait,1000);});})();}}).catch(function(){alert("Couldn't reach Visual Studio.");draw();});}
};
})();
