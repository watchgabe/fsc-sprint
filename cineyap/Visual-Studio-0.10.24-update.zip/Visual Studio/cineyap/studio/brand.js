/* Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE. */
/* brand.js — the Brand tab: a creator's colors, fonts, handle, LUT and logo, without editing a file.
   Reads and writes cineyap/brand.json through /api/brand. style.py applies it to every build.
   The preview is CSS, drawn from the same five colors and two fonts the builders use. */
(function(){
var COLORS=[
  ["dark","Dark","Cards, bands, and words on light plates"],
  ["light","Light","Cream plates and light words"],
  ["label","Label","The tag, label and pill box"],
  ["ink","Label text","Words on the label. Follows Dark if left empty"],
  ["text","Caption text","Words over your footage"],
  ["accent","Accent color","Optional. Tints the accent word"]];
var STYLES=[["serif-italic","Accent font"],["bold","Bold"],["underline","Underline"],["color","Color only"]];

window.renderBrand=function(page,APP,h,api){
  page.className="wrap wide brpage";page.innerHTML="";
  /* BACK (Gabe, 2026-10-24: "there's no return button, I can't go back to the project"): to the video you came from, else to your projects */
  var from="";try{from=sessionStorage.getItem("loop.brandFrom")||"";}catch(e){}
  var back=h("a",{class:"br-back",href:from||"#home",html:'<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3L5 8l5 5"/></svg><span>'+(from?"Back to your video":"Projects")+'</span>'});
  back.addEventListener("click",function(){try{sessionStorage.removeItem("loop.brandFrom");}catch(e){}});page.appendChild(back);
  page.appendChild(h("h1",{class:"pg-title",text:"Brand"}));
  page.appendChild(h("p",{class:"pg-sub",text:"Your colors, font and grade. New videos use them in every format."}));
  var body=h("div",{class:"as-p",text:"Loading…"});page.appendChild(body);
  api("/api/brand").then(function(S){draw(page,body,S,h,api);});
};

/* BRAND, SIMPLE (Gabe, 2026-10-23): three colors, the main font, the LUT. No logo (Gabe, 2026-10-23: "we can kill logo"). Name, handle, the label colors and the
   accent font keep whatever brand.json already has (label and label text follow Light and Dark when empty). */
var SIMPLE=[["dark","Dark","Color screens and cards"],["light","Light","Light plates, and words on dark"],["text","Captions","Words over your footage"]];
function draw(page,body,S,h,api){
  var B=JSON.parse(JSON.stringify(S.brand));delete B._native;
  B.colors=B.colors||{};B.fonts=B.fonts||{};
  var dirty=false;
  body.className="br-simple";body.innerHTML="";
  function touch(){dirty=true;saveBtn.disabled=false;status.textContent="Not saved yet";status.className="note warn";paint();}

  /* colors */
  var cs=h("div",{class:"br-sec"},[h("h3",{text:"Colors"})]);var sw={};
  SIMPLE.forEach(function(c){var k=c[0],val=B.colors[k]||S.presets.FSCreative[k]||"#000000";
    /* the editor's color picker (colorpick.js): the swatch shows the color, the rainbow opens the picker with the hex box ready */
    var pick=h("button",{type:"button",class:"br-sw","aria-label":c[1]+" color",title:"Pick a color"}),wheel=h("button",{type:"button",class:"cpick",title:"Pick a color"});pick.style.background=val;
    var hex=h("input",{type:"text",value:val.toUpperCase(),maxlength:"7",class:"hex","aria-label":c[1]+" hex"});
    var put=function(v){v=v.toUpperCase();pick.style.background=v;if(document.activeElement!==hex)hex.value=v;B.colors[k]=v;touch();};
    var open=function(e){e.stopPropagation();cpOpen(wheel,/^#[0-9A-F]{6}$/i.test(B.colors[k]||val)?(B.colors[k]||val).toUpperCase():"#FFFFFF",function(v){put(v);});};
    pick.addEventListener("click",open);wheel.addEventListener("click",open);
    hex.addEventListener("input",function(){var v=hex.value.trim();if(v[0]!=="#")v="#"+v;if(/^#[0-9a-fA-F]{6}$/.test(v))put(v);});
    sw[k]=pick;cs.appendChild(h("div",{class:"br-color"},[pick,h("div",{class:"br-cl"},[h("b",{text:c[1]}),h("small",{text:c[2]})]),hex,wheel]));});
  var smp=h("div",{class:"br-row"});var s1=h("div",{class:"sample",text:"Words on your dark"}),s2=h("div",{class:"sample",text:"Words on your light"});
  s1.style.flex=s2.style.flex="1 1 180px";smp.appendChild(s1);smp.appendChild(s2);cs.appendChild(smp);
  body.appendChild(cs);

  /* main font */
  var fs=h("div",{class:"br-sec"},[h("h3",{text:"Main font"})]);
  var sel=h("select",{"aria-label":"Main font"});
  function fill(){sel.innerHTML="";sel.appendChild(h("option",{value:"",text:"Default ("+base(S.pack_fonts.main).replace(/\.(ttf|otf|ttc)$/i,"").replace(/[-_]/g," ")+")"}));
    var g1=h("optgroup",{label:"Uploaded"}),g2=h("optgroup",{label:"Comes with Loop"}),g3=h("optgroup",{label:"On this Mac"});
    S.fonts.forEach(function(f){var o=h("option",{value:f.path,text:f.name});(f.path.indexOf("/brand_assets/")>=0?g1:f.shipped?g2:g3).appendChild(o);});
    [g1,g2,g3].forEach(function(g){if(g.children.length)sel.appendChild(g);});sel.value=B.fonts.main||"";}
  fill();sel.addEventListener("change",function(){B.fonts.main=sel.value;touch();});
  var up=h("label",{class:"hbtn",text:"Upload .ttf or .otf"}),fi=h("input",{type:"file",accept:".ttf,.otf",hidden:true});up.appendChild(fi);
  fi.addEventListener("change",function(){var f=fi.files[0];if(!f)return;upload(f,function(p){S.fonts.push({name:f.name.replace(/\.(ttf|otf)$/i,"").replace(/-/g," "),path:p,shipped:false});B.fonts.main=p;fill();touch();});});
  sel.style.flex="1 1 220px";fs.appendChild(h("div",{class:"br-row"},[sel,up]));
  fs.appendChild(h("small",{class:"note",text:"Captions, cards and titles. Any font on your Mac, or upload yours."}));
  body.appendChild(fs);

  /* LUT */
  var gs=h("div",{class:"br-sec"},[h("h3",{text:"LUT"})]);var lutName=h("b",{});
  function lutText(){lutName.textContent=B.lut?base(B.lut):"None. Your footage keeps its own color.";}lutText();
  var lu=h("label",{class:"hbtn",text:"Choose a .cube"}),lf=h("input",{type:"file",accept:".cube",hidden:true});lu.appendChild(lf);
  var lutSet=false;      /* only a LUT chosen or cleared here is written to config.json (R5: a colour change used to wipe it) */
  lf.addEventListener("change",function(){var f=lf.files[0];if(!f)return;upload(f,function(p){B.lut=p;lutSet=true;lutText();touch();});});
  gs.appendChild(h("div",{class:"br-file"},[lutName,h("div",{class:"br-row"},[lu,h("button",{type:"button",class:"hbtn",text:"No LUT",onclick:function(){B.lut="";lutSet=true;lutText();touch();}})])]));
  gs.appendChild(h("small",{class:"note",text:"Only if you shoot in log: the LUT that turns it into normal color. On normal footage it blows the picture out."}));
  body.appendChild(gs);


  /* save */
  var status=h("span",{class:"note",text:S.saved?"Saved":"Not saved yet. These are the defaults."});
  var saveBtn=h("button",{type:"button",class:"sbtn pri",text:"Save brand",disabled:S.saved,onclick:function(){
    saveBtn.disabled=true;status.textContent="Saving…";var out=JSON.parse(JSON.stringify(B));
    SIMPLE.forEach(function(c){if(!out.colors[c[0]])out.colors[c[0]]=S.presets.FSCreative[c[0]];});
    if(!out.colors.label)out.colors.label=out.colors.light;if(!out.colors.ink)out.colors.ink=out.colors.dark;
    api("/api/brand",{brand:out,lut_set:lutSet}).then(function(r){dirty=false;status.textContent=r.ok?"Saved. Your next video uses it.":"Could not save";status.className="note"+(r.ok?" good":" warn");
        /* saved: back where you came from, the video or the home page (Gabe, 2026-10-24: "Save Brand should go back to the homepage") */
        if(r.ok){var f="";try{f=sessionStorage.getItem("loop.brandFrom")||"";sessionStorage.removeItem("loop.brandFrom");}catch(e){}setTimeout(function(){location.href=f||"/#home";},350);}})
      .catch(function(){saveBtn.disabled=false;status.textContent="Could not save";status.className="note warn";});}});
  body.appendChild(h("div",{class:"br-save"},[saveBtn,status]));
  window.addEventListener("beforeunload",function(e){if(dirty){e.preventDefault();e.returnValue="";}});

  function paint(){var c={};SIMPLE.forEach(function(x){c[x[0]]=B.colors[x[0]]||S.presets.FSCreative[x[0]];});
    loadFace("BrandMain",B.fonts.main||S.pack_fonts.main);
    s1.style.background=c.dark;s1.style.color=c.light;s2.style.background=c.light;s2.style.color=c.dark;s1.style.fontFamily=s2.style.fontFamily="'BrandMain',Helvetica,sans-serif";}
  paint();
}

function fontUrl(p){return "/file?p="+encodeURIComponent(p);}
function loadFace(name,path){
  var id="bf-"+name,old=document.getElementById(id);if(old)old.remove();
  if(!path)return;
  var st=document.createElement("style");st.id=id;
  st.textContent="@font-face{font-family:'"+name+"';src:url('"+fontUrl(path)+"');font-display:block}";
  document.head.appendChild(st);}
function base(p){return String(p||"").split("/").pop()||"none";}
function upload(f,cb){fetch("/api/brand/upload?name="+encodeURIComponent(f.name),{method:"POST",body:f}).then(function(r){return r.json();}).then(function(r){if(r.path)cb(r.path);});}
})();
