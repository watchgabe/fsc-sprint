#!/usr/bin/env python3
"""fix_cutout.py — a cut-out of you that matches the video it sits on (Gabe, 2026-10-22: "it goes a little bit darker").

An effect that puts something BEHIND you draws a cut-out of you over the A-roll. Measured on c1511 ("Five reels behind me"):
`hyperframes remove-background` writes the cut-out about 2 levels darker than the clip it came from, and `hyperframes render`
loses about 1.5 more on any video with transparency (plain video and CSS colors come through exact). On a face around level 65
that is ~5% darker, so the moment the effect starts you visibly dim.

This rebuilds the cut-out from the ORIGINAL clip's pixels, keeping only the cut-out's transparency, and lifts it by what the
render takes off, so after the render it lands on the A-roll's own levels.

  ./vu-py cineyap/fix_cutout.py <cutout.webm> <clip it was cut from>        # rewrites the cut-out in place (keeps <name>.orig.webm)
"""
import pathlib, shutil, subprocess, sys

RENDER_LOSS = 1.5      # levels hyperframes render takes off an alpha WebM (calibrated on a gray ramp, 2026-10-22)

def fix(cut, src):
    cut, src = pathlib.Path(cut), pathlib.Path(src)
    orig = cut.with_name(cut.stem + ".orig.webm")
    if not orig.exists(): shutil.copy(cut, orig)      # always rebuild from the tool's own output, so running twice is harmless
    tmp = cut.with_name(cut.stem + ".fixing.webm")
    g = (f"[0:v]setpts=N/(24000/1001)/TB,alphaextract[a];"
         f"[1:v]setpts=N/(24000/1001)/TB,scale=w=iw:h=ih,format=yuv420p,lutyuv=y='clip(val+{RENDER_LOSS},16,235)'[c];"
         f"[a][c]scale2ref[a2][c2];[c2][a2]alphamerge,format=yuva420p[o]")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-c:v", "libvpx-vp9", "-i", str(orig), "-i", str(src), "-filter_complex", g,
                    "-map", "[o]", "-shortest", "-r", "24000/1001", "-c:v", "libvpx-vp9", "-crf", "16", "-b:v", "0", "-row-mt", "1",
                    "-auto-alt-ref", "0", "-pix_fmt", "yuva420p", "-colorspace", "bt709", "-color_range", "tv", str(tmp)], check=True)
    tmp.replace(cut)
    print(f"fixed {cut.name}: colors from {src.name}, +{RENDER_LOSS} for the render")

if __name__ == "__main__":
    if len(sys.argv) != 3: sys.exit(__doc__)
    fix(sys.argv[1], sys.argv[2])
