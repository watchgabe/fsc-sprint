#!/usr/bin/env python3
"""edit_learn.py — Loop Studio learns from how the creator finishes Claude's first version, with their approval (2026-10-22).

    ./vu-py cineyap/edit_learn.py diff <job> [version name]   # diff one version against its first version, print it
    ./vu-py cineyap/edit_learn.py summarise                   # turn the diffs into candidate preferences now
    ./vu-py cineyap/edit_learn.py list                        # the candidates and the approved ones

THE LOOP
 1. When ✦ First version runs, studio.first_pass() calls save_first_pass(): the patch Claude sent and the timeline it landed on go to
    projects/<job>/edit/first_pass.json. The editor's next save (the one that applies the patch) becomes the snapshot of what Claude made.
 2. When a version is exported or set to Approved, it is diffed against that snapshot: B-roll removed / swapped / added (with the line
    under it and the clip's description from broll_index.json when that exists), lines cut, caption rewrites and word swaps, color
    screens and Flashes added or removed (and whether they sit on a number or a named step), B-roll length and coverage, text layers,
    music level. One file per version: cineyap/edit_history/<job>-<version>.json (a re-export overwrites it).
 3. Once two or more videos have diffs, a cheap Claude (haiku) reads them and writes short CANDIDATE preferences, each with its evidence.
    They show in the editor's Chat panel under "What I've learned". Nothing is used until the creator approves it; approved ones join
    the editing rules every first version, chat and agent reads (studio.rules_text). Deleting one remembers it so it is not proposed again.

NEVER LEARNED (learned.py's rule): the hook, exact caption position, which takes to use and the register. They are decisions about
one video. The summariser is told so, and anything it writes about them anyway is dropped here.
"""
import difflib, json, pathlib, re, shutil, subprocess, sys, threading, time

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
try:
    from learned import NOT_LEARNABLE
except Exception:
    NOT_LEARNABLE = {"the hook": "", "caption position": "", "which takes": "", "register": ""}

HISTORY = PKG/"cineyap/edit_history"
PREFS = PKG/"cineyap/learned_prefs.json"       # {"prefs": [...], "dismissed": [...], "summarised": <diff count at the last run>}
INDEX = PKG/"cineyap/broll_index.json"         # what each B-roll clip shows (a sibling task builds it); optional
MIN_VIDEOS = 2                                 # videos (projects) with a finished edit before anything is proposed
MODEL = "haiku"                                # the cheap model: this is summarising, not editing
_LOCK = threading.Lock()
RUNNING = {"on": False}

# ---------------------------------------------------------------- small helpers
def _read(p, default=None):
    try: return json.loads(pathlib.Path(p).read_text())
    except Exception: return default

def _write(p, d):
    p = pathlib.Path(p); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(json.dumps(d, indent=1, ensure_ascii=False))

def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", str(s or "").lower()).strip("-")[:48] or "original"

def _claude():
    for c in (shutil.which("claude"), str(pathlib.Path.home()/".local/bin/claude"), str(pathlib.Path.home()/".claude/local/claude"),
              "/opt/homebrew/bin/claude", "/usr/local/bin/claude"):
        if c and pathlib.Path(c).exists(): return c
    return None

def version_state(d):
    """one version's own timeline: the editor's saved state without the list of versions"""
    return {k: v for k, v in (d or {}).items() if k not in ("VARS", "VACT")}

def _fmt_ok(o, fmt):
    return not o.get("fmt") or o.get("fmt") == fmt

# ---------------------------------------------------------------- 1. keep the first version
def save_first_pass(job, result):
    """called by studio.first_pass() with Claude's patch. The timeline it is about to land on is kept too, as a fallback snapshot."""
    J = PROJECTS/job
    if not job or not (J/"edit").is_dir() or not isinstance(result, dict) or not (result.get("br") or result.get("bg") or result.get("music")): return
    before = _read(J/"edit/timeline.json", {}) or {}
    _write(J/"edit/first_pass.json", {"made": time.strftime("%Y-%m-%d %H:%M:%S"), "pending": True, "patch": result,
                                      "before": version_state(before), "var": before.get("VACT"), "snapshot": None})

def _applied(fp, st):
    """did this save carry Claude's first version? (its B-roll clips or its song are on the timeline)"""
    P = fp.get("patch") or {}
    clips = {b.get("clip") for b in P.get("br") or []}
    if clips & {b.get("clip") for b in st.get("BR") or []}: return True
    m = str(P.get("music") or "").lower()
    return bool(m) and any(m[:12] in str(x.get("name", "")).lower() for x in st.get("MUSIC") or [])

def snapshot(job):
    """what Claude made: the saved snapshot, else the timeline before plus the patch"""
    fp = _read(PROJECTS/job/"edit/first_pass.json")
    if not fp: return None
    if fp.get("snapshot"): return fp["snapshot"]
    st = json.loads(json.dumps(fp.get("before") or {})); P = fp.get("patch") or {}
    st["BR"] = (st.get("BR") or []) + [{"clip": b["clip"], "in": b.get("in", 0), "t0": b["t0"], "t1": b["t1"]} for b in P.get("br") or [] if b.get("clip")]
    st["BG"] = (st.get("BG") or []) + [b for b in P.get("bg") or [] if b.get("screen")]
    st["FX"] = (st.get("FX") or []) + [{"builtin": "flash", "name": "Flash", "t0": float(t), "t1": float(t) + .458} for t in P.get("flashes") or []]
    if P.get("music") and not st.get("MUSIC"): st["MUSIC"] = [{"music": True, "name": P["music"], "gain_db": -20, "t0": 0, "t1": 1e9}]
    return st

# ---------------------------------------------------------------- 2. the diff
class Clock:
    """the A-roll of one version: timeline seconds <-> seconds in the raw take, and the words said"""
    def __init__(self, st, words):
        self.segs = []; t = 0.0
        for s in st.get("SEGS") or []:
            d = float(s["src_out"]) - float(s["src_in"]); self.segs.append((float(s["src_in"]), float(s["src_out"]), t, t + d)); t += d
        self.dur = t; self.words = words
    def src(self, a, b):
        """the stretches of the raw take a timeline block [a, b] plays over"""
        out = []
        for si, so, t0, t1 in self.segs:
            x0, x1 = max(a, t0), min(b, t1)
            if x1 > x0 + 1e-3: out.append((si + x0 - t0, si + x1 - t0))
        return out
    def at(self, t):
        for si, so, t0, t1 in self.segs:
            if t0 - 1e-3 <= t < t1: return si + t - t0
        return None
    def has(self, s):
        return any(si - .02 <= s < so - .02 for si, so, _, _ in self.segs)
    def said(self, R, pad=0.0):
        return " ".join(w[2] for w in self.words if any(a - pad <= w[0] < b + pad for a, b in R))

def _ov(A, B):
    return sum(max(0.0, min(b, d) - max(a, c)) for a, b in A for c, d in B)

def _len(R): return sum(b - a for a, b in R)

NUMW = r"\b(\d+|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|twenty|thirty|forty|fifty|hundred|thousand|million|first|second|third|fourth|fifth|half|percent)\b"
STEPW = r"\b(step|week|day|month|phase|part|number|next|first|second|third|finally|last|tip|rule|mistake|reason|lesson)\b"
def tags(text):
    t = text.lower(); out = []
    if re.search(NUMW, t): out.append("number")
    if re.search(STEPW, t): out.append("named step")
    if "?" in text: out.append("question")
    return out

def broll_index():
    """clip path -> what it shows, from broll_index.json if the index exists yet (any of its likely shapes)"""
    d = _read(INDEX)
    if not d: return {}
    out = {}
    if isinstance(d, dict) and isinstance(d.get("shots"), dict):      # broll_index.py: {"shots": {"<path>|<range>": {path, rel, description, place, action, tags, ...}}}
        for v in d["shots"].values():
            if not isinstance(v, dict) or not v.get("description"): continue
            txt = v["description"] + (f" Place: {v['place']}." if v.get("place") else "") + (f" Tags: {', '.join(v.get('tags') or [])}." if v.get("tags") else "")
            for k in (v.get("rel"), v.get("path")):
                if k and k not in out: out[k] = txt      # a long file with several shots keeps its first shot's description
        return out
    rows = d.get("clips") if isinstance(d, dict) and isinstance(d.get("clips"), (list, dict)) else d
    def desc(v):
        if isinstance(v, str): return v
        if not isinstance(v, dict): return ""
        bits = [str(v.get(k)) for k in ("description", "desc", "summary", "what", "shows", "caption") if v.get(k)]
        tg = v.get("tags") or v.get("keywords")
        if tg: bits.append("tags: " + (", ".join(map(str, tg)) if isinstance(tg, list) else str(tg)))
        return "; ".join(bits)
    if isinstance(rows, dict):
        for k, v in rows.items(): out[k] = desc(v)
    elif isinstance(rows, list):
        for v in rows:
            if isinstance(v, dict):
                k = v.get("clip") or v.get("path") or v.get("file") or v.get("rel")
                if k: out[str(k)] = desc(v)
    return out

def _desc(idx, clip):
    if not clip: return ""
    if clip in idx: return idx[clip]
    for k, v in idx.items():      # an absolute path in the index, a relative one on the timeline (or the other way round)
        if k.endswith("/" + clip) or clip.endswith("/" + k) or pathlib.Path(k).name == pathlib.Path(clip).name: return v
    return ""

def transcript_words(job):
    J = PROJECTS/job
    try:
        src = list(json.loads((J/"edit/edl.json").read_text())["sources"].keys())[0]
        tr = json.loads((J/"edit/transcripts"/f"{src}.json").read_text())
        return [(float(w["start"]), float(w["end"]), w["text"]) for w in tr["words"] if w.get("type") == "word"]
    except Exception:
        return []

def _match(A, B, fa, fb):
    """pair blocks of the first version (A) with blocks of the finished one (B) by how much of the take they share"""
    pairs, used = [], set()
    for i, a in enumerate(A):
        best, bi = 0.0, None
        for j, b in enumerate(B):
            if j in used: continue
            o = _ov(fa(a), fb(b))
            if o > best: best, bi = o, j
        short = min(_len(fa(a)), _len(fb(B[bi]))) if bi is not None else 0
        if bi is not None and short > 0 and best >= .3 * short: used.add(bi); pairs.append((a, B[bi]))
        else: pairs.append((a, None))
    return pairs, [b for j, b in enumerate(B) if j not in used]

def _is_flash(o): return o.get("builtin") == "flash" or str(o.get("name", "")).lower().startswith("flash")

def _swaps(a, b):
    A, B = a.split(), b.split(); out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, [w.lower().strip(".,!?\"'") for w in A], [w.lower().strip(".,!?\"'") for w in B]).get_opcodes():
        if op != "equal": out.append({"from": " ".join(A[i1:i2]), "to": " ".join(B[j1:j2])})
    return out

def diff(job, first, final, version="", how=""):
    """what the creator changed between Claude's first version and the version they finished"""
    words = transcript_words(job)
    F, G = Clock(first, words), Clock(final, words)
    fmt_a, fmt_b = first.get("FMT") or "169", final.get("FMT") or "169"
    idx = broll_index()
    sname = {s.get("id"): s.get("name") or s.get("id") for s in (final.get("SCREENS") or []) + (first.get("SCREENS") or [])}
    hook_end = max([float(h.get("t1", 0)) for h in first.get("HK") or []] + [2.5])      # the hook is never learned
    out = {"job": job, "version": version, "how": how, "when": time.strftime("%Y-%m-%d %H:%M"), "format": fmt_b,
           "broll": [], "screens": [], "flashes": [], "captions": [], "word_swaps": [], "accents": [], "lines_cut": [], "lines_added": [],
           "text_layers": {}, "music": {}, "stats": {}}

    # B-roll: removed, swapped, added, trimmed
    A = [b for b in first.get("BR") or [] if b.get("clip") and _fmt_ok(b, fmt_a)]
    B = [b for b in final.get("BR") or [] if b.get("clip") and _fmt_ok(b, fmt_b)]
    fa = lambda b: F.src(float(b["t0"]), float(b["t1"])); fb = lambda b: G.src(float(b["t0"]), float(b["t1"]))
    pairs, added = _match(A, B, fa, fb)
    for a, b in pairs:
        R = fa(a); line = F.said(R); kept = sum(1 for w in words if any(x <= w[0] < y for x, y in R) and G.has(w[0]))
        allw = sum(1 for w in words if any(x <= w[0] < y for x, y in R))
        rec = {"line": line, "proposed": a["clip"], "proposed_desc": _desc(idx, a["clip"]), "proposed_secs": round(float(a["t1"]) - float(a["t0"]), 2)}
        if b is None:
            rec["what"] = "removed with its line" if allw and kept < .3 * allw else "removed"
        elif b["clip"] != a["clip"]:
            rec.update({"what": "swapped", "chosen": b["clip"], "chosen_desc": _desc(idx, b["clip"]), "chosen_secs": round(float(b["t1"]) - float(b["t0"]), 2)})
        else:
            d = round(float(b["t1"]) - float(b["t0"]), 2)
            rec.update({"what": "kept" if abs(d - rec["proposed_secs"]) < .4 else ("lengthened" if d > rec["proposed_secs"] else "shortened"), "chosen_secs": d})
        out["broll"].append(rec)
    for b in added:
        out["broll"].append({"what": "added", "line": G.said(fb(b)), "chosen": b["clip"], "chosen_desc": _desc(idx, b["clip"]),
                             "chosen_secs": round(float(b["t1"]) - float(b["t0"]), 2), "at_secs": round(float(b["t0"]), 1)})

    # color screens
    A = [g for g in first.get("BG") or [] if g.get("screen") and _fmt_ok(g, fmt_a)]
    B = [g for g in final.get("BG") or [] if g.get("screen") and _fmt_ok(g, fmt_b)]
    pairs, added = _match(A, B, fa, fb)
    def scr(g): return sname.get(g["screen"], g["screen"]) + (" / " + sname.get(g["split"], g["split"]) if g.get("split") else "")
    for a, b in pairs:
        line = F.said(fa(a)); rec = {"line": line, "tags": tags(line), "proposed": scr(a), "proposed_secs": round(float(a["t1"]) - float(a["t0"]), 2)}
        if b is None: rec["what"] = "removed"
        else: rec.update({"what": "kept" if scr(a) == scr(b) else "recolored", "chosen": scr(b), "chosen_secs": round(float(b["t1"]) - float(b["t0"]), 2)})
        out["screens"].append(rec)
    for b in added:
        line = G.said(fb(b)); out["screens"].append({"what": "added", "line": line, "tags": tags(line), "chosen": scr(b), "chosen_secs": round(float(b["t1"]) - float(b["t0"]), 2)})

    # flashes: a point in the take, matched within half a second; the words right after it say what it marks
    def fl_src(clock, o):
        s = clock.at(float(o["t0"]) + .15); return s
    FA = [(fl_src(F, o), o) for o in first.get("FX") or [] if _is_flash(o) and _fmt_ok(o, fmt_a)]
    FB = [(fl_src(G, o), o) for o in final.get("FX") or [] if _is_flash(o) and _fmt_ok(o, fmt_b)]
    FA = [x for x in FA if x[0] is not None]; FB = [x for x in FB if x[0] is not None]; used = set()
    def after(s): return " ".join(w[2] for w in words if s - .3 <= w[0] < s + 2.5)[:120]
    for s, o in FA:
        j = next((j for j, (t, _) in enumerate(FB) if j not in used and abs(t - s) < .5), None)
        line = after(s)
        if j is None: out["flashes"].append({"what": "removed", "before_words": line, "tags": tags(line)})
        else: used.add(j); out["flashes"].append({"what": "kept", "before_words": line, "tags": tags(line)})
    for j, (s, o) in enumerate(FB):
        if j not in used:
            line = after(s); out["flashes"].append({"what": "added", "before_words": line, "tags": tags(line)})

    # captions: rewrites, word swaps, hidden captions, accent words (style only; never where a caption sits)
    OA, OB = first.get("OVR") or {}, final.get("OVR") or {}
    POS = {"ox", "oy", "v", "h", "px", "py", "da", "db", "wbox"}
    for k in sorted(set(OA) | set(OB), key=lambda x: int(x) if str(x).isdigit() else 0):
        a, b = OA.get(k) or {}, OB.get(k) or {}
        try: s0 = int(k) / 100
        except Exception: continue
        if not G.has(s0) and not F.has(s0): continue
        if b.get("text") is not None and b.get("text") != a.get("text"):
            n = len(str(b["text"]).split()) + 2
            raw = a.get("text") or " ".join(w[2] for w in words if w[0] >= s0 - .02)[:400]
            raw = " ".join(raw.split()[:n]).strip(".,?!") if not a.get("text") else raw
            sw = _swaps(raw, b["text"])
            out["captions"].append({"what": "reworded", "said": raw, "caption": b["text"]})
            out["word_swaps"] += [x for x in sw if x["from"] and x["to"] and len(x["from"].split()) <= 3]
        if b.get("hide") and not a.get("hide"):
            out["captions"].append({"what": "hidden", "said": " ".join(w[2] for w in words if s0 - .02 <= w[0] < s0 + 1.5)})
        wa, wb = a.get("w") or {}, b.get("w") or {}
        sty = {x: y for x, y in (b.get("st") or {}).items() if x not in POS}
        if (sty and sty != {x: y for x, y in (a.get("st") or {}).items() if x not in POS}) or (wb and wb != wa):
            cap = b.get("text") or " ".join(w[2] for w in words if s0 - .02 <= w[0] < s0 + 1.2)
            ws = cap.split(); styled = [ws[int(i)] for i in wb if str(i).isdigit() and int(i) < len(ws)] if wb else []
            out["accents"].append({"caption": cap, "words": styled, "look": json.dumps(sty or {i: wb[i] for i in list(wb)[:2]}, ensure_ascii=False)[:160]})

    # lines cut and put back (outside the hook)
    def runs(src_words, keep):
        R, cur = [], []
        for w in src_words:
            if keep(w): cur.append(w[2])
            elif cur: R.append(" ".join(cur)); cur = []
        if cur: R.append(" ".join(cur))
        return R
    in_first = [w for w in words if F.has(w[0])]
    hook_src = {w[0] for w in words if any(a <= w[0] < b for a, b in F.src(0, hook_end))}
    out["lines_cut"] = [r for r in runs([w for w in in_first if w[0] not in hook_src], lambda w: not G.has(w[0])) if r]
    in_final = [w for w in words if G.has(w[0])]
    out["lines_added"] = [r for r in runs(in_final, lambda w: not F.has(w[0])) if r][:8]

    # text layers and music
    def texts(st): return [" / ".join(str(l.get("text", "")) for l in (h.get("lines") or [])) or str(h.get("title", "")) for h in st.get("HK") or [] if _fmt_ok(h, st.get("FMT") or "169")]
    ta, tb = texts(first), texts(final)
    out["text_layers"] = {"first": len(ta), "final": len(tb), "added": [t for t in tb if t not in ta][:6], "removed": [t for t in ta if t not in tb][:6]}
    ma, mb = (first.get("MUSIC") or [{}])[0] if first.get("MUSIC") else {}, (final.get("MUSIC") or [{}])[0] if final.get("MUSIC") else {}
    out["music"] = {"first": ma.get("name", ""), "final": mb.get("name", ""), "first_db": ma.get("gain_db"), "final_db": mb.get("gain_db"),
                    "removed": bool(ma) and not mb, "changed_song": bool(ma and mb and ma.get("name") != mb.get("name"))}

    def cover(st, clock, fmt):
        L = [b for b in st.get("BR") or [] if b.get("clip") and _fmt_ok(b, fmt)]
        secs = sum(float(b["t1"]) - float(b["t0"]) for b in L)
        return {"broll_count": len(L), "broll_mean_secs": round(secs / len(L), 2) if L else 0, "broll_cover_pct": round(100 * secs / clock.dur) if clock.dur else 0,
                "screens": len([g for g in st.get("BG") or [] if _fmt_ok(g, fmt)]), "flashes": len([o for o in st.get("FX") or [] if _is_flash(o) and _fmt_ok(o, fmt)]),
                "secs": round(clock.dur, 1)}
    out["stats"] = {"first": cover(first, F, fmt_a), "final": cover(final, G, fmt_b)}
    return out

def changed(d):
    """did the creator change anything worth learning from?"""
    return any(x["what"] not in ("kept",) for x in d["broll"] + d["screens"] + d["flashes"]) or d["captions"] or d["lines_cut"] or d["accents"] \
        or d["music"].get("changed_song") or d["music"].get("removed") or (d["music"].get("first_db") != d["music"].get("final_db")) \
        or d["text_layers"].get("added") or d["text_layers"].get("removed")

def record(job, version, final_state, how):
    """diff one finished version against the first version and keep it. Returns the file, or None (no first version, a carousel)"""
    first = snapshot(job)
    st = version_state(final_state)
    if not first or st.get("KIND") == "carousel" or not st.get("SEGS"): return None
    d = diff(job, first, st, version, how)
    f = HISTORY/f"{job}-{_slug(version)}.json"; _write(f, d)
    return f

# ---------------------------------------------------------------- hooks the Studio calls
def on_save(job, prev, new, cl=None):
    """studio's /api/timeline-save, after the write: take the first-version snapshot, and diff any version just set to Approved"""
    J = PROJECTS/job; wrote = []
    try:
        fp = _read(J/"edit/first_pass.json")
        if fp and fp.get("pending") and _applied(fp, new):
            fp.update({"pending": False, "snapshot": version_state(new), "var": new.get("VACT"), "snap_at": time.strftime("%Y-%m-%d %H:%M:%S")})
            _write(J/"edit/first_pass.json", fp)
        if not fp: return []
        was = {v.get("id"): v.get("status") for v in (prev or {}).get("VARS") or []}
        for v in new.get("VARS") or []:
            if v.get("status") == "approved" and was.get(v.get("id")) != "approved" and v.get("id") in was:
                data = new if v.get("id") == new.get("VACT") or not v.get("data") else v["data"]
                f = record(job, v.get("name") or v.get("id"), data, "approved")
                if f: wrote.append(f)
        if not new.get("VARS") and (prev or {}).get("VARS") is None: pass
    except Exception as e:
        print("edit_learn.on_save:", e, flush=True)
    if wrote: maybe_summarise(cl)
    return wrote

def on_export(job, body, cl=None):
    """studio's /api/timeline-export: every version in the export is a finished edit"""
    wrote = []
    try:
        if body.get("variants"):
            for v in body["variants"]:
                f = record(job, v.get("name") or "version", v.get("state") or {}, "exported")
                if f: wrote.append(f)
        else:
            cur = _read(PROJECTS/job/"edit/timeline.json", {}) or {}
            name = next((v.get("name") for v in cur.get("VARS") or [] if v.get("id") == cur.get("VACT")), "Original")
            f = record(job, name, cur, "exported")
            if f: wrote.append(f)
    except Exception as e:
        print("edit_learn.on_export:", e, flush=True)
    if wrote: maybe_summarise(cl)
    return wrote

# ---------------------------------------------------------------- 3. candidate preferences
def history():
    out = []
    for f in sorted(HISTORY.glob("*.json")):
        d = _read(f)
        if d and changed(d): out.append(d)
    return out

def digest(d):
    """one finished version as short plain lines for the summariser"""
    L = [f"VIDEO {d['job']} / version \"{d['version']}\" ({d['how']}, format {d['format']})"]
    for b in d["broll"]:
        if b["what"] == "kept": continue
        ln = f"  line \"{b['line'][:90]}\""
        pd = f" [{b['proposed_desc'][:80]}]" if b.get("proposed_desc") else ""; cd = f" [{b['chosen_desc'][:80]}]" if b.get("chosen_desc") else ""
        if b["what"] == "swapped": L.append(f"- B-roll SWAPPED on{ln}: Claude's {b['proposed']}{pd} -> creator's {b['chosen']}{cd}")
        elif b["what"] == "added": L.append(f"- B-roll ADDED on{ln}: {b['chosen']}{cd}, {b['chosen_secs']}s")
        elif b["what"] == "removed": L.append(f"- B-roll REMOVED on{ln}: {b['proposed']}{pd}")
        elif b["what"] in ("lengthened", "shortened"): L.append(f"- B-roll {b['what'].upper()} {b['proposed_secs']}s -> {b['chosen_secs']}s ({b['proposed']})")
    for g in d["screens"]:
        if g["what"] == "kept": continue
        tg = f" (on: {', '.join(g['tags'])})" if g.get("tags") else ""
        L.append(f"- Color screen {g['what'].upper()} on line \"{g['line'][:80]}\"{tg}: " + (f"{g.get('proposed','')} -> {g.get('chosen','')}" if g["what"] == "recolored" else g.get("chosen") or g.get("proposed", "")))
    for x in d["flashes"]:
        if x["what"] == "kept": continue
        tg = f" (on: {', '.join(x['tags'])})" if x.get("tags") else ""
        L.append(f"- Flash {x['what'].upper()} right before \"{x['before_words'][:70]}\"{tg}")
    for c in d["captions"][:12]:
        L.append(f"- Caption {c['what']}: said \"{c.get('said','')[:70]}\"" + (f" -> caption \"{c['caption'][:70]}\"" if c.get("caption") else ""))
    for w in d["word_swaps"][:12]: L.append(f"- Word swap in captions: \"{w['from']}\" -> \"{w['to']}\"")
    for a in d["accents"][:8]: L.append(f"- Accent styling on caption \"{a['caption'][:60]}\" words {a['words']} look {a['look']}")
    for r in d["lines_cut"][:12]: L.append(f"- Line CUT: \"{r[:100]}\"")
    t = d["text_layers"]
    for x in t.get("added", []): L.append(f"- Text layer ADDED: \"{x[:70]}\"")
    for x in t.get("removed", []): L.append(f"- Text layer REMOVED: \"{x[:70]}\"")
    m = d["music"]
    if m.get("removed"): L.append(f"- Music REMOVED (Claude picked \"{m['first']}\")")
    elif m.get("changed_song"): L.append(f"- Music CHANGED: \"{m['first']}\" -> \"{m['final']}\"")
    if m.get("first_db") is not None and m.get("final_db") is not None and m["first_db"] != m["final_db"]: L.append(f"- Music level {m['first_db']} dB -> {m['final_db']} dB")
    a, b = d["stats"]["first"], d["stats"]["final"]
    L.append(f"- Totals, Claude -> creator: B-roll {a['broll_count']} clips, {a['broll_cover_pct']}% covered, mean {a['broll_mean_secs']}s -> {b['broll_count']} clips, "
             f"{b['broll_cover_pct']}% covered, mean {b['broll_mean_secs']}s; color screens {a['screens']} -> {b['screens']}; flashes {a['flashes']} -> {b['flashes']}")
    return "\n".join(L)

NEVER = "\n".join(f"- {k}: {v}" for k, v in NOT_LEARNABLE.items())
SUMMARY = """You help a video editor app learn one creator's editing taste. An AI made the FIRST VERSION of each video (B-roll, color
screens, flashes, captions, music); the creator then finished it. Below is what the creator changed, video by video.

Write CANDIDATE PREFERENCES: short standing instructions for the AI's next first version, in the creator's voice of instruction
("Use walking shots, not desk shots, on lines about habits"). Rules:
- Only a pattern seen in at least {need} different VIDEOS (the VIDEO name before the slash; versions of one video count once). A single
  change is not a preference.
- Each must say what to DO, concretely (which kind of clip, on which kind of line, how long, how many, which level), so the AI can follow it.
- Each has EVIDENCE: one plain sentence with counts and a concrete example, like "In 2 of 2 videos you replaced desk B-roll on habit
  lines with walking shots (\\"New House B Roll_17\\" -> \\"Walk_03\\")".
- NEVER propose anything about these, they are decisions about one video:
{never}
- Do not repeat an APPROVED preference or a DISMISSED one (listed below), or anything that means the same.
- At most 6, the strongest first. If nothing repeats across videos, return an empty list.
Reply with ONE JSON object and nothing else:
{{"prefs": [{{"text": "...", "evidence": "...", "kind": "broll|screens|flashes|captions|cuts|music|text|pacing", "videos": <number of videos>}}]}}

APPROVED:
{approved}
DISMISSED:
{dismissed}

WHAT THE CREATOR CHANGED:
{changes}
"""
BANNED = re.compile(r"\bhooks?\b|caption (position|placement|height)|position of (the )?captions?|captions? (higher|lower|sit|placed)|which takes?|\btakes? to use|\bregister\b|confessional|teaching tone", re.I)

def load_prefs():
    d = _read(PREFS, {}) or {}
    d.setdefault("prefs", []); d.setdefault("dismissed", []); d.setdefault("summarised", 0)
    return d

def save_prefs(d): _write(PREFS, d)

def videos():
    return sorted({d["job"] for d in history()})

def summarise(cl=None, force=False):
    """read every diff, ask the cheap model for candidates, keep the approved ones, replace the old candidates"""
    H = history(); jobs = {d["job"] for d in H}
    if len(jobs) < MIN_VIDEOS: return {"ok": False, "why": f"needs {MIN_VIDEOS} videos with finished edits, has {len(jobs)}"}
    cl = cl or _claude()
    if not cl: return {"ok": False, "why": "Claude Code was not found on this Mac"}
    with _LOCK:
        P = load_prefs()
        appr = [p for p in P["prefs"] if p.get("status") == "approved"]
        changes = "\n\n".join(digest(d) for d in H[-24:])
        prompt = SUMMARY.format(need=MIN_VIDEOS, never=NEVER, approved="\n".join("- " + p["text"] for p in appr) or "(none)",
                                dismissed="\n".join("- " + t for t in P["dismissed"][-40:]) or "(none)", changes=changes[:60000])
    try:
        r = subprocess.run([cl, "--model", MODEL, "-p", prompt, "--max-turns", "1"], cwd=PKG, capture_output=True, text=True, timeout=300)
        out = r.stdout.strip(); got = json.loads(out[out.index("{"): out.rindex("}") + 1]).get("prefs", [])
    except Exception as e:
        return {"ok": False, "why": f"the summary didn't come back: {e}"}
    with _LOCK:
        P = load_prefs()
        keep = [p for p in P["prefs"] if p.get("status") == "approved"]
        seen = [p["text"].lower() for p in keep] + [t.lower() for t in P["dismissed"]]
        new = []
        for g in got:
            t = str(g.get("text", "")).strip(); ev = str(g.get("evidence", "")).strip()
            if not t or BANNED.search(t) or BANNED.search(ev): continue
            if int(g.get("videos") or 0) and int(g.get("videos")) < MIN_VIDEOS: continue
            if any(difflib.SequenceMatcher(None, t.lower(), s).ratio() > .8 for s in seen): continue
            seen.append(t.lower())
            new.append({"id": "p" + format(abs(hash(t + str(time.time()))) % 16**6, "06x"), "text": t, "evidence": ev, "kind": g.get("kind", ""),
                        "videos": int(g.get("videos") or 0), "status": "candidate", "made": time.strftime("%Y-%m-%d %H:%M")})
        P["prefs"] = keep + new; P["summarised"] = len(H); P["last_run"] = time.strftime("%Y-%m-%d %H:%M"); save_prefs(P)
    return {"ok": True, "new": len(new)}

def maybe_summarise(cl=None):
    """after a new diff: summarise in the background once enough videos have been finished"""
    if RUNNING["on"] or len(videos()) < MIN_VIDEOS: return False
    def work():
        RUNNING["on"] = True
        try: summarise(cl)
        except Exception as e: print("edit_learn.summarise:", e, flush=True)
        finally: RUNNING["on"] = False
    threading.Thread(target=work, daemon=True).start(); return True

def api_state():
    P = load_prefs()
    return {"prefs": [p for p in P["prefs"] if p.get("status") in ("candidate", "approved")], "videos": len(videos()), "need": MIN_VIDEOS,
            "running": RUNNING["on"], "last_run": P.get("last_run", "")}

def api_op(body, cl=None):
    """{"op": "approve"|"edit"|"delete"|"refresh", "id"?, "text"?}"""
    op = body.get("op")
    if op == "refresh":
        maybe_summarise(cl); return api_state()
    with _LOCK:
        P = load_prefs(); p = next((x for x in P["prefs"] if x.get("id") == body.get("id")), None)
        if p:
            if op == "approve": p["status"] = "approved"; p["approved"] = time.strftime("%Y-%m-%d %H:%M")
            elif op == "edit" and str(body.get("text", "")).strip():
                if not BANNED.search(body["text"]): p["text"] = body["text"].strip(); p["edited"] = True
            elif op == "delete":
                P["prefs"].remove(p); P["dismissed"].append(p["text"])      # never proposed again
            save_prefs(P)
    return api_state()

def prefs_text():
    """the approved preferences, for every first version, chat and agent prompt (added to studio.rules_text)"""
    A = [p for p in load_prefs()["prefs"] if p.get("status") == "approved"]
    return ("\nWHAT THE CREATOR PREFERS (learned from their own finished edits and approved by them; follow these):\n" +
            "\n".join("- " + p["text"] for p in A) +
            "\n(When one of these sets the music level, a first version also returns it as \"music_db\": <number> in its JSON.)\n") if A else ""

# ---------------------------------------------------------------- command line
def main(a):
    if not a or a[0] == "list":
        P = load_prefs()
        print(f"{len(videos())} video(s) with finished edits; {len(history())} diff(s) in {HISTORY}")
        for p in P["prefs"]: print(f"  [{p['status']}] {p['text']}\n      {p.get('evidence','')}")
        if P["dismissed"]: print("  dismissed:", *P["dismissed"], sep="\n    ")
    elif a[0] == "diff":
        job = a[1]; cur = _read(PROJECTS/job/"edit/timeline.json", {})
        name = a[2] if len(a) > 2 else next((v.get("name") for v in cur.get("VARS") or [] if v.get("id") == cur.get("VACT")), "Original")
        v = next((v for v in cur.get("VARS") or [] if v.get("name") == name), None)
        st = cur if not v or v.get("id") == cur.get("VACT") or not v.get("data") else v["data"]
        first = snapshot(job)
        if not first: sys.exit(f"{job} has no first version saved (edit/first_pass.json)")
        d = diff(job, first, version_state(st), name, "by hand"); print(digest(d))
    elif a[0] == "summarise":
        print(summarise())
    else:
        sys.exit(__doc__)

if __name__ == "__main__": main(sys.argv[1:])
