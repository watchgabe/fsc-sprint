# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
"""plat.py — everything that differs between a Mac and a Windows PC, in one place (2026-10-23).

The rest of CineYap calls these and never asks which machine it is on. On a Mac every function does exactly what the code
did before this file existed (osascript pickers, open -R, pgrep / killall, system_profiler, fcntl). On Windows the same jobs
go through PowerShell, Explorer, tasklist / taskkill, the Fonts folders and msvcrt. Windows runs the package from Git Bash
(install.sh), the same way Startup Mom's Reels Editing Engine does; nothing here needs WSL or an administrator account.

Standard library only: the Studio's server imports this.
"""
import json, os, pathlib, shutil, subprocess, sys

IS_WIN = os.name == "nt"
PKG = pathlib.Path(__file__).resolve().parent.parent
# a venv keeps its Python in Scripts\python.exe on Windows, bin/python everywhere else
PY = PKG/".venv"/("Scripts/python.exe" if IS_WIN else "bin/python")
NPX = "npx.cmd" if IS_WIN else "npx"        # Windows can't start a .cmd by its bare name without a shell
# Node itself (the grade engine writes the export's .cube with it): on PATH when the Studio starts it, else install.sh's own copy
NODE = shutil.which("node") or str(PKG/"_local"/("node/node.exe" if IS_WIN else "bin/node"))
CAPCUT = "CapCut.exe" if IS_WIN else "CapCut"
# H.264 on the machine's video chip. A Mac has VideoToolbox; on Windows the software encoder is the one that is always there
H264_HW = None if IS_WIN else "h264_videotoolbox"


def utf8_env(env=None):
    """Windows Python reads and writes text in the old code page unless told otherwise, and a caption with a curly quote or an
    accent then crashes a build. Every Loop process gets UTF-8 mode (the launcher sets it for the Studio itself)"""
    env = dict(os.environ if env is None else env)
    env["PYTHONUTF8"] = "1"; env["PYTHONIOENCODING"] = "utf-8"
    return env


# ------------------------------------------------------------------ pickers (the Mac's own windows, or Windows' own)
_PSARGS = ["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command"]
_WARM = None      # a PowerShell already started with the dialogs loaded, waiting for one script on stdin
_WARM_LOOP = ("Add-Type -AssemblyName System.Windows.Forms;[System.Windows.Forms.Application]::EnableVisualStyles();"
              "$s=[Console]::In.ReadLine();if($s){Invoke-Expression ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($s)));"
              "[Console]::Out.Write([char]10+'<<LOOP-OK>>')}")


def warm_pickers():
    """Windows: start PowerShell ahead of time, so a click on Choose opens the dialog at once (a cold PowerShell plus the
    Forms library took a second or two: a tester, 2026-10-24). The Studio calls this at start and after every dialog"""
    global _WARM
    if not IS_WIN or (_WARM and _WARM.poll() is None): return
    try: _WARM = subprocess.Popen(_PSARGS + [_WARM_LOOP], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                  text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError: _WARM = None


def _ps(script):
    """run a PowerShell snippet in a single-threaded apartment (the file dialogs need it) and return what it printed"""
    global _WARM
    w, _WARM = _WARM, None
    if w and w.poll() is None:
        import base64
        try:
            out, _ = w.communicate(base64.b64encode(script.encode("utf-8")).decode() + "\n", timeout=3600)
            threading_warm()
            if out and out.rstrip().endswith("<<LOOP-OK>>"): return out.rstrip()[:-len("<<LOOP-OK>>")].strip()
        except Exception:
            try: w.kill()
            except Exception: pass
    r = subprocess.run(_PSARGS + [script], capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))      # the cold way, if the warm one is gone
    if IS_WIN: threading_warm()
    return r.stdout.strip()


def threading_warm():
    import threading
    threading.Thread(target=warm_pickers, daemon=True).start()


def _q(s):
    return "'" + str(s).replace("'", "''") + "'"      # a PowerShell single-quoted string


# the dialogs open on top of the browser: a hidden topmost form is their owner, or Windows can put them behind it
_OWNER = ("Add-Type -AssemblyName System.Windows.Forms;$o=New-Object System.Windows.Forms.Form;$o.TopMost=$true;"
          "$o.ShowInTaskbar=$false;$o.WindowState='Minimized';$o.Show();$o.Hide();")


def pick_file(prompt, kinds=None):
    """one file, or "" when cancelled. kinds: "movie", "cube", or None for anything"""
    if not IS_WIN:
        of = {"movie": ' of type {"public.movie"}', "cube": ""}.get(kinds or "", "")
        r = subprocess.run(["osascript", "-e", f'POSIX path of (choose file with prompt "{prompt}"{of})'], capture_output=True, text=True)
        return r.stdout.strip()
    flt = {"movie": "Videos|*.mp4;*.mov;*.m4v;*.mkv;*.avi;*.mts;*.mxf|All files|*.*", "cube": "LUT|*.cube|All files|*.*"}.get(kinds or "", "All files|*.*")
    return _ps(_OWNER + f"$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title={_q(prompt)};$d.Filter={_q(flt)};"
               "if($d.ShowDialog($o) -eq 'OK'){[Console]::Out.Write($d.FileName)}").replace("\\", "/")


def pick_files(prompt):
    """several videos at once, or [] when cancelled"""
    if not IS_WIN:
        r = subprocess.run(["osascript", "-e", f'set fs to (choose file with prompt "{prompt}" of type {{"public.movie"}} with multiple selections allowed)',
                            "-e", 'set out to ""', "-e", 'repeat with f in fs', "-e", 'set out to out & POSIX path of f & linefeed', "-e", 'end repeat',
                            "-e", 'return out'], capture_output=True, text=True)
        return [l for l in r.stdout.splitlines() if l.strip()]
    out = _ps(_OWNER + f"$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title={_q(prompt)};$d.Multiselect=$true;"
              "$d.Filter='Videos|*.mp4;*.mov;*.m4v;*.mkv;*.avi;*.mts;*.mxf|All files|*.*';"
              "if($d.ShowDialog($o) -eq 'OK'){[Console]::Out.Write(($d.FileNames -join \"`n\"))}")
    return [l.strip().replace("\\", "/") for l in out.splitlines() if l.strip()]


def pick_folder(prompt):
    """a folder, or "" when cancelled (a Mac answer ends in "/", like osascript's)"""
    if not IS_WIN:
        r = subprocess.run(["osascript", "-e", f'POSIX path of (choose folder with prompt "{prompt}")'], capture_output=True, text=True)
        return r.stdout.strip()
    p = _ps(_OWNER + f"$d=New-Object System.Windows.Forms.FolderBrowserDialog;$d.Description={_q(prompt)};$d.ShowNewFolderButton=$true;"
            "if($d.ShowDialog($o) -eq 'OK'){[Console]::Out.Write($d.SelectedPath)}")
    return (p.replace("\\", "/").rstrip("/") + "/") if p else ""


def save_file(prompt, default_name):
    """where to save a new file, or "" when cancelled"""
    if not IS_WIN:
        r = subprocess.run(["osascript", "-e", f'POSIX path of (choose file name with prompt "{prompt}" default name "{default_name}")'],
                           capture_output=True, text=True)
        return r.stdout.strip()
    ext = pathlib.Path(default_name).suffix.lstrip(".") or "*"
    return _ps(_OWNER + f"$d=New-Object System.Windows.Forms.SaveFileDialog;$d.Title={_q(prompt)};$d.FileName={_q(default_name)};"
               f"$d.Filter={_q(ext.upper() + '|*.' + ext)};if($d.ShowDialog($o) -eq 'OK'){{[Console]::Out.Write($d.FileName)}}").replace("\\", "/")


def alert(title, msg):
    if IS_WIN:
        _ps(f"Add-Type -AssemblyName System.Windows.Forms;[System.Windows.Forms.MessageBox]::Show({_q(msg)},{_q(title)})|Out-Null")
    else:
        m = msg.replace('"', "'")
        subprocess.run(["osascript", "-e", f'display dialog "{m}" buttons {{"OK"}} default button 1 with title "{title}"'], capture_output=True)


# ------------------------------------------------------------------ Finder / Explorer, the browser
def reveal(path):
    """show a file or folder selected in Finder (Explorer on Windows)"""
    if IS_WIN:
        subprocess.Popen(["explorer", "/select," + str(pathlib.Path(path))])
    else:
        subprocess.run(["open", "-R", str(path)])


def open_url(url):
    if IS_WIN:
        os.startfile(url)
    else:
        subprocess.Popen(["open", url])


# ------------------------------------------------------------------ other apps (CapCut)
def app_running(name=CAPCUT):
    if IS_WIN:
        r = subprocess.run(["tasklist", "/FI", f"IMAGENAME eq {name}", "/NH"], capture_output=True, text=True,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return name.lower() in r.stdout.lower()
    return subprocess.run(["pgrep", "-x", name], capture_output=True).returncode == 0


def quit_app(name=CAPCUT, force=False):
    """ask an app to quit (it saves first), or force it. Windows: taskkill without /F sends the close message"""
    if IS_WIN:
        subprocess.run(["taskkill", "/IM", name] + (["/F"] if force else []), capture_output=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    elif force:
        subprocess.run(["killall", name], capture_output=True)
    else:
        subprocess.run(["osascript", "-e", f'tell application "{name}" to quit'], capture_output=True)


def capcut_drafts():
    """CapCut's own folder of drafts, where its home screen looks"""
    if IS_WIN:
        return pathlib.Path(os.environ.get("LOCALAPPDATA", pathlib.Path.home()/"AppData/Local"))/"CapCut/User Data/Projects/com.lveditor.draft"
    return pathlib.Path.home()/"Movies/CapCut/User Data/Projects/com.lveditor.draft"


def claude_candidates():
    """the usual places Claude Code is installed, beyond PATH"""
    h = pathlib.Path.home()
    if IS_WIN:
        return [h/".local/bin/claude.exe", pathlib.Path(os.environ.get("APPDATA", h/"AppData/Roaming"))/"npm/claude.cmd",
                h/".claude/local/claude.exe"]
    return [h/".local/bin/claude", h/".claude/local/claude", pathlib.Path("/opt/homebrew/bin/claude"), pathlib.Path("/usr/local/bin/claude")]


def bash():
    """the shell the package's .sh scripts run in. Windows: Git Bash, never System32\\bash.exe (that one is WSL's)"""
    if not IS_WIN:
        return "bash"
    h = pathlib.Path.home()
    for d in (os.environ.get("ProgramFiles", "C:/Program Files"), os.environ.get("ProgramFiles(x86)", ""),
              str(pathlib.Path(os.environ.get("LOCALAPPDATA", h/"AppData/Local"))/"Programs")):
        b = pathlib.Path(d)/"Git/bin/bash.exe" if d else None
        if b and b.exists():
            return str(b)
    w = shutil.which("bash")
    return w if w and "system32" not in w.lower() else "bash"


def desktop():
    """the Desktop folder (on Windows OneDrive often moves it, so ask Windows where it is)"""
    if IS_WIN:
        d = _ps("[Console]::Out.Write([Environment]::GetFolderPath('Desktop'))")
        if d and pathlib.Path(d).is_dir():
            return pathlib.Path(d)
    return pathlib.Path.home()/"Desktop"


def link_or_copy(src, dst):
    """a symlink on a Mac; Windows only makes symlinks for administrators (or with Developer Mode), so it gets a copy"""
    dst = pathlib.Path(dst)
    if IS_WIN:
        shutil.copy2(src, dst)
    else:
        os.symlink(src, dst)


# ------------------------------------------------------------------ fonts installed on this machine
def font_files():
    """[{path, family, style, full, ps}] for every font file the machine has. Mac: system_profiler (as before). Windows: the
    system and per-user Fonts folders, named from the files themselves"""
    out = []
    if not IS_WIN:
        try:
            raw = json.loads(subprocess.run(["system_profiler", "SPFontsDataType", "-json"], capture_output=True, text=True, timeout=180).stdout)
        except Exception:
            return out
        for f in raw.get("SPFontsDataType", []):
            if f.get("enabled") == "no":
                continue
            for t in f.get("typefaces", []):
                if t.get("enabled") == "no":
                    continue
                out.append({"path": f.get("path", ""), "family": t.get("family") or "", "style": t.get("style") or "Regular",
                            "full": t.get("fullname") or t.get("_name") or "", "ps": t.get("_name") or ""})
        return out
    try:
        from PIL import ImageFont
    except ImportError:
        return out
    dirs = [pathlib.Path(os.environ.get("WINDIR", "C:/Windows"))/"Fonts",
            pathlib.Path(os.environ.get("LOCALAPPDATA", pathlib.Path.home()/"AppData/Local"))/"Microsoft/Windows/Fonts"]
    for d in dirs:
        for p in sorted(d.glob("*")) if d.is_dir() else []:
            if p.suffix.lower() not in (".ttf", ".otf", ".ttc"):
                continue
            for i in range(4 if p.suffix.lower() == ".ttc" else 1):
                try:
                    fam, sty = ImageFont.truetype(str(p), 12, index=i).getname()
                except Exception:
                    break
                out.append({"path": str(p), "family": fam, "style": sty or "Regular", "full": f"{fam} {sty}".strip(),
                            "ps": (fam + "-" + (sty or "Regular")).replace(" ", "")})
    return out


def user_fonts_dir():
    """where a font is installed for this user only, no administrator needed"""
    if IS_WIN:
        return pathlib.Path(os.environ.get("LOCALAPPDATA", pathlib.Path.home()/"AppData/Local"))/"Microsoft/Windows/Fonts"
    return pathlib.Path.home()/"Library/Fonts"


# ------------------------------------------------------------------ one process at a time (a lock file)
def lock(f, wait=True):
    """an exclusive lock on an open file; False when wait=False and another process holds it"""
    if IS_WIN:
        import msvcrt
        f.seek(0)
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_LOCK if wait else msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False
    import fcntl
    try:
        fcntl.flock(f, fcntl.LOCK_EX | (0 if wait else fcntl.LOCK_NB))
        return True
    except OSError:
        return False


def unlock(f):
    if IS_WIN:
        import msvcrt
        f.seek(0)
        try:
            msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass
    else:
        import fcntl
        fcntl.flock(f, fcntl.LOCK_UN)


# ------------------------------------------------------------------ drives
def volume(p):
    """the external drive a path lives on, or None for the computer's own disk. Mac: /Volumes/<name>. Windows: a drive letter
    other than the one Windows is on (D:, E:)"""
    s = str(p).replace("\\", "/")
    if IS_WIN:
        if len(s) > 1 and s[1] == ":":
            d = s[0].upper() + ":"
            return None if d == os.environ.get("SystemDrive", "C:").upper() else d
        return None
    parts = pathlib.PurePosixPath(s).parts
    return parts[2] if len(parts) > 2 and parts[1] == "Volumes" else None


def volume_root(v):
    return pathlib.Path(v + "/") if IS_WIN else pathlib.Path("/Volumes")/v


def web_paths(o):
    """paths going to the browser use forward slashes, the way the editor splits them (Windows writes C:\\Users\\..."""
    if not IS_WIN:
        return o
    if isinstance(o, str):
        return o.replace("\\", "/") if len(o) > 2 and o[1] == ":" and o[2] == "\\" else o
    if isinstance(o, list):
        return [web_paths(x) for x in o]
    if isinstance(o, dict):
        return {(web_paths(k) if isinstance(k, str) else k): web_paths(v) for k, v in o.items()}
    return o
