#!/usr/bin/env python3
# Copyright (c) 2026 Gabe Harris. All rights reserved. Proprietary: see LICENSE.
"""timeline_tools.py — what the Studio's timeline editor needs from the raw take, and its export.

    ./vu-py cineyap/timeline_tools.py prep <job>            -> edit/proxy.mp4, edit/faces_src.json, edit/peaks_src.json
    ./vu-py cineyap/timeline_tools.py export <job> <fmt> [--4k] [--out <file>]
                                                             -> exports/<job>-<fmt>.mp4, rendered from edit/timeline.json
    ./vu-py cineyap/timeline_tools.py xml <job> <fmt>       -> exports/<job>-<fmt>.xml for Premiere (after an export)

Everything here is measured on the RAW TAKE's own clock (source seconds), never on the cut, so the editor can
re-cut the A-roll freely and the face track and waveform stay right.

  proxy.mp4       1080p 8-bit copy of the raw take. Browsers cannot play the camera's 4K 10-bit 4:2:2 files.
  faces_src.json  {"rate": 2, "s": [[t, eye_x, eye_y], ...]}  where the subject's eyes are (fractions of the frame).
                  The vertical and 4:3 views centre each A-roll piece on its median eye_x.
  peaks_src.json  {"rate": 50, "p": [0-255, ...]}  loudness per 20 ms, drawn as the A-roll waveform.

The export (Gabe, 2026-10-20) is built in three layers so the file matches the editor's preview:
  1. ffmpeg   the A-roll pieces cut from the raw take at full quality, reframed for the format, with the shot moves,
              then the B-roll over it
  2. HyperFrames  the screens (colour plates) and captions, from the same CSS the preview uses, as a transparent layer
  3. ffmpeg   the effects (transparent WebMs) on top, then the audio: the A-roll's own sound with soft cuts, the music
              bed ducked 14 dB under the voice while talking, the sound effects, loudness to -14 LUFS
"""
import json, math, os, pathlib, re, shutil, subprocess, sys, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from _root import PKG, PROJECTS
import plat
import tlmigrate      # timeline.json key fixes, the same the editor runs (X4)
import hdr            # HLG/PQ takes tone-mapped to SDR, as the A-roll page does (R12)
HW264 = plat.H264_HW or "libx264"      # the video chip on a Mac; the software encoder on Windows

FPS_NUM, FPS_DEN = 24000, 1001
FORMATS = {"169": (1920, 1080), "43": (1440, 1080), "916": (1080, 1920), "34": (1080, 1440)}
BASIS = {"169": 1920, "43": 1440, "916": 1080, "34": 1080}          # caption px sizes are authored against this width
GREEN, CREAM = "#091A14", "#F5F0EA"

def run(cmd, **kw):
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, **kw)
    if r.returncode: raise RuntimeError(f"{pathlib.Path(str(cmd[0])).name} failed: {(r.stderr or r.stdout)[-900:]}")
    return r.stdout

def venc(k4):
    """the final encode on the Mac's video engine (2026-10-23): several times faster than x264 "slow", same look on Instagram.
    CINEYAP_X264=1 goes back to the software encoder"""
    if os.environ.get("CINEYAP_X264") or not plat.H264_HW: return ["-c:v", "libx264", "-preset", "slow", "-crf", "18" if k4 else "16", "-pix_fmt", "yuv420p"]
    return ["-c:v", "h264_videotoolbox", "-profile:v", "high", "-b:v", "35M" if k4 else "10M", "-maxrate", "55M" if k4 else "16M", "-bufsize", "70M" if k4 else "20M", "-pix_fmt", "yuv420p"]

def run_enc(cmd, k4):
    """run an ffmpeg command whose video encoder is venc(); if the hardware encoder refuses, the same command with x264"""
    try: return run(cmd)
    except RuntimeError as e:
        if "h264_videotoolbox" not in [str(c) for c in cmd]: raise
        print(f"  the Mac's encoder said no ({str(e)[-120:].strip()}); using the software encoder", flush=True)
        c = [str(x) for x in cmd]; i = c.index("-c:v"); j = c.index("-pix_fmt", i)
        return run(c[:i] + ["-c:v", "libx264", "-preset", "medium", "-crf", "18" if k4 else "16"] + c[j:])

def prores(profile="2"):
    """an in-between ProRes file: the hardware encoder when it's there (2026-10-23), the software one otherwise"""
    return ["-c:v", "prores_videotoolbox", "-profile:v", {"2": "standard", "3": "hq"}.get(profile, "standard")] if not (os.environ.get("CINEYAP_X264") or plat.IS_WIN) else ["-c:v", "prores_ks", "-profile:v", profile]

def source_of(J):
    edl = json.loads((J/"edit/edl.json").read_text())
    stem, path = next(iter(edl["sources"].items()))
    return stem, pathlib.Path(path)

# ------------------------------------------------------------------ prep
def prep(job):
    J = PROJECTS/job; E = J/"edit"; stem, src = source_of(J)
    proxy = E/"proxy.mp4"
    if not proxy.exists():
        print("making the 1080p proxy of the raw take", flush=True)
        run(["ffmpeg", "-v", "error", "-y", "-i", src, "-vf", hdr.sdr_vf(src, "scale='if(gt(iw,ih),1920,-2)':'if(gt(iw,ih),-2,1920)',format=yuv420p"), "-c:v", HW264,
             "-b:v", "8M", "-g", "24", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", proxy])
    if not (E/"peaks_src.json").exists():
        print("measuring the waveform", flush=True)
        raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(proxy), "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "-"],
                             capture_output=True).stdout
        import array
        a = array.array("h", raw); step = 160            # 20 ms at 8 kHz
        peaks = []
        for i in range(0, len(a), step):
            chunk = a[i:i + step]
            rms = math.sqrt(sum(x * x for x in chunk) / max(1, len(chunk))) / 32768
            db = 20 * math.log10(rms) if rms > 0 else -90
            peaks.append(max(0, min(255, int((db + 60) / 60 * 255))))   # -60..0 dBFS -> 0..255
        (E/"peaks_src.json").write_text(json.dumps({"rate": 50, "p": peaks}, separators=(",", ":")))
    if not (E/"faces_src.json").exists():
        print("finding your face across the take", flush=True)
        import numpy as np, cv2
        model = PKG/"cineyap/models/face_detection_yunet_2023mar.onnx"
        pw, ph = (int(x) for x in run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                                             "-of", "csv=p=0", proxy]).strip().split(",")[:2])      # ffprobe 9 adds a trailing comma (a tester, 2026-10-23)
        W, H, RATE = (640, 360, 2.0) if pw >= ph else (360, 640, 2.0)
        det = cv2.FaceDetectorYN.create(str(model), "", (W, H), 0.7)
        p = subprocess.Popen(["ffmpeg", "-v", "error", "-i", str(proxy), "-vf", f"fps={RATE},scale={W}:{H}", "-f", "rawvideo",
                              "-pix_fmt", "bgr24", "-"], stdout=subprocess.PIPE)
        out, n = [], 0
        while True:
            buf = p.stdout.read(W * H * 3)
            if len(buf) < W * H * 3: break
            t = round(n / RATE, 2); n += 1
            _, faces = det.detect(np.frombuffer(buf, np.uint8).reshape(H, W, 3))
            if faces is None or not len(faces): continue
            fc = max(faces, key=lambda r: r[2] * r[3])
            out.append([t, round(float((fc[4] + fc[6]) / 2 / W), 4), round(float((fc[5] + fc[7]) / 2 / H), 4)])
        p.wait()
        (E/"faces_src.json").write_text(json.dumps({"rate": RATE, "s": out}, separators=(",", ":")))
        print(f"  face found in {len(out)} of {n} samples", flush=True)
    print("ready", flush=True)

# ------------------------------------------------------------------ the timeline, laid out the way the editor lays it out
TL_FILE = None      # --tl: export one variation, written by the Studio to edit/variants/<slug>.json
SUFFIX = ""         # --suffix: that variation's name on the output files
NOXML = False      # --noxml: no Premiere XML beside the MP4 (the export dialog's switch)

def key100(x):
    """a time as the editor keys it: JavaScript's Math.round(x*100). Python's round() takes .5 to even, so a word at 157.125s
    was 15712 here and 15713 in the editor, and its caption edit never reached the export (2026-10-23)"""
    return int(math.floor(x * 100 + .5))

def load(job, fmt=None):
    J = PROJECTS/job; st = tlmigrate.migrate(json.loads((pathlib.Path(TL_FILE) if TL_FILE else J/"edit/timeline.json").read_text()))      # the editor's key fixes, the same on this side
    t = 0.0
    fps = FPS_NUM / FPS_DEN
    for i, s in enumerate(st["SEGS"]):
        s["n"] = i + 1; s["t0"] = t; t += s["src_out"] - s["src_in"]; s["t1"] = t
        # 2026-10-20: rounding each piece up on its own drifted the picture 0.4s late of the sound over 19 cuts.
        # Round the timeline's cut points to frames instead: the error stays under half a frame at every cut.
        s["nf"] = int(round(s["t1"] * fps)) - int(round(s["t0"] * fps))
    st["DUR"] = t
    tr = json.loads((J/"edit/transcripts"/(source_of(J)[0] + ".json")).read_text())
    srcw = [(w["start"], w["end"], w["text"]) for w in tr["words"] if w.get("type") == "word"]
    words = []
    for s in st["SEGS"]:
        for a, b, x in srcw:
            if s["src_in"] - .02 <= a < s["src_out"] - .02:
                words.append([s["t0"] + a - s["src_in"], min(s["t1"], s["t0"] + b - s["src_in"]), x, key100(a)])
    st["WORDS"] = words
    one_clock(st, fps)
    # a split matte is one block on the timeline, two colours in the picture: first half, second half
    bg = []
    for g in st.get("BG", []):
        if g.get("split"):
            m = g.get("mid") if g.get("mid") is not None else (g["t0"] + g["t1"]) / 2      # the split point (rolling edit)
            m = max(g["t0"] + .1, min(g["t1"] - .1, m))
            st2 = {k: v for k, v in (g.get("st") or {}).items() if k != "bg"}      # a split's own Background is its first color
            bg += [dict(g, t1=m, split=None), dict(g, t0=m, screen=g["split"], split=None, st=st2)]
        else: bg.append(g)
    # YapMaxxing (2026-10-22): over a screen with "panel" on (9:16 only), a B-roll block plays INSIDE the box above your head, so the
    # screen under it stays up (the editor's panelOn). Decided before the mattes are trimmed below.
    def under(t):
        g = at(bg, t)
        return scr(st, g["screen"]) if g else seg_scr(st, at(st.get("SEGS", []), t))
    # the layout lives on the B-roll block (2026-10-22): "lay" = full | wide | three | two | five. Older videos kept it on a screen
    # (a "panel" switch, or Three/Two/Five on the Matte track): converted here the same way the editor converts them on open
    if any(S.get("panel") for S in st["SCREENS"]):
        for b in st.get("BR", []):
            if not b.get("lay"):
                L = under((b["t0"] + b["t1"]) / 2).get("panel")
                if L: b["lay"] = "wide" if L is True else L
        gone = [S["id"] for S in st["SCREENS"] if re.match(r"^ym[325]$", S["id"])]
        bg = [g for g in bg if g["screen"] not in gone]
    for b in st.get("BR", []):
        L = b.get("lay") if fmt == "916" and st.get("KIND") != "carousel" else None
        b["inpanel"] = L if L and L != "full" else False      # the layout name: wide | three | two | five
        if b["inpanel"]:      # boxes moved, resized or added in the editor live on the layout screen (2026-10-23)
            Sb = next((x for x in st["SCREENS"] if x["id"] == (b.get("scr") or "broll")), None)
            if Sb and Sb.get("rects"): b["inrects"] = [(float(r["x"]), float(r["y"]), float(r["w"]), float(r["h"])) for r in Sb["rects"]]; b["inshapes"] = [r.get("shape") for r in Sb["rects"]]; b["inrads"] = [r.get("rad") for r in Sb["rects"]]
            if Sb and Sb.get("fill"): b["infill"] = str(Sb["fill"])
            if Sb and Sb.get("bfull"): b["inbfull"] = True      # a full-screen clip behind the frames: frame j holds pics[j]      # the layout's own background color behind its boxes (none: see through to what's under it)
    for g in bg:      # a color screen behind a box is drawn under the picture (step 2), so it can't cover the box
        g["inpic"] = any(b["inpanel"] and b["t0"] < g["t1"] and b["t1"] > g["t0"] for b in st.get("BR", []))
    if st.get("SCREENS") and not any(x.get("id") == "broll" for x in st["SCREENS"]):      # every video has a B-roll screen (the editor's ensureBroll)
        a = next((x for x in st["SCREENS"] if x.get("id") == "aroll"), st["SCREENS"][0])
        st["SCREENS"].insert(1, {**{k: v for k, v in a.items() if k not in ("px", "py", "rot", "sc", "punch", "behind", "panel", "bgc")}, "id": "broll", "name": "B-roll", "kind": "broll"})
    st["PANELT"] = st.get("PANELT") or {}
    # the Text Hook (its own track since 2026-10-22); older videos kept the title on the panel (PANELT)
    st["HOOKST"] = {"font": "h", "size": 72, "color": "#FFFFFF", "subc": "#F5D90A", "subsize": 37, "y": 31.5, "shadow": 45, **(st.get("HOOKST") or {})}
    if not st.get("HK") and st["PANELT"].get("title"):
        st["HK"] = [{"hook": True, "t0": 0, "t1": float(st["PANELT"].get("secs") or 6), "title": st["PANELT"]["title"], "sub": st["PANELT"].get("sub") or ""}]
    # text boxes (2026-10-22): a box holds lines, each with its own look; the box owns where it sits. Older pieces (title + sub with one
    # look, or none: the video's HOOKST) become a box the same way the editor's tbFix() does it
    LINEK = ("font", "size", "color", "kase", "b", "it", "ls", "shadow", "olw", "olc"); BOXK = ("v", "h", "ox", "oy", "wbox", "ta", "box", "boxc", "boxr", "boxp")
    for h in st.get("HK") or []:
        if h.get("lines") or not fmt: continue
        H = st["HOOKST"]; asp = FORMATS[fmt][0] / FORMATS[fmt][1]
        S = h.get("st") or {"font": H.get("font", "h"), "size": H.get("size", 72), "color": H.get("color", "#FFFFFF"), "shadow": H.get("shadow", 45), "v": "top", "h": "center", "ox": 0,
                             "oy": (float(H.get("y") or 31.5) - 18) / 100 * BASIS[fmt] / asp, "subc": H.get("subc"), "subsize": H.get("subsize"),
                             **{k: H[k] for k in ("olw", "olc", "box", "boxc", "boxr", "boxp", "wbox", "b", "it") if H.get(k) is not None}}
        L1 = {"font": "h", "size": 72, "color": "#FFFFFF", "shadow": 45, **{k: S[k] for k in LINEK if S.get(k) is not None}}
        h["lines"] = [{"text": h.get("title") or "", "st": L1}] + ([{"text": h["sub"], "st": {**L1, "size": float(S.get("subsize") or 37), "color": S.get("subc") or L1["color"]}}] if h.get("sub") else [])
        h["st"] = {"v": "top", "h": "center", "ox": 0, "oy": (31.5 - 18) / 100 * BASIS[fmt] / asp, **{k: S[k] for k in BOXK if S.get(k) is not None}}
    # text LAYERS (2026-10-22, night): every line has its own place. A box's lines become layers where they sat in it (the editor's tbFix)
    for h in st.get("HK") or []:
        if h.get("v") == 2 or not h.get("lines"): continue
        B = {"v": "top", "h": "center", "ox": 0, "oy": 0, **(h.get("st") or {})}
        def lh_(S, text=""): return float(S.get("size") or 72) * float(S.get("lh") or 108) / 100 * wrap_n(S, text, B.get("wbox"), fmt)
        vis = [l for l in h["lines"] if not l.get("hide")]; acc = -sum(lh_({"size": 72, **(l.get("st") or {})}, l.get("text") or "") for l in vis) / 2
        for l in h["lines"]:
            S = {"font": "h", "size": 72, "color": "#FFFFFF", "shadow": 45, **(l.get("st") or {})}; hh = lh_(S, l.get("text") or "")
            S.update(v=B.get("v") or "top", h=B.get("h") or "center", ox=float(B.get("ox") or 0), oy=round(float(B.get("oy") or 0) + (0 if l.get("hide") else acc + hh / 2)))
            for k in ("wbox", "ta"):
                if B.get(k): S[k] = B[k]
            if B.get("box"): S["box"] = True; S.update({k: B[k] for k in ("boxc", "boxr", "boxp") if B.get(k) is not None})
            l["st"] = S
            if not l.get("hide"): acc += hh
        h.pop("st", None); h["v"] = 2
    # the higher track wins (Gabe, 2026-10-21): B-roll sits above Matte, so a matte only shows where no B-roll covers it
    for b in [b for b in st.get("BR", []) if not b.get("inpanel")]:
        nb = []
        for g in bg:
            if b["t1"] <= g["t0"] + 1e-4 or b["t0"] >= g["t1"] - 1e-4: nb.append(g); continue
            if b["t0"] - g["t0"] > 1e-3: nb.append(dict(g, t1=b["t0"]))
            if g["t1"] - b["t1"] > 1e-3: nb.append(dict(g, t0=b["t1"]))
        bg = nb
    st["BG"] = bg
    st["FRAMES"] = frame_spans(st)
    faces = J/"edit/faces_src.json"
    st["FACES"] = json.loads(faces.read_text())["s"] if faces.exists() else []
    return st

def one_clock(st, fps, snap_frames=6):
    """THE ONE-CLOCK RULE in the export (CLAUDE.md 9c; 2026-10-25, Gabe found single frames of A-roll flashing at B-roll edges).
    Each A-roll piece is cut on a whole frame (round(t * fps)); a B-roll, matte or text edge was shown from the first frame AFTER its
    exact time. So where both sat on one time they could land a frame apart, and a B-roll ending a frame short of a cut showed
    one frame of the old piece. Every edge now sits half a frame before the frame it starts on (the same clock the picture is cut
    on), and a B-roll / matte / text edge within `snap_frames` of an A-roll cut lands ON that cut (the cut guard). Flashes and
    other effects keep their own timing (a flash straddles its cut on purpose), only moved onto the frame grid."""
    def q(x):
        x = float(x)
        return 0.0 if x <= 1e-6 else (round(x * fps) - .5) / fps
    end = st["DUR"]
    for s in st["SEGS"]:
        s["t0"] = q(s["t0"]); s["t1"] = end if s is st["SEGS"][-1] else q(s["t1"])
    cuts = [s["t0"] for s in st["SEGS"][1:]]
    tol = snap_frames / fps + 1e-6
    # only ever EXTEND to cover a cut that would show (the editor's cutGuard): a start up to snap_frames AFTER a cut goes back to
    # it, an end that much BEFORE one runs on to it; an edge that already covers its cut stays (and so does a flash timed on it)
    def start_to(x):
        c = [q_ for q_ in cuts if q_ < x - 1e-4 and x - q_ <= tol]; return max(c) if c else None
    def end_to(x):
        c = [q_ for q_ in cuts if q_ > x + 1e-4 and q_ - x <= tol]; return min(c) if c else None
    moved = []
    for L in ("BR", "BG", "HK"):
        Ls = sorted(st.get(L, []) or [], key=lambda o: o["t0"])
        for i, o in enumerate(Ls):
            pv, nx = (Ls[i - 1] if i else None), (Ls[i + 1] if i + 1 < len(Ls) else None)
            a = start_to(o["t0"]) if o["t0"] > 1e-6 else None; z = end_to(o["t1"]) if o["t1"] < end - 1e-6 else None
            if a is not None and pv and a < pv["t1"] - 1e-4: a = None
            if z is not None and nx and z > nx["t0"] + 1e-4: z = None
            if a is not None and (o.get("clip") or o.get("file")) and float(o.get("in") or 0) + (a - o["t0"]) < -1e-4: a = None
            if a is not None:
                moved.append((o["t0"], a - o["t0"]))
                if o.get("clip") or o.get("file"): o["in"] = max(0.0, float(o.get("in") or 0) + (a - o["t0"]))
                o["t0"] = a
            if z is not None: moved.append((o["t1"], z - o["t1"])); o["t1"] = z
    # no sliver between two B-roll clips (or two mattes) either: a gap under snap_frames closes, the first runs on to the next
    for L in ("BR", "BG"):
        Ls = sorted(st.get(L, []) or [], key=lambda o: o["t0"])
        for a_, b_ in zip(Ls, Ls[1:]):
            g = b_["t0"] - a_["t1"]
            if 1e-4 < g <= tol: moved.append((a_["t1"], g)); a_["t1"] = b_["t0"]
    for x, dlt in moved:      # a flash sitting on an edge that moved goes with it (and its click)
        for f in st.get("FX", []) or []:
            if f.get("_cg") or not (f.get("builtin") == "flash" or f.get("blend") == "screen" or "flash" in (f.get("name") or "").lower()): continue
            if abs(f["t0"] - x) <= .3 or f["t0"] <= x <= f["t1"]:
                f["t0"] += dlt; f["t1"] += dlt; f["_cg"] = 1
                for c in st.get("SFX", []) or []:
                    if f.get("link") and c.get("link") == f["link"]: c["t0"] += dlt; c["t1"] = c.get("t1", c["t0"]) + dlt
    for f in st.get("FX", []) or []: f.pop("_cg", None)
    for L in ("BR", "BG", "HK"):      # then everything onto the frame grid
        for o in st.get(L, []) or []:
            o["t0"] = q(o["t0"]) if o["t0"] not in cuts else o["t0"]; o["t1"] = (o["t1"] if o["t1"] in cuts or o["t1"] >= end - 1e-6 else q(o["t1"]))
            if o.get("mid") is not None: o["mid"] = q(o["mid"])
    for L in ("FX", "MOVES"):
        for o in st.get(L, []) or []:
            o["t0"] = q(o["t0"]); o["t1"] = min(end, q(o["t1"])) if o["t1"] < end - 1e-6 else end
    for L in ("BR", "BG", "HK", "FX", "MOVES"):      # an edge that snapped onto the other one leaves nothing: drop it
        st[L] = [o for o in st.get(L, []) or [] if o["t1"] - o["t0"] > .5 / fps]

def at(L, t):
    for o in L:
        if o["t0"] <= t < o["t1"]: return o
    return None

def scr(st, sid):
    return next((s for s in st["SCREENS"] if s["id"] == sid), None) or next((s for s in st["SCREENS"] if s["id"] == "aroll"), st["SCREENS"][0])      # not found: A-roll, wherever its pill is

def seg_scr(st, sg):
    """an A-roll piece's own screen ("scr", 2026-10-23: swapping a piece to "A-roll 2" puts it on the piece), else the A-roll screen"""
    if sg and sg.get("scr") and any(x["id"] == sg["scr"] for x in st["SCREENS"]): return scr(st, sg["scr"])
    return scr(st, "aroll")

def same_screen(X, S):
    """the same screen with the same effective settings (R14: own() builds a new dict each call, so `is not` was always true)"""
    return X is S or (bool(X) and bool(S) and X.get("id") == S.get("id") and X == S)

def screen_at(st, t):
    """the screen up at t, with that clip's own settings (Edit Selected Clip) on top"""
    def own(S, o):
        if not (o and o.get("st")): return S
        X = {**S, **o["st"]}
        if X.get("punchOn") is True: X["punch"] = float(S.get("punch") or S.get("_lastPunch") or .15)      # the clip switches Punch-in, the screen sets how much (2026-10-23)
        elif X.get("punchOn") is False: X.pop("punch", None)
        if X.get("punch") and X.get("punchAmt"): X["punch"] = float(X["punchAmt"])      # this clip's own amount (2026-10-24)
        return X
    b = at(st.get("BR", []), t)      # B-roll is above Matte: it wins (load() also trims the mattes under it)
    if b: return own(next((x for x in st["SCREENS"] if x["id"] == b.get("scr")), None) or scr(st, "broll"), b)      # frames or full: the block's own screen (2026-10-24, as the editor)      # a block can use another B-roll screen (2026-10-23)      # in a YapMaxxing box it doesn't change the screen
    g = at(st.get("BG", []), t)
    if g: return own(scr(st, g["screen"]), g)
    sg = at(st.get("SEGS", []), t); return own(seg_scr(st, sg), sg)

def shape_mask(D, w, h, shape, rad=None):
    """a white shape on black, w x h: a frame's rounded corners or circle (2026-10-23). Rounded = rad % of the shorter side (default 12),
    as in the editor (the Corners control, 2026-10-24)"""
    from PIL import Image, ImageDraw
    rad = 12.0 if rad is None else max(0.0, min(50.0, float(rad)))
    f = D/f"mask_{shape}_{w}x{h}_{rad:g}.png"
    if not f.exists():
        m = Image.new("L", (w, h), 0); d = ImageDraw.Draw(m)
        if shape == "circle": d.ellipse([0, 0, w - 1, h - 1], fill=255)
        else: d.rounded_rectangle([0, 0, w - 1, h - 1], radius=int(min(w, h) * rad / 100), fill=255)
        m.save(f)
    return f

def aroll_frame(graph, inputs, D, last, S, a0, b0, W, H, fps, tag, cover=None):
    """A-roll in a frame (2026-10-23, the editor's aboxS/aboxClip): the A-roll covers its box (scaled by the box's longer side), the
    screen's Transform moves and scales it inside, Punch-in zooms by its amount, cropped to the box or masked to its shape. `cover`
    first paints the whole screen (the matte, or black) so nothing of the full-size A-roll shows round the frame"""
    bx = S["abox"]; s0 = max(float(bx["w"]), float(bx["h"])); s = s0 * float(S.get("sc", 1) or 1) * (1 + float(S.get("punch", 0) or 0))
    X, Y = round(float(bx["x"]) * W / 2) * 2, round(float(bx["y"]) * H / 2) * 2
    BW, BH = max(2, round(float(bx["w"]) * W / 2) * 2), max(2, round(float(bx["h"]) * H / 2) * 2)
    sw, sh = max(BW, round(W * s / 2) * 2), max(BH, round(H * s / 2) * 2)
    ox, oy = float(S.get("px", 0) or 0) * s0 * W / 100, float(S.get("py", 0) or 0) * s0 * H / 100
    cx, cy = min(max(sw / 2 - BW / 2 - ox, 0), sw - BW), min(max(sh / 2 - BH / 2 - oy, 0), sh - BH)
    if cover:
        graph.append(f"color=c={cover}:s={W}x{H}:r={fps}:d={b0 - a0 + .5:.3f},setpts=PTS-STARTPTS+{a0:.4f}/TB[afc{tag}]")
        graph.append(f"[{last}][afc{tag}]overlay=enable='between(t,{a0:.4f},{b0:.4f})':eof_action=pass[afv{tag}]"); last = f"afv{tag}"
    inputs.append(D/"aroll.mov"); n = len(inputs) - 1
    rot = float(S.get("rot", 0) or 0)
    v = (f"[{n}:v]trim=start={a0:.4f}:end={b0 + .25:.4f},setpts=PTS-STARTPTS+{a0:.4f}/TB,scale={sw}:{sh}"
         + (f",rotate={rot * 3.14159265 / 180:.6f}:c=black" if rot else "") + f",crop={BW}:{BH}:{cx:.0f}:{cy:.0f}")
    shape = S.get("ashape")
    if shape in ("rounded", "circle"):
        inputs.append(shape_mask(D, BW, BH, shape, S.get("arad"))); mi = len(inputs) - 1
        graph.append(v + f",format=yuva420p[afp{tag}];[{mi}:v]format=gray,scale={BW}:{BH}[afm{tag}];[afp{tag}][afm{tag}]alphamerge[afa{tag}]")
    else: graph.append(v + f",format=yuv420p[afa{tag}]")
    graph.append(f"[{last}][afa{tag}]overlay=x={X}:y={Y}:enable='between(t,{a0:.4f},{b0:.4f})':eof_action=pass[afo{tag}]")
    return f"afo{tag}"

def frame_spans(st):
    """every stretch with a frame: a Frame set on the screen that's up (Screens tab), plus old Frame effect blocks"""
    fx = [o for o in st.get("FX", []) if o.get("frame")]
    end = max([s["t1"] for s in st["SEGS"]] or [0])
    pts = sorted({0.0, end, *[x for L in ("BG", "BR", "SEGS") for o in st.get(L, []) for x in (o["t0"], o["t1"])]})
    out = []
    for a, b in zip(pts, pts[1:]):
        if b - a < 1e-4 or b > end + 1e-6: continue
        m = (a + b) / 2
        if any(o["t0"] <= m < o["t1"] for o in fx): continue
        br = at(st.get("BR", []), m)
        if br and br.get("frame") and not at(st.get("BG", []), m):      # a B-roll clip's own frame (Edit Selected Clip)
            S = {"id": "clip" + str(round(br["t0"] * 1000)), "frame": br["frame"], "plate": br.get("plate", "#FFFFFF"), "border": br.get("border"), "zoom": br.get("zoom", 1)}
        else: S = screen_at(st, m)
        if not S.get("frame") or S.get("kind") == "color": continue
        f = {"t0": a, "t1": b, "frame": S["frame"], "plate": S.get("plate", "#FFFFFF"), "border": S.get("border"), "zoom": S.get("zoom", 1), "sid": f"{S['id']}|{S['frame']}|{S.get('plate')}|{S.get('border')}|{S.get('zoom')}"}
        if out and out[-1]["sid"] == f["sid"] and abs(out[-1]["t1"] - a) < 1e-4: out[-1]["t1"] = b
        else: out.append(f)
    return sorted(fx + out, key=lambda o: o["t0"])

def rule_swaps():
    """word swaps from the creator's editing rules (cineyap/rules.json): fuck -> f*ck, also inside words (unfuck -> unf*ck)"""
    try: R = json.loads((PKG/"cineyap/rules.json").read_text()).get("rules", [])
    except Exception: return []
    return [(w["from"], w["to"]) for r in R for w in r.get("swaps", []) if w.get("from")]

def swap_words(text, sw):
    import re
    for a, b in sw:
        text = re.sub(re.escape(a), lambda m: b.upper() if m.group(0).isupper() and len(m.group(0)) > 1 else (b[:1].upper() + b[1:]) if m.group(0)[:1].isupper() else b, text, flags=re.I)
    return text

def panel_rects(L):
    """the picture boxes of a YapMaxxing layout, fractions of the 9:16 frame (the editor's panelRects)"""
    W, H, g = 1080, 1920, .015; gv = g * W / H
    if L == "three": sd = (.83 - 2 * g) / 3; return [(.085 + k * (sd + g), .133, sd, sd * W / H) for k in range(3)]
    if L == "two": w2 = (.83 - g) / 2; return [(.085 + k * (w2 + g), .115, w2, .2) for k in range(2)]
    if L == "five":
        rh = (.22 - gv) / 2; wa = (.83 - g) / 2; wb = (.83 - 2 * g) / 3
        return [(.085 + k * (wa + g), .115, wa, rh) for k in range(2)] + [(.085 + k * (wb + g), .115 + rh + gv, wb, rh) for k in range(3)]
    return [(.1, .115, .8, .2)]

def cap_shadow(S):
    """the Shadow of captions and text: strength, angle, distance, blur and color (the editor's shadowCss)"""
    k = 45 if S.get("shadow") is True else float(S.get("shadow") or 0)
    if not k: return ""
    c = rgba_of(S.get("shc") or "#000000", min(.95, k / 100))
    if any(S.get(x) is not None for x in ("sha", "shd", "shb")):
        an = math.radians(float(S["sha"]) if S.get("sha") is not None else 180); d = (float(S["shd"]) if S.get("shd") is not None else 4) / 100
        bl = (float(S["shb"]) if S.get("shb") is not None else 21) / 100
        return f"text-shadow:{d * math.sin(an):.3f}em {-d * math.cos(an):.3f}em {bl:.3f}em {c};"
    return f"text-shadow:0 {.02 + k * .0004:.3f}em {.12 + k * .002:.3f}em {c};"

def rgba_of(h, a):
    h = str(h or "#000000").lstrip("#")
    if len(h) == 3: h = "".join(c * 2 for c in h)
    n = int(h[:6] or "0", 16)
    return f"rgba({(n >> 16) & 255},{(n >> 8) & 255},{n & 255},{float(a):.2f})"

def bg_of(S):
    """Background color with its opacity (the text window, 2026-10-24; the editor's bgOf)"""
    c = S.get("boxc") or "#FFFFFF"
    return rgba_of(c, max(0, float(S["boxo"])) / 100) if S.get("boxo") is not None and float(S["boxo"]) < 100 else c

def stroke_of(S):
    """Stroke plus faux bold (the editor's strokeOf)"""
    w = (float(S.get("olw") or 0) / 100 if float(S.get("olw") or 0) > 0 else 0) + (.025 if S.get("fb") else 0)
    if w <= 0: return ""
    return f"{w:.3f}em {S.get('olc') or '#000000'}" if float(S.get("olw") or 0) > 0 else f"{w:.3f}em {S.get('color') or '#FFFFFF'}"

def rot_scale(S):
    """Rotation and Scale (the editor's rotScale)"""
    o = f" rotate({float(S['rot'])}deg)" if float(S.get("rot") or 0) else ""
    if S.get("scl") is not None and float(S["scl"]) != 100: o += f" scale({float(S['scl']) / 100})"
    return o

def hug_css(S):
    """a text layer's background that follows the words line by line (the editor's hugCss, 2026-10-25)"""
    p = float(S["boxp"] if S.get("boxp") is not None else 22) / 100; r = float(S["boxr"] if S.get("boxr") is not None else 30) / 100
    return (f"background:{bg_of(S)};padding:{p * .7:.3f}em {p:.3f}em;border-radius:{r:.3f}em;"
            "-webkit-box-decoration-break:clone;box-decoration-break:clone;")

def ride_zoom(graph, last, rides, within, W, H, tag):
    """Ease-in zooms over a whole stream (2026-10-25): each move's stretch (cut to `within` spans when given) is split off, zoomed
    about the frame center with `perspective` (sub-pixel, so the ease glides) and laid back over itself. The same ease as the
    A-roll ride: from s0/s to 1 over `settle` seconds, quartic ease-out. Returns the new last label"""
    FPS = FPS_NUM / FPS_DEN; k = 0
    for m in rides:
        a0, b0 = float(m["t0"]), float(m["t1"])
        segs = [(a0, b0)] if within is None else [(max(a0, x), min(b0, y)) for x, y in within if min(b0, y) - max(a0, x) > 1e-3]
        s0, s = float(m.get("s0", 1.73)), float(m.get("s", 1.2)); st_ = max(.1, min(float(m.get("settle", 2.47)), b0 - a0))
        for a, b in segs:
            k += 1; f0 = math.ceil(a * FPS - 1e-6)
            T = f"({f0}/{FPS:.6f}+(in-1)/{FPS:.6f})"      # the clock inside the trimmed piece (perspective's `in` counts from 1)
            q = f"min(1,max(0,({T}-{a0:.4f})/{st_:.4f}))"
            Z = f"({s0 / s:.5f}+({1 - s0 / s:.5f})*(1-pow(1-{q},4)))"
            x0 = f"(W/2-W/(2*{Z}))"; y0 = f"(H/2-H/(2*{Z}))"; x1 = f"(W/2+W/(2*{Z}))"; y2 = f"(H/2+H/(2*{Z}))"
            graph.append(f"[{last}]split[{tag}{k}a][{tag}{k}b]")
            graph.append(f"[{tag}{k}b]trim=start={a:.4f}:end={b:.4f},perspective=x0='{x0}':y0='{y0}':x1='{x1}':y1='{y0}':x2='{x0}':y2='{y2}':x3='{x1}':y3='{y2}':"
                         f"interpolation=cubic:eval=frame[{tag}{k}z]")
            graph.append(f"[{tag}{k}a][{tag}{k}z]overlay=enable='between(t,{a:.4f},{b:.4f})':eof_action=pass[{tag}{k}]"); last = f"{tag}{k}"
    return last

def hug_html(S, body):
    """the words twice: backgrounds behind (letters invisible), then the letters exactly on top, so a line's background never
    covers the line above it (the editor's hugFill)"""
    p = float(S["boxp"] if S.get("boxp") is not None else 22) / 100
    return (f'<span style="{hug_css(S)}color:transparent;text-shadow:none;-webkit-text-stroke:0">{body}</span>'
            f'<span style="position:absolute;left:0;right:0;top:0;padding:{p * .7:.3f}em {p:.3f}em">{body}</span>')

def text_fx_css(S, two=False, hug=False):
    """Outline and Box for captions and the text hook, the same CSS as the editor's textFxCss(). hug: a text layer, whose
    background is a span inside it (hug_css); the layer keeps only the padding"""
    o = ""
    sk = stroke_of(S)
    if sk: o += f"-webkit-text-stroke:{sk};paint-order:stroke fill;"
    if S.get("box") and hug:
        p = float(S["boxp"] if S.get("boxp") is not None else 22) / 100
        return o + f"padding:{p * .7:.3f}em {p:.3f}em;"
    if S.get("box"):
        p = float(S["boxp"] if S.get("boxp") is not None else 22) / 100; r = float(S["boxr"] if S.get("boxr") is not None else 30) / 100
        o += (f"background:{bg_of(S)};padding:{p * .7 + .15:.3f}em {p:.3f}em;border-radius:{r:.3f}em;text-box:trim-both {'ex' if S.get('kase') == 'lower' else 'cap'} alphabetic;"
              + ("width:fit-content;max-width:84%;" if two else ""))      # trimmed to the capitals and the baseline: the words sit centered (the editor's BOXTRIM)
    return o

def chunks(st):
    """the captions, chunked exactly like the editor's chunks()"""
    W, out, i = st["WORDS"], [], 0
    SW = rule_swaps()
    import re
    while i < len(W):
        S = screen_at(st, W[i][0] + .01); cur = [W[i]]; j = i + 1
        if S.get("mode") == "chars":
            while j < len(W):
                pv, nx = W[j - 1], W[j]
                if re.search(r"[.,?!]$", pv[2]) or nx[0] - pv[1] > .3 or not same_screen(screen_at(st, nx[0] + .01), S): break
                if len(" ".join(w[2] for w in cur + [nx])) > S.get("chars", 14): break
                cur.append(nx); j += 1
        key = str(cur[0][3]); o = st.get("OVR", {}).get(key, {})
        raw = re.sub(r"[.,?!]", "", " ".join(w[2] for w in cur))
        last = cur[-1]
        behind = o["behind"] if "behind" in o else (bool(S.get("behind")) and S.get("behindCap") is not False)      # the Captions switch under Text behind subject
        b0, b1 = cur[0][0], (min(W[j][0], last[1] + .6) if j < len(W) else last[1] + .5)
        a0 = b0 + float(o.get("da", 0) or 0); a1 = max(a0 + .1, b1 + float(o.get("db", 0) or 0))   # the in/out points dragged in the editor
        cuts = [b0 + float(d) for d in (st.get("CAPCUT") or {}).get(key, []) if b0 + .05 < b0 + float(d) < b1 - .05]
        if not cuts:
            out.append({"t0": a0, "t1": a1,
                    "text": swap_words(o.get("text", raw), SW), "serif": bool(o.get("serif")), "hide": bool(o.get("hide")), "behind": bool(behind), "ws": o.get("w") or {}, "cb": o.get("b"), "cit": o.get("it"), "cta": o.get("ta"), "st": o.get("st") or {}})
        else:
            E = [b0] + sorted(cuts) + [b1]
            for q in range(len(E) - 1):
                po = st.get("OVR", {}).get(f"{key}~{q}", {}); pw = [w for w in cur if E[q] - 1e-3 <= w[0] < E[q + 1]]
                praw = re.sub(r"[.,?!]", "", " ".join(w[2] for w in pw)) if pw else raw
                c0 = E[q] + float(po.get("da", 0) or 0); c1 = max(c0 + .1, E[q + 1] + float(po.get("db", 0) or 0))
                out.append({"t0": c0, "t1": c1, "text": swap_words(po.get("text", praw), SW), "serif": bool(po.get("serif")), "hide": bool(po.get("hide")),
                            "behind": bool(po["behind"] if "behind" in po else behind), "ws": {}, "cb": po.get("b"), "cit": po.get("it"), "cta": po.get("ta"), "st": po.get("st") or {}})
        i = j
    for k in range(len(out) - 1):      # one caption at a time: a short word stretched to its 0.1 s minimum ends where the next starts
        n = next((m for m in range(k + 1, len(out)) if not out[m]["hide"]), None)      # a deleted caption doesn't count (2026-10-23)
        if n is not None and out[k]["t1"] > out[n]["t0"] > out[k]["t0"]: out[k]["t1"] = out[n]["t0"]
    return out

def behind_spans(st):
    """where captions sit behind the subject: (t0, t1, source), merged. source "aroll" cuts you out of the moved A-roll; over a
    full-frame B-roll whose screen has Text behind subject on (2026-10-22) it is "picture", the finished picture, so the subject
    of the B-roll comes forward. An effect or a colour screen covering the moment skips it."""
    cover = [(o["t0"], o["t1"]) for o in st.get("FX", []) if o.get("blend") != "screen"] + \
            [(g["t0"], g["t1"]) for g in st.get("BG", []) if scr(st, g["screen"]).get("kind") == "color"]
    spans = []
    for c in chunks(st):
        if not c["behind"] or c["hide"]: continue
        a, b = c["t0"], c["t1"]
        if any(x <= a < y for x, y in cover): continue
        br = at(st.get("BR", []), a + .01)
        if br and br.get("inpanel"): src = "aroll"      # a YapMaxxing box: you are still the picture
        elif br: src = "picture"; b = min(b, br["t1"])      # never past the B-roll's own edge
        else:
            src = "aroll"; nb = next((o["t0"] for o in st.get("BR", []) if a < o["t0"] < b and not o.get("inpanel")), None)
            if nb: b = nb
        if spans and spans[-1][2] == src and a - spans[-1][1] < .4: spans[-1][1] = max(spans[-1][1], b)
        else: spans.append([a, b, src])
    # text layers on an A-roll clip with Text behind subject on go behind you too (2026-10-25): the cut-out covers that stretch
    if st.get("KIND") != "carousel":
        for h in st.get("HK") or []:
            for sg in st.get("SEGS", []):
                a, b = max(float(h["t0"]), sg["t0"]), min(float(h["t1"]), sg["t1"])
                if b - a < .05: continue
                m = (a + b) / 2
                if any(x <= m < y for x, y in cover) or (at(st.get("BR", []), m) and not at(st.get("BR", []), m).get("inpanel")): continue
                Sm = screen_at(st, m)
                if not Sm.get("behind") or Sm.get("behindText") is False: continue      # the Text layers switch
                spans.append([a, b, "aroll"])
        spans.sort(key=lambda x: x[0]); merged = []
        for a, b, src in spans:
            if merged and merged[-1][2] == src and a - merged[-1][1] < .4: merged[-1][1] = max(merged[-1][1], b)
            else: merged.append([a, b, src])
        spans = merged
    return [(round(a, 3), round(min(b, st["DUR"]), 3), src) for a, b, src in spans if b - a > .05]

def cutout(job, src_in, src_out, src=None):
    """a cut-out of you over one stretch of the take, for the editor's text-behind preview. src is the preview the editor
    is playing (the LUT-graded copy when the LUT is on), so the cut-out's colors match the picture under it"""
    J = PROJECTS/job; C = J/"edit/cutouts"; C.mkdir(exist_ok=True)
    src = pathlib.Path(src) if src and pathlib.Path(src).exists() else J/"edit/proxy.mp4"
    tag = "" if src.name == "proxy.mp4" else "-" + src.stem.replace("proxy_lut_", "g")
    jr = key100      # the editor's Math.round, so it finds the file
    key = f"{jr(src_in)}-{jr(src_out)}{tag}"; out = C/f"{key}.webm"
    if out.exists() and out.stat().st_size > 1000: return out
    tmp = C/f"{key}.mp4"
    still = src.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp", ".heic", ".tif", ".tiff")      # a still B-roll (2026-10-22): one second of it is enough, the editor holds frame 0
    run(["ffmpeg", "-v", "error", "-y"] + (["-loop", "1", "-t", "1", "-i", src] if still else ["-ss", f"{src_in:.3f}", "-t", f"{src_out - src_in:.3f}", "-i", src]) +
        ["-vf", "scale=960:-2", "-c:v", "libx264", "-crf", "16", "-pix_fmt", "yuv420p", "-an", tmp])
    run([plat.NPX, "--yes", "hyperframes", "remove-background", tmp, "-o", out]); tmp.unlink(missing_ok=True)
    return out

LOOK_KEYS = ("exposure", "contrast", "pivot", "warmth", "curve", "curve_r", "curve_g", "curve_b", "saturation", "vibrance", "fade")
def grade_recipe(c, cc=None, broll=False, clipgrade=None):
    """a piece's grade for the grade engine (cineyap/studio/grade.js, GRADING.md): {"grades": [the clip's grade, the piece's own]},
    put together by grade.js fromGrades, the same function the editor's preview uses. The clip's grade: the take's (COLOR) for
    A-roll, the clip's own (cineyap/grades.json, Media's Edit) for B-roll. The piece's: its Inspector grade (`grade`, or the old
    `cc`). A grade: {fix, lut_on, lut, lut_amt, look_on, look, look_amt, then the look keys}."""
    G = (clipgrade if broll else c) or {}
    return {"grades": [G, cc or {}]}

def grade_idle(g):
    """a grade that changes nothing"""
    if not g: return True
    if g.get("lut_on") and g.get("lut") or g.get("look_on") and g.get("look"): return False
    if g.get("lut_amt") is not None and float(g["lut_amt"]) < .999 or g.get("look_amt") is not None and float(g["look_amt"]) < .999: return False      # a piece turning the clip's LUT down
    if any(abs(float(v or 0)) > 1e-4 for v in (g.get("fix") or {}).values()): return False
    for k in LOOK_KEYS:
        if g.get(k) is None: continue
        if k.startswith("curve") or abs(float(g[k]) - {"contrast": 1, "saturation": 1, "pivot": .5}.get(k, 0)) > 1e-3: return False
    return True

def grade_luts(R):
    """every LUT file a recipe uses"""
    return [str(g[k]) for g in R.get("grades", []) if g for on, k in (("lut_on", "lut"), ("look_on", "look")) if g.get(on) and g.get(k)]

GRADES = PKG/"_local/grades"
def grade_cube(R):
    """the recipe written as a 65-point .cube by the grade engine, cached by what's in it (every LUT file's size and date, and the
    engine itself: a change to grade.js must never export with a .cube the old maths wrote). A LUT that isn't on this Mac is left out"""
    import hashlib
    key = json.dumps(R, sort_keys=True) + hashlib.md5((PKG/"cineyap/studio/grade.js").read_bytes()).hexdigest()
    for l in grade_luts(R):
        try: st_ = pathlib.Path(l).stat(); key += f"|{l}|{st_.st_size}|{st_.st_mtime_ns}"
        except OSError: key += f"|{l}|missing"
    GRADES.mkdir(parents=True, exist_ok=True)
    out = GRADES/(hashlib.md5(key.encode()).hexdigest()[:16] + ".cube")
    if out.exists() and out.stat().st_size > 1000: out.touch(); return out
    for old in GRADES.glob("*.*"):      # each is ~7 MB: the ones no export has used in 30 days go
        if time.time() - old.stat().st_mtime > 30 * 86400: old.unlink(missing_ok=True)
    rj = out.with_suffix(".json"); rj.write_text(json.dumps(R))
    run([plat.NODE, PKG/"cineyap/studio/grade.js", "write", rj, out])
    return out

def grade_vf(R):
    """one lut3d for the whole grade (fix, LUTs, look), or "" when it changes nothing"""
    gs = R.get("grades", []) if R else []
    if len(gs) > 1 and gs[1] and gs[1].get("off"): return ""      # the piece's switch off: no color on it
    if all(grade_idle(g) or g.get("off") for g in gs): return ""
    f = str(grade_cube(R)).replace("\\", "/").replace("'", "\\'").replace(":", "\\:")
    return f"lut3d=file='{f}':interp=tetrahedral"

def grade_proxy(job, lut):
    """the proxy with the LUT baked in, so the editor previews exactly what the export will look like"""
    import hashlib
    J = PROJECTS/job; out = J/"edit"/f"proxy_lut_{hashlib.md5(lut.encode()).hexdigest()[:8]}.mp4"
    if out.exists() and out.stat().st_size > 1000: return out
    run(["ffmpeg", "-v", "error", "-y", "-i", J/"edit/proxy.mp4", "-vf", "lut3d=file='" + lut.replace("\\", "/").replace("'", "\\'").replace(":", "\\:") + "',format=yuv420p",
         "-c:v", HW264, "-b:v", "8M", "-g", "24", "-c:a", "copy", "-movflags", "+faststart", "-f", "mp4", out.with_suffix(".part")])
    out.with_suffix(".part").rename(out)      # whole or not at all: the editor opens on this file when it exists
    return out

def frame_geom(look, W, H, amt=None):
    """the Frame effect's window, the same numbers as the editor (measured in the old Library: fx_library.Frame).
    amt is the Border slider, a fraction of the short side."""
    s = min(W, H)
    if look == "rounded":
        m = round(s * (.04 if amt is None else amt)); mb = round(m * 1.1); w, h = W - 2 * m, H - m - mb
        return {"x": m, "y": m, "w": w, "h": h, "k": max(w / W, h / H), "r": s * .051}
    if look == "side":      # Side window: a tall 9:16 window down the middle of a plate
        m = round(s * (.06 if amt is None else amt)); h = (H - 2 * m) // 2 * 2; w = min(W - 2 * m, round(h * 9 / 16 / 2) * 2)
        return {"x": (W - w) // 2, "y": m, "w": w, "h": h, "k": max(w / W, h / H), "r": 0}
    k = max(.3, 1 - 2 * (.098 if amt is None else amt)); w, h = round(W * k / 2) * 2, round(H * k / 2) * 2
    return {"x": (W - w) // 2, "y": (H - h) // 2, "w": w, "h": h, "k": k, "r": 0}

def face_x(st, s):
    """median eye_x across one A-roll piece (source clock), 0.5 when no face was found"""
    xs = sorted(f[1] for f in st["FACES"] if s["src_in"] <= f[0] <= s["src_out"])
    return xs[len(xs) // 2] if xs else 0.5

def face_y(st, s):
    """median eye_y across one A-roll piece (source clock), 0.4 when no face was found"""
    ys = sorted(f[2] for f in st["FACES"] if s["src_in"] <= f[0] <= s["src_out"] and len(f) > 2)
    return ys[len(ys) // 2] if ys else 0.4

# ------------------------------------------------------------------ export
def free_name(p):
    """the first of p, p_1, p_2 ... with no MP4 or Premiere XML of that name yet (Premiere's rule for an export name that's taken)"""
    p = pathlib.Path(p); k = 0; c = p
    while c.exists() or c.with_suffix(".xml").exists():
        k += 1; c = p.with_name(f"{p.stem}_{k}{p.suffix}")
    return c

def export(job, fmt, k4=False, out=None):
    t_start = time.time()
    J = PROJECTS/job; st = load(job, fmt); stem, src = source_of(J)
    try:      # grading is on the footage (Media > A-roll, 2026-10-23): the take's own grade wins, so every video made from it matches
        gm = json.loads((PKG/"cineyap/aroll_grades.json").read_text()); g = gm.get(pathlib.Path(src).as_posix()) or gm.get(str(src))      # the editor keys it with forward slashes (X5: Windows missed it)
        if isinstance(g, dict): st["COLOR"] = {**(st.get("COLOR") or {}), **g}
    except Exception: pass
    # effects and shot moves are made for one shape; a 16:9 panel stretched to 9:16 is worse than none
    for k in ("FX", "MOVES"):
        st[k] = [o for o in st.get(k, []) if not o.get("fmt") or o["fmt"] == fmt]
    W, H = FORMATS[fmt]
    if k4: W, H = W * 2, H * 2
    D = J/"build/export"/fmt; D.mkdir(parents=True, exist_ok=True)       # A-roll pieces are cached by what they are
    out = pathlib.Path(out) if out else PKG/"exports"/f"{job}-{fmt}{'-4k' if k4 else ''}{SUFFIX}.mp4"
    out.parent.mkdir(parents=True, exist_ok=True)
    out = free_name(out)      # never over an earlier export: name_1, name_2 ... like Premiere (Gabe, 2026-10-25)
    fps = f"{FPS_NUM}/{FPS_DEN}"
    soft = st.get("SOFT", True)
    reframe = st.get("REFRAME", {}).get(fmt, {})
    try: BGRADES = json.loads((PKG/"cineyap/grades.json").read_text())      # each B-roll clip's own grade (the editor's Color grading on a clip)
    except Exception: BGRADES = {}        # per-piece manual x override (0..1), keyed by round(src_in*100)

    # 1. A-roll pieces: cut from the raw take, cover-scaled to the format, centred on the face
    print(f"1/5 cutting {len(st['SEGS'])} A-roll pieces from the raw take", flush=True)
    seglist = []
    for s in st["SEGS"]:
        cx = float(reframe.get(str(key100(s["src_in"])), face_x(st, s) if fmt != "169" else 0.5))
        # cover: scale so the frame is filled, then crop W x H around cx
        vf = hdr.sdr_vf(src, f"scale={W}:{H}:force_original_aspect_ratio=increase:flags=lanczos")      # an HLG iPhone take comes out Rec.709 (R12)
        cvf = grade_vf(grade_recipe(st.get("COLOR"), s.get("grade") or s.get("cc")))
        vf += f",crop={W}:{H}:'max(0,min(iw-{W},iw*{cx:.4f}-{W}/2))':'(ih-{H})/2'" + ("," + cvf if cvf else "") + f",format=yuv420p,fps={fps}"
        dur = s["src_out"] - s["src_in"]
        import hashlib
        f = D/("g_" + hashlib.md5(f"{s['src_in']:.3f}|{s['nf']}|{cx:.4f}|{W}x{H}|{cvf}|{vf[:8]}".encode()).hexdigest()[:12] + ".mov")      # the chain's head keys the cache too (R12)
        seglist.append(f)
        if f.exists() and f.stat().st_size > 1000: continue
        run(["ffmpeg", "-v", "error", "-y", "-ss", f"{s['src_in']:.3f}", "-t", f"{dur + 0.2:.3f}", "-i", src, "-vf", vf,
             "-frames:v", str(s["nf"]), "-c:v", "prores_ks", "-profile:v", "2", "-an", f])
    (D/"a.txt").write_text("".join(f"file '{p.name}'\n" for p in seglist))
    run(["ffmpeg", "-v", "error", "-y", "-f", "concat", "-safe", "0", "-i", "a.txt", "-c", "copy", "aroll.mov"], cwd=D)

    # 2. shot moves (translate x/y in % of the frame, scale s, eased ramps), then B-roll over it
    print("2/5 shot moves and B-roll", flush=True)
    moves = sorted(st.get("MOVES", []), key=lambda m: m["t0"])
    # an A-roll screen's Position and Scale (Screens > Align and Transform) hold for as long as that screen is up;
    # a shot move on top of it wins (it's later in the chain, so the outer if)
    held = []; SRCWH = []
    end = max([x["t1"] for x in st["SEGS"]] or [0])
    pts = sorted({0.0, end, *[x for L in ("BG", "BR", "SEGS") for o in st.get(L, []) for x in (o["t0"], o["t1"])]})
    for a0, b0 in zip(pts, pts[1:]):
        if b0 - a0 < 1e-4: continue
        S = dict(screen_at(st, (a0 + b0) / 2))
        if S.get("afit") == "frame" and S.get("abox"): continue      # A-roll in a frame: aroll_frame places it
        if S.get("kind") == "aroll" and S.get("punch"):     # Punch-in: closer by `punch`, the eyes held where they were (the editor's punchS)
            sg = next((x for x in st["SEGS"] if x["t0"] <= (a0 + b0) / 2 < x["t1"]), None)
            if sg:
                if not SRCWH:
                    o_ = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", src]).strip().split(",")
                    SRCWH.extend([int(o_[0]), int(o_[1])])
                sw0, sh0 = SRCWH; kk = max(W / sw0, H / sh0); iw, ih = sw0 * kk, sh0 * kk
                cx = float(reframe.get(str(key100(sg["src_in"])), face_x(st, sg) if fmt != "169" else 0.5))
                ox = (W - iw) / 2 if iw <= W + 1 else -max(0, min(iw - W, iw * cx - W / 2))
                ex, ey = (ox + face_x(st, sg) * iw) / W, ((H - ih) / 2 + face_y(st, sg) * ih) / H
                k_ = 1 + float(S["punch"])
                S["sc"] = float(S.get("sc", 1) or 1) * k_; S["px"] = float(S.get("px", 0) or 0) + (ex - .5) * (1 - k_) * 100; S["py"] = float(S.get("py", 0) or 0) + (ey - .5) * (1 - k_) * 100
        if S.get("kind") == "aroll" and (S.get("px") or S.get("py") or S.get("rot") or float(S.get("sc", 1) or 1) != 1):
            held.append({"t0": a0, "t1": b0, "x": float(S.get("px", 0) or 0), "y": float(S.get("py", 0) or 0), "s": float(S.get("sc", 1) or 1),
                         "r": float(S.get("rot", 0) or 0), "ramp": 0})
    rides = [m for m in moves if m.get("ride") and (m.get("zl") or "all") != "aroll"]      # zoomed later, over more than the A-roll (ride_zoom)
    moves = held + [m for m in moves if not (m.get("ride") and (m.get("zl") or "all") != "aroll")]
    def kexpr(m):   # smoothstep ramp 0..1..0 over the block
        if not float(m.get("ramp", 0) or 0): return "1"      # a held framing (screen scale, punch-in): fully on for the whole span. A 0.01 s ramp here
                                                              # dropped the zoom to nothing on the first and last frame of every A-roll cut (the twitch)
        r = max(.01, float(m.get("ramp", 0) or 0)); a, b = m["t0"], m["t1"]
        k = f"min(1,min((t-{a:.4f})/{r:.4f},({b:.4f}-t)/{r:.4f}))"
        return f"(({k})*({k})*(3-2*({k})))"
    sx, tx, ty, rz = "1", "0", "0", "0"
    for m in moves:
        on = f"between(t,{m['t0']:.4f},{m['t1']:.4f})"
        if m.get("ride"):   # Ease-in zoom: a factor ON TOP of the framing under it (screen scale, position, punch-in), easing from s0/s to 1
            st_ = max(.1, min(float(m.get("settle", 2.47)), m["t1"] - m["t0"]))
            q = f"min(1,max(0,(t-{m['t0']:.4f})/{st_:.4f}))"
            r = f"({float(m.get('s0', 1.73)) / float(m.get('s', 1.2)):.5f}+({1 - float(m.get('s0', 1.73)) / float(m.get('s', 1.2)):.5f})*(1-pow(1-{q},4)))"
            sx = f"if({on},({sx})*{r},{sx})"; tx = f"if({on},({tx})*{r},{tx})"; ty = f"if({on},({ty})*{r},{ty})"
            continue
        k = kexpr(m)
        rz = f"if({on},({float(m.get('r', 0) or 0) * 3.14159265 / 180:.6f})*{k},{rz})"
        sx = f"if({on},1+({float(m.get('s',1))-1:.4f})*{k},{sx})"
        tx = f"if({on},({float(m.get('x',0)):.4f})*{k},{tx})"
        ty = f"if({on},({float(m.get('y',0)):.4f})*{k},{ty})"
    graph = [f"color=c=black:s={W}x{H}:r={fps}:d={st['DUR']:.3f}[canvas0]"]
    # a screen's Background (bgc, 2026-10-22): the color behind the picture wherever that screen is up (seen where the picture is
    # scaled down or moved); a plain black canvas otherwise
    cv = "canvas0"; edges_ = sorted({0.0, st["DUR"], *[x for L in ("BG", "BR", "SEGS") for o in st.get(L, []) for x in (o["t0"], o["t1"])]})
    for k, (a0, b0) in enumerate(zip(edges_, edges_[1:])):
        if b0 - a0 < 1e-4: continue
        Sx = screen_at(st, (a0 + b0) / 2)
        if Sx.get("kind") == "color" or not Sx.get("bgc"): continue
        graph.append(f"color=c=0x{str(Sx['bgc']).lstrip('#')}:s={W}x{H}:r={fps}:d={st['DUR']:.3f}[bgc{k}]")
        graph.append(f"[{cv}][bgc{k}]overlay=enable='between(t,{a0:.4f},{b0:.4f})'[cvv{k}]"); cv = f"cvv{k}"
    graph.append(f"[{cv}]null[canvas]")
    # sub-pixel path (2026-10-21): `scale` + `overlay` round every frame to whole, even pixels, so a slow ease (the tail of
    # an Ease-in zoom) steps 2 px at a time and reads as frame-by-frame. `perspective` samples the source at fractional
    # positions, so the zoom glides. Used whenever every move stays inside the picture (scale 100%+, no rotation, the
    # position within what the zoom allows); anything else keeps the old path, which can show black around the picture.
    inside = moves and not any(m.get("r") for m in moves) and all(
        float(m.get("s", 1) or 1) >= 1 and abs(float(m.get("x", 0) or 0)) <= (float(m.get("s", 1) or 1) - 1) * 50 + 1e-6
        and abs(float(m.get("y", 0) or 0)) <= (float(m.get("s", 1) or 1) - 1) * 50 + 1e-6 for m in moves if not m.get("ride"))
    if inside:
        T = f"((in-1)/{FPS_NUM / FPS_DEN:.6f})"      # perspective's `in` counts from 1 (frame 0 reads 1): without the -1 every held zoom ended a frame early
        import re as _re2; sub = lambda e: _re2.sub(r"\bt\b", T, e)
        S_, X_, Y_ = sub(sx), sub(tx), sub(ty)
        x0 = f"(W/2-W/(2*({S_}))-({X_})*W/(100*({S_})))"; y0 = f"(H/2-H/(2*({S_}))-({Y_})*H/(100*({S_})))"
        x1 = f"({x0}+W/({S_}))"; y2 = f"({y0}+H/({S_}))"
        graph.append(f"[0:v]perspective=x0='{x0}':y0='{y0}':x1='{x1}':y1='{y0}':x2='{x0}':y2='{y2}':x3='{x1}':y3='{y2}':"
                     f"interpolation=cubic:eval=frame[mv]")
        graph.append("[canvas][mv]overlay=shortest=1[base0]")
    elif moves:
        rot = f",rotate=a='{rz}':c=black" if any(m.get("r") for m in moves) else ""      # the Rotation setting
        graph.append(f"[0:v]scale=w='{W}*({sx})':h='{H}*({sx})':eval=frame{rot}[mv]")
        graph.append(f"[canvas][mv]overlay=x='({W}-w)/2+({tx})*{W}/100':y='({H}-h)/2+({ty})*{H}/100':eval=frame:shortest=1[base0]")
    else:
        graph.append("[canvas][0:v]overlay=shortest=1[base0]")
    inputs = [D/"aroll.mov"]; last = "base0"
    for k, (a0, b0) in enumerate(zip(pts, pts[1:])):
        if b0 - a0 < 1e-4 or at(st.get("BR", []), (a0 + b0) / 2): continue      # under a picture block: done in the B-roll loop
        S = screen_at(st, (a0 + b0) / 2)
        if at(st.get("BG", []), (a0 + b0) / 2): continue
        if S.get("afit") == "frame" and S.get("abox"):
            bgx = S.get("bgc") or S.get("bg") or S.get("matte")      # no color picked = Background A-roll: you stay full behind your own frame (Gabe, 2026-10-24)
            last = aroll_frame(graph, inputs, D, last, S, a0, b0, W, H, fps, f"a{k}", cover=("0x" + str(bgx).lstrip("#")) if bgx else None)
        elif S.get("kind") == "color" or (S.get("kind") == "broll" and S.get("bfull")):      # a piece on a Color (or an empty B-roll) screen (2026-10-24)
            col = str(S.get("bg") or "#000000").lstrip("#") if S.get("kind") == "color" else "000000"
            graph.append(f"color=c=0x{col}:s={W}x{H}:r={fps}:d={b0 - a0 + .5:.3f},setpts=PTS-STARTPTS+{a0:.4f}/TB[sc{k}]")
            graph.append(f"[{last}][sc{k}]overlay=enable='between(t,{a0:.4f},{b0:.4f})':eof_action=pass[scv{k}]"); last = f"scv{k}"
    for k, g in enumerate([g for g in st.get("BG", []) if g.get("inpic")], 1):      # color screens behind a YapMaxxing box
        S = scr(st, g["screen"]); S = {**S, **g["st"]} if g.get("st") else S
        if S.get("kind") != "color": continue
        graph.append(f"color=c=0x{S['bg'].lstrip('#')}:s={W}x{H}:r={fps}:d={st['DUR']:.3f}[pl{k}]")
        graph.append(f"[{last}][pl{k}]overlay=enable='between(t,{g['t0']:.4f},{g['t1']:.4f})'[plv{k}]"); last = f"plv{k}"
    def pbox(r): return (round(r[0] * W / 2) * 2, round(r[1] * H / 2) * 2, round(r[2] * W / 2) * 2, round(r[3] * H / 2) * 2)      # a box in px, even
    for i, b in enumerate(sorted(st.get("BR", []), key=lambda o: o["t0"]), 1):
        Sbk = next((x for x in st["SCREENS"] if x["id"] == (b.get("scr") or "broll")), {})
        if not b.get("inpanel") and Sbk.get("kind") in ("aroll", "color"):      # BACKGROUND (2026-10-24): this block's screen shows you, or a color, not its clip
            if Sbk.get("kind") == "color":
                graph.append(f"color=c=0x{str(Sbk.get('bg') or '#000000').lstrip('#')}:s={W}x{H}:r={fps}:d={b['t1'] - b['t0'] + .5:.3f},setpts=PTS-STARTPTS+{b['t0']:.4f}/TB[bc{i}]")
                graph.append(f"[{last}][bc{i}]overlay=enable='between(t,{b['t0']:.4f},{b['t1']:.4f})':eof_action=pass[bcv{i}]"); last = f"bcv{i}"
            if Sbk.get("afit") == "frame" and Sbk.get("abox"):
                ASb = {**Sbk, **(b.get("ast") or {})}      # this clip's own A-roll framing, every shape (X1: only 9:16 read it)
                cbg = None if Sbk.get("kind") == "color" else (Sbk.get("bgc") or Sbk.get("matte") or Sbk.get("fill"))      # no colour = the full A-roll behind, as the editor (X2: it painted black)
                last = aroll_frame(graph, inputs, D, last, ASb, b["t0"], b["t1"], W, H, fps, f"g{i}", cover=("0x" + str(cbg).lstrip("#")) if cbg else None)
            continue
        clip = pathlib.Path(b["clip"]) if pathlib.Path(b["clip"]).is_absolute() else pathlib.Path(broll_root())/b["clip"]
        if not clip.exists(): print(f"  B-roll missing, skipped: {b['clip']}", flush=True); continue
        dur = b["t1"] - b["t0"]
        inputs.append(clip); n = len(inputs) - 1
        Sb = screen_at(st, (b["t0"] + b["t1"]) / 2)      # a B-roll screen's Picture settings: scale (100%+), rotation, position
        pic = ""
        if Sb.get("kind") == "broll" and (Sb.get("px") or Sb.get("py") or Sb.get("rot") or float(Sb.get("sc", 1) or 1) != 1):
            sc = max(1.0, float(Sb.get("sc", 1) or 1)); px, py = float(Sb.get("px", 0) or 0), float(Sb.get("py", 0) or 0)
            pic = (f",scale=trunc(iw*{sc:.4f}/2)*2:trunc(ih*{sc:.4f}/2)*2" + (f",rotate={float(Sb.get('rot', 0) or 0) * 3.14159265 / 180:.6f}:c=black" if Sb.get("rot") else "")
                   + f",crop={W}:{H}:x='min(max((iw-{W})/2-({px:.3f})*{W}/100,0),iw-{W})':y='min(max((ih-{H})/2-({py:.3f})*{H}/100,0),ih-{H})'")
        # this clip's own framing (click it on the timeline, drag it in the preview): where it sits, and a zoom of 100%+
        bfx, bfy, zs = float(b.get("fx", .5)), float(b.get("fy", .5)), float(b.get("zs", 1) or 1)
        rot, bxp, byp, fit = float(b.get("rot", 0) or 0), float(b.get("bx", 0) or 0), float(b.get("by", 0) or 0), b.get("fit") == "fit"
        cvb = grade_vf(grade_recipe(st.get("COLOR"), b.get("grade") or b.get("cc"), True, BGRADES.get(b["clip"]))); cvb = "," + cvb if cvb else ""
        if b.get("inpanel"):      # YapMaxxing: each picture filled into its box above your head (box 1 is this clip, the rest are pics)
            R = b.get("inrects") or panel_rects(b["inpanel"]); pics = [None] + list(b.get("pics") or [])
            off = 1 if b.get("inbfull") else 0      # full B-roll with frames (2026-10-23): the block's clip fills the screen, frame j is pics[j]
            if off and clip.name != "panel_placeholder.jpg":
                graph.append(f"[{n}:v]trim=start={float(b.get('in',0)):.3f}:duration={dur:.3f},setpts=PTS-STARTPTS+{b['t0']:.4f}/TB,"
                             f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}:x='(iw-{W})*{bfx:.4f}':y='(ih-{H})*{bfy:.4f}'" + cvb + f",fps={fps},tpad=stop_mode=clone:stop_duration=0.25,format=yuv420p[bf{i}]")
                graph.append(f"[{last}][bf{i}]overlay=enable='between(t,{b['t0']:.4f},{b['t1']:.4f})':eof_action=pass[bfv{i}]"); last = f"bfv{i}"
            if b.get("infill"):
                graph.append(f"color=c=0x{b['infill'].lstrip('#')}:s={W}x{H}:r={fps}:d={st['DUR']:.3f}[lf{i}]")
                graph.append(f"[{last}][lf{i}]overlay=enable='between(t,{b['t0']:.4f},{b['t1']:.4f})'[lfv{i}]"); last = f"lfv{i}"
            Sblk = next((x for x in st["SCREENS"] if x["id"] == (b.get("scr") or "broll")), {})
            AS = Sblk if Sblk.get("afit") == "frame" and Sblk.get("abox") else (Sb if Sb.get("kind") == "aroll" and Sb.get("afit") == "frame" and Sb.get("abox") else None)
            if AS and Sblk is AS and b.get("ast"): AS = {**AS, **b["ast"]}      # this clip's own A-roll framing (double-click it in the editor, 2026-10-24)
            if AS: last = aroll_frame(graph, inputs, D, last, AS, b["t0"], b["t1"], W, H, fps, f"p{i}", cover=None if b.get("infill") or b.get("inbfull") or not (AS.get("bgc") or AS.get("matte")) else "0x" + str(AS.get("bgc") or AS.get("matte")).lstrip("#"))      # no color = the A-roll behind
            shapes = b.get("inshapes") or []; rads = b.get("inrads") or []
            for j0, r in enumerate(R):
                j = j0 + off      # the slot: 0 is the block's own clip, j is pics[j-1]
                px_, py_, pw, ph = pbox(r); lab = f"{i}_{j}"
                if j == 0:
                    if clip.name == "panel_placeholder.jpg": continue
                    nn, start = n, float(b.get("in", 0))
                else:
                    pj = pics[j] if j < len(pics) and pics[j] else None
                    if not pj or pathlib.Path(pj).name == "panel_placeholder.jpg": continue      # an empty box exports empty (Gabe, 2026-10-23); the editor warns first
                    pp = pathlib.Path(pj) if pathlib.Path(pj).is_absolute() else pathlib.Path(broll_root())/pj
                    if not pp.exists(): continue
                    inputs.append(pp); nn, start = len(inputs) - 1, 0.0
                # each picture's own place and zoom inside its box (2026-10-23): box 1 is the clip (fx/fy/zs), the rest pf[j] = {x, y, z}
                pf = (b.get("pf") or {}).get(str(j)) or {} if j else {}
                qx, qy, qz = (bfx, bfy, max(1.0, zs)) if j == 0 else (float(pf.get("x", .5)), float(pf.get("y", .5)), max(1.0, float(pf.get("z", 1) or 1)))
                shp = shapes[j0] if j0 < len(shapes) else None
                graph.append(f"[{nn}:v]trim=start={start:.3f}:duration={dur:.3f},setpts=PTS-STARTPTS+{b['t0']:.4f}/TB,"
                             f"scale=trunc({pw}*{qz:.4f}/2)*2:trunc({ph}*{qz:.4f}/2)*2:force_original_aspect_ratio=increase,crop={pw}:{ph}:x='(iw-{pw})*{qx:.4f}':y='(ih-{ph})*{qy:.4f}'" + cvb + f",fps={fps},tpad=stop_mode=clone:stop_duration=0.25,format=" + ("yuva420p" if shp in ("rounded", "circle") else "yuv420p") + f"[b{lab}" + ("r]" if shp in ("rounded", "circle") else "]"))
                if shp in ("rounded", "circle"):      # a rounded or round frame (2026-10-23)
                    inputs.append(shape_mask(D, pw, ph, shp, rads[j0] if j0 < len(rads) else None)); mi = len(inputs) - 1
                    graph.append(f"[{mi}:v]format=gray,scale={pw}:{ph}[bm{lab}];[b{lab}r][bm{lab}]alphamerge[b{lab}]")
                graph.append(f"[{last}][b{lab}]overlay=x={px_}:y={py_}:enable='between(t,{b['t0']:.4f},{b['t1']:.4f})':eof_action=pass[v{lab}]"); last = f"v{lab}"
            continue
        if not fit and zs >= 1 and not rot and not bxp and not byp:      # fill the frame, zoom about the framing point (as before)
            bz = f",scale=trunc(iw*{zs:.4f}/2)*2:trunc(ih*{zs:.4f}/2)*2" if zs != 1 else ""
            graph.append(f"[{n}:v]trim=start={float(b.get('in',0)):.3f}:duration={dur:.3f},setpts=PTS-STARTPTS+{b['t0']:.4f}/TB,"
                         f"scale={W}:{H}:force_original_aspect_ratio=increase{bz},crop={W}:{H}:x='(iw-{W})*{bfx:.4f}':y='(ih-{H})*{bfy:.4f}'" + pic + cvb + f",fps={fps},tpad=stop_mode=clone:stop_duration=0.25,format=yuv420p[b{i}]")
        else:   # Premiere's Motion (2026-10-21): fit or fill, then scale, rotate the whole picture, place it at Position over black
            base = f"scale={W}:{H}:force_original_aspect_ratio=decrease" if fit else f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H}:x='(iw-{W})*{bfx:.4f}':y='(ih-{H})*{bfy:.4f}'"
            a_ = rot * 3.14159265 / 180
            graph.append(f"[{n}:v]trim=start={float(b.get('in',0)):.3f}:duration={dur:.3f},setpts=PTS-STARTPTS,{base},"
                         f"scale=trunc(iw*{zs:.4f}/2)*2:trunc(ih*{zs:.4f}/2)*2,format=rgba" + (f",rotate={a_:.6f}:ow='rotw({a_:.6f})':oh='roth({a_:.6f})':c=0x00000000" if rot else "") + f"[bp{i}]")
            graph.append(f"color=c=black:s={W}x{H}:r={fps}:d={dur:.3f}[bk{i}]")
            graph.append(f"[bk{i}][bp{i}]overlay=x='({W}-w)/2+({bxp:.3f})*{W}/100':y='({H}-h)/2+({byp:.3f})*{H}/100':shortest=1,setpts=PTS-STARTPTS+{b['t0']:.4f}/TB"
                         + pic + cvb + f",fps={fps},tpad=stop_mode=clone:stop_duration=0.25,format=yuv420p[b{i}]")
        # every B-roll stream holds its last frame 0.25 s (tpad above) and is shown only inside its own window: a clip trimmed to
        # exactly its length can end a fraction of a frame early, and where two B-roll clips touch that frame showed the A-roll
        # under them (a one-frame flash of A-roll between B-roll clips, Gabe 2026-10-25)
        graph.append(f"[{last}][b{i}]overlay=enable='between(t,{b['t0']:.4f},{b['t1']:.4f})':eof_action=pass[v{i}]")
        last = f"v{i}"
        Sblk = next((x for x in st["SCREENS"] if x["id"] == (b.get("scr") or "broll")), {})
        if Sblk.get("afit") == "frame" and Sblk.get("abox"): last = aroll_frame(graph, inputs, D, last, {**Sblk, **(b.get("ast") or {})}, b["t0"], b["t1"], W, H, fps, f"f{i}")      # you, framed over a full B-roll, with this clip's own framing (X1)
    for i, fb in enumerate(st["FRAMES"], 1):
        G = frame_geom(fb["frame"], W, H, fb.get("border")); a, b = fb["t0"], fb["t1"]; plate = fb.get("plate", "#FFFFFF").lstrip("#")
        z = float(fb.get("zoom", 1) or 1)                     # the Zoom slider: the picture punched in inside the border
        sw, sh = max(G["w"], round(W * G["k"] * z / 2) * 2), max(G["h"], round(H * G["k"] * z / 2) * 2)
        graph.append(f"[{last}]split[fr{i}a][fr{i}b]")
        graph.append(f"[fr{i}b]trim=start={a:.4f}:end={b:.4f},scale={sw}:{sh},crop={G['w']}:{G['h']},"
                     f"pad={W}:{H}:{G['x']}:{G['y']}:color=0x{plate}[fr{i}p]")
        if G["r"] > 0:      # rounded corners: the plate with a rounded window, laid over the picture
            png = D/f"frame_{fb['frame']}_{plate}_{fb.get('border')}_{W}x{H}.png"
            if not png.exists():
                from PIL import Image, ImageDraw
                im = Image.new("RGBA", (W, H), tuple(int(plate[k:k+2], 16) for k in (0, 2, 4)) + (255,))
                mk = Image.new("L", (W, H), 255); ImageDraw.Draw(mk).rounded_rectangle([G["x"], G["y"], G["x"] + G["w"] - 1, G["y"] + G["h"] - 1], radius=round(G["r"]), fill=0)
                im.putalpha(mk); im.save(png)
            inputs.append(png); n = len(inputs) - 1
            graph.append(f"[{n}:v]format=rgba[fm{i}];[fr{i}p][fm{i}]overlay=0:0:shortest=1[fr{i}q]"); fp = f"fr{i}q"
        else: fp = f"fr{i}p"
        graph.append(f"[fr{i}a][{fp}]overlay=enable='between(t,{a:.4f},{b:.4f})':eof_action=pass[frm{i}]"); last = f"frm{i}"
    # an Ease-in zoom set to B-roll: the picture zoomed wherever a B-roll is up during the move
    last = ride_zoom(graph, last, [m for m in rides if m.get("zl") == "broll"], [(o["t0"], o["t1"]) for o in st.get("BR", [])], W, H, "zb")
    args = ["ffmpeg", "-v", "error", "-y"]
    for p in inputs: args += (["-loop", "1"] if str(p).lower().endswith((".png", ".jpg", ".jpeg", ".webp")) else []) + ["-i", p]      # stills (and frame PNGs) loop into a clip
    spans = behind_spans(st)
    if any(x[2] == "aroll" for x in spans):      # the moved, reframed A-roll on its own: text-behind cut-outs are made from exactly this picture
        graph = [g.replace("[base0]", "[base0pre]") if "[base0]" in g and not g.startswith("[base0]") else g for g in graph]
        graph.append("[base0pre]split[base0][amoved]")
    (D/"graph1.txt").write_text(";\n".join(graph))
    args += ["-/filter_complex", D/"graph1.txt", "-map", f"[{last}]"] + prores() + ["-t", f"{st['DUR']:.3f}", D/"picture.mov"]
    if any(x[2] == "aroll" for x in spans): args += ["-map", "[amoved]"] + prores() + ["-t", f"{st['DUR']:.3f}", D/"aroll_moved.mov"]
    try: run(args)
    except RuntimeError:      # no hardware ProRes on this Mac: the software one
        print("  hardware ProRes not available; using the software one", flush=True)
        run([("prores_ks" if a == "prores_videotoolbox" else "2" if a == "standard" else a) for a in [str(x) for x in args]])
    cutouts = []
    for k, (a, b, ksrc) in enumerate(spans, 1):
        print(f"  cutting out the subject for text-behind {a:.1f}-{b:.1f}s ({'B-roll' if ksrc == 'picture' else 'you'})", flush=True)
        clipf, outw = D/f"behind{k}.mp4", D/f"behind{k}.webm"
        run(["ffmpeg", "-v", "error", "-y", "-ss", f"{a:.3f}", "-t", f"{b - a:.3f}", "-i", D/("picture.mov" if ksrc == "picture" else "aroll_moved.mov"), "-c:v", "libx264",
             "-crf", "12", "-pix_fmt", "yuv420p", clipf])
        run([plat.NPX, "--yes", "hyperframes", "remove-background", clipf, "-o", outw])
        cutouts.append((a, b, outw))

    # 3. screens + captions as a transparent HyperFrames layer
    print("3/5 drawing the captions and text", flush=True)
    graphics(st, fmt, W, H, D)

    # 4. effects on top
    print("4/5 effects", flush=True)
    # the graphics' WebM keeps whole-millisecond timestamps, rounded UP past the picture's frame times (frame 852: 35.536 vs
    # 35.5355), so the overlay took the frame before and every caption changed one frame after the cut. Re-time it by frame count.
    g2 = [f"[1:v]setpts=N/({FPS_NUM}/{FPS_DEN})/TB[gfx];[0:v][gfx]overlay=eof_action=pass[c0]"]; inputs = [D/"picture.mov", D/"graphics.webm"]; last = "c0"
    for k, (a, b, w) in enumerate(cutouts, 1):
        inputs.append(w); n = len(inputs) - 1
        g2.append(f"[{n}:v]setpts=N/({FPS_NUM}/{FPS_DEN})/TB+{a:.4f}/TB,format=yuva420p[u{k}]")
        g2.append(f"[{last}][u{k}]overlay=enable='between(t,{a:.4f},{b:.4f})':eof_action=pass[k{k}]"); last = f"k{k}"
    if (D/"front.webm").exists():      # text that stays in front of the cut-out of you (Text behind subject with one switch off)
        inputs.append(D/"front.webm"); n = len(inputs) - 1
        g2.append(f"[{n}:v]setpts=N/({FPS_NUM}/{FPS_DEN})/TB[frt];[{last}][frt]overlay=eof_action=pass[frt0]"); last = "frt0"
    alpha_fx = [x for x in st.get("FX", []) if x.get("file") and x.get("blend") != "screen"]
    rides = [m for m in st.get("MOVES", []) if m.get("ride") and (m.get("zl") or "all") in ("all", "color")]
    screen_fx = [x for x in st.get("FX", []) if x.get("file") and x.get("blend") == "screen"]
    for i, x in enumerate(sorted(alpha_fx, key=lambda o: o["t0"]), 1):
        p = pathlib.Path(x["file"])
        if not p.exists(): print(f"  effect missing, skipped: {p}", flush=True); continue
        inputs.append(p); n = len(inputs) - 1
        dur = x["t1"] - x["t0"]
        g2.append(f"[{n}:v]trim=start={float(x.get('in',0)):.3f}:duration={dur:.3f},setpts=PTS-STARTPTS+{x['t0']:.4f}/TB,"
                  f"scale={W}:{H},format=yuva420p[x{i}]")
        g2.append(f"[{last}][x{i}]overlay=enable='between(t,{x['t0']:.4f},{x['t1']:.4f})':eof_action=pass[c{i}]")
        last = f"c{i}"
    # an Ease-in zoom set to Everything (the default): the finished picture with every text, caption and effect on it, like an
    # adjustment layer. Set to Color screen: the same, only while a Color screen is up
    last = ride_zoom(g2, last, [m for m in rides if (m.get("zl") or "all") == "all"], None, W, H, "za")
    last = ride_zoom(g2, last, [m for m in rides if m.get("zl") == "color"],
                     [(g["t0"], g["t1"]) for g in st.get("BG", []) if not g.get("inpic") and scr(st, g["screen"]).get("kind") == "color"], W, H, "zc")
    # the flash: the ORIGINAL leak clip with Screen blend (an alpha copy bands), on black elsewhere so Screen changes nothing there
    if screen_fx:
        g2.append(f"color=c=black:s={W}x{H}:r={fps}:d={st['DUR']:.3f},format=yuv420p[fk0]"); fk = "fk0"
        for i, x in enumerate(sorted(screen_fx, key=lambda o: o["t0"]), 1):
            p = pathlib.Path(x["file"])
            if not p.exists(): continue
            inputs.append(p); n = len(inputs) - 1; dur = x["t1"] - x["t0"]
            rot = "transpose=1," if (W > H and x.get("portrait", True)) else ""
            g2.append(f"[{n}:v]trim=start={float(x.get('in',0)):.3f}:duration={dur:.3f},setpts=PTS-STARTPTS+{x['t0']:.4f}/TB,{rot}"
                      f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={fps},format=yuv420p[fl{i}]")
            g2.append(f"[{fk}][fl{i}]overlay=enable='between(t,{x['t0']:.4f},{x['t1']:.4f})':eof_action=pass[fk{i}]"); fk = f"fk{i}"
        g2.append(f"[{last}]format=gbrp[sb];[{fk}]format=gbrp[sf];[sb][sf]blend=all_mode=screen:shortest=1,format=yuv420p[scr]"); last = "scr"
    # 5. audio, then ONE encode straight from the composite to the MP4 (2026-10-23: no video.mov in between)
    print("5/5 audio and final encode", flush=True)
    audio(st, src, D, soft)
    args = ["ffmpeg", "-v", "error", "-y", "-i", inputs[0]]
    for p in inputs[1:]: args += (["-c:v", "libvpx-vp9"] if str(p).lower().endswith(".webm") else []) + ["-i", p]
    args += ["-i", D/"mix.wav"]
    (D/"graph2.txt").write_text(";\n".join(g2))
    args += ["-/filter_complex", D/"graph2.txt", "-map", f"[{last}]", "-map", f"{len(inputs)}:a"] + venc(k4) + \
            ["-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", "-t", f"{st['DUR']:.3f}", "-shortest", out]
    run_enc(args, k4)
    xml_too = not k4 and not NOXML

    # the graphics and effects as ONE ProRes 4444 layer with alpha, for the Premiere XML's V3 (WebM does not import there)
    g3 = ["[0:v]format=yuva444p10le[g0]"]; last = "g0"; n = 0
    for i, x in enumerate(sorted(alpha_fx, key=lambda o: o["t0"]), 1):
        if not pathlib.Path(x["file"]).exists(): continue
        n += 1; dur = x["t1"] - x["t0"]
        g3.append(f"[{n}:v]trim=start={float(x.get('in',0)):.3f}:duration={dur:.3f},setpts=PTS-STARTPTS+{x['t0']:.4f}/TB,scale={W}:{H},format=yuva444p10le[y{i}]")
        g3.append(f"[{last}][y{i}]overlay=enable='between(t,{x['t0']:.4f},{x['t1']:.4f})':eof_action=pass:format=auto[h{i}]"); last = f"h{i}"
    (D/"graph3.txt").write_text(";\n".join(g3))
    if xml_too:      # the Premiere XML's graphics layer, only when there's an XML (it was a full-length ProRes 4444 every time)
        a3 = ["ffmpeg", "-v", "error", "-y", "-c:v", "libvpx-vp9", "-i", D/"graphics.webm"]
        for x in sorted(alpha_fx, key=lambda o: o["t0"]):
            if pathlib.Path(x["file"]).exists(): a3 += ["-c:v", "libvpx-vp9", "-i", x["file"]]
        run(a3 + ["-/filter_complex", D/"graph3.txt", "-map", f"[{last}]", "-c:v", "prores_ks", "-profile:v", "4", "-pix_fmt", "yuva444p10le",
                  "-t", f"{st['DUR']:.3f}", D/"overlay_4444.mov"])
    if xml_too:
        try: xml(job, fmt, out.with_suffix(".xml"))      # beside the MP4, same name (so an _1 export gets an _1 XML)
        except Exception as e: print(f"  the Premiere XML could not be written: {e}", flush=True)
    if st.get("KIND") == "carousel":       # one file per slide, in order: MP4 for a video slide, PNG for a still
        SD = out.parent/(out.stem + "-slides"); shutil.rmtree(SD, ignore_errors=True); SD.mkdir()
        for i, sg in enumerate(st["SEGS"]):
            sl = sg.get("slide") or {}; d = sg["t1"] - sg["t0"]; nm = SD/f"slide_{i + 1:02d}"
            if sl.get("still"):
                run(["ffmpeg", "-v", "error", "-y", "-ss", f"{sg['t0'] + min(.5, d / 2):.3f}", "-i", out, "-frames:v", "1", str(nm) + ".png"])
            else:
                run(["ffmpeg", "-v", "error", "-y", "-ss", f"{sg['t0']:.3f}", "-t", f"{d:.3f}", "-i", out, "-c:v", "libx264", "-preset", "slow", "-crf", "16",
                     "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "256k", "-movflags", "+faststart", str(nm) + ".mp4"])
        print(f"  {len(st['SEGS'])} slides in {SD}", flush=True)
        out = SD/("slide_01.mp4" if (SD/"slide_01.mp4").exists() else "slide_01.png")
    print(f"DONE {out} ({time.time() - t_start:.0f}s)", flush=True)
    return out

def broll_root():
    sys.path.insert(0, str(PKG/"cineyap")); import config
    return config.opt("broll_clips") or config.opt("broll_root")

# single quotes only: these go inside a style="..." attribute (double quotes there cut the style short, 2026-10-20)
FONT_CSS = {"h": ("Helvetica, 'Helvetica Neue', Arial, sans-serif", 700, "normal"), "i": ("Inter", 800, "normal"),
            "s": ("'Instrument Serif'", 400, "italic"), "f": ("Futura, 'Futura PT', sans-serif", 700, "normal")}

def sys_face(ps):
    """a font from this Mac ("sys:<PostScript name>" in a screen or word): its record from system_fonts.json"""
    try: fams = json.loads((PKG/"cineyap/system_fonts.json").read_text())["families"]
    except Exception: fams = []
    for f in fams:
        for x in f["faces"]:
            if x["ps"] == ps: return x
    return {"ps": ps, "full": ps, "path": ""}

def wrap_n(S, text, wb, fmt):
    """how many lines a text wraps to inside a box width (the editor's wrapN, 2026-10-22), so a two-line title converts with the line
    under it placed below it. Helvetica is measured with its own font file; other fonts use an average letter width"""
    if not wb or float(wb) <= 0 or not text: return 1
    sz = float(S.get("size") or 72); ls = (float(S["ls"]) if S.get("ls") is not None else (-.08 if sz >= 110 else -.04)) * sz
    t = text.upper() if S.get("kase") == "upper" else text.lower() if S.get("kase") == "lower" else text
    meas = lambda w: len(w) * sz * .56
    if (S.get("font") or "h") == "h":
        try:
            from PIL import ImageFont
            i = (0 if S.get("b") is False else 1) + (2 if S.get("it") else 0)
            # Windows has no Helvetica: the export's Chrome draws it as Arial, so measure with Arial
            f = ImageFont.truetype(os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", ("arial.ttf", "arialbd.ttf", "ariali.ttf", "arialbi.ttf")[i]), max(1, int(round(sz)))) if plat.IS_WIN \
                else ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", max(1, int(round(sz))), index=i)
            meas = f.getlength
        except Exception: pass
    Wb, sp, n, cur = float(wb) / 100 * BASIS.get(fmt or "916", 1080), meas(" ") + ls, 1, 0.0
    for w in t.split():
        ww = meas(w) + ls * len(w)
        if cur > 0 and cur + sp + ww > Wb + .5: n += 1; cur = ww
        else: cur += (sp if cur > 0 else 0) + ww
    return n

def graphics(st, fmt, W, H, D):
    """the screens' colour plates and every caption, as one transparent HyperFrames composition"""
    P = D/"hf"; shutil.rmtree(P, ignore_errors=True); P.mkdir()
    basis = BASIS[fmt]      # sizes are authored against this width and scale with W (R11: the old W factor cancelled out, so 4K text came out half size)
    fonts_dir = PKG/"fonts"
    faces = []
    for name, fam, w, style in (("InstrumentSerif-Italic", "Instrument Serif", 400, "italic"), ("Inter-Bold", "Inter", 800, "normal")):
        for ext in (".ttf", ".otf"):
            src = next(iter(list(fonts_dir.glob(name + ext)) + list(plat.user_fonts_dir().glob(name + ext))), None)
            if src:
                shutil.copy(src, P/src.name)
                faces.append(f'@font-face{{font-family:"{fam}";src:url("{src.name}");font-weight:{w};font-style:{style};}}')
                break
    sysdone = set()
    def font_css(k):
        if k and str(k).startswith("sys:"):
            ps = k[4:]; fam = "sys-" + ps
            if ps not in sysdone:
                sysdone.add(ps); x = sys_face(ps); src = f'local("{ps}"),local("{x["full"]}")'
                pth = pathlib.Path(x.get("path") or "")
                if pth.suffix.lower() in (".ttf", ".otf") and pth.exists():
                    shutil.copy(pth, P/pth.name); src += f',url("{pth.name}")'
                faces.append(f'@font-face{{font-family:"{fam}";src:{src};}}')
            return (f"'{fam}'", 400, "normal")
        if k and str(k).startswith("file:"):           # a brand font file that isn't installed on this Mac
            pth = pathlib.Path(k[5:]); fam = "file-" + pth.stem
            if str(pth) not in sysdone and pth.exists():
                sysdone.add(str(pth)); shutil.copy(pth, P/pth.name); faces.append(f'@font-face{{font-family:"{fam}";src:url("{pth.name}");}}')
            return (f"'{fam}'", 400, "normal")
        return FONT_CSS.get(k, FONT_CSS["h"])
    els = []; fels = []      # fels: text that stays IN FRONT of the cut-out of you, rendered as its own layer over it (front.webm)
    bspans = [(a, b) for a, b, _ in behind_spans(st)]
    def over_cut(a, b): return any(min(b, y) - max(a, x) > .02 for x, y in bspans)
    def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    def styled(c, S=None):       # per-word styles from the editor: serif, a color; a highlighted word takes its screen's look (2026-10-23)
        ws = c.get("ws") or {}
        if not ws: return esc(c["text"])
        out = []; H = (S or {}).get("hl") or {}
        for i, w in enumerate(c["text"].split(" ")):
            x = ws.get(str(i)) or ws.get(i) or {}
            if x.get("hl"): x = {**{k: H[k] for k in ("font", "b", "it", "color", "sz", "fb", "kase", "smc", "ls") if H.get(k) is not None}, **{k: v for k, v in x.items() if k != "hl" and v is not None}}
            st_ = ""      # same rules as the editor's wordCss(): serif, else a font; then bold, italic, color
            if x.get("serif"): st_ += "font-family:'Instrument Serif';font-weight:400;font-style:italic;letter-spacing:-.01em;"
            elif x.get("font") in FONT_CSS or str(x.get("font") or "").startswith(("sys:", "file:")): fa, wt_, sy_ = font_css(x["font"]); st_ += f"font-family:{fa};font-weight:{wt_};font-style:{sy_};"
            if x.get("b") is not None: st_ += f"font-weight:{900 if x['b'] else 400};"
            if x.get("it") is not None: st_ += f"font-style:{'italic' if x['it'] else 'normal'};"
            if x.get("color"): st_ += f"color:{x['color']};"
            if x.get("sz") and float(x["sz"]) != 100: st_ += f"font-size:{float(x['sz']):.0f}%;"
            if x.get("fb"): st_ += f"-webkit-text-stroke:.025em {x.get('color') or (S or {}).get('color') or '#FFFFFF'};paint-order:stroke fill;"      # the Highlight word's own Font row (2026-10-24)
            if x.get("kase") == "upper": st_ += "text-transform:uppercase;"
            if x.get("smc"): st_ += "font-variant:small-caps;"
            if x.get("ls") is not None: st_ += f"letter-spacing:{float(x['ls'])}em;"
            st_ = st_.replace('"', "'")
            out.append(f"<span style=\"{st_}\">{esc(w)}</span>" if st_ else esc(w))
        return " ".join(out)
    for i, g in enumerate(st.get("BG", [])):
        S = scr(st, g["screen"]); S = {**S, **g["st"]} if g.get("st") else S      # a color block's own color
        if S.get("kind") != "color" or g.get("inpic"): continue      # (a color screen behind a box is in the picture already)
        els.append(f'<div id="bg{i}" class="clip plate" data-start="{g["t0"]:.4f}" data-duration="{g["t1"]-g["t0"]:.4f}" '
                   f'data-track-index="1" style="background:{S["bg"]}"></div>')
    # SCREEN TITLES (2026-10-24, the editor's titleDraw): every text a screen has (S.titles), styled exactly like a caption, up for as
    # long as the screen is
    def text_div(S, text, a0, b0, eid, track):
        fam, wt, sty = font_css(S.get("font", "h"))
        if S.get("b") is False: wt = 400
        if S.get("it"): sty = "italic"
        size = float(S.get("size", 96)) / basis * W
        ls = f"{float(S['ls'])}em" if S.get("ls") is not None else ("-.08em" if float(S.get("size", 96)) >= 110 else "-.04em")
        tt_ = {"lower": "lowercase", "upper": "uppercase"}.get(S.get("kase"), "none")
        top = {"top": "18%", "bottom": "82%"}.get(S.get("v"), "50%")
        nx = f" translate({float(S.get('ox', 0)) / basis * W:.1f}px,{float(S.get('oy', 0)) / basis * W:.1f}px)"
        if S.get("h") == "left": pos = f"left:8.3%;top:{top};transform:translateY(-50%){nx}"
        elif S.get("h") == "right": pos = f"right:8.3%;top:{top};transform:translateY(-50%){nx}"
        else: pos = f"left:50%;top:{top};transform:translate(-50%,-50%){nx}"
        k = 45 if S.get("shadow") is True else float(S.get("shadow") or 0)
        shadow = f"text-shadow:0 {.02 + k * .0004:.3f}em {.12 + k * .002:.3f}em rgba(0,0,0,{min(.95, k / 100):.2f});" if k else ""
        op = float(S["op"]) if S.get("op") is not None else 100.0
        return (f'<div id="{eid}" class="clip cap" data-start="{a0:.4f}" data-duration="{b0 - a0:.4f}" data-track-index="{track}" style="position:absolute;'
                f'font-family:{fam};font-weight:{wt};font-style:{sty};font-size:{size:.1f}px;letter-spacing:{ls};text-transform:{tt_};color:{S.get("color", "#FFFFFF")};'
                f'{pos};{shadow}' + (f"opacity:{op / 100:.3f};" if op < 100 else "") + text_fx_css(S, False) + f'">{esc(text)}</div>')
    tedges = sorted({0.0, st["DUR"], *[x for L in ("BG", "BR", "SEGS") for o in st.get(L, []) for x in (o["t0"], o["t1"])]}); tspans = []
    for a0, b0 in zip(tedges, tedges[1:]):
        if b0 - a0 < 1e-3: continue
        Sx = screen_at(st, (a0 + b0) / 2); T = [x for x in (Sx.get("titles") or []) if x.get("text")]
        if Sx.get("title", {}).get("text"): T = T + [{"text": Sx["title"]["text"], "size": Sx["title"].get("size", 64), "color": Sx["title"].get("color", "#FFFFFF"), "v": "top"}]      # an older single title
        if not T: continue
        if tspans and tspans[-1][2] == T and abs(tspans[-1][1] - a0) < 1e-3: tspans[-1][1] = b0
        else: tspans.append([a0, b0, T])
    for k, (a0, b0, T) in enumerate(tspans):
        for q, x in enumerate(T): els.append(text_div(x, x["text"], a0, b0, f"st{k}_{q}", 3))
    # a screen's text (S.text, 2026-10-24): the same object as a Text-track text, drawn by the TEXT LAYERS code below for as long as
    # its screen is up
    sblocks = []
    for a0, b0 in zip(tedges, tedges[1:]):
        if b0 - a0 < 1e-3: continue
        Sx = screen_at(st, (a0 + b0) / 2); X = Sx.get("text") or {}
        if not X.get("lines"): continue
        if sblocks and sblocks[-1]["lines"] is X["lines"] and abs(sblocks[-1]["t1"] - a0) < 1e-3: sblocks[-1]["t1"] = b0
        else: sblocks.append({"t0": a0, "t1": b0, "lines": X["lines"]})
    fx_spans = [(x["t0"], x["t1"]) for x in st.get("FX", []) if x.get("hide_captions", True) and x.get("blend") != "screen"]
    # where the screen can change (B-roll, backgrounds, A-roll pieces): a caption that runs across one is split there, each part in
    # the look of the screen it is over, so the picture cut and the caption style change land on the same frame (the editor's preview
    # already did this; the export used the caption's first screen for all of it, so a big B-roll caption carried onto the A-roll)
    edges = sorted({x for L in ("BG", "BR", "SEGS") for o in st.get(L, []) for x in (o["t0"], o["t1"])})
    for i, c in enumerate(chunks(st)):
        if c["hide"] or not c["text"].strip(): continue
        cuts = [c["t0"]] + [e for e in edges if c["t0"] + 1e-3 < e < c["t1"] - 1e-3] + [c["t1"]]
        for pi, (pa, pb) in enumerate(zip(cuts, cuts[1:])):
            if any(a <= pa < b for a, b in fx_spans): continue      # captions step aside while an effect is up
            S = {**screen_at(st, pa + .01), **(c.get("st") or {})}      # a caption's own Text settings win over its screen's
            op = float(S["op"]) if S.get("op") is not None else 100.0      # Opacity (2026-10-23): 0 = no captions there
            if op <= 0: continue
            fam, wt, sty = FONT_CSS["s"] if c["serif"] else font_css(S.get("font", "h"))
            b_ = c.get("cb") if c.get("cb") is not None else S.get("b")       # Bold off = regular weight (caption first, then its screen)
            it_ = c.get("cit") if c.get("cit") is not None else S.get("it")
            if b_ is False and not c["serif"]: wt = 400
            if it_: sty = "italic"
            ta_ = c.get("cta") or S.get("ta")
            size = S["size"] / basis * W
            ls = f"{float(S['ls'])}em" if S.get("ls") is not None else ("-.01em" if c["serif"] or S.get("kase") == "upper" or S.get("smc") else ("-.08em" if S["size"] >= 110 else "-.04em"))      # caps: no tight default (2026-10-24)
            tt = {"lower": "lowercase", "upper": "uppercase"}.get(S.get("kase"), "none")
            top = {"top": "18%", "bottom": "82%"}.get(S.get("v"), "50%")
            nx = f" translate({float(S.get('ox', 0)) / basis * W:.1f}px,{float(S.get('oy', 0)) / basis * W:.1f}px)" + rot_scale(S)   # the Nudge sliders, Rotation, Scale
            fr_ = next((o for o in st["FRAMES"] if o["t0"] <= pa < o["t1"]), None)
            G_ = frame_geom(fr_["frame"], W, H, fr_.get("border")) if fr_ else {"x": 0, "w": W}      # under a frame: inside the picture
            lx, rx = (G_["x"] + .083 * G_["w"]) / W * 100, (W - G_["x"] - G_["w"] + .083 * G_["w"]) / W * 100
            if S.get("h") == "left": pos = f"left:{lx:.3f}%;top:{top};transform:translateY(-50%){nx}"
            elif S.get("h") == "right": pos = f"right:{rx:.3f}%;top:{top};transform:translateY(-50%){nx}"
            else: pos = f"left:50%;top:{top};transform:translate(-50%,-50%){nx}"
            shadow = cap_shadow(S) + ("font-variant:small-caps;" if S.get("smc") else "")      # the text window's Shadow (angle, distance, blur, color), same maths as the editor
            two = S.get("mode") == "chars" and S.get("lines") == 2      # "2 lines": wraps, balanced, like the editor
            lh_ = f"{float(S['lh']) / 100}" if float(S.get("lh") or 0) > 0 else "1.04"      # Leading
            wrap = (f"white-space:normal;width:{84 if S.get('h', 'center') == 'center' else 72}%;text-wrap:balance;line-height:{lh_};"
                    f"text-align:{S.get('h', 'center')};") if two else ""
            if not wrap and float(S.get("lh") or 0) > 0: wrap = f"line-height:{lh_};"
            if float(S.get("wbox") or 0) > 0:      # a width dragged with the box's handles: the words wrap inside it
                wrap = f"white-space:normal;width:{float(S['wbox']):.2f}%;text-wrap:balance;line-height:{lh_};text-align:{S.get('h', 'center')};"
            (fels if not c["behind"] and over_cut(pa, pb) else els).append(f'<div id="c{i}_{pi}" class="clip cap" data-start="{pa:.4f}" data-duration="{max(.02, pb - pa):.4f}" '
                       f'data-track-index="2" style="font-family:{fam};font-weight:{wt};font-style:{sty};font-size:{size:.1f}px;'
                       f'letter-spacing:{ls};text-transform:{tt};color:{"transparent" if S.get("nofill") else S["color"]};{pos};{shadow}{wrap}' + (f"opacity:{op / 100:.3f};" if op < 100 else "") + (f"text-align:{ta_};" if ta_ else "") + text_fx_css(S, two) + f'">{styled(c, S)}</div>')
    # TEXT LAYERS (the Text track, 2026-10-22 night): one element per visible layer, each with its own place, width, align, look,
    # Background and shadow. The same CSS as the editor's textDraw() / lineCss() / tbPlace() / shadowCss()
    SW = rule_swaps()
    def shadow_css(S):
        k = 45 if S.get("shadow") is True else float(S.get("shadow") or 0)
        if not k: return ""
        if any(S.get(x) is not None for x in ("sha", "shd", "shb")):
            an = math.radians(float(S["sha"]) if S.get("sha") is not None else 180); d = (float(S["shd"]) if S.get("shd") is not None else 4) / 100
            bl = (float(S["shb"]) if S.get("shb") is not None else 21) / 100
            return f"text-shadow:{d * math.sin(an):.3f}em {-d * math.cos(an):.3f}em {bl:.3f}em {rgba_of(S.get('shc') or '#000000', min(.95, k / 100))};"
        return f"text-shadow:0 {.02 + k * .0004:.3f}em {.12 + k * .002:.3f}em {rgba_of(S.get('shc') or '#000000', min(.95, k / 100))};"
    def line_css(S):
        fam, wt, sty = font_css(S.get("font", "h")); sz = float(S.get("size") or 72)
        if S.get("b") is False: wt = 400
        if S.get("it"): sty = "italic"
        return (f"font-family:{fam};font-weight:{wt};font-style:{sty};font-size:{sz / basis * W:.1f}px;color:{'transparent' if S.get('nofill') else (S.get('color') or '#fff')};"
                f"letter-spacing:{(str(float(S['ls'])) + 'em') if S.get('ls') is not None else ('-.01em' if S.get('kase') == 'upper' or S.get('smc') else ('-.08em' if sz >= 110 else '-.04em'))};"
                f"text-transform:{ {'lower': 'lowercase', 'upper': 'uppercase'}.get(S.get('kase'), 'none') };line-height:{float(S.get('lh') or 108) / 100};text-wrap:balance;"
                + ("font-variant:small-caps;" if S.get("smc") else "") + (f"opacity:{max(0, float(S['op'])) / 100:.3f};" if S.get("op") is not None and float(S["op"]) < 100 else "")
                + shadow_css(S) + text_fx_css(S, hug=True))
    if st.get("KIND") != "carousel":
        for k, h in enumerate(list(st.get("HK") or []) + sblocks):
            for j, l in enumerate(h.get("lines") or []):
                if l.get("hide") or not (l.get("text") or "").strip(): continue
                S = {"font": "h", "size": 72, "color": "#FFFFFF", "shadow": 45, "v": "top", "h": "center", "ox": 0, "oy": 0, **(l.get("st") or {})}
                top = {"top": "18%", "bottom": "82%"}.get(S.get("v"), "50%")
                nx = f" translate({float(S.get('ox') or 0) / basis * W:.1f}px,{float(S.get('oy') or 0) / basis * W:.1f}px)" + rot_scale(S)
                if S.get("h") == "left": pos = f"left:8.3%;top:{top};transform:translateY(-50%){nx}"
                elif S.get("h") == "right": pos = f"right:8.3%;top:{top};transform:translateY(-50%){nx}"
                else: pos = f"left:50%;top:{top};transform:translate(-50%,-50%){nx}"
                wb = float(S.get("wbox") or 0)
                place = f"text-align:{S.get('ta') or S.get('h') or 'center'};" + (f"width:{wb:.2f}%;white-space:pre-line;" if wb > 0 else "white-space:pre;")      # pre: Enter's line breaks show
                h0, h1 = float(h["t0"]), float(h["t1"])      # a text layer in front of the cut-out: its clip has Text layers off
                front = over_cut(h0, h1) and not any(min(h1, sg["t1"]) - max(h0, sg["t0"]) > .05 and (lambda Sx: Sx.get("behind") and Sx.get("behindText") is not False)(screen_at(st, (max(h0, sg["t0"]) + min(h1, sg["t1"])) / 2)) for sg in st.get("SEGS", []))
                (fels if front else els).append(f'<div id="txt{k}_{j}" class="clip cap" data-start="{float(h["t0"]):.4f}" data-duration="{max(.05, float(h["t1"]) - float(h["t0"])):.4f}" data-track-index="3" '
                           f'style="{line_css(S)}{pos};{place}">' + (hug_html(S, esc(swap_words(l["text"], SW))) if S.get("box") else esc(swap_words(l["text"], SW))) + '</div>')
    # Carousel slides: each A-roll piece is a slide. Its look = the template (CTPL) with the slide's own tweaks (slide.st), the same
    # maths as the editor's carPaint(): sizes are px at a 1440 px wide slide, so everything scales with the width
    import re as _re
    CB = {"font": "h", "size": 95, "color": "#FFFFFF", "v": "middle", "h": "left", "ox": 0, "oy": 0, "shadow": 0, "kase": "none"}
    tpls = {t["id"]: t for t in st.get("CTPL") or []}
    def sl_serif(x): return _re.sub(r"`([^`]+)`", r"<span style=\"font-family:'Instrument Serif';font-style:italic;font-weight:400;letter-spacing:-.01em\">\1</span>", esc(x))
    for i, sg in enumerate(st["SEGS"]):
        sl = sg.get("slide")
        if not sl: continue
        S = {**CB, **(tpls.get(sl.get("tpl")) or (list(tpls.values())[0] if tpls else {})), **(sl.get("st") or {})}
        u = W / 1440; sz = float(S.get("size") or 95); fam, wt, sty = font_css(S.get("font", "h"))
        if S.get("b") is False: wt = 400
        if S.get("it"): sty = "italic"
        ta = S.get("ta") or {"center": "center", "right": "right"}.get(S.get("h"), "left")
        k = float(S.get("shadow") or 0)
        sh = f"text-shadow:0 {.02 + k * .0004:.3f}em {.12 + k * .002:.3f}em rgba(0,0,0,{min(.95, k / 100):.2f});" if k else ""
        tt = {"upper": "uppercase", "lower": "lowercase"}.get(S.get("kase"), "none")
        def ls(d): return f"{S['ls'] if S.get('ls') is not None else d}em"
        ox, oy = float(S.get("ox") or 0) * u, float(S.get("oy") or 0) * u
        vpos = f"bottom:{.10 * H - oy:.1f}px" if S.get("v") == "bottom" else f"top:{(.10 if S.get('v') == 'top' else .323) * H + oy:.1f}px"
        body = ""
        for ln in [x.strip() for x in str(sl.get("body") or "").split("\n") if x.strip()]:
            if _re.match(r"^[-•→]\s*", ln): ln = "→ " + _re.sub(r"^[-•→]\s*", "", ln)
            body += f'<p style="margin:0 0 .25em">{sl_serif(ln)}</p>'
        box = sl.get("box") or {}
        al = "margin-left:auto;margin-right:auto;" if ta == "center" else "margin-left:auto;" if ta == "right" else ""
        def tr(k): o = box.get(k) or {}; return (f"width:{float(o['w']) * u:.1f}px;max-width:none;" if float(o.get("w") or 0) > 0 else "width:fit-content;max-width:100%;") + f"{al}transform:translate({float(o.get('ox') or 0) * u:.1f}px,{float(o.get('oy') or 0) * u:.1f}px);"
        hh = ""
        if sl.get("eyebrow"):
            hh += (f'<div style="{tr("eyebrow")}font-family:\'Instrument Serif\';font-style:italic;font-weight:400;font-size:{sz * 49 / 95 * u:.1f}px;'
                   f'letter-spacing:-.02em;line-height:1.1;margin-bottom:{sz * 27 / 95 * u:.1f}px">{sl_serif(sl["eyebrow"])}</div>')
        hh += f'<div style="{tr("head")}font-family:{fam};font-weight:{wt};font-style:{sty};font-size:{sz * u:.1f}px;line-height:.947;letter-spacing:{ls(-.07)}">{sl_serif(sl.get("head", ""))}</div>'
        if body:
            hh += (f'<div style="{tr("body")}font-family:{fam};font-weight:{wt};font-style:{sty};font-size:{sz * 42 / 95 * u:.1f}px;line-height:1.19;'
                   f'letter-spacing:{ls(-.04)};margin-top:{sz * 27 / 95 * u:.1f}px">{body}</div>')
        d_ = sg["t1"] - sg["t0"]; a_ = max(0, min(d_ - .1, float(sl.get("tin") or 0)))      # the text's in/out inside its slide (dragged in the editor)
        b_ = max(a_ + .1, min(d_, float(sl["tout"]))) if sl.get("tout") is not None else d_
        els.append(f'<div id="sl{i}" class="clip" data-start="{sg["t0"] + a_:.4f}" data-duration="{b_ - a_:.4f}" data-track-index="4" '
                   f'style="position:absolute;left:{81 * u + ox:.1f}px;right:{81 * u - ox:.1f}px;{vpos};color:{S.get("color") or "#fff"};'
                   f'text-align:{ta};text-transform:{tt};{sh}white-space:normal">{hh}</div>')
        for j, x in enumerate(sl.get("extra") or []):      # added text boxes: anywhere on the slide
            els.append(f'<div id="sx{i}_{j}" class="clip" data-start="{sg["t0"]:.4f}" data-duration="{sg["t1"] - sg["t0"]:.4f}" data-track-index="5" '
                       f'style="position:absolute;left:{(81 + float(x.get("ox") or 0)) * u:.1f}px;top:{.5 * H + float(x.get("oy") or 0) * u:.1f}px;' + (f'width:{float(x["w"]) * u:.1f}px;' if float(x.get("w") or 0) > 0 else f'max-width:{.8875 * W:.1f}px;') +
                       f'color:{x.get("color") or S.get("color") or "#fff"};font-family:{fam};font-weight:{400 if x.get("b") is False else wt};font-style:{sty};'
                       f'font-size:{float(x.get("size") or 42) * u:.1f}px;line-height:1.15;letter-spacing:{ls(-.04)};white-space:pre-wrap;text-transform:{tt};{sh}">{sl_serif(x.get("text", ""))}</div>')
    # Ease-in zoom titles: Instrument Serif italic, small, placed at their settled spot and scaled with the shot (k / settled k)
    # about the frame center; the same ease-out and speed as the picture (rideK in the editor)
    rjs = ""
    for i, m in enumerate(sorted((x for x in st.get("MOVES", []) if x.get("ride") and x.get("title")), key=lambda x: x["t0"])):
        own = (m.get("zl") or "all") in ("aroll", "broll")      # "all" / "color": the whole-frame zoom already scales the title
        fam, wt, sty = FONT_CSS["s"]; top = float(m.get("ty", .17)) * H; d = max(.05, m["t1"] - m["t0"]); st_ = max(.1, float(m.get("settle", 2.47)))
        k0 = float(m.get("s0", 1.73)) / float(m.get("s", 1.2))
        els.append(f'<div id="ride{i}" class="clip ride" data-start="{m["t0"]:.4f}" data-duration="{d:.4f}" data-track-index="3" style="position:absolute;left:0;width:{W}px;top:{top:.1f}px;'
                   f'text-align:center;color:#fff;font-family:{fam};font-weight:{wt};font-style:{sty};font-size:{float(m.get("tsize", .04)) * W:.1f}px;line-height:1.05;'
                   f'padding:0 {W * .10:.0f}px;box-sizing:border-box;text-shadow:0 2px 14px rgba(0,0,0,.3);transform-origin:50% {H / 2 - top:.1f}px">{esc(m["title"])}</div>')
        if own: rjs += (f'window.__timelines["gfx"].fromTo("#ride{i}",{{scale:{k0:.4f}}},{{scale:1,duration:{min(st_, d):.4f},'
                f'ease:function(q){{return 1-Math.pow(1-q,4);}}}},{m["t0"]:.4f});')
    def page(E, js):
        return f"""<!doctype html><html><head><meta charset="utf-8"><style>
{''.join(faces)}
html,body{{margin:0;background:transparent}}
#root{{position:relative;width:100%;height:100%;overflow:hidden;background:transparent}}
.plate{{position:absolute;inset:0}}
.cap{{position:absolute;white-space:nowrap;line-height:1}}
</style></head><body>
<div id="root" data-composition-id="gfx" data-start="0" data-width="{W}" data-height="{H}" data-duration="{st['DUR']:.3f}" data-fps="{FPS_NUM}/{FPS_DEN}">
{chr(10).join(E)}
</div>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
<script>window.__timelines["gfx"] = gsap.timeline({{paused: true}});{js}</script>
</body></html>"""
    def render(E, js, name):
        (P/"index.html").write_text(page(E, js))
        r = subprocess.run([plat.NPX, "--yes", "hyperframes", "render", "--format", "webm", "--quality", "looks", "--fps", f"{FPS_NUM}/{FPS_DEN}",      # the video's own 23.976: at a flat 24 the
                            # captions drifted 0.1% behind the picture (1 frame late by 35 s, 3 by 2 min), so they changed after the cut
                            "--output", str(D/name)], cwd=P, capture_output=True, text=True)
        if r.returncode or not (D/name).exists():
            raise RuntimeError("HyperFrames render failed: " + (r.stderr or r.stdout)[-1200:])
    (D/"front.webm").unlink(missing_ok=True)
    render(els, rjs, "graphics.webm")
    if fels:      # only when a clip puts some text behind you and keeps other text in front (2026-10-25)
        print(f"  {len(fels)} text piece(s) stay in front of the cut-out: rendering them as their own layer", flush=True)
        render(fels, "", "front.webm")

def audio(st, src, D, soft):
    """the A-roll's sound with a crossfade at every cut (soft cuts, 2 frames by default: each piece runs a frame into the
    take on either side, fading, and the two overlap at the cut), the music bed ducked under the voice, sound effects, -14 LUFS"""
    xf = float(st.get("AUDIO_XF", 2)) * FPS_DEN / FPS_NUM if soft else 0.0      # crossfade length in seconds
    total = sum(s["nf"] for s in st["SEGS"]) * 2002
    parts, pos = [], 0
    # (2026-10-25, Gabe heard the previous line bleed in at cuts) no handles: each piece's sound is ONLY its own stretch of the take,
    # never the audio the cut left out either side. A 12 ms fade at each end keeps the cut click-free (Premiere's cross-dissolve needs
    # handles, and handles are exactly that cut-out audio). Pieces butt end to end, so the sound stays on the picture's frames
    xf = 0.0
    for s in st["SEGS"]:
        ns = s["nf"] * 2002; dur = ns / 48000; h = xf / 2
        pre = min(h, s["src_in"]); a0 = s["src_in"] - pre; L = dur + pre + h
        f = D/f"s{s['n']:03d}.wav"
        fd = 0.012
        run(["ffmpeg", "-v", "error", "-y", "-ss", f"{a0:.4f}", "-t", f"{L + 0.2:.3f}", "-i", src, "-vn", "-ac", "2", "-ar", "48000",
             "-af", f"apad,atrim=end_sample={int(round(L * 48000))},afade=t=in:d={fd:.4f},afade=t=out:st={max(0, L - fd):.4f}:d={fd:.4f}", f])
        parts.append((f, max(0, pos - int(round(pre * 48000))))); pos += ns
    ins = []
    for f, at_ in parts: ins += ["-i", f]
    g = ";".join(f"[{i}:a]adelay={at_}S:all=1[d{i}]" for i, (f, at_) in enumerate(parts))
    g += ";" + "".join(f"[d{i}]" for i in range(len(parts))) + f"amix=inputs={len(parts)}:normalize=0:duration=longest,apad,atrim=end_sample={total}[v]"
    (D/"xf.txt").write_text(g)
    run(["ffmpeg", "-v", "error", "-y", *ins, "-/filter_complex", D/"xf.txt", "-map", "[v]", "-ar", "48000", "-ac", "2", D/"voice.wav"])
    inputs, graph, mix = [D/"voice.wav"], [], ["[0:a]"]
    # the voice is "talking" wherever words are; the bed sits 14 dB under it there and 8 dB under it in gaps
    talk = []      # the editor's talkingAt(): from 0.15 s before a word to 0.25 s after it
    for w in st["WORDS"]:
        a, b = w[0] - .15, w[1] + .25
        if talk and a <= talk[-1][1]: talk[-1][1] = max(talk[-1][1], b)
        else: talk.append([a, b])
    for i, m in enumerate(st.get("MUSIC", []), 1):
        p = pathlib.Path(m["file"])
        if not p.exists(): continue
        inputs.append(p); n = len(inputs) - 1; dur = m["t1"] - m["t0"]
        base = float(m.get("gain_db", -20))
        # the level you hear in the editor (2026-10-25: the export was 9.5 dB quieter): the preview plays a song at 3x its slider
        # gain, half that under your voice (MUS.volume in tick()), so the export does the same, capped where the preview caps it
        lvl = min(1.0, 3 * 10 ** (base / 20))
        duck = "+".join(f"between(t,{a + m['t0'] * 0:.3f},{b:.3f})" for a, b in talk if b > m["t0"] and a < m["t1"]) or "0"
        graph.append(f"[{n}:a]aloop=loop=-1:size=2e9,atrim=duration={dur:.3f},asetpts=PTS-STARTPTS,"
                     f"afade=t=in:d=0.6,afade=t=out:st={max(0, dur - 1.2):.3f}:d=1.2,adelay={int(m['t0']*1000)}|{int(m['t0']*1000)},"
                     f"volume='{lvl:.4f}*if(gt({duck},0),0.5,1)':eval=frame[m{i}]")
        mix.append(f"[m{i}]")
    for i, x in enumerate(st.get("SFX", []), 1):
        p = pathlib.Path(x["file"])
        if not p.exists(): continue
        inputs.append(p); n = len(inputs) - 1
        graph.append(f"[{n}:a]adelay={int(x['t0']*1000)}|{int(x['t0']*1000)},volume={10**(float(x.get('gain_db',-6))/20):.4f}[x{i}]")
        mix.append(f"[x{i}]")
    if len(mix) > 1:      # music + sound effects mixed ONCE, then split: one copy is A2 in the Premiere XML, one goes under the voice.
        # (Each [m1]/[x1] used to be named in both mixes; a filter output can feed only one input, so ffmpeg gave them all
        # to the bed and the MP4 came out voice only.)
        bed = mix[1:]
        graph.append(f"anullsrc=r=48000:cl=stereo,atrim=duration={st['DUR']:.3f}[sil]")
        graph.append(f"[sil]{''.join(bed)}amix=inputs={len(bed)+1}:normalize=0:duration=first,asplit=2[bedout][bedmix]")
        mix = ["[0:a]", "[bedmix]"]
    graph.append(f"{''.join(mix)}amix=inputs={len(mix)}:normalize=0:duration=first,loudnorm=I=-14:TP=-1.5:LRA=11[out]")
    args = ["ffmpeg", "-v", "error", "-y"]
    for p in inputs: args += ["-i", p]
    (D/"agraph.txt").write_text(";\n".join(graph))
    extra = ["-map", "[bedout]", "-ar", "48000", D/"bed.wav"] if len(mix) > 1 else []
    if not extra: (D/"bed.wav").unlink(missing_ok=True)
    run(args + ["-/filter_complex", D/"agraph.txt", "-map", "[out]", "-ar", "48000", D/"mix.wav"] + extra)

# ------------------------------------------------------------------ Premiere XML (FCP7 xmeml), built on a finished export
def xml(job, fmt, dest=None):
    import urllib.parse
    J = PROJECTS/job; st = load(job, fmt); stem, src = source_of(J)
    for k in ("FX", "MOVES"): st[k] = [o for o in st.get(k, []) if not o.get("fmt") or o["fmt"] == fmt]
    W, H = FORMATS[fmt]; D = J/"build/export"/fmt
    if not (D/"overlay_4444.mov").exists(): sys.exit("export this format first: the XML points at its graphics layer")
    FPS = FPS_NUM / FPS_DEN; fr = lambda s: int(math.floor(s * FPS + .5 + 1e-6))      # half up: edges sit half a frame before their frame (one_clock)
    from xml.sax.saxutils import escape as xesc      # R13: a file called B&W.mp4 made Premiere refuse the XML
    url = lambda p: "file://localhost/" + urllib.parse.quote(pathlib.Path(p).as_posix().lstrip("/"), safe="/:")      # Mac: file://localhost/Users/…; Windows: file://localhost/C:/Users/…
    def dims(p):
        o = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", p]).strip().split(",")
        return int(o[0]), int(o[1])
    def dur(p):
        if str(p).lower().endswith((".png", ".jpg", ".jpeg", ".webp")): return 3600.0      # a still: as long as it needs to be
        try: return float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p]).strip() or 0)
        except ValueError: return 0.0
    rate = "<rate><timebase>24</timebase><ntsc>TRUE</ntsc></rate>"
    files = {}
    def fileref(p, audio_only=False, alpha=False):
        p = str(p)
        if p in files: return f'<file id="f{files[p]}"/>'
        files[p] = len(files) + 1; i = files[p]; d = fr(dur(p))
        media = "<audio><channelcount>2</channelcount></audio>" if audio_only else (
            f"<video><samplecharacteristics>{rate}<width>{dims(p)[0]}</width><height>{dims(p)[1]}</height>"
            f"{'<alpha>straight</alpha>' if alpha else ''}</samplecharacteristics></video><audio><channelcount>2</channelcount></audio>")
        return (f'<file id="f{i}"><name>{xesc(pathlib.Path(p).name)}</name><pathurl>{xesc(url(p))}</pathurl>{rate}<duration>{d}</duration>'
                f"<media>{media}</media></file>")
    def motion(scale, ch=0.0, cv=0.0):
        return ('<filter><effect><name>Basic Motion</name><effectid>basic</effectid><effectcategory>motion</effectcategory>'
                '<effecttype>motion</effecttype><mediatype>video</mediatype>'
                f'<parameter><parameterid>scale</parameterid><name>Scale</name><value>{scale:.2f}</value></parameter>'
                f'<parameter><parameterid>center</parameterid><name>Center</name><value><horiz>{ch:.4f}</horiz><vert>{cv:.4f}</vert></value></parameter>'
                '</effect></filter>')
    def clip(cid, name, p, start, end, cin, cout, extra="", audio_only=False, alpha=False, link=None):
        lk = "".join(f"<link><linkclipref>{l}</linkclipref></link>" for l in (link or []))
        return (f'<clipitem id="{cid}"><name>{xesc(str(name))}</name><enabled>TRUE</enabled>{rate}<start>{start}</start><end>{end}</end>'
                f"<in>{cin}</in><out>{cout}</out>{fileref(p, audio_only, alpha)}{extra}{lk}</clipitem>")
    sw, sh = dims(src)
    rot = run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream_side_data=rotation", "-of", "csv=p=0", src]).strip()
    if rot and abs(int(float(rot.split(",")[0]))) in (90, 270): sw, sh = sh, sw
    v1, a1, t = [], [], 0
    for s in st["SEGS"]:
        a = fr(s["src_in"]); n = s["nf"]; b = a + n
        sc = max(W / sw, H / sh) * 100; iw = sw * sc / 100
        if fmt == "169" and sw / sh >= W / H - .01: ch = 0.0
        else:
            cx = float(st.get("REFRAME", {}).get(fmt, {}).get(str(key100(s["src_in"])), face_x(st, s)))
            off = max(W - iw, min(0, W / 2 - cx * iw)); ch = (off + iw / 2 - W / 2) / W
        v1.append(clip(f"v1-{s['n']}", f"A-roll {s['n']}", src, t, t + n, a, b, motion(sc, ch), link=[f"v1-{s['n']}", f"a1-{s['n']}"]))
        a1.append(clip(f"a1-{s['n']}", f"A-roll {s['n']}", src, t, t + n, a, b, link=[f"v1-{s['n']}", f"a1-{s['n']}"]))
        t += n
    total = t; v2 = []
    for i, o in enumerate(sorted(st.get("BR", []), key=lambda o: o["t0"]), 1):
        p = pathlib.Path(o["clip"]) if pathlib.Path(o["clip"]).is_absolute() else pathlib.Path(broll_root())/o["clip"]
        if not p.exists(): continue
        cw, chh = dims(p); sc = max(W / cw, H / chh) * 100; cin = fr(float(o.get("in", 0)))
        v2.append(clip(f"v2-{i}", p.name, p, fr(o["t0"]), fr(o["t1"]), cin, cin + fr(o["t1"]) - fr(o["t0"]), motion(sc)))
    out = pathlib.Path(dest) if dest else PKG/"exports"/f"{job}-{fmt}{SUFFIX}.xml"
    gfx, bed = out.with_name(out.stem + "-graphics.mov"), out.with_name(out.stem + "-bed.wav")      # beside the XML (R13: build/export/<fmt> is overwritten by the next export)
    shutil.copy2(D/"overlay_4444.mov", gfx)
    if (D/"bed.wav").exists(): shutil.copy2(D/"bed.wav", bed)
    v3 = [clip("v3-1", "Screens, captions and effects", gfx, 0, total, 0, total, motion(100), alpha=True)]
    a2 = [clip("a2-1", "Music and sound effects", bed, 0, total, 0, total, audio_only=True)] if bed.exists() else []
    tr = lambda items: "<track>" + "".join(items) + "</track>"
    seq = (f'<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="5"><sequence id="seq"><name>{xesc(job)} {fmt}</name>'
           f"<duration>{total}</duration>{rate}<media><video><format><samplecharacteristics>{rate}<width>{W}</width><height>{H}</height>"
           f"<pixelaspectratio>square</pixelaspectratio></samplecharacteristics></format>{tr(v1)}{tr(v2)}{tr(v3)}</video>"
           f"<audio>{tr(a1)}{tr(a2) if a2 else ''}</audio></media></sequence></xmeml>")
    out.write_text(seq)
    print(f"  Premiere XML: {out} (shot moves are in the MP4; in Premiere they arrive flat)", flush=True)
    return out

if __name__ == "__main__":
    a = sys.argv[1:]
    if "--tl" in a: i = a.index("--tl"); TL_FILE = a[i + 1]; del a[i:i + 2]
    if "--suffix" in a: i = a.index("--suffix"); SUFFIX = a[i + 1]; del a[i:i + 2]
    if "--noxml" in a: NOXML = True; a.remove("--noxml")      # the export dialog's Premiere XML switch
    if len(a) >= 2 and a[0] == "prep": prep(a[1])
    elif len(a) >= 3 and a[0] == "export":
        export(a[1], a[2], "--4k" in a, a[a.index("--out") + 1] if "--out" in a else None)
    elif len(a) >= 3 and a[0] == "xml": xml(a[1], a[2])
    elif len(a) >= 3 and a[0] == "gradeproxy": print("DONE " + str(grade_proxy(a[1], a[2])), flush=True)
    elif len(a) >= 3 and a[0] == "cutouts":
        rs = json.loads(a[2])
        for i, r in enumerate(rs, 1):      # [in, out] of the take, or [in, out, source] for a B-roll clip (text behind subject on B-roll)
            x, y = r[0], r[1]; src = r[2] if len(r) > 2 else (a[3] if len(a) > 3 else None)
            print(f"{i}/{len(rs)} cutting out the subject in {x:.1f}-{y:.1f}s", flush=True); cutout(a[1], x, y, src)
        print("DONE cutouts", flush=True)
    else: sys.exit(__doc__)
