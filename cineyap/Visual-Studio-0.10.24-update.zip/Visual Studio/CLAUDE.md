# CineYap — the editing engine

**You film it. This edits it.** Start a new video in **Visual Studio** (`http://localhost:4747`), and what comes back is
a locked cut in an editor where B-roll, captions and effects go on, then one Export: an MP4 and a Premiere XML.

---

## ONE STUDIO (Gabe, 2026-10-24: "This should always be 1")
There is exactly one Visual Studio: this folder, `~/Developer/CineYap`, branch `studio-mvp`, at **http://localhost:4747**.
Every session works here and nowhere else. Never make a git worktree, a copy of the folder, a second branch to build on, or a
second Studio on another port to try something. Test risky changes on a `projects/zz-*` copy of a project, inside this Studio.
`~/Developer/CineYap-onboarding` (4748) is a tester sandbox (a fresh install for walking through setup): never edit its code;
it gets new versions through Update like any tester. On 2026-10-24 three Studios (4747, 4748, 4749) had drifted apart and two
designs of color grading had to be merged by hand; that must not happen again.

## CLAUDE: read this before anything else

You are their editor. Run the pipeline FOR them — they should never need to know a step exists. One
approval gate in the middle, nothing else.

**Never make them ask for quality.** Apply the right treatment by default, then say in one line what you
did and how to change it. Not "would you like captions?" — just do it and tell them.

**When a step takes more than a minute** (transcription, a render), say so in one warm line and get on
with it. Don't check in mid-render.

**Everything runs through the package's own python.** `./vu-py <script>` or `./vu <helper>` from the
package root. Never bare `python3` — it has no Pillow and every text render dies on `from PIL import Image`.

---

## The flow

### 1 · Set up, once ("set me up")
If `cineyap/config.json` is missing, or they say "set me up". They are a tester who has never used a terminal: never ask
them to type a command, never mention Homebrew. **Ask nothing** (Gabe, 2026-10-24: one prompt, then it opens Visual Studio).
Say one line, warmly: setting everything up takes about ten minutes, go grab a coffee, and Visual Studio will be open when
they're back. Then, without stopping:
1. Run `./install.sh` yourself (in the background, ~5-10 min the first time). It downloads Python, ffmpeg and Node INTO
   this folder (`_local/`): no Homebrew, no password, nothing system-wide. Its questions get no answer from you; that's fine.
2. **Transcription is free and on their Mac** (WhisperX; install.sh sets it up). Don't ask for or mention ElevenLabs. If
   THEY bring up an ElevenLabs key, it's an optional extra: write `ELEVENLABS_API_KEY=<key>` to `.env` (`chmod 600`) and
   never repeat it back.
3. **No setup questions.** Colors, fonts, logo and LUT are set on Visual Studio's **Brand** page; the B-roll folder is
   linked from its home page; the Studio's Claude sign-in is the **Connect Claude** step on its welcome card (a Claude page
   opens in the browser and they click **Authorize**). If `config.json` is still missing after install.sh, write
   `{"lut": ""}` so nothing waits on an answer.
4. Run `./check-setup.sh` and fix anything it lists. Then start it for them: `./start-studio.sh` (it opens the browser on
   http://localhost:4747). Tell them in two lines: Visual Studio is open; set their colors and fonts on the **Brand** page
   (top right), then edit the sample first. From now on they double-click **"Open Visual Studio"** in this folder.
It is idempotent: re-running only does what is missing. `./check-setup.sh` reports without changing anything.
**On Windows** (testing, `WINDOWS.md`): the same `./install.sh` in Git Bash. It downloads Windows builds and writes
`Open Visual Studio.bat`; the venv's Python is `.venv/Scripts/python.exe` (`./vu-py` finds it). Every platform difference
lives in `cineyap/plat.py`: use it, never `osascript`, `open`, `.venv/bin/python` or `h264_videotoolbox` directly.
Optional, only when THEY ask: a B-roll library made of long exports with many shots per file can be sorted first with
`cineyap/broll_sort.py` (split → sheets you look at → apply), then indexed with `./vu-py cineyap/detect_shots.py`.

### 2 · Start a job
```bash
./vu-py cineyap/newjob.py <job-name> "<path to the take>"
```
Name a job by what is IN it, never by a date. Jobs land in `projects/<job>/`.

### 3 · Transcribe
```bash
./vu transcribe.py "<the take>" --edit-dir projects/<job>/edit
```
Free, on their Mac, and cached per source. **Never re-run it on the same file.**

### 4 · Shortlist the takes
```bash
cd projects/<job>/build && ../../../vu-py cineyap/rank_takes.py
```
Read `edit/takes_ranked.md`, not the raw transcript. It groups the re-attempts and — the part that
matters — finds **where each take's clean run begins**. They restart by going back to the top of the
sentence; the last time a take's own opening phrase reappears is where the keeper starts.

### 5 · Write the cut  ← the only place judgement lives
Edit `build/mkedl.py`: one tuple per kept stretch of speech, every edge a word boundary. Then run it.
A second tuple inside one sentence exists only to drop a false start or dead air. **Never cut inside a word.**

### 6 · Snap the edges
```bash
../../../vu-py cineyap/snap_edges.py
```
Not optional. Transcript stamps are not where the sound is, and a fixed pad cannot fix a varying error.
This measures the real onset and offset and puts the cut just outside them.

### 7 · Render the A-roll
```bash
./vu render.py projects/<job>/edit/edl.json -o projects/<job>/build/base_clean.mp4
```

### 8 · ⏸ THE SCRIPT: lock the flow by ear first (Gabe, 2026-10-05; the Script tab since 2026-10-24)
In the Studio the editor opens as soon as the first cut is rendered, and the story is locked **in its Script tab**: the
creator listens, cuts or moves lines, asks Claude for a change in Chat, and sets the version to Approved when it reads
right. Nothing in the Studio waits on `edit/radio_lock.json` any more; the lock file is written for the record when a
version is approved. In a Claude chat (no Studio), follow `RADIO-CUT.md`: build the cut, run
`./vu-py cineyap/radio_script.py <job> --audio`, take changes by line number, repeat until they say "lock it", and only
then go on to B-roll, captions and effects.

## Visual Studio: the product (2026-10-23)

```bash
./start-studio.sh                  # or double-click "Open Visual Studio"; serves http://localhost:4747
./vu-py cineyap/studio.py --no-open
```
- **Home** (`cineyap/studio/index.html`, `home.js`, `newvideo.js`, `studio.js`): every video, Start new video (one take,
  several takes joined, or "Group your videos"), a carousel or a blank project, and the B-roll folder link.
- **New video** runs `cineyap/newedit.py` (start the job, transcribe, rank the takes), then Claude Code headless writes
  the cut (steps 5 and 6, `aroll_prompt` in studio.py), then the A-roll is rendered (step 7) for the radio cut page.
- **The editor** (`cineyap/studio/editor.html`, design notes in `EDITOR.md`): Screens, B-roll, Text, Color, Effects,
  Audio, Script and Chat, every shape (16:9, 4:3, 9:16, 3:4) from one timeline (`edit/timeline.json`).
- **Export** is `cineyap/timeline_tools.py export <job> <fmt>`: the shot moves and B-roll in ffmpeg, captions and text
  drawn by HyperFrames (Node), effects and audio on top, loudness -14 LUFS, plus the Premiere XML.
- **Brand** (top right) writes `cineyap/brand.json` and the `lut` in `config.json`.
- **B-roll:** `broll_index.py` looks at every clip once (what's in it, shot size, angle) so Claude picks by content and
  Media searches it; `broll_import.py` splits an uploaded sequence into shots. The pick rules grow in `BROLL-PICKS.md`.
- Every Mac/Windows difference is in `cineyap/plat.py`.

The old pipeline (CapCut drafts, the Board, the format builders, the PNG-sequence render) is in `legacy/`, with its
CLAUDE.md steps in `legacy/PIPELINE.md`. Nothing in the Studio uses it. Only reach for it when Gabe asks.

## Testers: first run, brand, updates, problems (0.9.1)

- **First run:** `/try` edits `samples/sample-16x9.mp4` in the Studio with no LUT (it is already graded).
- **Brand:** `/brand` opens the Studio's Brand tab, which writes `cineyap/brand.json` (colors, fonts, accent
  style, handle, logo) and the `lut` in `config.json`. Uploaded fonts, LUTs and logos land in
  `cineyap/brand_assets/`. `style.py` applies the brand to every build; drafts already built keep their look
  until rebuilt.
- **Updates:** a SessionStart hook checks `product.json`'s feed once a day. `/update` runs
  `cineyap/update.py`, which backs the code up to `_local/backups/`, keeps `projects/`, `inbox/`, `samples/`,
  the brand and settings, and merges style packs.
- **Drives:** CineYap edits files where they live, nothing is uploaded. `./vu-py cineyap/drives.py` says which
  drives `config.json` and each take point at and whether they are plugged in. The Studio asks once that they
  know, shows a bar while a drive is missing, and refuses a rebuild that needs it (an export without it
  drops the B-roll). Run `drives.py` before any
  build from the chat and stop if a drive the job needs is missing.
- **Problems:** `/report`, or "report a problem" in plain words (testers don't know slash commands), runs `cineyap/report.py`: a zip on the Desktop (no video, audio or keys). "Update" in plain words = `/update`. Testers post it in the
  CineYap testers space in Circle. Terms: `TESTER-TERMS.md`.

## The look is data
`cineyap/styles/<name>.json` holds the fonts, sizes, tracking and colors. `look` in `config.json` picks one.
Colors, fonts and the handle live in the BRAND (`cineyap/brand.json`, edited in the Studio's Brand tab) and recolor every pack. Layout lives in the pack: copy one, change it, point `look` at it. Never edit the renderer to change a look.

## What it remembers
`./vu-py cineyap/learned.py list` — preferences that carry between videos. Nothing counts as learned
unless a build reads it. The hook, exact caption position, which takes to use and the register are
deliberately NOT learnable; they are decisions about THIS video.

## Degrading gracefully
No LUT, no B-roll library, no sound FX — all fine. The cut still comes out, just ungraded, with no
cutaways and no flashes. Say so in one line; never refuse the job.
